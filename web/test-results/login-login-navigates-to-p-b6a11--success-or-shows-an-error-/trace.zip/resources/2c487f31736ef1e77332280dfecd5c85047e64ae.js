import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import "/src/App.css?t=1786627148598";
import LandingPage from "/src/pages/LandingPage.tsx?t=1786626172235";
import Header from "/src/components/Header.tsx?t=1786627141744";
import Footer from "/src/components/Footer.tsx";
import AuthPage from "/src/pages/AuthPage.tsx?t=1786626475007";
import ProductsPage from "/src/pages/ProductsPage.tsx";
import { Routes, Route, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=b02da74d";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
var _s = $RefreshSig$();
function App() {
	_s();
	const location = useLocation();
	const hideChrome = location.pathname === "/login" || location.pathname === "/signup";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-root",
		children: [
			!hideChrome && /* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 23
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "app-main",
				children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/",
						element: /* @__PURE__ */ _jsxDEV(LandingPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 36
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 21,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/login",
						element: /* @__PURE__ */ _jsxDEV(AuthPage, { initialMode: "login" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 41
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/signup",
						element: /* @__PURE__ */ _jsxDEV(AuthPage, { initialMode: "signup" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 42
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/products",
						element: /* @__PURE__ */ _jsxDEV(ProductsPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 44
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 7
			}, this),
			!hideChrome && /* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 23
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
}
_s(App, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
	return [useLocation];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx?t=1786627148598";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUVQLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sWUFBWTtBQUNuQixPQUFPLFlBQVk7QUFDbkIsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sa0JBQWtCO0FBRXpCLFNBQVMsUUFBUSxPQUFPLG1CQUFtQjs7OztBQUUzQyxTQUFTLE1BQU07O0NBQ2IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxhQUFhLFNBQVMsYUFBYSxZQUFZLFNBQVMsYUFBYTtDQUUzRSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRyxDQUFDLGNBQWMsd0JBQUMsUUFBRCxDQUFTOzs7OztHQUV6Qix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUNkLHdCQUFDLFFBQUQ7S0FDRSx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFJLFNBQVMsd0JBQUMsYUFBRCxDQUFjOzs7OztLQUFJOzs7OztLQUMzQyx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFTLFNBQVMsd0JBQUMsVUFBRCxFQUFVLGFBQVksUUFBUzs7Ozs7S0FBSTs7Ozs7S0FDakUsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBVSxTQUFTLHdCQUFDLFVBQUQsRUFBVSxhQUFZLFNBQVU7Ozs7O0tBQUk7Ozs7O0tBQ25FLHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQVksU0FBUyx3QkFBQyxjQUFELENBQWU7Ozs7O0tBQUk7Ozs7O0lBQzlDOzs7OztHQUNKOzs7OztHQUVMLENBQUMsY0FBYyx3QkFBQyxRQUFELENBQVM7Ozs7O0VBQ3RCOzs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuL0FwcC5jc3MnXG5cbmltcG9ydCBMYW5kaW5nUGFnZSBmcm9tICcuL3BhZ2VzL0xhbmRpbmdQYWdlJ1xuaW1wb3J0IEhlYWRlciBmcm9tICcuL2NvbXBvbmVudHMvSGVhZGVyJ1xuaW1wb3J0IEZvb3RlciBmcm9tICcuL2NvbXBvbmVudHMvRm9vdGVyJ1xuaW1wb3J0IEF1dGhQYWdlIGZyb20gJy4vcGFnZXMvQXV0aFBhZ2UnXG5pbXBvcnQgUHJvZHVjdHNQYWdlIGZyb20gJy4vcGFnZXMvUHJvZHVjdHNQYWdlJ1xuXG5pbXBvcnQgeyBSb3V0ZXMsIFJvdXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpXG4gIGNvbnN0IGhpZGVDaHJvbWUgPSBsb2NhdGlvbi5wYXRobmFtZSA9PT0gJy9sb2dpbicgfHwgbG9jYXRpb24ucGF0aG5hbWUgPT09ICcvc2lnbnVwJ1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhcHAtcm9vdFwiPlxuICAgICAgeyFoaWRlQ2hyb21lICYmIDxIZWFkZXIgLz59XG5cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImFwcC1tYWluXCI+XG4gICAgICAgIDxSb3V0ZXM+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PExhbmRpbmdQYWdlIC8+fSAvPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL2xvZ2luXCIgZWxlbWVudD17PEF1dGhQYWdlIGluaXRpYWxNb2RlPVwibG9naW5cIiAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9zaWdudXBcIiBlbGVtZW50PXs8QXV0aFBhZ2UgaW5pdGlhbE1vZGU9XCJzaWdudXBcIiAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9wcm9kdWN0c1wiIGVsZW1lbnQ9ezxQcm9kdWN0c1BhZ2UgLz59IC8+XG4gICAgICAgIDwvUm91dGVzPlxuICAgICAgPC9tYWluPlxuXG4gICAgICB7IWhpZGVDaHJvbWUgJiYgPEZvb3RlciAvPn1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHBcbiJdfQ==