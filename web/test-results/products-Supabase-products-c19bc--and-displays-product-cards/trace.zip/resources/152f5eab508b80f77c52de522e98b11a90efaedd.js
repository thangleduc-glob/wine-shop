import { n as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-BPOCksWG.js?v=170e5944";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=93d23258";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom.js?v=93d23258";
//#region node_modules/@remix-run/router/dist/router.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom());
/**
* @remix-run/router v1.23.3
*
* Copyright (c) Remix Software Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE.md file in the root directory of this source tree.
*
* @license MIT
*/
function _extends$2() {
	return _extends$2 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$2.apply(null, arguments);
}
/**
* Actions represent the type of change to a location value.
*/
var Action;
(function(Action) {
	/**
	* A POP indicates a change to an arbitrary index in the history stack, such
	* as a back or forward navigation. It does not describe the direction of the
	* navigation, only that the current index changed.
	*
	* Note: This is the default action for newly created history objects.
	*/
	Action["Pop"] = "POP";
	/**
	* A PUSH indicates a new entry being added to the history stack, such as when
	* a link is clicked and a new page loads. When this happens, all subsequent
	* entries in the stack are lost.
	*/
	Action["Push"] = "PUSH";
	/**
	* A REPLACE indicates the entry at the current index in the history stack
	* being replaced by a new one.
	*/
	Action["Replace"] = "REPLACE";
})(Action || (Action = {}));
var PopStateEventType = "popstate";
/**
* Memory history stores the current location in memory. It is designed for use
* in stateful non-browser environments like tests and React Native.
*/
function createMemoryHistory(options) {
	if (options === void 0) options = {};
	let { initialEntries = ["/"], initialIndex, v5Compat = false } = options;
	let entries;
	entries = initialEntries.map((entry, index) => createMemoryLocation(entry, typeof entry === "string" ? null : entry.state, index === 0 ? "default" : void 0));
	let index = clampIndex(initialIndex == null ? entries.length - 1 : initialIndex);
	let action = Action.Pop;
	let listener = null;
	function clampIndex(n) {
		return Math.min(Math.max(n, 0), entries.length - 1);
	}
	function getCurrentLocation() {
		return entries[index];
	}
	function createMemoryLocation(to, state, key) {
		if (state === void 0) state = null;
		let location = createLocation(entries ? getCurrentLocation().pathname : "/", to, state, key);
		warning(location.pathname.charAt(0) === "/", "relative pathnames are not supported in memory history: " + JSON.stringify(to));
		return location;
	}
	function createHref(to) {
		return typeof to === "string" ? to : createPath(to);
	}
	return {
		get index() {
			return index;
		},
		get action() {
			return action;
		},
		get location() {
			return getCurrentLocation();
		},
		createHref,
		createURL(to) {
			return new URL(createHref(to), "http://localhost");
		},
		encodeLocation(to) {
			let path = typeof to === "string" ? parsePath(to) : to;
			return {
				pathname: path.pathname || "",
				search: path.search || "",
				hash: path.hash || ""
			};
		},
		push(to, state) {
			action = Action.Push;
			let nextLocation = createMemoryLocation(to, state);
			index += 1;
			entries.splice(index, entries.length, nextLocation);
			if (v5Compat && listener) listener({
				action,
				location: nextLocation,
				delta: 1
			});
		},
		replace(to, state) {
			action = Action.Replace;
			let nextLocation = createMemoryLocation(to, state);
			entries[index] = nextLocation;
			if (v5Compat && listener) listener({
				action,
				location: nextLocation,
				delta: 0
			});
		},
		go(delta) {
			action = Action.Pop;
			let nextIndex = clampIndex(index + delta);
			let nextLocation = entries[nextIndex];
			index = nextIndex;
			if (listener) listener({
				action,
				location: nextLocation,
				delta
			});
		},
		listen(fn) {
			listener = fn;
			return () => {
				listener = null;
			};
		}
	};
}
/**
* Browser history stores the location in regular URLs. This is the standard for
* most web apps, but it requires some configuration on the server to ensure you
* serve the same app at multiple URLs.
*
* @see https://github.com/remix-run/history/tree/main/docs/api-reference.md#createbrowserhistory
*/
function createBrowserHistory(options) {
	if (options === void 0) options = {};
	function createBrowserLocation(window, globalHistory) {
		let { pathname, search, hash } = window.location;
		return createLocation("", {
			pathname,
			search,
			hash
		}, globalHistory.state && globalHistory.state.usr || null, globalHistory.state && globalHistory.state.key || "default");
	}
	function createBrowserHref(window, to) {
		return typeof to === "string" ? to : createPath(to);
	}
	return getUrlBasedHistory(createBrowserLocation, createBrowserHref, null, options);
}
/**
* Hash history stores the location in window.location.hash. This makes it ideal
* for situations where you don't want to send the location to the server for
* some reason, either because you do cannot configure it or the URL space is
* reserved for something else.
*
* @see https://github.com/remix-run/history/tree/main/docs/api-reference.md#createhashhistory
*/
function createHashHistory(options) {
	if (options === void 0) options = {};
	function createHashLocation(window, globalHistory) {
		let { pathname = "/", search = "", hash = "" } = parsePath(window.location.hash.substr(1));
		if (!pathname.startsWith("/") && !pathname.startsWith(".")) pathname = "/" + pathname;
		return createLocation("", {
			pathname,
			search,
			hash
		}, globalHistory.state && globalHistory.state.usr || null, globalHistory.state && globalHistory.state.key || "default");
	}
	function createHashHref(window, to) {
		let base = window.document.querySelector("base");
		let href = "";
		if (base && base.getAttribute("href")) {
			let url = window.location.href;
			let hashIndex = url.indexOf("#");
			href = hashIndex === -1 ? url : url.slice(0, hashIndex);
		}
		return href + "#" + (typeof to === "string" ? to : createPath(to));
	}
	function validateHashLocation(location, to) {
		warning(location.pathname.charAt(0) === "/", "relative pathnames are not supported in hash history.push(" + JSON.stringify(to) + ")");
	}
	return getUrlBasedHistory(createHashLocation, createHashHref, validateHashLocation, options);
}
function invariant(value, message) {
	if (value === false || value === null || typeof value === "undefined") throw new Error(message);
}
function warning(cond, message) {
	if (!cond) {
		if (typeof console !== "undefined") console.warn(message);
		try {
			throw new Error(message);
		} catch (e) {}
	}
}
function createKey() {
	return Math.random().toString(36).substr(2, 8);
}
/**
* For browser-based histories, we combine the state and key into an object
*/
function getHistoryState(location, index) {
	return {
		usr: location.state,
		key: location.key,
		idx: index
	};
}
/**
* Creates a Location object with a unique key from the given Path
*/
function createLocation(current, to, state, key) {
	if (state === void 0) state = null;
	return _extends$2({
		pathname: typeof current === "string" ? current : current.pathname,
		search: "",
		hash: ""
	}, typeof to === "string" ? parsePath(to) : to, {
		state,
		key: to && to.key || key || createKey()
	});
}
/**
* Creates a string URL path from the given pathname, search, and hash components.
*/
function createPath(_ref) {
	let { pathname = "/", search = "", hash = "" } = _ref;
	if (search && search !== "?") pathname += search.charAt(0) === "?" ? search : "?" + search;
	if (hash && hash !== "#") pathname += hash.charAt(0) === "#" ? hash : "#" + hash;
	return pathname;
}
/**
* Parses a string URL path into its separate pathname, search, and hash components.
*/
function parsePath(path) {
	let parsedPath = {};
	if (path) {
		let hashIndex = path.indexOf("#");
		if (hashIndex >= 0) {
			parsedPath.hash = path.substr(hashIndex);
			path = path.substr(0, hashIndex);
		}
		let searchIndex = path.indexOf("?");
		if (searchIndex >= 0) {
			parsedPath.search = path.substr(searchIndex);
			path = path.substr(0, searchIndex);
		}
		if (path) parsedPath.pathname = path;
	}
	return parsedPath;
}
function getUrlBasedHistory(getLocation, createHref, validateLocation, options) {
	if (options === void 0) options = {};
	let { window = document.defaultView, v5Compat = false } = options;
	let globalHistory = window.history;
	let action = Action.Pop;
	let listener = null;
	let index = getIndex();
	if (index == null) {
		index = 0;
		globalHistory.replaceState(_extends$2({}, globalHistory.state, { idx: index }), "");
	}
	function getIndex() {
		return (globalHistory.state || { idx: null }).idx;
	}
	function handlePop() {
		action = Action.Pop;
		let nextIndex = getIndex();
		let delta = nextIndex == null ? null : nextIndex - index;
		index = nextIndex;
		if (listener) listener({
			action,
			location: history.location,
			delta
		});
	}
	function push(to, state) {
		action = Action.Push;
		let location = createLocation(history.location, to, state);
		if (validateLocation) validateLocation(location, to);
		index = getIndex() + 1;
		let historyState = getHistoryState(location, index);
		let url = history.createHref(location);
		try {
			globalHistory.pushState(historyState, "", url);
		} catch (error) {
			if (error instanceof DOMException && error.name === "DataCloneError") throw error;
			window.location.assign(url);
		}
		if (v5Compat && listener) listener({
			action,
			location: history.location,
			delta: 1
		});
	}
	function replace(to, state) {
		action = Action.Replace;
		let location = createLocation(history.location, to, state);
		if (validateLocation) validateLocation(location, to);
		index = getIndex();
		let historyState = getHistoryState(location, index);
		let url = history.createHref(location);
		globalHistory.replaceState(historyState, "", url);
		if (v5Compat && listener) listener({
			action,
			location: history.location,
			delta: 0
		});
	}
	function createURL(to) {
		let base = window.location.origin !== "null" ? window.location.origin : window.location.href;
		let href = typeof to === "string" ? to : createPath(to);
		href = href.replace(/ $/, "%20");
		invariant(base, "No window.location.(origin|href) available to create URL for href: " + href);
		return new URL(href, base);
	}
	let history = {
		get action() {
			return action;
		},
		get location() {
			return getLocation(window, globalHistory);
		},
		listen(fn) {
			if (listener) throw new Error("A history only accepts one active listener");
			window.addEventListener(PopStateEventType, handlePop);
			listener = fn;
			return () => {
				window.removeEventListener(PopStateEventType, handlePop);
				listener = null;
			};
		},
		createHref(to) {
			return createHref(window, to);
		},
		createURL,
		encodeLocation(to) {
			let url = createURL(to);
			return {
				pathname: url.pathname,
				search: url.search,
				hash: url.hash
			};
		},
		push,
		replace,
		go(n) {
			return globalHistory.go(n);
		}
	};
	return history;
}
var ResultType;
(function(ResultType) {
	ResultType["data"] = "data";
	ResultType["deferred"] = "deferred";
	ResultType["redirect"] = "redirect";
	ResultType["error"] = "error";
})(ResultType || (ResultType = {}));
var immutableRouteKeys = /* @__PURE__ */ new Set([
	"lazy",
	"caseSensitive",
	"path",
	"id",
	"index",
	"children"
]);
function isIndexRoute(route) {
	return route.index === true;
}
function convertRoutesToDataRoutes(routes, mapRouteProperties, parentPath, manifest) {
	if (parentPath === void 0) parentPath = [];
	if (manifest === void 0) manifest = {};
	return routes.map((route, index) => {
		let treePath = [...parentPath, String(index)];
		let id = typeof route.id === "string" ? route.id : treePath.join("-");
		invariant(route.index !== true || !route.children, "Cannot specify children on an index route");
		invariant(!manifest[id], "Found a route id collision on id \"" + id + "\".  Route id's must be globally unique within Data Router usages");
		if (isIndexRoute(route)) {
			let indexRoute = _extends$2({}, route, mapRouteProperties(route), { id });
			manifest[id] = indexRoute;
			return indexRoute;
		} else {
			let pathOrLayoutRoute = _extends$2({}, route, mapRouteProperties(route), {
				id,
				children: void 0
			});
			manifest[id] = pathOrLayoutRoute;
			if (route.children) pathOrLayoutRoute.children = convertRoutesToDataRoutes(route.children, mapRouteProperties, treePath, manifest);
			return pathOrLayoutRoute;
		}
	});
}
/**
* Matches the given routes to a location and returns the match data.
*
* @see https://reactrouter.com/v6/utils/match-routes
*/
function matchRoutes(routes, locationArg, basename) {
	if (basename === void 0) basename = "/";
	return matchRoutesImpl(routes, locationArg, basename, false);
}
function matchRoutesImpl(routes, locationArg, basename, allowPartial) {
	let pathname = stripBasename((typeof locationArg === "string" ? parsePath(locationArg) : locationArg).pathname || "/", basename);
	if (pathname == null) return null;
	let branches = flattenRoutes(routes);
	rankRouteBranches(branches);
	let matches = null;
	let decoded = decodePath(pathname);
	for (let i = 0; matches == null && i < branches.length; ++i) matches = matchRouteBranch(branches[i], decoded, allowPartial);
	return matches;
}
function convertRouteMatchToUiMatch(match, loaderData) {
	let { route, pathname, params } = match;
	return {
		id: route.id,
		pathname,
		params,
		data: loaderData[route.id],
		handle: route.handle
	};
}
function flattenRoutes(routes, branches, parentsMeta, parentPath) {
	if (branches === void 0) branches = [];
	if (parentsMeta === void 0) parentsMeta = [];
	if (parentPath === void 0) parentPath = "";
	let flattenRoute = (route, index, relativePath) => {
		let meta = {
			relativePath: relativePath === void 0 ? route.path || "" : relativePath,
			caseSensitive: route.caseSensitive === true,
			childrenIndex: index,
			route
		};
		if (meta.relativePath.startsWith("/")) {
			invariant(meta.relativePath.startsWith(parentPath), "Absolute route path \"" + meta.relativePath + "\" nested under path " + ("\"" + parentPath + "\" is not valid. An absolute child route path ") + "must start with the combined path of all its parent routes.");
			meta.relativePath = meta.relativePath.slice(parentPath.length);
		}
		let path = joinPaths([parentPath, meta.relativePath]);
		let routesMeta = parentsMeta.concat(meta);
		if (route.children && route.children.length > 0) {
			invariant(route.index !== true, "Index routes must not have child routes. Please remove " + ("all child routes from route path \"" + path + "\"."));
			flattenRoutes(route.children, branches, routesMeta, path);
		}
		if (route.path == null && !route.index) return;
		branches.push({
			path,
			score: computeScore(path, route.index),
			routesMeta
		});
	};
	routes.forEach((route, index) => {
		var _route$path;
		if (route.path === "" || !((_route$path = route.path) != null && _route$path.includes("?"))) flattenRoute(route, index);
		else for (let exploded of explodeOptionalSegments(route.path)) flattenRoute(route, index, exploded);
	});
	return branches;
}
/**
* Computes all combinations of optional path segments for a given path,
* excluding combinations that are ambiguous and of lower priority.
*
* For example, `/one/:two?/three/:four?/:five?` explodes to:
* - `/one/three`
* - `/one/:two/three`
* - `/one/three/:four`
* - `/one/three/:five`
* - `/one/:two/three/:four`
* - `/one/:two/three/:five`
* - `/one/three/:four/:five`
* - `/one/:two/three/:four/:five`
*/
function explodeOptionalSegments(path) {
	let segments = path.split("/");
	if (segments.length === 0) return [];
	let [first, ...rest] = segments;
	let isOptional = first.endsWith("?");
	let required = first.replace(/\?$/, "");
	if (rest.length === 0) return isOptional ? [required, ""] : [required];
	let restExploded = explodeOptionalSegments(rest.join("/"));
	let result = [];
	result.push(...restExploded.map((subpath) => subpath === "" ? required : [required, subpath].join("/")));
	if (isOptional) result.push(...restExploded);
	return result.map((exploded) => path.startsWith("/") && exploded === "" ? "/" : exploded);
}
function rankRouteBranches(branches) {
	branches.sort((a, b) => a.score !== b.score ? b.score - a.score : compareIndexes(a.routesMeta.map((meta) => meta.childrenIndex), b.routesMeta.map((meta) => meta.childrenIndex)));
}
var paramRe = /^:[\w-]+$/;
var dynamicSegmentValue = 3;
var indexRouteValue = 2;
var emptySegmentValue = 1;
var staticSegmentValue = 10;
var splatPenalty = -2;
var isSplat = (s) => s === "*";
function computeScore(path, index) {
	let segments = path.split("/");
	let initialScore = segments.length;
	if (segments.some(isSplat)) initialScore += splatPenalty;
	if (index) initialScore += indexRouteValue;
	return segments.filter((s) => !isSplat(s)).reduce((score, segment) => score + (paramRe.test(segment) ? dynamicSegmentValue : segment === "" ? emptySegmentValue : staticSegmentValue), initialScore);
}
function compareIndexes(a, b) {
	return a.length === b.length && a.slice(0, -1).every((n, i) => n === b[i]) ? a[a.length - 1] - b[b.length - 1] : 0;
}
function matchRouteBranch(branch, pathname, allowPartial) {
	if (allowPartial === void 0) allowPartial = false;
	let { routesMeta } = branch;
	let matchedParams = {};
	let matchedPathname = "/";
	let matches = [];
	for (let i = 0; i < routesMeta.length; ++i) {
		let meta = routesMeta[i];
		let end = i === routesMeta.length - 1;
		let remainingPathname = matchedPathname === "/" ? pathname : pathname.slice(matchedPathname.length) || "/";
		let match = matchPath({
			path: meta.relativePath,
			caseSensitive: meta.caseSensitive,
			end
		}, remainingPathname);
		let route = meta.route;
		if (!match && end && allowPartial && !routesMeta[routesMeta.length - 1].route.index) match = matchPath({
			path: meta.relativePath,
			caseSensitive: meta.caseSensitive,
			end: false
		}, remainingPathname);
		if (!match) return null;
		Object.assign(matchedParams, match.params);
		matches.push({
			params: matchedParams,
			pathname: joinPaths([matchedPathname, match.pathname]),
			pathnameBase: normalizePathname(joinPaths([matchedPathname, match.pathnameBase])),
			route
		});
		if (match.pathnameBase !== "/") matchedPathname = joinPaths([matchedPathname, match.pathnameBase]);
	}
	return matches;
}
/**
* Returns a path with params interpolated.
*
* @see https://reactrouter.com/v6/utils/generate-path
*/
function generatePath(originalPath, params) {
	if (params === void 0) params = {};
	let path = originalPath;
	if (path.endsWith("*") && path !== "*" && !path.endsWith("/*")) {
		warning(false, "Route path \"" + path + "\" will be treated as if it were " + ("\"" + path.replace(/\*$/, "/*") + "\" because the `*` character must ") + "always follow a `/` in the pattern. To get rid of this warning, " + ("please change the route path to \"" + path.replace(/\*$/, "/*") + "\"."));
		path = path.replace(/\*$/, "/*");
	}
	const prefix = path.startsWith("/") ? "/" : "";
	const stringify = (p) => p == null ? "" : typeof p === "string" ? p : String(p);
	return prefix + path.split(/\/+/).map((segment, index, array) => {
		if (index === array.length - 1 && segment === "*") return stringify(params["*"]);
		const keyMatch = segment.match(/^:([\w-]+)(\??)$/);
		if (keyMatch) {
			const [, key, optional] = keyMatch;
			let param = params[key];
			invariant(optional === "?" || param != null, "Missing \":" + key + "\" param");
			return stringify(param);
		}
		return segment.replace(/\?$/g, "");
	}).filter((segment) => !!segment).join("/");
}
/**
* Performs pattern matching on a URL pathname and returns information about
* the match.
*
* @see https://reactrouter.com/v6/utils/match-path
*/
function matchPath(pattern, pathname) {
	if (typeof pattern === "string") pattern = {
		path: pattern,
		caseSensitive: false,
		end: true
	};
	let [matcher, compiledParams] = compilePath(pattern.path, pattern.caseSensitive, pattern.end);
	let match = pathname.match(matcher);
	if (!match) return null;
	let matchedPathname = match[0];
	let pathnameBase = matchedPathname.replace(/(.)\/+$/, "$1");
	let captureGroups = match.slice(1);
	return {
		params: compiledParams.reduce((memo, _ref, index) => {
			let { paramName, isOptional } = _ref;
			if (paramName === "*") {
				let splatValue = captureGroups[index] || "";
				pathnameBase = matchedPathname.slice(0, matchedPathname.length - splatValue.length).replace(/(.)\/+$/, "$1");
			}
			const value = captureGroups[index];
			if (isOptional && !value) memo[paramName] = void 0;
			else memo[paramName] = (value || "").replace(/%2F/g, "/");
			return memo;
		}, {}),
		pathname: matchedPathname,
		pathnameBase,
		pattern
	};
}
function compilePath(path, caseSensitive, end) {
	if (caseSensitive === void 0) caseSensitive = false;
	if (end === void 0) end = true;
	warning(path === "*" || !path.endsWith("*") || path.endsWith("/*"), "Route path \"" + path + "\" will be treated as if it were " + ("\"" + path.replace(/\*$/, "/*") + "\" because the `*` character must ") + "always follow a `/` in the pattern. To get rid of this warning, " + ("please change the route path to \"" + path.replace(/\*$/, "/*") + "\"."));
	let params = [];
	let regexpSource = "^" + path.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (_, paramName, isOptional) => {
		params.push({
			paramName,
			isOptional: isOptional != null
		});
		return isOptional ? "/?([^\\/]+)?" : "/([^\\/]+)";
	});
	if (path.endsWith("*")) {
		params.push({ paramName: "*" });
		regexpSource += path === "*" || path === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$";
	} else if (end) regexpSource += "\\/*$";
	else if (path !== "" && path !== "/") regexpSource += "(?:(?=\\/|$))";
	return [new RegExp(regexpSource, caseSensitive ? void 0 : "i"), params];
}
function decodePath(value) {
	try {
		return value.split("/").map((v) => decodeURIComponent(v).replace(/\//g, "%2F")).join("/");
	} catch (error) {
		warning(false, "The URL path \"" + value + "\" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent " + ("encoding (" + error + ")."));
		return value;
	}
}
/**
* @private
*/
function stripBasename(pathname, basename) {
	if (basename === "/") return pathname;
	if (!pathname.toLowerCase().startsWith(basename.toLowerCase())) return null;
	let startIndex = basename.endsWith("/") ? basename.length - 1 : basename.length;
	let nextChar = pathname.charAt(startIndex);
	if (nextChar && nextChar !== "/") return null;
	return pathname.slice(startIndex) || "/";
}
var ABSOLUTE_URL_REGEX$1 = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;
var isAbsoluteUrl = (url) => ABSOLUTE_URL_REGEX$1.test(url);
/**
* Returns a resolved path object relative to the given pathname.
*
* @see https://reactrouter.com/v6/utils/resolve-path
*/
function resolvePath(to, fromPathname) {
	if (fromPathname === void 0) fromPathname = "/";
	let { pathname: toPathname, search = "", hash = "" } = typeof to === "string" ? parsePath(to) : to;
	let pathname;
	if (toPathname) {
		if (isAbsoluteUrl(toPathname)) pathname = toPathname;
		else {
			if (toPathname.includes("//")) {
				let oldPathname = toPathname;
				toPathname = removeDoubleSlashes(toPathname);
				warning(false, "Pathnames cannot have embedded double slashes - normalizing " + (oldPathname + " -> " + toPathname));
			}
			if (toPathname.startsWith("/")) pathname = resolvePathname(toPathname.substring(1), "/");
			else pathname = resolvePathname(toPathname, fromPathname);
		}
	} else pathname = fromPathname;
	return {
		pathname,
		search: normalizeSearch(search),
		hash: normalizeHash(hash)
	};
}
function resolvePathname(relativePath, fromPathname) {
	let segments = fromPathname.replace(/\/+$/, "").split("/");
	relativePath.split("/").forEach((segment) => {
		if (segment === "..") {
			if (segments.length > 1) segments.pop();
		} else if (segment !== ".") segments.push(segment);
	});
	return segments.length > 1 ? segments.join("/") : "/";
}
function getInvalidPathError(char, field, dest, path) {
	return "Cannot include a '" + char + "' character in a manually specified " + ("`to." + field + "` field [" + JSON.stringify(path) + "].  Please separate it out to the ") + ("`to." + dest + "` field. Alternatively you may provide the full path as ") + "a string in <Link to=\"...\"> and the router will parse it for you.";
}
/**
* @private
*
* When processing relative navigation we want to ignore ancestor routes that
* do not contribute to the path, such that index/pathless layout routes don't
* interfere.
*
* For example, when moving a route element into an index route and/or a
* pathless layout route, relative link behavior contained within should stay
* the same.  Both of the following examples should link back to the root:
*
*   <Route path="/">
*     <Route path="accounts" element={<Link to=".."}>
*   </Route>
*
*   <Route path="/">
*     <Route path="accounts">
*       <Route element={<AccountsLayout />}>       // <-- Does not contribute
*         <Route index element={<Link to=".."} />  // <-- Does not contribute
*       </Route
*     </Route>
*   </Route>
*/
function getPathContributingMatches(matches) {
	return matches.filter((match, index) => index === 0 || match.route.path && match.route.path.length > 0);
}
function getResolveToMatches(matches, v7_relativeSplatPath) {
	let pathMatches = getPathContributingMatches(matches);
	if (v7_relativeSplatPath) return pathMatches.map((match, idx) => idx === pathMatches.length - 1 ? match.pathname : match.pathnameBase);
	return pathMatches.map((match) => match.pathnameBase);
}
/**
* @private
*/
function resolveTo(toArg, routePathnames, locationPathname, isPathRelative) {
	if (isPathRelative === void 0) isPathRelative = false;
	let to;
	if (typeof toArg === "string") to = parsePath(toArg);
	else {
		to = _extends$2({}, toArg);
		invariant(!to.pathname || !to.pathname.includes("?"), getInvalidPathError("?", "pathname", "search", to));
		invariant(!to.pathname || !to.pathname.includes("#"), getInvalidPathError("#", "pathname", "hash", to));
		invariant(!to.search || !to.search.includes("#"), getInvalidPathError("#", "search", "hash", to));
	}
	let isEmptyPath = toArg === "" || to.pathname === "";
	let toPathname = isEmptyPath ? "/" : to.pathname;
	let from;
	if (toPathname == null) from = locationPathname;
	else {
		let routePathnameIndex = routePathnames.length - 1;
		if (!isPathRelative && toPathname.startsWith("..")) {
			let toSegments = toPathname.split("/");
			while (toSegments[0] === "..") {
				toSegments.shift();
				routePathnameIndex -= 1;
			}
			to.pathname = toSegments.join("/");
		}
		from = routePathnameIndex >= 0 ? routePathnames[routePathnameIndex] : "/";
	}
	let path = resolvePath(to, from);
	let hasExplicitTrailingSlash = toPathname && toPathname !== "/" && toPathname.endsWith("/");
	let hasCurrentTrailingSlash = (isEmptyPath || toPathname === ".") && locationPathname.endsWith("/");
	if (!path.pathname.endsWith("/") && (hasExplicitTrailingSlash || hasCurrentTrailingSlash)) path.pathname += "/";
	return path;
}
var removeDoubleSlashes = (path) => path.replace(/\/\/+/g, "/");
/**
* @private
*/
var joinPaths = (paths) => removeDoubleSlashes(paths.join("/"));
/**
* @private
*/
var normalizePathname = (pathname) => pathname.replace(/\/+$/, "").replace(/^\/*/, "/");
/**
* @private
*/
var normalizeSearch = (search) => !search || search === "?" ? "" : search.startsWith("?") ? search : "?" + search;
/**
* @private
*/
var normalizeHash = (hash) => !hash || hash === "#" ? "" : hash.startsWith("#") ? hash : "#" + hash;
/**
* This is a shortcut for creating `application/json` responses. Converts `data`
* to JSON and sets the `Content-Type` header.
*
* @deprecated The `json` method is deprecated in favor of returning raw objects.
* This method will be removed in v7.
*/
var json = function json(data, init) {
	if (init === void 0) init = {};
	let responseInit = typeof init === "number" ? { status: init } : init;
	let headers = new Headers(responseInit.headers);
	if (!headers.has("Content-Type")) headers.set("Content-Type", "application/json; charset=utf-8");
	return new Response(JSON.stringify(data), _extends$2({}, responseInit, { headers }));
};
var AbortedDeferredError = class extends Error {};
var DeferredData = class {
	constructor(data, responseInit) {
		this.pendingKeysSet = /* @__PURE__ */ new Set();
		this.subscribers = /* @__PURE__ */ new Set();
		this.deferredKeys = [];
		invariant(data && typeof data === "object" && !Array.isArray(data), "defer() only accepts plain objects");
		let reject;
		this.abortPromise = new Promise((_, r) => reject = r);
		this.controller = new AbortController();
		let onAbort = () => reject(new AbortedDeferredError("Deferred data aborted"));
		this.unlistenAbortSignal = () => this.controller.signal.removeEventListener("abort", onAbort);
		this.controller.signal.addEventListener("abort", onAbort);
		this.data = Object.entries(data).reduce((acc, _ref2) => {
			let [key, value] = _ref2;
			return Object.assign(acc, { [key]: this.trackPromise(key, value) });
		}, {});
		if (this.done) this.unlistenAbortSignal();
		this.init = responseInit;
	}
	trackPromise(key, value) {
		if (!(value instanceof Promise)) return value;
		this.deferredKeys.push(key);
		this.pendingKeysSet.add(key);
		let promise = Promise.race([value, this.abortPromise]).then((data) => this.onSettle(promise, key, void 0, data), (error) => this.onSettle(promise, key, error));
		promise.catch(() => {});
		Object.defineProperty(promise, "_tracked", { get: () => true });
		return promise;
	}
	onSettle(promise, key, error, data) {
		if (this.controller.signal.aborted && error instanceof AbortedDeferredError) {
			this.unlistenAbortSignal();
			Object.defineProperty(promise, "_error", { get: () => error });
			return Promise.reject(error);
		}
		this.pendingKeysSet.delete(key);
		if (this.done) this.unlistenAbortSignal();
		if (error === void 0 && data === void 0) {
			let undefinedError = /* @__PURE__ */ new Error("Deferred data for key \"" + key + "\" resolved/rejected with `undefined`, you must resolve/reject with a value or `null`.");
			Object.defineProperty(promise, "_error", { get: () => undefinedError });
			this.emit(false, key);
			return Promise.reject(undefinedError);
		}
		if (data === void 0) {
			Object.defineProperty(promise, "_error", { get: () => error });
			this.emit(false, key);
			return Promise.reject(error);
		}
		Object.defineProperty(promise, "_data", { get: () => data });
		this.emit(false, key);
		return data;
	}
	emit(aborted, settledKey) {
		this.subscribers.forEach((subscriber) => subscriber(aborted, settledKey));
	}
	subscribe(fn) {
		this.subscribers.add(fn);
		return () => this.subscribers.delete(fn);
	}
	cancel() {
		this.controller.abort();
		this.pendingKeysSet.forEach((v, k) => this.pendingKeysSet.delete(k));
		this.emit(true);
	}
	async resolveData(signal) {
		let aborted = false;
		if (!this.done) {
			let onAbort = () => this.cancel();
			signal.addEventListener("abort", onAbort);
			aborted = await new Promise((resolve) => {
				this.subscribe((aborted) => {
					signal.removeEventListener("abort", onAbort);
					if (aborted || this.done) resolve(aborted);
				});
			});
		}
		return aborted;
	}
	get done() {
		return this.pendingKeysSet.size === 0;
	}
	get unwrappedData() {
		invariant(this.data !== null && this.done, "Can only unwrap data on initialized and settled deferreds");
		return Object.entries(this.data).reduce((acc, _ref3) => {
			let [key, value] = _ref3;
			return Object.assign(acc, { [key]: unwrapTrackedPromise(value) });
		}, {});
	}
	get pendingKeys() {
		return Array.from(this.pendingKeysSet);
	}
};
function isTrackedPromise(value) {
	return value instanceof Promise && value._tracked === true;
}
function unwrapTrackedPromise(value) {
	if (!isTrackedPromise(value)) return value;
	if (value._error) throw value._error;
	return value._data;
}
/**
* @deprecated The `defer` method is deprecated in favor of returning raw
* objects. This method will be removed in v7.
*/
var defer = function defer(data, init) {
	if (init === void 0) init = {};
	return new DeferredData(data, typeof init === "number" ? { status: init } : init);
};
/**
* A redirect response. Sets the status code and the `Location` header.
* Defaults to "302 Found".
*/
var redirect = function redirect(url, init) {
	if (init === void 0) init = 302;
	let responseInit = init;
	if (typeof responseInit === "number") responseInit = { status: responseInit };
	else if (typeof responseInit.status === "undefined") responseInit.status = 302;
	let headers = new Headers(responseInit.headers);
	headers.set("Location", url);
	return new Response(null, _extends$2({}, responseInit, { headers }));
};
/**
* A redirect response that will force a document reload to the new location.
* Sets the status code and the `Location` header.
* Defaults to "302 Found".
*/
var redirectDocument = (url, init) => {
	let response = redirect(url, init);
	response.headers.set("X-Remix-Reload-Document", "true");
	return response;
};
/**
* A redirect response that will perform a `history.replaceState` instead of a
* `history.pushState` for client-side navigation redirects.
* Sets the status code and the `Location` header.
* Defaults to "302 Found".
*/
var replace = (url, init) => {
	let response = redirect(url, init);
	response.headers.set("X-Remix-Replace", "true");
	return response;
};
/**
* @private
* Utility class we use to hold auto-unwrapped 4xx/5xx Response bodies
*
* We don't export the class for public use since it's an implementation
* detail, but we export the interface above so folks can build their own
* abstractions around instances via isRouteErrorResponse()
*/
var ErrorResponseImpl = class {
	constructor(status, statusText, data, internal) {
		if (internal === void 0) internal = false;
		this.status = status;
		this.statusText = statusText || "";
		this.internal = internal;
		if (data instanceof Error) {
			this.data = data.toString();
			this.error = data;
		} else this.data = data;
	}
};
/**
* Check if the given error is an ErrorResponse generated from a 4xx/5xx
* Response thrown from an action/loader
*/
function isRouteErrorResponse(error) {
	return error != null && typeof error.status === "number" && typeof error.statusText === "string" && typeof error.internal === "boolean" && "data" in error;
}
var validMutationMethodsArr = [
	"post",
	"put",
	"patch",
	"delete"
];
var validMutationMethods = new Set(validMutationMethodsArr);
var validRequestMethodsArr = ["get", ...validMutationMethodsArr];
var validRequestMethods = new Set(validRequestMethodsArr);
var redirectStatusCodes = /* @__PURE__ */ new Set([
	301,
	302,
	303,
	307,
	308
]);
var redirectPreserveMethodStatusCodes = /* @__PURE__ */ new Set([307, 308]);
var IDLE_NAVIGATION = {
	state: "idle",
	location: void 0,
	formMethod: void 0,
	formAction: void 0,
	formEncType: void 0,
	formData: void 0,
	json: void 0,
	text: void 0
};
var IDLE_FETCHER = {
	state: "idle",
	data: void 0,
	formMethod: void 0,
	formAction: void 0,
	formEncType: void 0,
	formData: void 0,
	json: void 0,
	text: void 0
};
var IDLE_BLOCKER = {
	state: "unblocked",
	proceed: void 0,
	reset: void 0,
	location: void 0
};
var ABSOLUTE_URL_REGEX$2 = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;
var defaultMapRouteProperties = (route) => ({ hasErrorBoundary: Boolean(route.hasErrorBoundary) });
var TRANSITIONS_STORAGE_KEY = "remix-router-transitions";
/**
* Create a router and listen to history POP navigations
*/
function createRouter(init) {
	const routerWindow = init.window ? init.window : typeof window !== "undefined" ? window : void 0;
	const isBrowser = typeof routerWindow !== "undefined" && typeof routerWindow.document !== "undefined" && typeof routerWindow.document.createElement !== "undefined";
	const isServer = !isBrowser;
	invariant(init.routes.length > 0, "You must provide a non-empty routes array to createRouter");
	let mapRouteProperties;
	if (init.mapRouteProperties) mapRouteProperties = init.mapRouteProperties;
	else if (init.detectErrorBoundary) {
		let detectErrorBoundary = init.detectErrorBoundary;
		mapRouteProperties = (route) => ({ hasErrorBoundary: detectErrorBoundary(route) });
	} else mapRouteProperties = defaultMapRouteProperties;
	let manifest = {};
	let dataRoutes = convertRoutesToDataRoutes(init.routes, mapRouteProperties, void 0, manifest);
	let inFlightDataRoutes;
	let basename = init.basename || "/";
	let dataStrategyImpl = init.dataStrategy || defaultDataStrategy;
	let patchRoutesOnNavigationImpl = init.patchRoutesOnNavigation;
	let future = _extends$2({
		v7_fetcherPersist: false,
		v7_normalizeFormMethod: false,
		v7_partialHydration: false,
		v7_prependBasename: false,
		v7_relativeSplatPath: false,
		v7_skipActionErrorRevalidation: false
	}, init.future);
	let unlistenHistory = null;
	let subscribers = /* @__PURE__ */ new Set();
	let savedScrollPositions = null;
	let getScrollRestorationKey = null;
	let getScrollPosition = null;
	let initialScrollRestored = init.hydrationData != null;
	let initialMatches = matchRoutes(dataRoutes, init.history.location, basename);
	let initialMatchesIsFOW = false;
	let initialErrors = null;
	if (initialMatches == null && !patchRoutesOnNavigationImpl) {
		let error = getInternalRouterError(404, { pathname: init.history.location.pathname });
		let { matches, route } = getShortCircuitMatches(dataRoutes);
		initialMatches = matches;
		initialErrors = { [route.id]: error };
	}
	if (initialMatches && !init.hydrationData) {
		if (checkFogOfWar(initialMatches, dataRoutes, init.history.location.pathname).active) initialMatches = null;
	}
	let initialized;
	if (!initialMatches) {
		initialized = false;
		initialMatches = [];
		if (future.v7_partialHydration) {
			let fogOfWar = checkFogOfWar(null, dataRoutes, init.history.location.pathname);
			if (fogOfWar.active && fogOfWar.matches) {
				initialMatchesIsFOW = true;
				initialMatches = fogOfWar.matches;
			}
		}
	} else if (initialMatches.some((m) => m.route.lazy)) initialized = false;
	else if (!initialMatches.some((m) => m.route.loader)) initialized = true;
	else if (future.v7_partialHydration) {
		let loaderData = init.hydrationData ? init.hydrationData.loaderData : null;
		let errors = init.hydrationData ? init.hydrationData.errors : null;
		if (errors) {
			let idx = initialMatches.findIndex((m) => errors[m.route.id] !== void 0);
			initialized = initialMatches.slice(0, idx + 1).every((m) => !shouldLoadRouteOnHydration(m.route, loaderData, errors));
		} else initialized = initialMatches.every((m) => !shouldLoadRouteOnHydration(m.route, loaderData, errors));
	} else initialized = init.hydrationData != null;
	let router;
	let state = {
		historyAction: init.history.action,
		location: init.history.location,
		matches: initialMatches,
		initialized,
		navigation: IDLE_NAVIGATION,
		restoreScrollPosition: init.hydrationData != null ? false : null,
		preventScrollReset: false,
		revalidation: "idle",
		loaderData: init.hydrationData && init.hydrationData.loaderData || {},
		actionData: init.hydrationData && init.hydrationData.actionData || null,
		errors: init.hydrationData && init.hydrationData.errors || initialErrors,
		fetchers: /* @__PURE__ */ new Map(),
		blockers: /* @__PURE__ */ new Map()
	};
	let pendingAction = Action.Pop;
	let pendingPreventScrollReset = false;
	let pendingNavigationController;
	let pendingViewTransitionEnabled = false;
	let appliedViewTransitions = /* @__PURE__ */ new Map();
	let removePageHideEventListener = null;
	let isUninterruptedRevalidation = false;
	let isRevalidationRequired = false;
	let cancelledDeferredRoutes = [];
	let cancelledFetcherLoads = /* @__PURE__ */ new Set();
	let fetchControllers = /* @__PURE__ */ new Map();
	let incrementingLoadId = 0;
	let pendingNavigationLoadId = -1;
	let fetchReloadIds = /* @__PURE__ */ new Map();
	let fetchRedirectIds = /* @__PURE__ */ new Set();
	let fetchLoadMatches = /* @__PURE__ */ new Map();
	let activeFetchers = /* @__PURE__ */ new Map();
	let deletedFetchers = /* @__PURE__ */ new Set();
	let activeDeferreds = /* @__PURE__ */ new Map();
	let blockerFunctions = /* @__PURE__ */ new Map();
	let unblockBlockerHistoryUpdate = void 0;
	function initialize() {
		unlistenHistory = init.history.listen((_ref) => {
			let { action: historyAction, location, delta } = _ref;
			if (unblockBlockerHistoryUpdate) {
				unblockBlockerHistoryUpdate();
				unblockBlockerHistoryUpdate = void 0;
				return;
			}
			warning(blockerFunctions.size === 0 || delta != null, "You are trying to use a blocker on a POP navigation to a location that was not created by @remix-run/router. This will fail silently in production. This can happen if you are navigating outside the router via `window.history.pushState`/`window.location.hash` instead of using router navigation APIs.  This can also happen if you are using createHashRouter and the user manually changes the URL.");
			let blockerKey = shouldBlockNavigation({
				currentLocation: state.location,
				nextLocation: location,
				historyAction
			});
			if (blockerKey && delta != null) {
				let nextHistoryUpdatePromise = new Promise((resolve) => {
					unblockBlockerHistoryUpdate = resolve;
				});
				init.history.go(delta * -1);
				updateBlocker(blockerKey, {
					state: "blocked",
					location,
					proceed() {
						updateBlocker(blockerKey, {
							state: "proceeding",
							proceed: void 0,
							reset: void 0,
							location
						});
						nextHistoryUpdatePromise.then(() => init.history.go(delta));
					},
					reset() {
						let blockers = new Map(state.blockers);
						blockers.set(blockerKey, IDLE_BLOCKER);
						updateState({ blockers });
					}
				});
				return;
			}
			return startNavigation(historyAction, location);
		});
		if (isBrowser) {
			restoreAppliedTransitions(routerWindow, appliedViewTransitions);
			let _saveAppliedTransitions = () => persistAppliedTransitions(routerWindow, appliedViewTransitions);
			routerWindow.addEventListener("pagehide", _saveAppliedTransitions);
			removePageHideEventListener = () => routerWindow.removeEventListener("pagehide", _saveAppliedTransitions);
		}
		if (!state.initialized) startNavigation(Action.Pop, state.location, { initialHydration: true });
		return router;
	}
	function dispose() {
		if (unlistenHistory) unlistenHistory();
		if (removePageHideEventListener) removePageHideEventListener();
		subscribers.clear();
		pendingNavigationController && pendingNavigationController.abort();
		state.fetchers.forEach((_, key) => deleteFetcher(key));
		state.blockers.forEach((_, key) => deleteBlocker(key));
	}
	function subscribe(fn) {
		subscribers.add(fn);
		return () => subscribers.delete(fn);
	}
	function updateState(newState, opts) {
		if (opts === void 0) opts = {};
		state = _extends$2({}, state, newState);
		let completedFetchers = [];
		let deletedFetchersKeys = [];
		if (future.v7_fetcherPersist) state.fetchers.forEach((fetcher, key) => {
			if (fetcher.state === "idle") {
				if (deletedFetchers.has(key)) deletedFetchersKeys.push(key);
				else completedFetchers.push(key);
			}
		});
		deletedFetchers.forEach((key) => {
			if (!state.fetchers.has(key) && !fetchControllers.has(key)) deletedFetchersKeys.push(key);
		});
		[...subscribers].forEach((subscriber) => subscriber(state, {
			deletedFetchers: deletedFetchersKeys,
			viewTransitionOpts: opts.viewTransitionOpts,
			flushSync: opts.flushSync === true
		}));
		if (future.v7_fetcherPersist) {
			completedFetchers.forEach((key) => state.fetchers.delete(key));
			deletedFetchersKeys.forEach((key) => deleteFetcher(key));
		} else deletedFetchersKeys.forEach((key) => deletedFetchers.delete(key));
	}
	function completeNavigation(location, newState, _temp) {
		var _location$state, _location$state2;
		let { flushSync } = _temp === void 0 ? {} : _temp;
		let isActionReload = state.actionData != null && state.navigation.formMethod != null && isMutationMethod(state.navigation.formMethod) && state.navigation.state === "loading" && ((_location$state = location.state) == null ? void 0 : _location$state._isRedirect) !== true;
		let actionData;
		if (newState.actionData) {
			if (Object.keys(newState.actionData).length > 0) actionData = newState.actionData;
			else actionData = null;
		} else if (isActionReload) actionData = state.actionData;
		else actionData = null;
		let loaderData = newState.loaderData ? mergeLoaderData(state.loaderData, newState.loaderData, newState.matches || [], newState.errors) : state.loaderData;
		let blockers = state.blockers;
		if (blockers.size > 0) {
			blockers = new Map(blockers);
			blockers.forEach((_, k) => blockers.set(k, IDLE_BLOCKER));
		}
		let preventScrollReset = pendingPreventScrollReset === true || state.navigation.formMethod != null && isMutationMethod(state.navigation.formMethod) && ((_location$state2 = location.state) == null ? void 0 : _location$state2._isRedirect) !== true;
		if (inFlightDataRoutes) {
			dataRoutes = inFlightDataRoutes;
			inFlightDataRoutes = void 0;
		}
		if (isUninterruptedRevalidation);
		else if (pendingAction === Action.Pop);
		else if (pendingAction === Action.Push) init.history.push(location, location.state);
		else if (pendingAction === Action.Replace) init.history.replace(location, location.state);
		let viewTransitionOpts;
		if (pendingAction === Action.Pop) {
			let priorPaths = appliedViewTransitions.get(state.location.pathname);
			if (priorPaths && priorPaths.has(location.pathname)) viewTransitionOpts = {
				currentLocation: state.location,
				nextLocation: location
			};
			else if (appliedViewTransitions.has(location.pathname)) viewTransitionOpts = {
				currentLocation: location,
				nextLocation: state.location
			};
		} else if (pendingViewTransitionEnabled) {
			let toPaths = appliedViewTransitions.get(state.location.pathname);
			if (toPaths) toPaths.add(location.pathname);
			else {
				toPaths = /* @__PURE__ */ new Set([location.pathname]);
				appliedViewTransitions.set(state.location.pathname, toPaths);
			}
			viewTransitionOpts = {
				currentLocation: state.location,
				nextLocation: location
			};
		}
		updateState(_extends$2({}, newState, {
			actionData,
			loaderData,
			historyAction: pendingAction,
			location,
			initialized: true,
			navigation: IDLE_NAVIGATION,
			revalidation: "idle",
			restoreScrollPosition: getSavedScrollPosition(location, newState.matches || state.matches),
			preventScrollReset,
			blockers
		}), {
			viewTransitionOpts,
			flushSync: flushSync === true
		});
		pendingAction = Action.Pop;
		pendingPreventScrollReset = false;
		pendingViewTransitionEnabled = false;
		isUninterruptedRevalidation = false;
		isRevalidationRequired = false;
		cancelledDeferredRoutes = [];
	}
	async function navigate(to, opts) {
		if (typeof to === "number") {
			init.history.go(to);
			return;
		}
		let normalizedPath = normalizeTo(state.location, state.matches, basename, future.v7_prependBasename, to, future.v7_relativeSplatPath, opts == null ? void 0 : opts.fromRouteId, opts == null ? void 0 : opts.relative);
		let { path, submission, error } = normalizeNavigateOptions(future.v7_normalizeFormMethod, false, normalizedPath, opts);
		let currentLocation = state.location;
		let nextLocation = createLocation(state.location, path, opts && opts.state);
		nextLocation = _extends$2({}, nextLocation, init.history.encodeLocation(nextLocation));
		let userReplace = opts && opts.replace != null ? opts.replace : void 0;
		let historyAction = Action.Push;
		if (userReplace === true) historyAction = Action.Replace;
		else if (userReplace === false);
		else if (submission != null && isMutationMethod(submission.formMethod) && submission.formAction === state.location.pathname + state.location.search) historyAction = Action.Replace;
		let preventScrollReset = opts && "preventScrollReset" in opts ? opts.preventScrollReset === true : void 0;
		let flushSync = (opts && opts.flushSync) === true;
		let blockerKey = shouldBlockNavigation({
			currentLocation,
			nextLocation,
			historyAction
		});
		if (blockerKey) {
			updateBlocker(blockerKey, {
				state: "blocked",
				location: nextLocation,
				proceed() {
					updateBlocker(blockerKey, {
						state: "proceeding",
						proceed: void 0,
						reset: void 0,
						location: nextLocation
					});
					navigate(to, opts);
				},
				reset() {
					let blockers = new Map(state.blockers);
					blockers.set(blockerKey, IDLE_BLOCKER);
					updateState({ blockers });
				}
			});
			return;
		}
		return await startNavigation(historyAction, nextLocation, {
			submission,
			pendingError: error,
			preventScrollReset,
			replace: opts && opts.replace,
			enableViewTransition: opts && opts.viewTransition,
			flushSync
		});
	}
	function revalidate() {
		interruptActiveLoads();
		updateState({ revalidation: "loading" });
		if (state.navigation.state === "submitting") return;
		if (state.navigation.state === "idle") {
			startNavigation(state.historyAction, state.location, { startUninterruptedRevalidation: true });
			return;
		}
		startNavigation(pendingAction || state.historyAction, state.navigation.location, {
			overrideNavigation: state.navigation,
			enableViewTransition: pendingViewTransitionEnabled === true
		});
	}
	async function startNavigation(historyAction, location, opts) {
		pendingNavigationController && pendingNavigationController.abort();
		pendingNavigationController = null;
		pendingAction = historyAction;
		isUninterruptedRevalidation = (opts && opts.startUninterruptedRevalidation) === true;
		saveScrollPosition(state.location, state.matches);
		pendingPreventScrollReset = (opts && opts.preventScrollReset) === true;
		pendingViewTransitionEnabled = (opts && opts.enableViewTransition) === true;
		let routesToUse = inFlightDataRoutes || dataRoutes;
		let loadingNavigation = opts && opts.overrideNavigation;
		let matches = opts != null && opts.initialHydration && state.matches && state.matches.length > 0 && !initialMatchesIsFOW ? state.matches : matchRoutes(routesToUse, location, basename);
		let flushSync = (opts && opts.flushSync) === true;
		if (matches && state.initialized && !isRevalidationRequired && isHashChangeOnly(state.location, location) && !(opts && opts.submission && isMutationMethod(opts.submission.formMethod))) {
			completeNavigation(location, { matches }, { flushSync });
			return;
		}
		let fogOfWar = checkFogOfWar(matches, routesToUse, location.pathname);
		if (fogOfWar.active && fogOfWar.matches) matches = fogOfWar.matches;
		if (!matches) {
			let { error, notFoundMatches, route } = handleNavigational404(location.pathname);
			completeNavigation(location, {
				matches: notFoundMatches,
				loaderData: {},
				errors: { [route.id]: error }
			}, { flushSync });
			return;
		}
		pendingNavigationController = new AbortController();
		let request = createClientSideRequest(init.history, location, pendingNavigationController.signal, opts && opts.submission);
		let pendingActionResult;
		if (opts && opts.pendingError) pendingActionResult = [findNearestBoundary(matches).route.id, {
			type: ResultType.error,
			error: opts.pendingError
		}];
		else if (opts && opts.submission && isMutationMethod(opts.submission.formMethod)) {
			let actionResult = await handleAction(request, location, opts.submission, matches, fogOfWar.active, {
				replace: opts.replace,
				flushSync
			});
			if (actionResult.shortCircuited) return;
			if (actionResult.pendingActionResult) {
				let [routeId, result] = actionResult.pendingActionResult;
				if (isErrorResult(result) && isRouteErrorResponse(result.error) && result.error.status === 404) {
					pendingNavigationController = null;
					completeNavigation(location, {
						matches: actionResult.matches,
						loaderData: {},
						errors: { [routeId]: result.error }
					});
					return;
				}
			}
			matches = actionResult.matches || matches;
			pendingActionResult = actionResult.pendingActionResult;
			loadingNavigation = getLoadingNavigation(location, opts.submission);
			flushSync = false;
			fogOfWar.active = false;
			request = createClientSideRequest(init.history, request.url, request.signal);
		}
		let { shortCircuited, matches: updatedMatches, loaderData, errors } = await handleLoaders(request, location, matches, fogOfWar.active, loadingNavigation, opts && opts.submission, opts && opts.fetcherSubmission, opts && opts.replace, opts && opts.initialHydration === true, flushSync, pendingActionResult);
		if (shortCircuited) return;
		pendingNavigationController = null;
		completeNavigation(location, _extends$2({ matches: updatedMatches || matches }, getActionDataForCommit(pendingActionResult), {
			loaderData,
			errors
		}));
	}
	async function handleAction(request, location, submission, matches, isFogOfWar, opts) {
		if (opts === void 0) opts = {};
		interruptActiveLoads();
		updateState({ navigation: getSubmittingNavigation(location, submission) }, { flushSync: opts.flushSync === true });
		if (isFogOfWar) {
			let discoverResult = await discoverRoutes(matches, location.pathname, request.signal);
			if (discoverResult.type === "aborted") return { shortCircuited: true };
			else if (discoverResult.type === "error") {
				let boundaryId = findNearestBoundary(discoverResult.partialMatches).route.id;
				return {
					matches: discoverResult.partialMatches,
					pendingActionResult: [boundaryId, {
						type: ResultType.error,
						error: discoverResult.error
					}]
				};
			} else if (!discoverResult.matches) {
				let { notFoundMatches, error, route } = handleNavigational404(location.pathname);
				return {
					matches: notFoundMatches,
					pendingActionResult: [route.id, {
						type: ResultType.error,
						error
					}]
				};
			} else matches = discoverResult.matches;
		}
		let result;
		let actionMatch = getTargetMatch(matches, location);
		if (!actionMatch.route.action && !actionMatch.route.lazy) result = {
			type: ResultType.error,
			error: getInternalRouterError(405, {
				method: request.method,
				pathname: location.pathname,
				routeId: actionMatch.route.id
			})
		};
		else {
			result = (await callDataStrategy("action", state, request, [actionMatch], matches, null))[actionMatch.route.id];
			if (request.signal.aborted) return { shortCircuited: true };
		}
		if (isRedirectResult(result)) {
			let replace;
			if (opts && opts.replace != null) replace = opts.replace;
			else replace = normalizeRedirectLocation(result.response.headers.get("Location"), new URL(request.url), basename, init.history) === state.location.pathname + state.location.search;
			await startRedirectNavigation(request, result, true, {
				submission,
				replace
			});
			return { shortCircuited: true };
		}
		if (isDeferredResult(result)) throw getInternalRouterError(400, { type: "defer-action" });
		if (isErrorResult(result)) {
			let boundaryMatch = findNearestBoundary(matches, actionMatch.route.id);
			if ((opts && opts.replace) !== true) pendingAction = Action.Push;
			return {
				matches,
				pendingActionResult: [boundaryMatch.route.id, result]
			};
		}
		return {
			matches,
			pendingActionResult: [actionMatch.route.id, result]
		};
	}
	async function handleLoaders(request, location, matches, isFogOfWar, overrideNavigation, submission, fetcherSubmission, replace, initialHydration, flushSync, pendingActionResult) {
		let loadingNavigation = overrideNavigation || getLoadingNavigation(location, submission);
		let activeSubmission = submission || fetcherSubmission || getSubmissionFromNavigation(loadingNavigation);
		let shouldUpdateNavigationState = !isUninterruptedRevalidation && (!future.v7_partialHydration || !initialHydration);
		if (isFogOfWar) {
			if (shouldUpdateNavigationState) {
				let actionData = getUpdatedActionData(pendingActionResult);
				updateState(_extends$2({ navigation: loadingNavigation }, actionData !== void 0 ? { actionData } : {}), { flushSync });
			}
			let discoverResult = await discoverRoutes(matches, location.pathname, request.signal);
			if (discoverResult.type === "aborted") return { shortCircuited: true };
			else if (discoverResult.type === "error") {
				let boundaryId = findNearestBoundary(discoverResult.partialMatches).route.id;
				return {
					matches: discoverResult.partialMatches,
					loaderData: {},
					errors: { [boundaryId]: discoverResult.error }
				};
			} else if (!discoverResult.matches) {
				let { error, notFoundMatches, route } = handleNavigational404(location.pathname);
				return {
					matches: notFoundMatches,
					loaderData: {},
					errors: { [route.id]: error }
				};
			} else matches = discoverResult.matches;
		}
		let routesToUse = inFlightDataRoutes || dataRoutes;
		let [matchesToLoad, revalidatingFetchers] = getMatchesToLoad(init.history, state, matches, activeSubmission, location, future.v7_partialHydration && initialHydration === true, future.v7_skipActionErrorRevalidation, isRevalidationRequired, cancelledDeferredRoutes, cancelledFetcherLoads, deletedFetchers, fetchLoadMatches, fetchRedirectIds, routesToUse, basename, pendingActionResult);
		cancelActiveDeferreds((routeId) => !(matches && matches.some((m) => m.route.id === routeId)) || matchesToLoad && matchesToLoad.some((m) => m.route.id === routeId));
		pendingNavigationLoadId = ++incrementingLoadId;
		if (matchesToLoad.length === 0 && revalidatingFetchers.length === 0) {
			let updatedFetchers = markFetchRedirectsDone();
			completeNavigation(location, _extends$2({
				matches,
				loaderData: {},
				errors: pendingActionResult && isErrorResult(pendingActionResult[1]) ? { [pendingActionResult[0]]: pendingActionResult[1].error } : null
			}, getActionDataForCommit(pendingActionResult), updatedFetchers ? { fetchers: new Map(state.fetchers) } : {}), { flushSync });
			return { shortCircuited: true };
		}
		if (shouldUpdateNavigationState) {
			let updates = {};
			if (!isFogOfWar) {
				updates.navigation = loadingNavigation;
				let actionData = getUpdatedActionData(pendingActionResult);
				if (actionData !== void 0) updates.actionData = actionData;
			}
			if (revalidatingFetchers.length > 0) updates.fetchers = getUpdatedRevalidatingFetchers(revalidatingFetchers);
			updateState(updates, { flushSync });
		}
		revalidatingFetchers.forEach((rf) => {
			abortFetcher(rf.key);
			if (rf.controller) fetchControllers.set(rf.key, rf.controller);
		});
		let abortPendingFetchRevalidations = () => revalidatingFetchers.forEach((f) => abortFetcher(f.key));
		if (pendingNavigationController) pendingNavigationController.signal.addEventListener("abort", abortPendingFetchRevalidations);
		let { loaderResults, fetcherResults } = await callLoadersAndMaybeResolveData(state, matches, matchesToLoad, revalidatingFetchers, request);
		if (request.signal.aborted) return { shortCircuited: true };
		if (pendingNavigationController) pendingNavigationController.signal.removeEventListener("abort", abortPendingFetchRevalidations);
		revalidatingFetchers.forEach((rf) => fetchControllers.delete(rf.key));
		let redirect = findRedirect(loaderResults);
		if (redirect) {
			await startRedirectNavigation(request, redirect.result, true, { replace });
			return { shortCircuited: true };
		}
		redirect = findRedirect(fetcherResults);
		if (redirect) {
			fetchRedirectIds.add(redirect.key);
			await startRedirectNavigation(request, redirect.result, true, { replace });
			return { shortCircuited: true };
		}
		let { loaderData, errors } = processLoaderData(state, matches, loaderResults, pendingActionResult, revalidatingFetchers, fetcherResults, activeDeferreds);
		activeDeferreds.forEach((deferredData, routeId) => {
			deferredData.subscribe((aborted) => {
				if (aborted || deferredData.done) activeDeferreds.delete(routeId);
			});
		});
		if (future.v7_partialHydration && initialHydration && state.errors) errors = _extends$2({}, state.errors, errors);
		let updatedFetchers = markFetchRedirectsDone();
		let didAbortFetchLoads = abortStaleFetchLoads(pendingNavigationLoadId);
		let shouldUpdateFetchers = updatedFetchers || didAbortFetchLoads || revalidatingFetchers.length > 0;
		return _extends$2({
			matches,
			loaderData,
			errors
		}, shouldUpdateFetchers ? { fetchers: new Map(state.fetchers) } : {});
	}
	function getUpdatedActionData(pendingActionResult) {
		if (pendingActionResult && !isErrorResult(pendingActionResult[1])) return { [pendingActionResult[0]]: pendingActionResult[1].data };
		else if (state.actionData) {
			if (Object.keys(state.actionData).length === 0) return null;
			else return state.actionData;
		}
	}
	function getUpdatedRevalidatingFetchers(revalidatingFetchers) {
		revalidatingFetchers.forEach((rf) => {
			let fetcher = state.fetchers.get(rf.key);
			let revalidatingFetcher = getLoadingFetcher(void 0, fetcher ? fetcher.data : void 0);
			state.fetchers.set(rf.key, revalidatingFetcher);
		});
		return new Map(state.fetchers);
	}
	function fetch(key, routeId, href, opts) {
		if (isServer) throw new Error("router.fetch() was called during the server render, but it shouldn't be. You are likely calling a useFetcher() method in the body of your component. Try moving it to a useEffect or a callback.");
		abortFetcher(key);
		let flushSync = (opts && opts.flushSync) === true;
		let routesToUse = inFlightDataRoutes || dataRoutes;
		let normalizedPath = normalizeTo(state.location, state.matches, basename, future.v7_prependBasename, href, future.v7_relativeSplatPath, routeId, opts == null ? void 0 : opts.relative);
		let matches = matchRoutes(routesToUse, normalizedPath, basename);
		let fogOfWar = checkFogOfWar(matches, routesToUse, normalizedPath);
		if (fogOfWar.active && fogOfWar.matches) matches = fogOfWar.matches;
		if (!matches) {
			setFetcherError(key, routeId, getInternalRouterError(404, { pathname: normalizedPath }), { flushSync });
			return;
		}
		let { path, submission, error } = normalizeNavigateOptions(future.v7_normalizeFormMethod, true, normalizedPath, opts);
		if (error) {
			setFetcherError(key, routeId, error, { flushSync });
			return;
		}
		let match = getTargetMatch(matches, path);
		let preventScrollReset = (opts && opts.preventScrollReset) === true;
		if (submission && isMutationMethod(submission.formMethod)) {
			handleFetcherAction(key, routeId, path, match, matches, fogOfWar.active, flushSync, preventScrollReset, submission);
			return;
		}
		fetchLoadMatches.set(key, {
			routeId,
			path
		});
		handleFetcherLoader(key, routeId, path, match, matches, fogOfWar.active, flushSync, preventScrollReset, submission);
	}
	async function handleFetcherAction(key, routeId, path, match, requestMatches, isFogOfWar, flushSync, preventScrollReset, submission) {
		interruptActiveLoads();
		fetchLoadMatches.delete(key);
		function detectAndHandle405Error(m) {
			if (!m.route.action && !m.route.lazy) {
				setFetcherError(key, routeId, getInternalRouterError(405, {
					method: submission.formMethod,
					pathname: path,
					routeId
				}), { flushSync });
				return true;
			}
			return false;
		}
		if (!isFogOfWar && detectAndHandle405Error(match)) return;
		updateFetcherState(key, getSubmittingFetcher(submission, state.fetchers.get(key)), { flushSync });
		let abortController = new AbortController();
		let fetchRequest = createClientSideRequest(init.history, path, abortController.signal, submission);
		if (isFogOfWar) {
			let discoverResult = await discoverRoutes(requestMatches, new URL(fetchRequest.url).pathname, fetchRequest.signal, key);
			if (discoverResult.type === "aborted") return;
			else if (discoverResult.type === "error") {
				setFetcherError(key, routeId, discoverResult.error, { flushSync });
				return;
			} else if (!discoverResult.matches) {
				setFetcherError(key, routeId, getInternalRouterError(404, { pathname: path }), { flushSync });
				return;
			} else {
				requestMatches = discoverResult.matches;
				match = getTargetMatch(requestMatches, path);
				if (detectAndHandle405Error(match)) return;
			}
		}
		fetchControllers.set(key, abortController);
		let originatingLoadId = incrementingLoadId;
		let actionResult = (await callDataStrategy("action", state, fetchRequest, [match], requestMatches, key))[match.route.id];
		if (fetchRequest.signal.aborted) {
			if (fetchControllers.get(key) === abortController) fetchControllers.delete(key);
			return;
		}
		if (future.v7_fetcherPersist && deletedFetchers.has(key)) {
			if (isRedirectResult(actionResult) || isErrorResult(actionResult)) {
				updateFetcherState(key, getDoneFetcher(void 0));
				return;
			}
		} else {
			if (isRedirectResult(actionResult)) {
				fetchControllers.delete(key);
				if (pendingNavigationLoadId > originatingLoadId) {
					updateFetcherState(key, getDoneFetcher(void 0));
					return;
				} else {
					fetchRedirectIds.add(key);
					updateFetcherState(key, getLoadingFetcher(submission));
					return startRedirectNavigation(fetchRequest, actionResult, false, {
						fetcherSubmission: submission,
						preventScrollReset
					});
				}
			}
			if (isErrorResult(actionResult)) {
				setFetcherError(key, routeId, actionResult.error);
				return;
			}
		}
		if (isDeferredResult(actionResult)) throw getInternalRouterError(400, { type: "defer-action" });
		let nextLocation = state.navigation.location || state.location;
		let revalidationRequest = createClientSideRequest(init.history, nextLocation, abortController.signal);
		let routesToUse = inFlightDataRoutes || dataRoutes;
		let matches = state.navigation.state !== "idle" ? matchRoutes(routesToUse, state.navigation.location, basename) : state.matches;
		invariant(matches, "Didn't find any matches after fetcher action");
		let loadId = ++incrementingLoadId;
		fetchReloadIds.set(key, loadId);
		let loadFetcher = getLoadingFetcher(submission, actionResult.data);
		state.fetchers.set(key, loadFetcher);
		let [matchesToLoad, revalidatingFetchers] = getMatchesToLoad(init.history, state, matches, submission, nextLocation, false, future.v7_skipActionErrorRevalidation, isRevalidationRequired, cancelledDeferredRoutes, cancelledFetcherLoads, deletedFetchers, fetchLoadMatches, fetchRedirectIds, routesToUse, basename, [match.route.id, actionResult]);
		revalidatingFetchers.filter((rf) => rf.key !== key).forEach((rf) => {
			let staleKey = rf.key;
			let existingFetcher = state.fetchers.get(staleKey);
			let revalidatingFetcher = getLoadingFetcher(void 0, existingFetcher ? existingFetcher.data : void 0);
			state.fetchers.set(staleKey, revalidatingFetcher);
			abortFetcher(staleKey);
			if (rf.controller) fetchControllers.set(staleKey, rf.controller);
		});
		updateState({ fetchers: new Map(state.fetchers) });
		let abortPendingFetchRevalidations = () => revalidatingFetchers.forEach((rf) => abortFetcher(rf.key));
		abortController.signal.addEventListener("abort", abortPendingFetchRevalidations);
		let { loaderResults, fetcherResults } = await callLoadersAndMaybeResolveData(state, matches, matchesToLoad, revalidatingFetchers, revalidationRequest);
		if (abortController.signal.aborted) return;
		abortController.signal.removeEventListener("abort", abortPendingFetchRevalidations);
		fetchReloadIds.delete(key);
		fetchControllers.delete(key);
		revalidatingFetchers.forEach((r) => fetchControllers.delete(r.key));
		let redirect = findRedirect(loaderResults);
		if (redirect) return startRedirectNavigation(revalidationRequest, redirect.result, false, { preventScrollReset });
		redirect = findRedirect(fetcherResults);
		if (redirect) {
			fetchRedirectIds.add(redirect.key);
			return startRedirectNavigation(revalidationRequest, redirect.result, false, { preventScrollReset });
		}
		let { loaderData, errors } = processLoaderData(state, matches, loaderResults, void 0, revalidatingFetchers, fetcherResults, activeDeferreds);
		if (state.fetchers.has(key)) {
			let doneFetcher = getDoneFetcher(actionResult.data);
			state.fetchers.set(key, doneFetcher);
		}
		abortStaleFetchLoads(loadId);
		if (state.navigation.state === "loading" && loadId > pendingNavigationLoadId) {
			invariant(pendingAction, "Expected pending action");
			pendingNavigationController && pendingNavigationController.abort();
			completeNavigation(state.navigation.location, {
				matches,
				loaderData,
				errors,
				fetchers: new Map(state.fetchers)
			});
		} else {
			updateState({
				errors,
				loaderData: mergeLoaderData(state.loaderData, loaderData, matches, errors),
				fetchers: new Map(state.fetchers)
			});
			isRevalidationRequired = false;
		}
	}
	async function handleFetcherLoader(key, routeId, path, match, matches, isFogOfWar, flushSync, preventScrollReset, submission) {
		let existingFetcher = state.fetchers.get(key);
		updateFetcherState(key, getLoadingFetcher(submission, existingFetcher ? existingFetcher.data : void 0), { flushSync });
		let abortController = new AbortController();
		let fetchRequest = createClientSideRequest(init.history, path, abortController.signal);
		if (isFogOfWar) {
			let discoverResult = await discoverRoutes(matches, new URL(fetchRequest.url).pathname, fetchRequest.signal, key);
			if (discoverResult.type === "aborted") return;
			else if (discoverResult.type === "error") {
				setFetcherError(key, routeId, discoverResult.error, { flushSync });
				return;
			} else if (!discoverResult.matches) {
				setFetcherError(key, routeId, getInternalRouterError(404, { pathname: path }), { flushSync });
				return;
			} else {
				matches = discoverResult.matches;
				match = getTargetMatch(matches, path);
			}
		}
		fetchControllers.set(key, abortController);
		let originatingLoadId = incrementingLoadId;
		let result = (await callDataStrategy("loader", state, fetchRequest, [match], matches, key))[match.route.id];
		if (isDeferredResult(result)) result = await resolveDeferredData(result, fetchRequest.signal, true) || result;
		if (fetchControllers.get(key) === abortController) fetchControllers.delete(key);
		if (fetchRequest.signal.aborted) return;
		if (deletedFetchers.has(key)) {
			updateFetcherState(key, getDoneFetcher(void 0));
			return;
		}
		if (isRedirectResult(result)) {
			if (pendingNavigationLoadId > originatingLoadId) {
				updateFetcherState(key, getDoneFetcher(void 0));
				return;
			} else {
				fetchRedirectIds.add(key);
				await startRedirectNavigation(fetchRequest, result, false, { preventScrollReset });
				return;
			}
		}
		if (isErrorResult(result)) {
			setFetcherError(key, routeId, result.error);
			return;
		}
		invariant(!isDeferredResult(result), "Unhandled fetcher deferred data");
		updateFetcherState(key, getDoneFetcher(result.data));
	}
	/**
	* Utility function to handle redirects returned from an action or loader.
	* Normally, a redirect "replaces" the navigation that triggered it.  So, for
	* example:
	*
	*  - user is on /a
	*  - user clicks a link to /b
	*  - loader for /b redirects to /c
	*
	* In a non-JS app the browser would track the in-flight navigation to /b and
	* then replace it with /c when it encountered the redirect response.  In
	* the end it would only ever update the URL bar with /c.
	*
	* In client-side routing using pushState/replaceState, we aim to emulate
	* this behavior and we also do not update history until the end of the
	* navigation (including processed redirects).  This means that we never
	* actually touch history until we've processed redirects, so we just use
	* the history action from the original navigation (PUSH or REPLACE).
	*/
	async function startRedirectNavigation(request, redirect, isNavigation, _temp2) {
		let { submission, fetcherSubmission, preventScrollReset, replace } = _temp2 === void 0 ? {} : _temp2;
		if (redirect.response.headers.has("X-Remix-Revalidate")) isRevalidationRequired = true;
		let location = redirect.response.headers.get("Location");
		invariant(location, "Expected a Location header on the redirect Response");
		location = normalizeRedirectLocation(location, new URL(request.url), basename, init.history);
		let redirectLocation = createLocation(state.location, location, { _isRedirect: true });
		if (isBrowser) {
			let isDocumentReload = false;
			if (redirect.response.headers.has("X-Remix-Reload-Document")) isDocumentReload = true;
			else if (ABSOLUTE_URL_REGEX$2.test(location)) {
				const url = init.history.createURL(location);
				isDocumentReload = url.origin !== routerWindow.location.origin || stripBasename(url.pathname, basename) == null;
			}
			if (isDocumentReload) {
				if (replace) routerWindow.location.replace(location);
				else routerWindow.location.assign(location);
				return;
			}
		}
		pendingNavigationController = null;
		let redirectHistoryAction = replace === true || redirect.response.headers.has("X-Remix-Replace") ? Action.Replace : Action.Push;
		let { formMethod, formAction, formEncType } = state.navigation;
		if (!submission && !fetcherSubmission && formMethod && formAction && formEncType) submission = getSubmissionFromNavigation(state.navigation);
		let activeSubmission = submission || fetcherSubmission;
		if (redirectPreserveMethodStatusCodes.has(redirect.response.status) && activeSubmission && isMutationMethod(activeSubmission.formMethod)) await startNavigation(redirectHistoryAction, redirectLocation, {
			submission: _extends$2({}, activeSubmission, { formAction: location }),
			preventScrollReset: preventScrollReset || pendingPreventScrollReset,
			enableViewTransition: isNavigation ? pendingViewTransitionEnabled : void 0
		});
		else await startNavigation(redirectHistoryAction, redirectLocation, {
			overrideNavigation: getLoadingNavigation(redirectLocation, submission),
			fetcherSubmission,
			preventScrollReset: preventScrollReset || pendingPreventScrollReset,
			enableViewTransition: isNavigation ? pendingViewTransitionEnabled : void 0
		});
	}
	async function callDataStrategy(type, state, request, matchesToLoad, matches, fetcherKey) {
		let results;
		let dataResults = {};
		try {
			results = await callDataStrategyImpl(dataStrategyImpl, type, state, request, matchesToLoad, matches, fetcherKey, manifest, mapRouteProperties);
		} catch (e) {
			matchesToLoad.forEach((m) => {
				dataResults[m.route.id] = {
					type: ResultType.error,
					error: e
				};
			});
			return dataResults;
		}
		for (let [routeId, result] of Object.entries(results)) if (isRedirectDataStrategyResultResult(result)) {
			let response = result.result;
			dataResults[routeId] = {
				type: ResultType.redirect,
				response: normalizeRelativeRoutingRedirectResponse(response, request, routeId, matches, basename, future.v7_relativeSplatPath)
			};
		} else dataResults[routeId] = await convertDataStrategyResultToDataResult(result);
		return dataResults;
	}
	async function callLoadersAndMaybeResolveData(state, matches, matchesToLoad, fetchersToLoad, request) {
		let currentMatches = state.matches;
		let loaderResultsPromise = callDataStrategy("loader", state, request, matchesToLoad, matches, null);
		let fetcherResultsPromise = Promise.all(fetchersToLoad.map(async (f) => {
			if (f.matches && f.match && f.controller) {
				let result = (await callDataStrategy("loader", state, createClientSideRequest(init.history, f.path, f.controller.signal), [f.match], f.matches, f.key))[f.match.route.id];
				return { [f.key]: result };
			} else return Promise.resolve({ [f.key]: {
				type: ResultType.error,
				error: getInternalRouterError(404, { pathname: f.path })
			} });
		}));
		let loaderResults = await loaderResultsPromise;
		let fetcherResults = (await fetcherResultsPromise).reduce((acc, r) => Object.assign(acc, r), {});
		await Promise.all([resolveNavigationDeferredResults(matches, loaderResults, request.signal, currentMatches, state.loaderData), resolveFetcherDeferredResults(matches, fetcherResults, fetchersToLoad)]);
		return {
			loaderResults,
			fetcherResults
		};
	}
	function interruptActiveLoads() {
		isRevalidationRequired = true;
		cancelledDeferredRoutes.push(...cancelActiveDeferreds());
		fetchLoadMatches.forEach((_, key) => {
			if (fetchControllers.has(key)) cancelledFetcherLoads.add(key);
			abortFetcher(key);
		});
	}
	function updateFetcherState(key, fetcher, opts) {
		if (opts === void 0) opts = {};
		state.fetchers.set(key, fetcher);
		updateState({ fetchers: new Map(state.fetchers) }, { flushSync: (opts && opts.flushSync) === true });
	}
	function setFetcherError(key, routeId, error, opts) {
		if (opts === void 0) opts = {};
		let boundaryMatch = findNearestBoundary(state.matches, routeId);
		deleteFetcher(key);
		updateState({
			errors: { [boundaryMatch.route.id]: error },
			fetchers: new Map(state.fetchers)
		}, { flushSync: (opts && opts.flushSync) === true });
	}
	function getFetcher(key) {
		activeFetchers.set(key, (activeFetchers.get(key) || 0) + 1);
		if (deletedFetchers.has(key)) deletedFetchers.delete(key);
		return state.fetchers.get(key) || IDLE_FETCHER;
	}
	function deleteFetcher(key) {
		let fetcher = state.fetchers.get(key);
		if (fetchControllers.has(key) && !(fetcher && fetcher.state === "loading" && fetchReloadIds.has(key))) abortFetcher(key);
		fetchLoadMatches.delete(key);
		fetchReloadIds.delete(key);
		fetchRedirectIds.delete(key);
		if (future.v7_fetcherPersist) deletedFetchers.delete(key);
		cancelledFetcherLoads.delete(key);
		state.fetchers.delete(key);
	}
	function deleteFetcherAndUpdateState(key) {
		let count = (activeFetchers.get(key) || 0) - 1;
		if (count <= 0) {
			activeFetchers.delete(key);
			deletedFetchers.add(key);
			if (!future.v7_fetcherPersist) deleteFetcher(key);
		} else activeFetchers.set(key, count);
		updateState({ fetchers: new Map(state.fetchers) });
	}
	function abortFetcher(key) {
		let controller = fetchControllers.get(key);
		if (controller) {
			controller.abort();
			fetchControllers.delete(key);
		}
	}
	function markFetchersDone(keys) {
		for (let key of keys) {
			let doneFetcher = getDoneFetcher(getFetcher(key).data);
			state.fetchers.set(key, doneFetcher);
		}
	}
	function markFetchRedirectsDone() {
		let doneKeys = [];
		let updatedFetchers = false;
		for (let key of fetchRedirectIds) {
			let fetcher = state.fetchers.get(key);
			invariant(fetcher, "Expected fetcher: " + key);
			if (fetcher.state === "loading") {
				fetchRedirectIds.delete(key);
				doneKeys.push(key);
				updatedFetchers = true;
			}
		}
		markFetchersDone(doneKeys);
		return updatedFetchers;
	}
	function abortStaleFetchLoads(landedId) {
		let yeetedKeys = [];
		for (let [key, id] of fetchReloadIds) if (id < landedId) {
			let fetcher = state.fetchers.get(key);
			invariant(fetcher, "Expected fetcher: " + key);
			if (fetcher.state === "loading") {
				abortFetcher(key);
				fetchReloadIds.delete(key);
				yeetedKeys.push(key);
			}
		}
		markFetchersDone(yeetedKeys);
		return yeetedKeys.length > 0;
	}
	function getBlocker(key, fn) {
		let blocker = state.blockers.get(key) || IDLE_BLOCKER;
		if (blockerFunctions.get(key) !== fn) blockerFunctions.set(key, fn);
		return blocker;
	}
	function deleteBlocker(key) {
		state.blockers.delete(key);
		blockerFunctions.delete(key);
	}
	function updateBlocker(key, newBlocker) {
		let blocker = state.blockers.get(key) || IDLE_BLOCKER;
		invariant(blocker.state === "unblocked" && newBlocker.state === "blocked" || blocker.state === "blocked" && newBlocker.state === "blocked" || blocker.state === "blocked" && newBlocker.state === "proceeding" || blocker.state === "blocked" && newBlocker.state === "unblocked" || blocker.state === "proceeding" && newBlocker.state === "unblocked", "Invalid blocker state transition: " + blocker.state + " -> " + newBlocker.state);
		let blockers = new Map(state.blockers);
		blockers.set(key, newBlocker);
		updateState({ blockers });
	}
	function shouldBlockNavigation(_ref2) {
		let { currentLocation, nextLocation, historyAction } = _ref2;
		if (blockerFunctions.size === 0) return;
		if (blockerFunctions.size > 1) warning(false, "A router only supports one blocker at a time");
		let entries = Array.from(blockerFunctions.entries());
		let [blockerKey, blockerFunction] = entries[entries.length - 1];
		let blocker = state.blockers.get(blockerKey);
		if (blocker && blocker.state === "proceeding") return;
		if (blockerFunction({
			currentLocation,
			nextLocation,
			historyAction
		})) return blockerKey;
	}
	function handleNavigational404(pathname) {
		let error = getInternalRouterError(404, { pathname });
		let { matches, route } = getShortCircuitMatches(inFlightDataRoutes || dataRoutes);
		cancelActiveDeferreds();
		return {
			notFoundMatches: matches,
			route,
			error
		};
	}
	function cancelActiveDeferreds(predicate) {
		let cancelledRouteIds = [];
		activeDeferreds.forEach((dfd, routeId) => {
			if (!predicate || predicate(routeId)) {
				dfd.cancel();
				cancelledRouteIds.push(routeId);
				activeDeferreds.delete(routeId);
			}
		});
		return cancelledRouteIds;
	}
	function enableScrollRestoration(positions, getPosition, getKey) {
		savedScrollPositions = positions;
		getScrollPosition = getPosition;
		getScrollRestorationKey = getKey || null;
		if (!initialScrollRestored && state.navigation === IDLE_NAVIGATION) {
			initialScrollRestored = true;
			let y = getSavedScrollPosition(state.location, state.matches);
			if (y != null) updateState({ restoreScrollPosition: y });
		}
		return () => {
			savedScrollPositions = null;
			getScrollPosition = null;
			getScrollRestorationKey = null;
		};
	}
	function getScrollKey(location, matches) {
		if (getScrollRestorationKey) return getScrollRestorationKey(location, matches.map((m) => convertRouteMatchToUiMatch(m, state.loaderData))) || location.key;
		return location.key;
	}
	function saveScrollPosition(location, matches) {
		if (savedScrollPositions && getScrollPosition) {
			let key = getScrollKey(location, matches);
			savedScrollPositions[key] = getScrollPosition();
		}
	}
	function getSavedScrollPosition(location, matches) {
		if (savedScrollPositions) {
			let key = getScrollKey(location, matches);
			let y = savedScrollPositions[key];
			if (typeof y === "number") return y;
		}
		return null;
	}
	function checkFogOfWar(matches, routesToUse, pathname) {
		if (patchRoutesOnNavigationImpl) {
			if (!matches) return {
				active: true,
				matches: matchRoutesImpl(routesToUse, pathname, basename, true) || []
			};
			else if (Object.keys(matches[0].params).length > 0) return {
				active: true,
				matches: matchRoutesImpl(routesToUse, pathname, basename, true)
			};
		}
		return {
			active: false,
			matches: null
		};
	}
	async function discoverRoutes(matches, pathname, signal, fetcherKey) {
		if (!patchRoutesOnNavigationImpl) return {
			type: "success",
			matches
		};
		let partialMatches = matches;
		while (true) {
			let isNonHMR = inFlightDataRoutes == null;
			let routesToUse = inFlightDataRoutes || dataRoutes;
			let localManifest = manifest;
			try {
				await patchRoutesOnNavigationImpl({
					signal,
					path: pathname,
					matches: partialMatches,
					fetcherKey,
					patch: (routeId, children) => {
						if (signal.aborted) return;
						patchRoutesImpl(routeId, children, routesToUse, localManifest, mapRouteProperties);
					}
				});
			} catch (e) {
				return {
					type: "error",
					error: e,
					partialMatches
				};
			} finally {
				if (isNonHMR && !signal.aborted) dataRoutes = [...dataRoutes];
			}
			if (signal.aborted) return { type: "aborted" };
			let newMatches = matchRoutes(routesToUse, pathname, basename);
			if (newMatches) return {
				type: "success",
				matches: newMatches
			};
			let newPartialMatches = matchRoutesImpl(routesToUse, pathname, basename, true);
			if (!newPartialMatches || partialMatches.length === newPartialMatches.length && partialMatches.every((m, i) => m.route.id === newPartialMatches[i].route.id)) return {
				type: "success",
				matches: null
			};
			partialMatches = newPartialMatches;
		}
	}
	function _internalSetRoutes(newRoutes) {
		manifest = {};
		inFlightDataRoutes = convertRoutesToDataRoutes(newRoutes, mapRouteProperties, void 0, manifest);
	}
	function patchRoutes(routeId, children) {
		let isNonHMR = inFlightDataRoutes == null;
		patchRoutesImpl(routeId, children, inFlightDataRoutes || dataRoutes, manifest, mapRouteProperties);
		if (isNonHMR) {
			dataRoutes = [...dataRoutes];
			updateState({});
		}
	}
	router = {
		get basename() {
			return basename;
		},
		get future() {
			return future;
		},
		get state() {
			return state;
		},
		get routes() {
			return dataRoutes;
		},
		get window() {
			return routerWindow;
		},
		initialize,
		subscribe,
		enableScrollRestoration,
		navigate,
		fetch,
		revalidate,
		createHref: (to) => init.history.createHref(to),
		encodeLocation: (to) => init.history.encodeLocation(to),
		getFetcher,
		deleteFetcher: deleteFetcherAndUpdateState,
		dispose,
		getBlocker,
		deleteBlocker,
		patchRoutes,
		_internalFetchControllers: fetchControllers,
		_internalActiveDeferreds: activeDeferreds,
		_internalSetRoutes
	};
	return router;
}
function isSubmissionNavigation(opts) {
	return opts != null && ("formData" in opts && opts.formData != null || "body" in opts && opts.body !== void 0);
}
function normalizeTo(location, matches, basename, prependBasename, to, v7_relativeSplatPath, fromRouteId, relative) {
	let contextualMatches;
	let activeRouteMatch;
	if (fromRouteId) {
		contextualMatches = [];
		for (let match of matches) {
			contextualMatches.push(match);
			if (match.route.id === fromRouteId) {
				activeRouteMatch = match;
				break;
			}
		}
	} else {
		contextualMatches = matches;
		activeRouteMatch = matches[matches.length - 1];
	}
	let path = resolveTo(to ? to : ".", getResolveToMatches(contextualMatches, v7_relativeSplatPath), stripBasename(location.pathname, basename) || location.pathname, relative === "path");
	if (to == null) {
		path.search = location.search;
		path.hash = location.hash;
	}
	if ((to == null || to === "" || to === ".") && activeRouteMatch) {
		let nakedIndex = hasNakedIndexQuery(path.search);
		if (activeRouteMatch.route.index && !nakedIndex) path.search = path.search ? path.search.replace(/^\?/, "?index&") : "?index";
		else if (!activeRouteMatch.route.index && nakedIndex) {
			let params = new URLSearchParams(path.search);
			let indexValues = params.getAll("index");
			params.delete("index");
			indexValues.filter((v) => v).forEach((v) => params.append("index", v));
			let qs = params.toString();
			path.search = qs ? "?" + qs : "";
		}
	}
	if (prependBasename && basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
	return createPath(path);
}
function normalizeNavigateOptions(normalizeFormMethod, isFetcher, path, opts) {
	if (!opts || !isSubmissionNavigation(opts)) return { path };
	if (opts.formMethod && !isValidMethod(opts.formMethod)) return {
		path,
		error: getInternalRouterError(405, { method: opts.formMethod })
	};
	let getInvalidBodyError = () => ({
		path,
		error: getInternalRouterError(400, { type: "invalid-body" })
	});
	let rawFormMethod = opts.formMethod || "get";
	let formMethod = normalizeFormMethod ? rawFormMethod.toUpperCase() : rawFormMethod.toLowerCase();
	let formAction = stripHashFromPath(path);
	if (opts.body !== void 0) {
		if (opts.formEncType === "text/plain") {
			if (!isMutationMethod(formMethod)) return getInvalidBodyError();
			let text = typeof opts.body === "string" ? opts.body : opts.body instanceof FormData || opts.body instanceof URLSearchParams ? Array.from(opts.body.entries()).reduce((acc, _ref3) => {
				let [name, value] = _ref3;
				return "" + acc + name + "=" + value + "\n";
			}, "") : String(opts.body);
			return {
				path,
				submission: {
					formMethod,
					formAction,
					formEncType: opts.formEncType,
					formData: void 0,
					json: void 0,
					text
				}
			};
		} else if (opts.formEncType === "application/json") {
			if (!isMutationMethod(formMethod)) return getInvalidBodyError();
			try {
				let json = typeof opts.body === "string" ? JSON.parse(opts.body) : opts.body;
				return {
					path,
					submission: {
						formMethod,
						formAction,
						formEncType: opts.formEncType,
						formData: void 0,
						json,
						text: void 0
					}
				};
			} catch (e) {
				return getInvalidBodyError();
			}
		}
	}
	invariant(typeof FormData === "function", "FormData is not available in this environment");
	let searchParams;
	let formData;
	if (opts.formData) {
		searchParams = convertFormDataToSearchParams(opts.formData);
		formData = opts.formData;
	} else if (opts.body instanceof FormData) {
		searchParams = convertFormDataToSearchParams(opts.body);
		formData = opts.body;
	} else if (opts.body instanceof URLSearchParams) {
		searchParams = opts.body;
		formData = convertSearchParamsToFormData(searchParams);
	} else if (opts.body == null) {
		searchParams = new URLSearchParams();
		formData = new FormData();
	} else try {
		searchParams = new URLSearchParams(opts.body);
		formData = convertSearchParamsToFormData(searchParams);
	} catch (e) {
		return getInvalidBodyError();
	}
	let submission = {
		formMethod,
		formAction,
		formEncType: opts && opts.formEncType || "application/x-www-form-urlencoded",
		formData,
		json: void 0,
		text: void 0
	};
	if (isMutationMethod(submission.formMethod)) return {
		path,
		submission
	};
	let parsedPath = parsePath(path);
	if (isFetcher && parsedPath.search && hasNakedIndexQuery(parsedPath.search)) searchParams.append("index", "");
	parsedPath.search = "?" + searchParams;
	return {
		path: createPath(parsedPath),
		submission
	};
}
function getLoaderMatchesUntilBoundary(matches, boundaryId, includeBoundary) {
	if (includeBoundary === void 0) includeBoundary = false;
	let index = matches.findIndex((m) => m.route.id === boundaryId);
	if (index >= 0) return matches.slice(0, includeBoundary ? index + 1 : index);
	return matches;
}
function getMatchesToLoad(history, state, matches, submission, location, initialHydration, skipActionErrorRevalidation, isRevalidationRequired, cancelledDeferredRoutes, cancelledFetcherLoads, deletedFetchers, fetchLoadMatches, fetchRedirectIds, routesToUse, basename, pendingActionResult) {
	let actionResult = pendingActionResult ? isErrorResult(pendingActionResult[1]) ? pendingActionResult[1].error : pendingActionResult[1].data : void 0;
	let currentUrl = history.createURL(state.location);
	let nextUrl = history.createURL(location);
	let boundaryMatches = matches;
	if (initialHydration && state.errors) boundaryMatches = getLoaderMatchesUntilBoundary(matches, Object.keys(state.errors)[0], true);
	else if (pendingActionResult && isErrorResult(pendingActionResult[1])) boundaryMatches = getLoaderMatchesUntilBoundary(matches, pendingActionResult[0]);
	let actionStatus = pendingActionResult ? pendingActionResult[1].statusCode : void 0;
	let shouldSkipRevalidation = skipActionErrorRevalidation && actionStatus && actionStatus >= 400;
	let navigationMatches = boundaryMatches.filter((match, index) => {
		let { route } = match;
		if (route.lazy) return true;
		if (route.loader == null) return false;
		if (initialHydration) return shouldLoadRouteOnHydration(route, state.loaderData, state.errors);
		if (isNewLoader(state.loaderData, state.matches[index], match) || cancelledDeferredRoutes.some((id) => id === match.route.id)) return true;
		let currentRouteMatch = state.matches[index];
		let nextRouteMatch = match;
		return shouldRevalidateLoader(match, _extends$2({
			currentUrl,
			currentParams: currentRouteMatch.params,
			nextUrl,
			nextParams: nextRouteMatch.params
		}, submission, {
			actionResult,
			actionStatus,
			defaultShouldRevalidate: shouldSkipRevalidation ? false : isRevalidationRequired || currentUrl.pathname + currentUrl.search === nextUrl.pathname + nextUrl.search || currentUrl.search !== nextUrl.search || isNewRouteInstance(currentRouteMatch, nextRouteMatch)
		}));
	});
	let revalidatingFetchers = [];
	fetchLoadMatches.forEach((f, key) => {
		if (initialHydration || !matches.some((m) => m.route.id === f.routeId) || deletedFetchers.has(key)) return;
		let fetcherMatches = matchRoutes(routesToUse, f.path, basename);
		if (!fetcherMatches) {
			revalidatingFetchers.push({
				key,
				routeId: f.routeId,
				path: f.path,
				matches: null,
				match: null,
				controller: null
			});
			return;
		}
		let fetcher = state.fetchers.get(key);
		let fetcherMatch = getTargetMatch(fetcherMatches, f.path);
		let shouldRevalidate = false;
		if (fetchRedirectIds.has(key)) shouldRevalidate = false;
		else if (cancelledFetcherLoads.has(key)) {
			cancelledFetcherLoads.delete(key);
			shouldRevalidate = true;
		} else if (fetcher && fetcher.state !== "idle" && fetcher.data === void 0) shouldRevalidate = isRevalidationRequired;
		else shouldRevalidate = shouldRevalidateLoader(fetcherMatch, _extends$2({
			currentUrl,
			currentParams: state.matches[state.matches.length - 1].params,
			nextUrl,
			nextParams: matches[matches.length - 1].params
		}, submission, {
			actionResult,
			actionStatus,
			defaultShouldRevalidate: shouldSkipRevalidation ? false : isRevalidationRequired
		}));
		if (shouldRevalidate) revalidatingFetchers.push({
			key,
			routeId: f.routeId,
			path: f.path,
			matches: fetcherMatches,
			match: fetcherMatch,
			controller: new AbortController()
		});
	});
	return [navigationMatches, revalidatingFetchers];
}
function shouldLoadRouteOnHydration(route, loaderData, errors) {
	if (route.lazy) return true;
	if (!route.loader) return false;
	let hasData = loaderData != null && loaderData[route.id] !== void 0;
	let hasError = errors != null && errors[route.id] !== void 0;
	if (!hasData && hasError) return false;
	if (typeof route.loader === "function" && route.loader.hydrate === true) return true;
	return !hasData && !hasError;
}
function isNewLoader(currentLoaderData, currentMatch, match) {
	let isNew = !currentMatch || match.route.id !== currentMatch.route.id;
	let isMissingData = currentLoaderData[match.route.id] === void 0;
	return isNew || isMissingData;
}
function isNewRouteInstance(currentMatch, match) {
	let currentPath = currentMatch.route.path;
	return currentMatch.pathname !== match.pathname || currentPath != null && currentPath.endsWith("*") && currentMatch.params["*"] !== match.params["*"];
}
function shouldRevalidateLoader(loaderMatch, arg) {
	if (loaderMatch.route.shouldRevalidate) {
		let routeChoice = loaderMatch.route.shouldRevalidate(arg);
		if (typeof routeChoice === "boolean") return routeChoice;
	}
	return arg.defaultShouldRevalidate;
}
function patchRoutesImpl(routeId, children, routesToUse, manifest, mapRouteProperties) {
	var _childrenToPatch;
	let childrenToPatch;
	if (routeId) {
		let route = manifest[routeId];
		invariant(route, "No route found to patch children into: routeId = " + routeId);
		if (!route.children) route.children = [];
		childrenToPatch = route.children;
	} else childrenToPatch = routesToUse;
	let newRoutes = convertRoutesToDataRoutes(children.filter((newRoute) => !childrenToPatch.some((existingRoute) => isSameRoute(newRoute, existingRoute))), mapRouteProperties, [
		routeId || "_",
		"patch",
		String(((_childrenToPatch = childrenToPatch) == null ? void 0 : _childrenToPatch.length) || "0")
	], manifest);
	childrenToPatch.push(...newRoutes);
}
function isSameRoute(newRoute, existingRoute) {
	if ("id" in newRoute && "id" in existingRoute && newRoute.id === existingRoute.id) return true;
	if (!(newRoute.index === existingRoute.index && newRoute.path === existingRoute.path && newRoute.caseSensitive === existingRoute.caseSensitive)) return false;
	if ((!newRoute.children || newRoute.children.length === 0) && (!existingRoute.children || existingRoute.children.length === 0)) return true;
	return newRoute.children.every((aChild, i) => {
		var _existingRoute$childr;
		return (_existingRoute$childr = existingRoute.children) == null ? void 0 : _existingRoute$childr.some((bChild) => isSameRoute(aChild, bChild));
	});
}
/**
* Execute route.lazy() methods to lazily load route modules (loader, action,
* shouldRevalidate) and update the routeManifest in place which shares objects
* with dataRoutes so those get updated as well.
*/
async function loadLazyRouteModule(route, mapRouteProperties, manifest) {
	if (!route.lazy) return;
	let lazyRoute = await route.lazy();
	if (!route.lazy) return;
	let routeToUpdate = manifest[route.id];
	invariant(routeToUpdate, "No route found in manifest");
	let routeUpdates = {};
	for (let lazyRouteProperty in lazyRoute) {
		let isPropertyStaticallyDefined = routeToUpdate[lazyRouteProperty] !== void 0 && lazyRouteProperty !== "hasErrorBoundary";
		warning(!isPropertyStaticallyDefined, "Route \"" + routeToUpdate.id + "\" has a static property \"" + lazyRouteProperty + "\" defined but its lazy function is also returning a value for this property. " + ("The lazy route property \"" + lazyRouteProperty + "\" will be ignored."));
		if (!isPropertyStaticallyDefined && !immutableRouteKeys.has(lazyRouteProperty)) routeUpdates[lazyRouteProperty] = lazyRoute[lazyRouteProperty];
	}
	Object.assign(routeToUpdate, routeUpdates);
	Object.assign(routeToUpdate, _extends$2({}, mapRouteProperties(routeToUpdate), { lazy: void 0 }));
}
async function defaultDataStrategy(_ref4) {
	let { matches } = _ref4;
	let matchesToLoad = matches.filter((m) => m.shouldLoad);
	return (await Promise.all(matchesToLoad.map((m) => m.resolve()))).reduce((acc, result, i) => Object.assign(acc, { [matchesToLoad[i].route.id]: result }), {});
}
async function callDataStrategyImpl(dataStrategyImpl, type, state, request, matchesToLoad, matches, fetcherKey, manifest, mapRouteProperties, requestContext) {
	let loadRouteDefinitionsPromises = matches.map((m) => m.route.lazy ? loadLazyRouteModule(m.route, mapRouteProperties, manifest) : void 0);
	let results = await dataStrategyImpl({
		matches: matches.map((match, i) => {
			let loadRoutePromise = loadRouteDefinitionsPromises[i];
			let shouldLoad = matchesToLoad.some((m) => m.route.id === match.route.id);
			let resolve = async (handlerOverride) => {
				if (handlerOverride && request.method === "GET" && (match.route.lazy || match.route.loader)) shouldLoad = true;
				return shouldLoad ? callLoaderOrAction(type, request, match, loadRoutePromise, handlerOverride, requestContext) : Promise.resolve({
					type: ResultType.data,
					result: void 0
				});
			};
			return _extends$2({}, match, {
				shouldLoad,
				resolve
			});
		}),
		request,
		params: matches[0].params,
		fetcherKey,
		context: requestContext
	});
	try {
		await Promise.all(loadRouteDefinitionsPromises);
	} catch (e) {}
	return results;
}
async function callLoaderOrAction(type, request, match, loadRoutePromise, handlerOverride, staticContext) {
	let result;
	let onReject;
	let runHandler = (handler) => {
		let reject;
		let abortPromise = new Promise((_, r) => reject = r);
		onReject = () => reject();
		request.signal.addEventListener("abort", onReject);
		let actualHandler = (ctx) => {
			if (typeof handler !== "function") return Promise.reject(/* @__PURE__ */ new Error("You cannot call the handler for a route which defines a boolean " + ("\"" + type + "\" [routeId: " + match.route.id + "]")));
			return handler({
				request,
				params: match.params,
				context: staticContext
			}, ...ctx !== void 0 ? [ctx] : []);
		};
		let handlerPromise = (async () => {
			try {
				return {
					type: "data",
					result: await (handlerOverride ? handlerOverride((ctx) => actualHandler(ctx)) : actualHandler())
				};
			} catch (e) {
				return {
					type: "error",
					result: e
				};
			}
		})();
		return Promise.race([handlerPromise, abortPromise]);
	};
	try {
		let handler = match.route[type];
		if (loadRoutePromise) {
			if (handler) {
				let handlerError;
				let [value] = await Promise.all([runHandler(handler).catch((e) => {
					handlerError = e;
				}), loadRoutePromise]);
				if (handlerError !== void 0) throw handlerError;
				result = value;
			} else {
				await loadRoutePromise;
				handler = match.route[type];
				if (handler) result = await runHandler(handler);
				else if (type === "action") {
					let url = new URL(request.url);
					let pathname = url.pathname + url.search;
					throw getInternalRouterError(405, {
						method: request.method,
						pathname,
						routeId: match.route.id
					});
				} else return {
					type: ResultType.data,
					result: void 0
				};
			}
		} else if (!handler) {
			let url = new URL(request.url);
			throw getInternalRouterError(404, { pathname: url.pathname + url.search });
		} else result = await runHandler(handler);
		invariant(result.result !== void 0, "You defined " + (type === "action" ? "an action" : "a loader") + " for route " + ("\"" + match.route.id + "\" but didn't return anything from your `" + type + "` ") + "function. Please return a value or `null`.");
	} catch (e) {
		return {
			type: ResultType.error,
			result: e
		};
	} finally {
		if (onReject) request.signal.removeEventListener("abort", onReject);
	}
	return result;
}
async function convertDataStrategyResultToDataResult(dataStrategyResult) {
	let { result, type } = dataStrategyResult;
	if (isResponse(result)) {
		let data;
		try {
			let contentType = result.headers.get("Content-Type");
			if (contentType && /\bapplication\/json\b/.test(contentType)) {
				if (result.body == null) data = null;
				else data = await result.json();
			} else data = await result.text();
		} catch (e) {
			return {
				type: ResultType.error,
				error: e
			};
		}
		if (type === ResultType.error) return {
			type: ResultType.error,
			error: new ErrorResponseImpl(result.status, result.statusText, data),
			statusCode: result.status,
			headers: result.headers
		};
		return {
			type: ResultType.data,
			data,
			statusCode: result.status,
			headers: result.headers
		};
	}
	if (type === ResultType.error) {
		if (isDataWithResponseInit(result)) {
			var _result$init3, _result$init4;
			if (result.data instanceof Error) {
				var _result$init, _result$init2;
				return {
					type: ResultType.error,
					error: result.data,
					statusCode: (_result$init = result.init) == null ? void 0 : _result$init.status,
					headers: (_result$init2 = result.init) != null && _result$init2.headers ? new Headers(result.init.headers) : void 0
				};
			}
			return {
				type: ResultType.error,
				error: new ErrorResponseImpl(((_result$init3 = result.init) == null ? void 0 : _result$init3.status) || 500, void 0, result.data),
				statusCode: isRouteErrorResponse(result) ? result.status : void 0,
				headers: (_result$init4 = result.init) != null && _result$init4.headers ? new Headers(result.init.headers) : void 0
			};
		}
		return {
			type: ResultType.error,
			error: result,
			statusCode: isRouteErrorResponse(result) ? result.status : void 0
		};
	}
	if (isDeferredData(result)) {
		var _result$init5, _result$init6;
		return {
			type: ResultType.deferred,
			deferredData: result,
			statusCode: (_result$init5 = result.init) == null ? void 0 : _result$init5.status,
			headers: ((_result$init6 = result.init) == null ? void 0 : _result$init6.headers) && new Headers(result.init.headers)
		};
	}
	if (isDataWithResponseInit(result)) {
		var _result$init7, _result$init8;
		return {
			type: ResultType.data,
			data: result.data,
			statusCode: (_result$init7 = result.init) == null ? void 0 : _result$init7.status,
			headers: (_result$init8 = result.init) != null && _result$init8.headers ? new Headers(result.init.headers) : void 0
		};
	}
	return {
		type: ResultType.data,
		data: result
	};
}
function normalizeRelativeRoutingRedirectResponse(response, request, routeId, matches, basename, v7_relativeSplatPath) {
	let location = response.headers.get("Location");
	invariant(location, "Redirects returned/thrown from loaders/actions must have a Location header");
	if (!ABSOLUTE_URL_REGEX$2.test(location)) {
		let trimmedMatches = matches.slice(0, matches.findIndex((m) => m.route.id === routeId) + 1);
		location = normalizeTo(new URL(request.url), trimmedMatches, basename, true, location, v7_relativeSplatPath);
		response.headers.set("Location", location);
	}
	return response;
}
function normalizeRedirectLocation(location, currentUrl, basename, historyInstance) {
	let invalidProtocols = [
		"about:",
		"blob:",
		"chrome:",
		"chrome-untrusted:",
		"content:",
		"data:",
		"devtools:",
		"file:",
		"filesystem:",
		"javascript:"
	];
	if (ABSOLUTE_URL_REGEX$2.test(location)) {
		let normalizedLocation = location;
		let url = normalizedLocation.startsWith("//") ? new URL(currentUrl.protocol + normalizedLocation) : new URL(normalizedLocation);
		if (invalidProtocols.includes(url.protocol)) throw new Error("Invalid redirect location");
		let isSameBasename = stripBasename(url.pathname, basename) != null;
		if (url.origin === currentUrl.origin && isSameBasename) return removeDoubleSlashes(url.pathname) + url.search + url.hash;
	}
	try {
		let url = historyInstance.createURL(location);
		if (invalidProtocols.includes(url.protocol)) throw new Error("Invalid redirect location");
	} catch (e) {}
	return location;
}
function createClientSideRequest(history, location, signal, submission) {
	let url = history.createURL(stripHashFromPath(location)).toString();
	let init = { signal };
	if (submission && isMutationMethod(submission.formMethod)) {
		let { formMethod, formEncType } = submission;
		init.method = formMethod.toUpperCase();
		if (formEncType === "application/json") {
			init.headers = new Headers({ "Content-Type": formEncType });
			init.body = JSON.stringify(submission.json);
		} else if (formEncType === "text/plain") init.body = submission.text;
		else if (formEncType === "application/x-www-form-urlencoded" && submission.formData) init.body = convertFormDataToSearchParams(submission.formData);
		else init.body = submission.formData;
	}
	return new Request(url, init);
}
function convertFormDataToSearchParams(formData) {
	let searchParams = new URLSearchParams();
	for (let [key, value] of formData.entries()) searchParams.append(key, typeof value === "string" ? value : value.name);
	return searchParams;
}
function convertSearchParamsToFormData(searchParams) {
	let formData = new FormData();
	for (let [key, value] of searchParams.entries()) formData.append(key, value);
	return formData;
}
function processRouteLoaderData(matches, results, pendingActionResult, activeDeferreds, skipLoaderErrorBubbling) {
	let loaderData = {};
	let errors = null;
	let statusCode;
	let foundError = false;
	let loaderHeaders = {};
	let pendingError = pendingActionResult && isErrorResult(pendingActionResult[1]) ? pendingActionResult[1].error : void 0;
	matches.forEach((match) => {
		if (!(match.route.id in results)) return;
		let id = match.route.id;
		let result = results[id];
		invariant(!isRedirectResult(result), "Cannot handle redirect results in processLoaderData");
		if (isErrorResult(result)) {
			let error = result.error;
			if (pendingError !== void 0) {
				error = pendingError;
				pendingError = void 0;
			}
			errors = errors || {};
			if (skipLoaderErrorBubbling) errors[id] = error;
			else {
				let boundaryMatch = findNearestBoundary(matches, id);
				if (errors[boundaryMatch.route.id] == null) errors[boundaryMatch.route.id] = error;
			}
			loaderData[id] = void 0;
			if (!foundError) {
				foundError = true;
				statusCode = isRouteErrorResponse(result.error) ? result.error.status : 500;
			}
			if (result.headers) loaderHeaders[id] = result.headers;
		} else if (isDeferredResult(result)) {
			activeDeferreds.set(id, result.deferredData);
			loaderData[id] = result.deferredData.data;
			if (result.statusCode != null && result.statusCode !== 200 && !foundError) statusCode = result.statusCode;
			if (result.headers) loaderHeaders[id] = result.headers;
		} else {
			loaderData[id] = result.data;
			if (result.statusCode && result.statusCode !== 200 && !foundError) statusCode = result.statusCode;
			if (result.headers) loaderHeaders[id] = result.headers;
		}
	});
	if (pendingError !== void 0 && pendingActionResult) {
		errors = { [pendingActionResult[0]]: pendingError };
		loaderData[pendingActionResult[0]] = void 0;
	}
	return {
		loaderData,
		errors,
		statusCode: statusCode || 200,
		loaderHeaders
	};
}
function processLoaderData(state, matches, results, pendingActionResult, revalidatingFetchers, fetcherResults, activeDeferreds) {
	let { loaderData, errors } = processRouteLoaderData(matches, results, pendingActionResult, activeDeferreds, false);
	revalidatingFetchers.forEach((rf) => {
		let { key, match, controller } = rf;
		let result = fetcherResults[key];
		invariant(result, "Did not find corresponding fetcher result");
		if (controller && controller.signal.aborted) return;
		else if (isErrorResult(result)) {
			let boundaryMatch = findNearestBoundary(state.matches, match == null ? void 0 : match.route.id);
			if (!(errors && errors[boundaryMatch.route.id])) errors = _extends$2({}, errors, { [boundaryMatch.route.id]: result.error });
			state.fetchers.delete(key);
		} else if (isRedirectResult(result)) invariant(false, "Unhandled fetcher revalidation redirect");
		else if (isDeferredResult(result)) invariant(false, "Unhandled fetcher deferred data");
		else {
			let doneFetcher = getDoneFetcher(result.data);
			state.fetchers.set(key, doneFetcher);
		}
	});
	return {
		loaderData,
		errors
	};
}
function mergeLoaderData(loaderData, newLoaderData, matches, errors) {
	let mergedLoaderData = _extends$2({}, newLoaderData);
	for (let match of matches) {
		let id = match.route.id;
		if (newLoaderData.hasOwnProperty(id)) {
			if (newLoaderData[id] !== void 0) mergedLoaderData[id] = newLoaderData[id];
		} else if (loaderData[id] !== void 0 && match.route.loader) mergedLoaderData[id] = loaderData[id];
		if (errors && errors.hasOwnProperty(id)) break;
	}
	return mergedLoaderData;
}
function getActionDataForCommit(pendingActionResult) {
	if (!pendingActionResult) return {};
	return isErrorResult(pendingActionResult[1]) ? { actionData: {} } : { actionData: { [pendingActionResult[0]]: pendingActionResult[1].data } };
}
function findNearestBoundary(matches, routeId) {
	return (routeId ? matches.slice(0, matches.findIndex((m) => m.route.id === routeId) + 1) : [...matches]).reverse().find((m) => m.route.hasErrorBoundary === true) || matches[0];
}
function getShortCircuitMatches(routes) {
	let route = routes.length === 1 ? routes[0] : routes.find((r) => r.index || !r.path || r.path === "/") || { id: "__shim-error-route__" };
	return {
		matches: [{
			params: {},
			pathname: "",
			pathnameBase: "",
			route
		}],
		route
	};
}
function getInternalRouterError(status, _temp5) {
	let { pathname, routeId, method, type, message } = _temp5 === void 0 ? {} : _temp5;
	let statusText = "Unknown Server Error";
	let errorMessage = "Unknown @remix-run/router error";
	if (status === 400) {
		statusText = "Bad Request";
		if (method && pathname && routeId) errorMessage = "You made a " + method + " request to \"" + pathname + "\" but " + ("did not provide a `loader` for route \"" + routeId + "\", ") + "so there is no way to handle the request.";
		else if (type === "defer-action") errorMessage = "defer() is not supported in actions";
		else if (type === "invalid-body") errorMessage = "Unable to encode submission body";
	} else if (status === 403) {
		statusText = "Forbidden";
		errorMessage = "Route \"" + routeId + "\" does not match URL \"" + pathname + "\"";
	} else if (status === 404) {
		statusText = "Not Found";
		errorMessage = "No route matches URL \"" + pathname + "\"";
	} else if (status === 405) {
		statusText = "Method Not Allowed";
		if (method && pathname && routeId) errorMessage = "You made a " + method.toUpperCase() + " request to \"" + pathname + "\" but " + ("did not provide an `action` for route \"" + routeId + "\", ") + "so there is no way to handle the request.";
		else if (method) errorMessage = "Invalid request method \"" + method.toUpperCase() + "\"";
	}
	return new ErrorResponseImpl(status || 500, statusText, new Error(errorMessage), true);
}
function findRedirect(results) {
	let entries = Object.entries(results);
	for (let i = entries.length - 1; i >= 0; i--) {
		let [key, result] = entries[i];
		if (isRedirectResult(result)) return {
			key,
			result
		};
	}
}
function stripHashFromPath(path) {
	let parsedPath = typeof path === "string" ? parsePath(path) : path;
	return createPath(_extends$2({}, parsedPath, { hash: "" }));
}
function isHashChangeOnly(a, b) {
	if (a.pathname !== b.pathname || a.search !== b.search) return false;
	if (a.hash === "") return b.hash !== "";
	else if (a.hash === b.hash) return true;
	else if (b.hash !== "") return true;
	return false;
}
function isRedirectDataStrategyResultResult(result) {
	return isResponse(result.result) && redirectStatusCodes.has(result.result.status);
}
function isDeferredResult(result) {
	return result.type === ResultType.deferred;
}
function isErrorResult(result) {
	return result.type === ResultType.error;
}
function isRedirectResult(result) {
	return (result && result.type) === ResultType.redirect;
}
function isDataWithResponseInit(value) {
	return typeof value === "object" && value != null && "type" in value && "data" in value && "init" in value && value.type === "DataWithResponseInit";
}
function isDeferredData(value) {
	let deferred = value;
	return deferred && typeof deferred === "object" && typeof deferred.data === "object" && typeof deferred.subscribe === "function" && typeof deferred.cancel === "function" && typeof deferred.resolveData === "function";
}
function isResponse(value) {
	return value != null && typeof value.status === "number" && typeof value.statusText === "string" && typeof value.headers === "object" && typeof value.body !== "undefined";
}
function isValidMethod(method) {
	return validRequestMethods.has(method.toLowerCase());
}
function isMutationMethod(method) {
	return validMutationMethods.has(method.toLowerCase());
}
async function resolveNavigationDeferredResults(matches, results, signal, currentMatches, currentLoaderData) {
	let entries = Object.entries(results);
	for (let index = 0; index < entries.length; index++) {
		let [routeId, result] = entries[index];
		let match = matches.find((m) => (m == null ? void 0 : m.route.id) === routeId);
		if (!match) continue;
		let currentMatch = currentMatches.find((m) => m.route.id === match.route.id);
		let isRevalidatingLoader = currentMatch != null && !isNewRouteInstance(currentMatch, match) && (currentLoaderData && currentLoaderData[match.route.id]) !== void 0;
		if (isDeferredResult(result) && isRevalidatingLoader) await resolveDeferredData(result, signal, false).then((result) => {
			if (result) results[routeId] = result;
		});
	}
}
async function resolveFetcherDeferredResults(matches, results, revalidatingFetchers) {
	for (let index = 0; index < revalidatingFetchers.length; index++) {
		let { key, routeId, controller } = revalidatingFetchers[index];
		let result = results[key];
		if (!matches.find((m) => (m == null ? void 0 : m.route.id) === routeId)) continue;
		if (isDeferredResult(result)) {
			invariant(controller, "Expected an AbortController for revalidating fetcher deferred result");
			await resolveDeferredData(result, controller.signal, true).then((result) => {
				if (result) results[key] = result;
			});
		}
	}
}
async function resolveDeferredData(result, signal, unwrap) {
	if (unwrap === void 0) unwrap = false;
	if (await result.deferredData.resolveData(signal)) return;
	if (unwrap) try {
		return {
			type: ResultType.data,
			data: result.deferredData.unwrappedData
		};
	} catch (e) {
		return {
			type: ResultType.error,
			error: e
		};
	}
	return {
		type: ResultType.data,
		data: result.deferredData.data
	};
}
function hasNakedIndexQuery(search) {
	return new URLSearchParams(search).getAll("index").some((v) => v === "");
}
function getTargetMatch(matches, location) {
	let search = typeof location === "string" ? parsePath(location).search : location.search;
	if (matches[matches.length - 1].route.index && hasNakedIndexQuery(search || "")) return matches[matches.length - 1];
	let pathMatches = getPathContributingMatches(matches);
	return pathMatches[pathMatches.length - 1];
}
function getSubmissionFromNavigation(navigation) {
	let { formMethod, formAction, formEncType, text, formData, json } = navigation;
	if (!formMethod || !formAction || !formEncType) return;
	if (text != null) return {
		formMethod,
		formAction,
		formEncType,
		formData: void 0,
		json: void 0,
		text
	};
	else if (formData != null) return {
		formMethod,
		formAction,
		formEncType,
		formData,
		json: void 0,
		text: void 0
	};
	else if (json !== void 0) return {
		formMethod,
		formAction,
		formEncType,
		formData: void 0,
		json,
		text: void 0
	};
}
function getLoadingNavigation(location, submission) {
	if (submission) return {
		state: "loading",
		location,
		formMethod: submission.formMethod,
		formAction: submission.formAction,
		formEncType: submission.formEncType,
		formData: submission.formData,
		json: submission.json,
		text: submission.text
	};
	else return {
		state: "loading",
		location,
		formMethod: void 0,
		formAction: void 0,
		formEncType: void 0,
		formData: void 0,
		json: void 0,
		text: void 0
	};
}
function getSubmittingNavigation(location, submission) {
	return {
		state: "submitting",
		location,
		formMethod: submission.formMethod,
		formAction: submission.formAction,
		formEncType: submission.formEncType,
		formData: submission.formData,
		json: submission.json,
		text: submission.text
	};
}
function getLoadingFetcher(submission, data) {
	if (submission) return {
		state: "loading",
		formMethod: submission.formMethod,
		formAction: submission.formAction,
		formEncType: submission.formEncType,
		formData: submission.formData,
		json: submission.json,
		text: submission.text,
		data
	};
	else return {
		state: "loading",
		formMethod: void 0,
		formAction: void 0,
		formEncType: void 0,
		formData: void 0,
		json: void 0,
		text: void 0,
		data
	};
}
function getSubmittingFetcher(submission, existingFetcher) {
	return {
		state: "submitting",
		formMethod: submission.formMethod,
		formAction: submission.formAction,
		formEncType: submission.formEncType,
		formData: submission.formData,
		json: submission.json,
		text: submission.text,
		data: existingFetcher ? existingFetcher.data : void 0
	};
}
function getDoneFetcher(data) {
	return {
		state: "idle",
		formMethod: void 0,
		formAction: void 0,
		formEncType: void 0,
		formData: void 0,
		json: void 0,
		text: void 0,
		data
	};
}
function restoreAppliedTransitions(_window, transitions) {
	try {
		let sessionPositions = _window.sessionStorage.getItem(TRANSITIONS_STORAGE_KEY);
		if (sessionPositions) {
			let json = JSON.parse(sessionPositions);
			for (let [k, v] of Object.entries(json || {})) if (v && Array.isArray(v)) transitions.set(k, new Set(v || []));
		}
	} catch (e) {}
}
function persistAppliedTransitions(_window, transitions) {
	if (transitions.size > 0) {
		let json = {};
		for (let [k, v] of transitions) json[k] = [...v];
		try {
			_window.sessionStorage.setItem(TRANSITIONS_STORAGE_KEY, JSON.stringify(json));
		} catch (error) {
			warning(false, "Failed to save applied view transitions in sessionStorage (" + error + ").");
		}
	}
}
//#endregion
//#region node_modules/react-router/dist/index.js
/**
* React Router v6.30.4
*
* Copyright (c) Remix Software Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE.md file in the root directory of this source tree.
*
* @license MIT
*/
function _extends$1() {
	return _extends$1 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$1.apply(null, arguments);
}
var DataRouterContext = /*#__PURE__*/ import_react.createContext(null);
DataRouterContext.displayName = "DataRouter";
var DataRouterStateContext = /*#__PURE__*/ import_react.createContext(null);
DataRouterStateContext.displayName = "DataRouterState";
var AwaitContext = /*#__PURE__*/ import_react.createContext(null);
AwaitContext.displayName = "Await";
/**
* A Navigator is a "location changer"; it's how you get to different locations.
*
* Every history instance conforms to the Navigator interface, but the
* distinction is useful primarily when it comes to the low-level `<Router>` API
* where both the location and a navigator must be provided separately in order
* to avoid "tearing" that may occur in a suspense-enabled app if the action
* and/or location were to be read directly from the history instance.
*/
var NavigationContext = /*#__PURE__*/ import_react.createContext(null);
NavigationContext.displayName = "Navigation";
var LocationContext = /*#__PURE__*/ import_react.createContext(null);
LocationContext.displayName = "Location";
var RouteContext = /*#__PURE__*/ import_react.createContext({
	outlet: null,
	matches: [],
	isDataRoute: false
});
RouteContext.displayName = "Route";
var RouteErrorContext = /*#__PURE__*/ import_react.createContext(null);
RouteErrorContext.displayName = "RouteError";
/**
* Returns the full href for the given "to" value. This is useful for building
* custom links that are also accessible and preserve right-click behavior.
*
* @see https://reactrouter.com/v6/hooks/use-href
*/
function useHref(to, _temp) {
	let { relative } = _temp === void 0 ? {} : _temp;
	!useInRouterContext() && invariant(false, "useHref() may be used only in the context of a <Router> component.");
	let { basename, navigator } = import_react.useContext(NavigationContext);
	let { hash, pathname, search } = useResolvedPath(to, { relative });
	let joinedPathname = pathname;
	if (basename !== "/") joinedPathname = pathname === "/" ? basename : joinPaths([basename, pathname]);
	return navigator.createHref({
		pathname: joinedPathname,
		search,
		hash
	});
}
/**
* Returns true if this component is a descendant of a `<Router>`.
*
* @see https://reactrouter.com/v6/hooks/use-in-router-context
*/
function useInRouterContext() {
	return import_react.useContext(LocationContext) != null;
}
/**
* Returns the current location object, which represents the current URL in web
* browsers.
*
* Note: If you're using this it may mean you're doing some of your own
* "routing" in your app, and we'd like to know what your use case is. We may
* be able to provide something higher-level to better suit your needs.
*
* @see https://reactrouter.com/v6/hooks/use-location
*/
function useLocation() {
	!useInRouterContext() && invariant(false, "useLocation() may be used only in the context of a <Router> component.");
	return import_react.useContext(LocationContext).location;
}
/**
* Returns the current navigation action which describes how the router came to
* the current location, either by a pop, push, or replace on the history stack.
*
* @see https://reactrouter.com/v6/hooks/use-navigation-type
*/
function useNavigationType() {
	return import_react.useContext(LocationContext).navigationType;
}
/**
* Returns a PathMatch object if the given pattern matches the current URL.
* This is useful for components that need to know "active" state, e.g.
* `<NavLink>`.
*
* @see https://reactrouter.com/v6/hooks/use-match
*/
function useMatch(pattern) {
	!useInRouterContext() && invariant(false, "useMatch() may be used only in the context of a <Router> component.");
	let { pathname } = useLocation();
	return import_react.useMemo(() => matchPath(pattern, decodePath(pathname)), [pathname, pattern]);
}
/**
* The interface for the navigate() function returned from useNavigate().
*/
var navigateEffectWarning = "You should call navigate() in a React.useEffect(), not when your component is first rendered.";
function useIsomorphicLayoutEffect(cb) {
	if (!import_react.useContext(NavigationContext).static) import_react.useLayoutEffect(cb);
}
/**
* Returns an imperative method for changing the location. Used by `<Link>`s, but
* may also be used by other elements to change the location.
*
* @see https://reactrouter.com/v6/hooks/use-navigate
*/
function useNavigate() {
	let { isDataRoute } = import_react.useContext(RouteContext);
	return isDataRoute ? useNavigateStable() : useNavigateUnstable();
}
function useNavigateUnstable() {
	!useInRouterContext() && invariant(false, "useNavigate() may be used only in the context of a <Router> component.");
	let dataRouterContext = import_react.useContext(DataRouterContext);
	let { basename, future, navigator } = import_react.useContext(NavigationContext);
	let { matches } = import_react.useContext(RouteContext);
	let { pathname: locationPathname } = useLocation();
	let routePathnamesJson = JSON.stringify(getResolveToMatches(matches, future.v7_relativeSplatPath));
	let activeRef = import_react.useRef(false);
	useIsomorphicLayoutEffect(() => {
		activeRef.current = true;
	});
	return import_react.useCallback(function(to, options) {
		if (options === void 0) options = {};
		warning(activeRef.current, navigateEffectWarning);
		if (!activeRef.current) return;
		if (typeof to === "number") {
			navigator.go(to);
			return;
		}
		let path = resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, options.relative === "path");
		if (dataRouterContext == null && basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
		(!!options.replace ? navigator.replace : navigator.push)(path, options.state, options);
	}, [
		basename,
		navigator,
		routePathnamesJson,
		locationPathname,
		dataRouterContext
	]);
}
var OutletContext = /*#__PURE__*/ import_react.createContext(null);
/**
* Returns the context (if provided) for the child route at this level of the route
* hierarchy.
* @see https://reactrouter.com/v6/hooks/use-outlet-context
*/
function useOutletContext() {
	return import_react.useContext(OutletContext);
}
/**
* Returns the element for the child route at this level of the route
* hierarchy. Used internally by `<Outlet>` to render child routes.
*
* @see https://reactrouter.com/v6/hooks/use-outlet
*/
function useOutlet(context) {
	let outlet = import_react.useContext(RouteContext).outlet;
	if (outlet) return /*#__PURE__*/ import_react.createElement(OutletContext.Provider, { value: context }, outlet);
	return outlet;
}
/**
* Returns an object of key/value pairs of the dynamic params from the current
* URL that were matched by the route path.
*
* @see https://reactrouter.com/v6/hooks/use-params
*/
function useParams() {
	let { matches } = import_react.useContext(RouteContext);
	let routeMatch = matches[matches.length - 1];
	return routeMatch ? routeMatch.params : {};
}
/**
* Resolves the pathname of the given `to` value against the current location.
*
* @see https://reactrouter.com/v6/hooks/use-resolved-path
*/
function useResolvedPath(to, _temp2) {
	let { relative } = _temp2 === void 0 ? {} : _temp2;
	let { future } = import_react.useContext(NavigationContext);
	let { matches } = import_react.useContext(RouteContext);
	let { pathname: locationPathname } = useLocation();
	let routePathnamesJson = JSON.stringify(getResolveToMatches(matches, future.v7_relativeSplatPath));
	return import_react.useMemo(() => resolveTo(to, JSON.parse(routePathnamesJson), locationPathname, relative === "path"), [
		to,
		routePathnamesJson,
		locationPathname,
		relative
	]);
}
/**
* Returns the element of the route that matched the current location, prepared
* with the correct context to render the remainder of the route tree. Route
* elements in the tree must render an `<Outlet>` to render their child route's
* element.
*
* @see https://reactrouter.com/v6/hooks/use-routes
*/
function useRoutes(routes, locationArg) {
	return useRoutesImpl(routes, locationArg);
}
function useRoutesImpl(routes, locationArg, dataRouterState, future) {
	!useInRouterContext() && invariant(false, "useRoutes() may be used only in the context of a <Router> component.");
	let { navigator } = import_react.useContext(NavigationContext);
	let { matches: parentMatches } = import_react.useContext(RouteContext);
	let routeMatch = parentMatches[parentMatches.length - 1];
	let parentParams = routeMatch ? routeMatch.params : {};
	let parentPathname = routeMatch ? routeMatch.pathname : "/";
	let parentPathnameBase = routeMatch ? routeMatch.pathnameBase : "/";
	let parentRoute = routeMatch && routeMatch.route;
	{
		let parentPath = parentRoute && parentRoute.path || "";
		warningOnce(parentPathname, !parentRoute || parentPath.endsWith("*"), "You rendered descendant <Routes> (or called `useRoutes()`) at " + ("\"" + parentPathname + "\" (under <Route path=\"" + parentPath + "\">) but the ") + "parent route path has no trailing \"*\". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.\n\n" + ("Please change the parent <Route path=\"" + parentPath + "\"> to <Route ") + ("path=\"" + (parentPath === "/" ? "*" : parentPath + "/*") + "\">."));
	}
	let locationFromContext = useLocation();
	let location;
	if (locationArg) {
		var _parsedLocationArg$pa;
		let parsedLocationArg = typeof locationArg === "string" ? parsePath(locationArg) : locationArg;
		!(parentPathnameBase === "/" || ((_parsedLocationArg$pa = parsedLocationArg.pathname) == null ? void 0 : _parsedLocationArg$pa.startsWith(parentPathnameBase))) && invariant(false, "When overriding the location using `<Routes location>` or `useRoutes(routes, location)`, the location pathname must begin with the portion of the URL pathname that was " + ("matched by all parent routes. The current pathname base is \"" + parentPathnameBase + "\" ") + ("but pathname \"" + parsedLocationArg.pathname + "\" was given in the `location` prop."));
		location = parsedLocationArg;
	} else location = locationFromContext;
	let pathname = location.pathname || "/";
	let remainingPathname = pathname;
	if (parentPathnameBase !== "/") {
		let parentSegments = parentPathnameBase.replace(/^\//, "").split("/");
		remainingPathname = "/" + pathname.replace(/^\//, "").split("/").slice(parentSegments.length).join("/");
	}
	let matches = matchRoutes(routes, { pathname: remainingPathname });
	warning(parentRoute || matches != null, "No routes matched location \"" + location.pathname + location.search + location.hash + "\" ");
	warning(matches == null || matches[matches.length - 1].route.element !== void 0 || matches[matches.length - 1].route.Component !== void 0 || matches[matches.length - 1].route.lazy !== void 0, "Matched leaf route at location \"" + location.pathname + location.search + location.hash + "\" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an \"empty\" page.");
	let renderedMatches = _renderMatches(matches && matches.map((match) => Object.assign({}, match, {
		params: Object.assign({}, parentParams, match.params),
		pathname: joinPaths([parentPathnameBase, navigator.encodeLocation ? navigator.encodeLocation(match.pathname).pathname : match.pathname]),
		pathnameBase: match.pathnameBase === "/" ? parentPathnameBase : joinPaths([parentPathnameBase, navigator.encodeLocation ? navigator.encodeLocation(match.pathnameBase).pathname : match.pathnameBase])
	})), parentMatches, dataRouterState, future);
	if (locationArg && renderedMatches) return /*#__PURE__*/ import_react.createElement(LocationContext.Provider, { value: {
		location: _extends$1({
			pathname: "/",
			search: "",
			hash: "",
			state: null,
			key: "default"
		}, location),
		navigationType: Action.Pop
	} }, renderedMatches);
	return renderedMatches;
}
function DefaultErrorComponent() {
	let error = useRouteError();
	let message = isRouteErrorResponse(error) ? error.status + " " + error.statusText : error instanceof Error ? error.message : JSON.stringify(error);
	let stack = error instanceof Error ? error.stack : null;
	let lightgrey = "rgba(200,200,200, 0.5)";
	let preStyles = {
		padding: "0.5rem",
		backgroundColor: lightgrey
	};
	let codeStyles = {
		padding: "2px 4px",
		backgroundColor: lightgrey
	};
	let devInfo = null;
	console.error("Error handled by React Router default ErrorBoundary:", error);
	devInfo = /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement("p", null, "💿 Hey developer 👋"), /*#__PURE__*/ import_react.createElement("p", null, "You can provide a way better UX than this when your app throws errors by providing your own ", /*#__PURE__*/ import_react.createElement("code", { style: codeStyles }, "ErrorBoundary"), " or", " ", /*#__PURE__*/ import_react.createElement("code", { style: codeStyles }, "errorElement"), " prop on your route."));
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement("h2", null, "Unexpected Application Error!"), /*#__PURE__*/ import_react.createElement("h3", { style: { fontStyle: "italic" } }, message), stack ? /*#__PURE__*/ import_react.createElement("pre", { style: preStyles }, stack) : null, devInfo);
}
var defaultErrorElement = /*#__PURE__*/ import_react.createElement(DefaultErrorComponent, null);
var RenderErrorBoundary = class extends import_react.Component {
	constructor(props) {
		super(props);
		this.state = {
			location: props.location,
			revalidation: props.revalidation,
			error: props.error
		};
	}
	static getDerivedStateFromError(error) {
		return { error };
	}
	static getDerivedStateFromProps(props, state) {
		if (state.location !== props.location || state.revalidation !== "idle" && props.revalidation === "idle") return {
			error: props.error,
			location: props.location,
			revalidation: props.revalidation
		};
		return {
			error: props.error !== void 0 ? props.error : state.error,
			location: state.location,
			revalidation: props.revalidation || state.revalidation
		};
	}
	componentDidCatch(error, errorInfo) {
		console.error("React Router caught the following error during render", error, errorInfo);
	}
	render() {
		return this.state.error !== void 0 ? /*#__PURE__*/ import_react.createElement(RouteContext.Provider, { value: this.props.routeContext }, /*#__PURE__*/ import_react.createElement(RouteErrorContext.Provider, {
			value: this.state.error,
			children: this.props.component
		})) : this.props.children;
	}
};
function RenderedRoute(_ref) {
	let { routeContext, match, children } = _ref;
	let dataRouterContext = import_react.useContext(DataRouterContext);
	if (dataRouterContext && dataRouterContext.static && dataRouterContext.staticContext && (match.route.errorElement || match.route.ErrorBoundary)) dataRouterContext.staticContext._deepestRenderedBoundaryId = match.route.id;
	return /*#__PURE__*/ import_react.createElement(RouteContext.Provider, { value: routeContext }, children);
}
function _renderMatches(matches, parentMatches, dataRouterState, future) {
	var _dataRouterState;
	if (parentMatches === void 0) parentMatches = [];
	if (dataRouterState === void 0) dataRouterState = null;
	if (future === void 0) future = null;
	if (matches == null) {
		var _future;
		if (!dataRouterState) return null;
		if (dataRouterState.errors) matches = dataRouterState.matches;
		else if ((_future = future) != null && _future.v7_partialHydration && parentMatches.length === 0 && !dataRouterState.initialized && dataRouterState.matches.length > 0) matches = dataRouterState.matches;
		else return null;
	}
	let renderedMatches = matches;
	let errors = (_dataRouterState = dataRouterState) == null ? void 0 : _dataRouterState.errors;
	if (errors != null) {
		let errorIndex = renderedMatches.findIndex((m) => m.route.id && (errors == null ? void 0 : errors[m.route.id]) !== void 0);
		!(errorIndex >= 0) && invariant(false, "Could not find a matching route for errors on route IDs: " + Object.keys(errors).join(","));
		renderedMatches = renderedMatches.slice(0, Math.min(renderedMatches.length, errorIndex + 1));
	}
	let renderFallback = false;
	let fallbackIndex = -1;
	if (dataRouterState && future && future.v7_partialHydration) for (let i = 0; i < renderedMatches.length; i++) {
		let match = renderedMatches[i];
		if (match.route.HydrateFallback || match.route.hydrateFallbackElement) fallbackIndex = i;
		if (match.route.id) {
			let { loaderData, errors } = dataRouterState;
			let needsToRunLoader = match.route.loader && loaderData[match.route.id] === void 0 && (!errors || errors[match.route.id] === void 0);
			if (match.route.lazy || needsToRunLoader) {
				renderFallback = true;
				if (fallbackIndex >= 0) renderedMatches = renderedMatches.slice(0, fallbackIndex + 1);
				else renderedMatches = [renderedMatches[0]];
				break;
			}
		}
	}
	return renderedMatches.reduceRight((outlet, match, index) => {
		let error;
		let shouldRenderHydrateFallback = false;
		let errorElement = null;
		let hydrateFallbackElement = null;
		if (dataRouterState) {
			error = errors && match.route.id ? errors[match.route.id] : void 0;
			errorElement = match.route.errorElement || defaultErrorElement;
			if (renderFallback) {
				if (fallbackIndex < 0 && index === 0) {
					warningOnce("route-fallback", false, "No `HydrateFallback` element provided to render during initial hydration");
					shouldRenderHydrateFallback = true;
					hydrateFallbackElement = null;
				} else if (fallbackIndex === index) {
					shouldRenderHydrateFallback = true;
					hydrateFallbackElement = match.route.hydrateFallbackElement || null;
				}
			}
		}
		let matches = parentMatches.concat(renderedMatches.slice(0, index + 1));
		let getChildren = () => {
			let children;
			if (error) children = errorElement;
			else if (shouldRenderHydrateFallback) children = hydrateFallbackElement;
			else if (match.route.Component) children = /*#__PURE__*/ import_react.createElement(match.route.Component, null);
			else if (match.route.element) children = match.route.element;
			else children = outlet;
			return /*#__PURE__*/ import_react.createElement(RenderedRoute, {
				match,
				routeContext: {
					outlet,
					matches,
					isDataRoute: dataRouterState != null
				},
				children
			});
		};
		return dataRouterState && (match.route.ErrorBoundary || match.route.errorElement || index === 0) ? /*#__PURE__*/ import_react.createElement(RenderErrorBoundary, {
			location: dataRouterState.location,
			revalidation: dataRouterState.revalidation,
			component: errorElement,
			error,
			children: getChildren(),
			routeContext: {
				outlet: null,
				matches,
				isDataRoute: true
			}
		}) : getChildren();
	}, null);
}
var DataRouterHook$1 = /*#__PURE__*/ function(DataRouterHook) {
	DataRouterHook["UseBlocker"] = "useBlocker";
	DataRouterHook["UseRevalidator"] = "useRevalidator";
	DataRouterHook["UseNavigateStable"] = "useNavigate";
	return DataRouterHook;
}(DataRouterHook$1 || {});
var DataRouterStateHook$1 = /*#__PURE__*/ function(DataRouterStateHook) {
	DataRouterStateHook["UseBlocker"] = "useBlocker";
	DataRouterStateHook["UseLoaderData"] = "useLoaderData";
	DataRouterStateHook["UseActionData"] = "useActionData";
	DataRouterStateHook["UseRouteError"] = "useRouteError";
	DataRouterStateHook["UseNavigation"] = "useNavigation";
	DataRouterStateHook["UseRouteLoaderData"] = "useRouteLoaderData";
	DataRouterStateHook["UseMatches"] = "useMatches";
	DataRouterStateHook["UseRevalidator"] = "useRevalidator";
	DataRouterStateHook["UseNavigateStable"] = "useNavigate";
	DataRouterStateHook["UseRouteId"] = "useRouteId";
	return DataRouterStateHook;
}(DataRouterStateHook$1 || {});
function getDataRouterConsoleError$1(hookName) {
	return hookName + " must be used within a data router.  See https://reactrouter.com/v6/routers/picking-a-router.";
}
function useDataRouterContext$1(hookName) {
	let ctx = import_react.useContext(DataRouterContext);
	!ctx && invariant(false, getDataRouterConsoleError$1(hookName));
	return ctx;
}
function useDataRouterState$1(hookName) {
	let state = import_react.useContext(DataRouterStateContext);
	!state && invariant(false, getDataRouterConsoleError$1(hookName));
	return state;
}
function useRouteContext(hookName) {
	let route = import_react.useContext(RouteContext);
	!route && invariant(false, getDataRouterConsoleError$1(hookName));
	return route;
}
function useCurrentRouteId(hookName) {
	let route = useRouteContext(hookName);
	let thisRoute = route.matches[route.matches.length - 1];
	!thisRoute.route.id && invariant(false, hookName + " can only be used on routes that contain a unique \"id\"");
	return thisRoute.route.id;
}
/**
* Returns the ID for the nearest contextual route
*/
function useRouteId() {
	return useCurrentRouteId(DataRouterStateHook$1.UseRouteId);
}
/**
* Returns the current navigation, defaulting to an "idle" navigation when
* no navigation is in progress
*/
function useNavigation() {
	return useDataRouterState$1(DataRouterStateHook$1.UseNavigation).navigation;
}
/**
* Returns a revalidate function for manually triggering revalidation, as well
* as the current state of any manual revalidations
*/
function useRevalidator() {
	let dataRouterContext = useDataRouterContext$1(DataRouterHook$1.UseRevalidator);
	let state = useDataRouterState$1(DataRouterStateHook$1.UseRevalidator);
	return import_react.useMemo(() => ({
		revalidate: dataRouterContext.router.revalidate,
		state: state.revalidation
	}), [dataRouterContext.router.revalidate, state.revalidation]);
}
/**
* Returns the active route matches, useful for accessing loaderData for
* parent/child routes or the route "handle" property
*/
function useMatches() {
	let { matches, loaderData } = useDataRouterState$1(DataRouterStateHook$1.UseMatches);
	return import_react.useMemo(() => matches.map((m) => convertRouteMatchToUiMatch(m, loaderData)), [matches, loaderData]);
}
/**
* Returns the loader data for the nearest ancestor Route loader
*/
function useLoaderData() {
	let state = useDataRouterState$1(DataRouterStateHook$1.UseLoaderData);
	let routeId = useCurrentRouteId(DataRouterStateHook$1.UseLoaderData);
	if (state.errors && state.errors[routeId] != null) {
		console.error("You cannot `useLoaderData` in an errorElement (routeId: " + routeId + ")");
		return;
	}
	return state.loaderData[routeId];
}
/**
* Returns the loaderData for the given routeId
*/
function useRouteLoaderData(routeId) {
	return useDataRouterState$1(DataRouterStateHook$1.UseRouteLoaderData).loaderData[routeId];
}
/**
* Returns the action data for the nearest ancestor Route action
*/
function useActionData() {
	let state = useDataRouterState$1(DataRouterStateHook$1.UseActionData);
	let routeId = useCurrentRouteId(DataRouterStateHook$1.UseLoaderData);
	return state.actionData ? state.actionData[routeId] : void 0;
}
/**
* Returns the nearest ancestor Route error, which could be a loader/action
* error or a render error.  This is intended to be called from your
* ErrorBoundary/errorElement to display a proper error message.
*/
function useRouteError() {
	var _state$errors;
	let error = import_react.useContext(RouteErrorContext);
	let state = useDataRouterState$1(DataRouterStateHook$1.UseRouteError);
	let routeId = useCurrentRouteId(DataRouterStateHook$1.UseRouteError);
	if (error !== void 0) return error;
	return (_state$errors = state.errors) == null ? void 0 : _state$errors[routeId];
}
/**
* Returns the happy-path data from the nearest ancestor `<Await />` value
*/
function useAsyncValue() {
	let value = import_react.useContext(AwaitContext);
	return value == null ? void 0 : value._data;
}
/**
* Returns the error from the nearest ancestor `<Await />` value
*/
function useAsyncError() {
	let value = import_react.useContext(AwaitContext);
	return value == null ? void 0 : value._error;
}
var blockerId = 0;
/**
* Allow the application to block navigations within the SPA and present the
* user a confirmation dialog to confirm the navigation.  Mostly used to avoid
* using half-filled form data.  This does not handle hard-reloads or
* cross-origin navigations.
*/
function useBlocker(shouldBlock) {
	let { router, basename } = useDataRouterContext$1(DataRouterHook$1.UseBlocker);
	let state = useDataRouterState$1(DataRouterStateHook$1.UseBlocker);
	let [blockerKey, setBlockerKey] = import_react.useState("");
	let blockerFunction = import_react.useCallback((arg) => {
		if (typeof shouldBlock !== "function") return !!shouldBlock;
		if (basename === "/") return shouldBlock(arg);
		let { currentLocation, nextLocation, historyAction } = arg;
		return shouldBlock({
			currentLocation: _extends$1({}, currentLocation, { pathname: stripBasename(currentLocation.pathname, basename) || currentLocation.pathname }),
			nextLocation: _extends$1({}, nextLocation, { pathname: stripBasename(nextLocation.pathname, basename) || nextLocation.pathname }),
			historyAction
		});
	}, [basename, shouldBlock]);
	import_react.useEffect(() => {
		let key = String(++blockerId);
		setBlockerKey(key);
		return () => router.deleteBlocker(key);
	}, [router]);
	import_react.useEffect(() => {
		if (blockerKey !== "") router.getBlocker(blockerKey, blockerFunction);
	}, [
		router,
		blockerKey,
		blockerFunction
	]);
	return blockerKey && state.blockers.has(blockerKey) ? state.blockers.get(blockerKey) : IDLE_BLOCKER;
}
/**
* Stable version of useNavigate that is used when we are in the context of
* a RouterProvider.
*/
function useNavigateStable() {
	let { router } = useDataRouterContext$1(DataRouterHook$1.UseNavigateStable);
	let id = useCurrentRouteId(DataRouterStateHook$1.UseNavigateStable);
	let activeRef = import_react.useRef(false);
	useIsomorphicLayoutEffect(() => {
		activeRef.current = true;
	});
	return import_react.useCallback(function(to, options) {
		if (options === void 0) options = {};
		warning(activeRef.current, navigateEffectWarning);
		if (!activeRef.current) return;
		if (typeof to === "number") router.navigate(to);
		else router.navigate(to, _extends$1({ fromRouteId: id }, options));
	}, [router, id]);
}
var alreadyWarned$1 = {};
function warningOnce(key, cond, message) {
	if (!cond && !alreadyWarned$1[key]) {
		alreadyWarned$1[key] = true;
		warning(false, message);
	}
}
var alreadyWarned = {};
function warnOnce(key, message) {
	if (!alreadyWarned[message]) {
		alreadyWarned[message] = true;
		console.warn(message);
	}
}
var logDeprecation = (flag, msg, link) => warnOnce(flag, "⚠️ React Router Future Flag Warning: " + msg + ". " + ("You can use the `" + flag + "` future flag to opt-in early. ") + ("For more information, see " + link + "."));
function logV6DeprecationWarnings(renderFuture, routerFuture) {
	if ((renderFuture == null ? void 0 : renderFuture.v7_startTransition) === void 0) logDeprecation("v7_startTransition", "React Router will begin wrapping state updates in `React.startTransition` in v7", "https://reactrouter.com/v6/upgrading/future#v7_starttransition");
	if ((renderFuture == null ? void 0 : renderFuture.v7_relativeSplatPath) === void 0 && (!routerFuture || routerFuture.v7_relativeSplatPath === void 0)) logDeprecation("v7_relativeSplatPath", "Relative route resolution within Splat routes is changing in v7", "https://reactrouter.com/v6/upgrading/future#v7_relativesplatpath");
	if (routerFuture) {
		if (routerFuture.v7_fetcherPersist === void 0) logDeprecation("v7_fetcherPersist", "The persistence behavior of fetchers is changing in v7", "https://reactrouter.com/v6/upgrading/future#v7_fetcherpersist");
		if (routerFuture.v7_normalizeFormMethod === void 0) logDeprecation("v7_normalizeFormMethod", "Casing of `formMethod` fields is being normalized to uppercase in v7", "https://reactrouter.com/v6/upgrading/future#v7_normalizeformmethod");
		if (routerFuture.v7_partialHydration === void 0) logDeprecation("v7_partialHydration", "`RouterProvider` hydration behavior is changing in v7", "https://reactrouter.com/v6/upgrading/future#v7_partialhydration");
		if (routerFuture.v7_skipActionErrorRevalidation === void 0) logDeprecation("v7_skipActionErrorRevalidation", "The revalidation behavior after 4xx/5xx `action` responses is changing in v7", "https://reactrouter.com/v6/upgrading/future#v7_skipactionerrorrevalidation");
	}
}
var startTransitionImpl$1 = import_react.startTransition;
/**
* A `<Router>` that stores all entries in memory.
*
* @see https://reactrouter.com/v6/router-components/memory-router
*/
function MemoryRouter(_ref3) {
	let { basename, children, initialEntries, initialIndex, future } = _ref3;
	let historyRef = import_react.useRef();
	if (historyRef.current == null) historyRef.current = createMemoryHistory({
		initialEntries,
		initialIndex,
		v5Compat: true
	});
	let history = historyRef.current;
	let [state, setStateImpl] = import_react.useState({
		action: history.action,
		location: history.location
	});
	let { v7_startTransition } = future || {};
	let setState = import_react.useCallback((newState) => {
		v7_startTransition && startTransitionImpl$1 ? startTransitionImpl$1(() => setStateImpl(newState)) : setStateImpl(newState);
	}, [setStateImpl, v7_startTransition]);
	import_react.useLayoutEffect(() => history.listen(setState), [history, setState]);
	import_react.useEffect(() => logV6DeprecationWarnings(future), [future]);
	return /*#__PURE__*/ import_react.createElement(Router, {
		basename,
		children,
		location: state.location,
		navigationType: state.action,
		navigator: history,
		future
	});
}
/**
* Changes the current location.
*
* Note: This API is mostly useful in React.Component subclasses that are not
* able to use hooks. In functional components, we recommend you use the
* `useNavigate` hook instead.
*
* @see https://reactrouter.com/v6/components/navigate
*/
function Navigate(_ref4) {
	let { to, replace, state, relative } = _ref4;
	!useInRouterContext() && invariant(false, "<Navigate> may be used only in the context of a <Router> component.");
	let { future, static: isStatic } = import_react.useContext(NavigationContext);
	warning(!isStatic, "<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.");
	let { matches } = import_react.useContext(RouteContext);
	let { pathname: locationPathname } = useLocation();
	let navigate = useNavigate();
	let path = resolveTo(to, getResolveToMatches(matches, future.v7_relativeSplatPath), locationPathname, relative === "path");
	let jsonPath = JSON.stringify(path);
	import_react.useEffect(() => navigate(JSON.parse(jsonPath), {
		replace,
		state,
		relative
	}), [
		navigate,
		jsonPath,
		relative,
		replace,
		state
	]);
	return null;
}
/**
* Renders the child route's element, if there is one.
*
* @see https://reactrouter.com/v6/components/outlet
*/
function Outlet(props) {
	return useOutlet(props.context);
}
/**
* Declares an element that should be rendered at a certain URL path.
*
* @see https://reactrouter.com/v6/components/route
*/
function Route(_props) {
	invariant(false, "A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.");
}
/**
* Provides location context for the rest of the app.
*
* Note: You usually won't render a `<Router>` directly. Instead, you'll render a
* router that is more specific to your environment such as a `<BrowserRouter>`
* in web browsers or a `<StaticRouter>` for server rendering.
*
* @see https://reactrouter.com/v6/router-components/router
*/
function Router(_ref5) {
	let { basename: basenameProp = "/", children = null, location: locationProp, navigationType = Action.Pop, navigator, static: staticProp = false, future } = _ref5;
	useInRouterContext() && invariant(false, "You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");
	let basename = basenameProp.replace(/^\/*/, "/");
	let navigationContext = import_react.useMemo(() => ({
		basename,
		navigator,
		static: staticProp,
		future: _extends$1({ v7_relativeSplatPath: false }, future)
	}), [
		basename,
		future,
		navigator,
		staticProp
	]);
	if (typeof locationProp === "string") locationProp = parsePath(locationProp);
	let { pathname = "/", search = "", hash = "", state = null, key = "default" } = locationProp;
	let locationContext = import_react.useMemo(() => {
		let trailingPathname = stripBasename(pathname, basename);
		if (trailingPathname == null) return null;
		return {
			location: {
				pathname: trailingPathname,
				search,
				hash,
				state,
				key
			},
			navigationType
		};
	}, [
		basename,
		pathname,
		search,
		hash,
		state,
		key,
		navigationType
	]);
	warning(locationContext != null, "<Router basename=\"" + basename + "\"> is not able to match the URL " + ("\"" + pathname + search + hash + "\" because it does not start with the ") + "basename, so the <Router> won't render anything.");
	if (locationContext == null) return null;
	return /*#__PURE__*/ import_react.createElement(NavigationContext.Provider, { value: navigationContext }, /*#__PURE__*/ import_react.createElement(LocationContext.Provider, {
		children,
		value: locationContext
	}));
}
/**
* A container for a nested tree of `<Route>` elements that renders the branch
* that best matches the current location.
*
* @see https://reactrouter.com/v6/components/routes
*/
function Routes(_ref6) {
	let { children, location } = _ref6;
	return useRoutes(createRoutesFromChildren(children), location);
}
/**
* Component to use for rendering lazily loaded data from returning defer()
* in a loader function
*/
function Await(_ref7) {
	let { children, errorElement, resolve } = _ref7;
	return /*#__PURE__*/ import_react.createElement(AwaitErrorBoundary, {
		resolve,
		errorElement
	}, /*#__PURE__*/ import_react.createElement(ResolveAwait, null, children));
}
var AwaitRenderStatus = /*#__PURE__*/ function(AwaitRenderStatus) {
	AwaitRenderStatus[AwaitRenderStatus["pending"] = 0] = "pending";
	AwaitRenderStatus[AwaitRenderStatus["success"] = 1] = "success";
	AwaitRenderStatus[AwaitRenderStatus["error"] = 2] = "error";
	return AwaitRenderStatus;
}(AwaitRenderStatus || {});
var neverSettledPromise = new Promise(() => {});
var AwaitErrorBoundary = class extends import_react.Component {
	constructor(props) {
		super(props);
		this.state = { error: null };
	}
	static getDerivedStateFromError(error) {
		return { error };
	}
	componentDidCatch(error, errorInfo) {
		console.error("<Await> caught the following error during render", error, errorInfo);
	}
	render() {
		let { children, errorElement, resolve } = this.props;
		let promise = null;
		let status = AwaitRenderStatus.pending;
		if (!(resolve instanceof Promise)) {
			status = AwaitRenderStatus.success;
			promise = Promise.resolve();
			Object.defineProperty(promise, "_tracked", { get: () => true });
			Object.defineProperty(promise, "_data", { get: () => resolve });
		} else if (this.state.error) {
			status = AwaitRenderStatus.error;
			let renderError = this.state.error;
			promise = Promise.reject().catch(() => {});
			Object.defineProperty(promise, "_tracked", { get: () => true });
			Object.defineProperty(promise, "_error", { get: () => renderError });
		} else if (resolve._tracked) {
			promise = resolve;
			status = "_error" in promise ? AwaitRenderStatus.error : "_data" in promise ? AwaitRenderStatus.success : AwaitRenderStatus.pending;
		} else {
			status = AwaitRenderStatus.pending;
			Object.defineProperty(resolve, "_tracked", { get: () => true });
			promise = resolve.then((data) => Object.defineProperty(resolve, "_data", { get: () => data }), (error) => Object.defineProperty(resolve, "_error", { get: () => error }));
		}
		if (status === AwaitRenderStatus.error && promise._error instanceof AbortedDeferredError) throw neverSettledPromise;
		if (status === AwaitRenderStatus.error && !errorElement) throw promise._error;
		if (status === AwaitRenderStatus.error) return /*#__PURE__*/ import_react.createElement(AwaitContext.Provider, {
			value: promise,
			children: errorElement
		});
		if (status === AwaitRenderStatus.success) return /*#__PURE__*/ import_react.createElement(AwaitContext.Provider, {
			value: promise,
			children
		});
		throw promise;
	}
};
/**
* @private
* Indirection to leverage useAsyncValue for a render-prop API on `<Await>`
*/
function ResolveAwait(_ref8) {
	let { children } = _ref8;
	let data = useAsyncValue();
	let toRender = typeof children === "function" ? children(data) : children;
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, toRender);
}
/**
* Creates a route config from a React "children" object, which is usually
* either a `<Route>` element or an array of them. Used internally by
* `<Routes>` to create a route config from its children.
*
* @see https://reactrouter.com/v6/utils/create-routes-from-children
*/
function createRoutesFromChildren(children, parentPath) {
	if (parentPath === void 0) parentPath = [];
	let routes = [];
	import_react.Children.forEach(children, (element, index) => {
		if (!/*#__PURE__*/ import_react.isValidElement(element)) return;
		let treePath = [...parentPath, index];
		if (element.type === import_react.Fragment) {
			routes.push.apply(routes, createRoutesFromChildren(element.props.children, treePath));
			return;
		}
		!(element.type === Route) && invariant(false, "[" + (typeof element.type === "string" ? element.type : element.type.name) + "] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>");
		!(!element.props.index || !element.props.children) && invariant(false, "An index route cannot have child routes.");
		let route = {
			id: element.props.id || treePath.join("-"),
			caseSensitive: element.props.caseSensitive,
			element: element.props.element,
			Component: element.props.Component,
			index: element.props.index,
			path: element.props.path,
			loader: element.props.loader,
			action: element.props.action,
			errorElement: element.props.errorElement,
			ErrorBoundary: element.props.ErrorBoundary,
			hasErrorBoundary: element.props.ErrorBoundary != null || element.props.errorElement != null,
			shouldRevalidate: element.props.shouldRevalidate,
			handle: element.props.handle,
			lazy: element.props.lazy
		};
		if (element.props.children) route.children = createRoutesFromChildren(element.props.children, treePath);
		routes.push(route);
	});
	return routes;
}
/**
* Renders the result of `matchRoutes()` into a React element.
*/
function renderMatches(matches) {
	return _renderMatches(matches);
}
function mapRouteProperties(route) {
	let updates = { hasErrorBoundary: route.ErrorBoundary != null || route.errorElement != null };
	if (route.Component) {
		if (route.element) warning(false, "You should not include both `Component` and `element` on your route - `Component` will be used.");
		Object.assign(updates, {
			element: /*#__PURE__*/ import_react.createElement(route.Component),
			Component: void 0
		});
	}
	if (route.HydrateFallback) {
		if (route.hydrateFallbackElement) warning(false, "You should not include both `HydrateFallback` and `hydrateFallbackElement` on your route - `HydrateFallback` will be used.");
		Object.assign(updates, {
			hydrateFallbackElement: /*#__PURE__*/ import_react.createElement(route.HydrateFallback),
			HydrateFallback: void 0
		});
	}
	if (route.ErrorBoundary) {
		if (route.errorElement) warning(false, "You should not include both `ErrorBoundary` and `errorElement` on your route - `ErrorBoundary` will be used.");
		Object.assign(updates, {
			errorElement: /*#__PURE__*/ import_react.createElement(route.ErrorBoundary),
			ErrorBoundary: void 0
		});
	}
	return updates;
}
function createMemoryRouter(routes, opts) {
	return createRouter({
		basename: opts == null ? void 0 : opts.basename,
		future: _extends$1({}, opts == null ? void 0 : opts.future, { v7_prependBasename: true }),
		history: createMemoryHistory({
			initialEntries: opts == null ? void 0 : opts.initialEntries,
			initialIndex: opts == null ? void 0 : opts.initialIndex
		}),
		hydrationData: opts == null ? void 0 : opts.hydrationData,
		routes,
		mapRouteProperties,
		dataStrategy: opts == null ? void 0 : opts.dataStrategy,
		patchRoutesOnNavigation: opts == null ? void 0 : opts.patchRoutesOnNavigation
	}).initialize();
}
//#endregion
//#region node_modules/react-router-dom/dist/index.js
/**
* React Router DOM v6.30.4
*
* Copyright (c) Remix Software Inc.
*
* This source code is licensed under the MIT license found in the
* LICENSE.md file in the root directory of this source tree.
*
* @license MIT
*/
function _extends() {
	return _extends = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends.apply(null, arguments);
}
function _objectWithoutPropertiesLoose(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
var defaultMethod = "get";
var defaultEncType = "application/x-www-form-urlencoded";
function isHtmlElement(object) {
	return object != null && typeof object.tagName === "string";
}
function isButtonElement(object) {
	return isHtmlElement(object) && object.tagName.toLowerCase() === "button";
}
function isFormElement(object) {
	return isHtmlElement(object) && object.tagName.toLowerCase() === "form";
}
function isInputElement(object) {
	return isHtmlElement(object) && object.tagName.toLowerCase() === "input";
}
function isModifiedEvent(event) {
	return !!(event.metaKey || event.altKey || event.ctrlKey || event.shiftKey);
}
function shouldProcessLinkClick(event, target) {
	return event.button === 0 && (!target || target === "_self") && !isModifiedEvent(event);
}
/**
* Creates a URLSearchParams object using the given initializer.
*
* This is identical to `new URLSearchParams(init)` except it also
* supports arrays as values in the object form of the initializer
* instead of just strings. This is convenient when you need multiple
* values for a given key, but don't want to use an array initializer.
*
* For example, instead of:
*
*   let searchParams = new URLSearchParams([
*     ['sort', 'name'],
*     ['sort', 'price']
*   ]);
*
* you can do:
*
*   let searchParams = createSearchParams({
*     sort: ['name', 'price']
*   });
*/
function createSearchParams(init) {
	if (init === void 0) init = "";
	return new URLSearchParams(typeof init === "string" || Array.isArray(init) || init instanceof URLSearchParams ? init : Object.keys(init).reduce((memo, key) => {
		let value = init[key];
		return memo.concat(Array.isArray(value) ? value.map((v) => [key, v]) : [[key, value]]);
	}, []));
}
function getSearchParamsForLocation(locationSearch, defaultSearchParams) {
	let searchParams = createSearchParams(locationSearch);
	if (defaultSearchParams) defaultSearchParams.forEach((_, key) => {
		if (!searchParams.has(key)) defaultSearchParams.getAll(key).forEach((value) => {
			searchParams.append(key, value);
		});
	});
	return searchParams;
}
var _formDataSupportsSubmitter = null;
function isFormDataSubmitterSupported() {
	if (_formDataSupportsSubmitter === null) try {
		new FormData(document.createElement("form"), 0);
		_formDataSupportsSubmitter = false;
	} catch (e) {
		_formDataSupportsSubmitter = true;
	}
	return _formDataSupportsSubmitter;
}
var supportedFormEncTypes = /* @__PURE__ */ new Set([
	"application/x-www-form-urlencoded",
	"multipart/form-data",
	"text/plain"
]);
function getFormEncType(encType) {
	if (encType != null && !supportedFormEncTypes.has(encType)) {
		warning(false, "\"" + encType + "\" is not a valid `encType` for `<Form>`/`<fetcher.Form>` and will default to \"application/x-www-form-urlencoded\"");
		return null;
	}
	return encType;
}
function getFormSubmissionInfo(target, basename) {
	let method;
	let action;
	let encType;
	let formData;
	let body;
	if (isFormElement(target)) {
		let attr = target.getAttribute("action");
		action = attr ? stripBasename(attr, basename) : null;
		method = target.getAttribute("method") || defaultMethod;
		encType = getFormEncType(target.getAttribute("enctype")) || defaultEncType;
		formData = new FormData(target);
	} else if (isButtonElement(target) || isInputElement(target) && (target.type === "submit" || target.type === "image")) {
		let form = target.form;
		if (form == null) throw new Error("Cannot submit a <button> or <input type=\"submit\"> without a <form>");
		let attr = target.getAttribute("formaction") || form.getAttribute("action");
		action = attr ? stripBasename(attr, basename) : null;
		method = target.getAttribute("formmethod") || form.getAttribute("method") || defaultMethod;
		encType = getFormEncType(target.getAttribute("formenctype")) || getFormEncType(form.getAttribute("enctype")) || defaultEncType;
		formData = new FormData(form, target);
		if (!isFormDataSubmitterSupported()) {
			let { name, type, value } = target;
			if (type === "image") {
				let prefix = name ? name + "." : "";
				formData.append(prefix + "x", "0");
				formData.append(prefix + "y", "0");
			} else if (name) formData.append(name, value);
		}
	} else if (isHtmlElement(target)) throw new Error("Cannot submit element that is not <form>, <button>, or <input type=\"submit|image\">");
	else {
		method = defaultMethod;
		action = null;
		encType = defaultEncType;
		body = target;
	}
	if (formData && encType === "text/plain") {
		body = formData;
		formData = void 0;
	}
	return {
		action,
		method: method.toLowerCase(),
		encType,
		formData,
		body
	};
}
var _excluded = [
	"onClick",
	"relative",
	"reloadDocument",
	"replace",
	"state",
	"target",
	"to",
	"preventScrollReset",
	"viewTransition"
];
var _excluded2 = [
	"aria-current",
	"caseSensitive",
	"className",
	"end",
	"style",
	"to",
	"viewTransition",
	"children"
];
var _excluded3 = [
	"fetcherKey",
	"navigate",
	"reloadDocument",
	"replace",
	"state",
	"method",
	"action",
	"onSubmit",
	"relative",
	"preventScrollReset",
	"viewTransition"
];
var REACT_ROUTER_VERSION = "6";
try {
	window.__reactRouterVersion = REACT_ROUTER_VERSION;
} catch (e) {}
function createBrowserRouter(routes, opts) {
	return createRouter({
		basename: opts == null ? void 0 : opts.basename,
		future: _extends({}, opts == null ? void 0 : opts.future, { v7_prependBasename: true }),
		history: createBrowserHistory({ window: opts == null ? void 0 : opts.window }),
		hydrationData: (opts == null ? void 0 : opts.hydrationData) || parseHydrationData(),
		routes,
		mapRouteProperties,
		dataStrategy: opts == null ? void 0 : opts.dataStrategy,
		patchRoutesOnNavigation: opts == null ? void 0 : opts.patchRoutesOnNavigation,
		window: opts == null ? void 0 : opts.window
	}).initialize();
}
function createHashRouter(routes, opts) {
	return createRouter({
		basename: opts == null ? void 0 : opts.basename,
		future: _extends({}, opts == null ? void 0 : opts.future, { v7_prependBasename: true }),
		history: createHashHistory({ window: opts == null ? void 0 : opts.window }),
		hydrationData: (opts == null ? void 0 : opts.hydrationData) || parseHydrationData(),
		routes,
		mapRouteProperties,
		dataStrategy: opts == null ? void 0 : opts.dataStrategy,
		patchRoutesOnNavigation: opts == null ? void 0 : opts.patchRoutesOnNavigation,
		window: opts == null ? void 0 : opts.window
	}).initialize();
}
function parseHydrationData() {
	var _window;
	let state = (_window = window) == null ? void 0 : _window.__staticRouterHydrationData;
	if (state && state.errors) state = _extends({}, state, { errors: deserializeErrors(state.errors) });
	return state;
}
function deserializeErrors(errors) {
	if (!errors) return null;
	let entries = Object.entries(errors);
	let serialized = {};
	for (let [key, val] of entries) if (val && val.__type === "RouteErrorResponse") serialized[key] = new ErrorResponseImpl(val.status, val.statusText, val.data, val.internal === true);
	else if (val && val.__type === "Error") {
		if (val.__subType) {
			let ErrorConstructor = window[val.__subType];
			if (typeof ErrorConstructor === "function") try {
				let error = new ErrorConstructor(val.message);
				error.stack = "";
				serialized[key] = error;
			} catch (e) {}
		}
		if (serialized[key] == null) {
			let error = new Error(val.message);
			error.stack = "";
			serialized[key] = error;
		}
	} else serialized[key] = val;
	return serialized;
}
var ViewTransitionContext = /*#__PURE__*/ import_react.createContext({ isTransitioning: false });
ViewTransitionContext.displayName = "ViewTransition";
var FetchersContext = /*#__PURE__*/ import_react.createContext(/* @__PURE__ */ new Map());
FetchersContext.displayName = "Fetchers";
var startTransitionImpl = import_react.startTransition;
var flushSyncImpl = import_react_dom.flushSync;
var useIdImpl = import_react.useId;
function startTransitionSafe(cb) {
	if (startTransitionImpl) startTransitionImpl(cb);
	else cb();
}
function flushSyncSafe(cb) {
	if (flushSyncImpl) flushSyncImpl(cb);
	else cb();
}
var Deferred = class {
	constructor() {
		this.status = "pending";
		this.promise = new Promise((resolve, reject) => {
			this.resolve = (value) => {
				if (this.status === "pending") {
					this.status = "resolved";
					resolve(value);
				}
			};
			this.reject = (reason) => {
				if (this.status === "pending") {
					this.status = "rejected";
					reject(reason);
				}
			};
		});
	}
};
/**
* Given a Remix Router instance, render the appropriate UI
*/
function RouterProvider(_ref) {
	let { fallbackElement, router, future } = _ref;
	let [state, setStateImpl] = import_react.useState(router.state);
	let [pendingState, setPendingState] = import_react.useState();
	let [vtContext, setVtContext] = import_react.useState({ isTransitioning: false });
	let [renderDfd, setRenderDfd] = import_react.useState();
	let [transition, setTransition] = import_react.useState();
	let [interruption, setInterruption] = import_react.useState();
	let fetcherData = import_react.useRef(/* @__PURE__ */ new Map());
	let { v7_startTransition } = future || {};
	let optInStartTransition = import_react.useCallback((cb) => {
		if (v7_startTransition) startTransitionSafe(cb);
		else cb();
	}, [v7_startTransition]);
	let setState = import_react.useCallback((newState, _ref2) => {
		let { deletedFetchers, flushSync, viewTransitionOpts } = _ref2;
		newState.fetchers.forEach((fetcher, key) => {
			if (fetcher.data !== void 0) fetcherData.current.set(key, fetcher.data);
		});
		deletedFetchers.forEach((key) => fetcherData.current.delete(key));
		let isViewTransitionUnavailable = router.window == null || router.window.document == null || typeof router.window.document.startViewTransition !== "function";
		if (!viewTransitionOpts || isViewTransitionUnavailable) {
			if (flushSync) flushSyncSafe(() => setStateImpl(newState));
			else optInStartTransition(() => setStateImpl(newState));
			return;
		}
		if (flushSync) {
			flushSyncSafe(() => {
				if (transition) {
					renderDfd && renderDfd.resolve();
					transition.skipTransition();
				}
				setVtContext({
					isTransitioning: true,
					flushSync: true,
					currentLocation: viewTransitionOpts.currentLocation,
					nextLocation: viewTransitionOpts.nextLocation
				});
			});
			let t = router.window.document.startViewTransition(() => {
				flushSyncSafe(() => setStateImpl(newState));
			});
			t.finished.finally(() => {
				flushSyncSafe(() => {
					setRenderDfd(void 0);
					setTransition(void 0);
					setPendingState(void 0);
					setVtContext({ isTransitioning: false });
				});
			});
			flushSyncSafe(() => setTransition(t));
			return;
		}
		if (transition) {
			renderDfd && renderDfd.resolve();
			transition.skipTransition();
			setInterruption({
				state: newState,
				currentLocation: viewTransitionOpts.currentLocation,
				nextLocation: viewTransitionOpts.nextLocation
			});
		} else {
			setPendingState(newState);
			setVtContext({
				isTransitioning: true,
				flushSync: false,
				currentLocation: viewTransitionOpts.currentLocation,
				nextLocation: viewTransitionOpts.nextLocation
			});
		}
	}, [
		router.window,
		transition,
		renderDfd,
		fetcherData,
		optInStartTransition
	]);
	import_react.useLayoutEffect(() => router.subscribe(setState), [router, setState]);
	import_react.useEffect(() => {
		if (vtContext.isTransitioning && !vtContext.flushSync) setRenderDfd(new Deferred());
	}, [vtContext]);
	import_react.useEffect(() => {
		if (renderDfd && pendingState && router.window) {
			let newState = pendingState;
			let renderPromise = renderDfd.promise;
			let transition = router.window.document.startViewTransition(async () => {
				optInStartTransition(() => setStateImpl(newState));
				await renderPromise;
			});
			transition.finished.finally(() => {
				setRenderDfd(void 0);
				setTransition(void 0);
				setPendingState(void 0);
				setVtContext({ isTransitioning: false });
			});
			setTransition(transition);
		}
	}, [
		optInStartTransition,
		pendingState,
		renderDfd,
		router.window
	]);
	import_react.useEffect(() => {
		if (renderDfd && pendingState && state.location.key === pendingState.location.key) renderDfd.resolve();
	}, [
		renderDfd,
		transition,
		state.location,
		pendingState
	]);
	import_react.useEffect(() => {
		if (!vtContext.isTransitioning && interruption) {
			setPendingState(interruption.state);
			setVtContext({
				isTransitioning: true,
				flushSync: false,
				currentLocation: interruption.currentLocation,
				nextLocation: interruption.nextLocation
			});
			setInterruption(void 0);
		}
	}, [vtContext.isTransitioning, interruption]);
	import_react.useEffect(() => {
		warning(fallbackElement == null || !router.future.v7_partialHydration, "`<RouterProvider fallbackElement>` is deprecated when using `v7_partialHydration`, use a `HydrateFallback` component instead");
	}, []);
	let navigator = import_react.useMemo(() => {
		return {
			createHref: router.createHref,
			encodeLocation: router.encodeLocation,
			go: (n) => router.navigate(n),
			push: (to, state, opts) => router.navigate(to, {
				state,
				preventScrollReset: opts == null ? void 0 : opts.preventScrollReset
			}),
			replace: (to, state, opts) => router.navigate(to, {
				replace: true,
				state,
				preventScrollReset: opts == null ? void 0 : opts.preventScrollReset
			})
		};
	}, [router]);
	let basename = router.basename || "/";
	let dataRouterContext = import_react.useMemo(() => ({
		router,
		navigator,
		static: false,
		basename
	}), [
		router,
		navigator,
		basename
	]);
	let routerFuture = import_react.useMemo(() => ({ v7_relativeSplatPath: router.future.v7_relativeSplatPath }), [router.future.v7_relativeSplatPath]);
	import_react.useEffect(() => logV6DeprecationWarnings(future, router.future), [future, router.future]);
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement(DataRouterContext.Provider, { value: dataRouterContext }, /*#__PURE__*/ import_react.createElement(DataRouterStateContext.Provider, { value: state }, /*#__PURE__*/ import_react.createElement(FetchersContext.Provider, { value: fetcherData.current }, /*#__PURE__*/ import_react.createElement(ViewTransitionContext.Provider, { value: vtContext }, /*#__PURE__*/ import_react.createElement(Router, {
		basename,
		location: state.location,
		navigationType: state.historyAction,
		navigator,
		future: routerFuture
	}, state.initialized || router.future.v7_partialHydration ? /*#__PURE__*/ import_react.createElement(MemoizedDataRoutes, {
		routes: router.routes,
		future: router.future,
		state
	}) : fallbackElement))))), null);
}
var MemoizedDataRoutes = /*#__PURE__*/ import_react.memo(DataRoutes);
function DataRoutes(_ref3) {
	let { routes, future, state } = _ref3;
	return useRoutesImpl(routes, void 0, state, future);
}
/**
* A `<Router>` for use in web browsers. Provides the cleanest URLs.
*/
function BrowserRouter(_ref4) {
	let { basename, children, future, window } = _ref4;
	let historyRef = import_react.useRef();
	if (historyRef.current == null) historyRef.current = createBrowserHistory({
		window,
		v5Compat: true
	});
	let history = historyRef.current;
	let [state, setStateImpl] = import_react.useState({
		action: history.action,
		location: history.location
	});
	let { v7_startTransition } = future || {};
	let setState = import_react.useCallback((newState) => {
		v7_startTransition && startTransitionImpl ? startTransitionImpl(() => setStateImpl(newState)) : setStateImpl(newState);
	}, [setStateImpl, v7_startTransition]);
	import_react.useLayoutEffect(() => history.listen(setState), [history, setState]);
	import_react.useEffect(() => logV6DeprecationWarnings(future), [future]);
	return /*#__PURE__*/ import_react.createElement(Router, {
		basename,
		children,
		location: state.location,
		navigationType: state.action,
		navigator: history,
		future
	});
}
/**
* A `<Router>` for use in web browsers. Stores the location in the hash
* portion of the URL so it is not sent to the server.
*/
function HashRouter(_ref5) {
	let { basename, children, future, window } = _ref5;
	let historyRef = import_react.useRef();
	if (historyRef.current == null) historyRef.current = createHashHistory({
		window,
		v5Compat: true
	});
	let history = historyRef.current;
	let [state, setStateImpl] = import_react.useState({
		action: history.action,
		location: history.location
	});
	let { v7_startTransition } = future || {};
	let setState = import_react.useCallback((newState) => {
		v7_startTransition && startTransitionImpl ? startTransitionImpl(() => setStateImpl(newState)) : setStateImpl(newState);
	}, [setStateImpl, v7_startTransition]);
	import_react.useLayoutEffect(() => history.listen(setState), [history, setState]);
	import_react.useEffect(() => logV6DeprecationWarnings(future), [future]);
	return /*#__PURE__*/ import_react.createElement(Router, {
		basename,
		children,
		location: state.location,
		navigationType: state.action,
		navigator: history,
		future
	});
}
/**
* A `<Router>` that accepts a pre-instantiated history object. It's important
* to note that using your own history object is highly discouraged and may add
* two versions of the history library to your bundles unless you use the same
* version of the history library that React Router uses internally.
*/
function HistoryRouter(_ref6) {
	let { basename, children, future, history } = _ref6;
	let [state, setStateImpl] = import_react.useState({
		action: history.action,
		location: history.location
	});
	let { v7_startTransition } = future || {};
	let setState = import_react.useCallback((newState) => {
		v7_startTransition && startTransitionImpl ? startTransitionImpl(() => setStateImpl(newState)) : setStateImpl(newState);
	}, [setStateImpl, v7_startTransition]);
	import_react.useLayoutEffect(() => history.listen(setState), [history, setState]);
	import_react.useEffect(() => logV6DeprecationWarnings(future), [future]);
	return /*#__PURE__*/ import_react.createElement(Router, {
		basename,
		children,
		location: state.location,
		navigationType: state.action,
		navigator: history,
		future
	});
}
HistoryRouter.displayName = "unstable_HistoryRouter";
var isBrowser = typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.document.createElement !== "undefined";
var ABSOLUTE_URL_REGEX = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;
/**
* The public API for rendering a history-aware `<a>`.
*/
var Link = /*#__PURE__*/ import_react.forwardRef(function LinkWithRef(_ref7, ref) {
	let { onClick, relative, reloadDocument, replace, state, target, to, preventScrollReset, viewTransition } = _ref7, rest = _objectWithoutPropertiesLoose(_ref7, _excluded);
	let { basename } = import_react.useContext(NavigationContext);
	let absoluteHref;
	let isExternal = false;
	if (typeof to === "string" && ABSOLUTE_URL_REGEX.test(to)) {
		absoluteHref = to;
		if (isBrowser) try {
			let currentUrl = new URL(window.location.href);
			let targetUrl = to.startsWith("//") ? new URL(currentUrl.protocol + to) : new URL(to);
			let path = stripBasename(targetUrl.pathname, basename);
			if (targetUrl.origin === currentUrl.origin && path != null) to = path + targetUrl.search + targetUrl.hash;
			else isExternal = true;
		} catch (e) {
			warning(false, "<Link to=\"" + to + "\"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.");
		}
	}
	let href = useHref(to, { relative });
	let internalOnClick = useLinkClickHandler(to, {
		replace,
		state,
		target,
		preventScrollReset,
		relative,
		viewTransition
	});
	function handleClick(event) {
		if (onClick) onClick(event);
		if (!event.defaultPrevented) internalOnClick(event);
	}
	return /*#__PURE__*/ import_react.createElement("a", _extends({}, rest, {
		href: absoluteHref || href,
		onClick: isExternal || reloadDocument ? onClick : handleClick,
		ref,
		target
	}));
});
Link.displayName = "Link";
/**
* A `<Link>` wrapper that knows if it's "active" or not.
*/
var NavLink = /*#__PURE__*/ import_react.forwardRef(function NavLinkWithRef(_ref8, ref) {
	let { "aria-current": ariaCurrentProp = "page", caseSensitive = false, className: classNameProp = "", end = false, style: styleProp, to, viewTransition, children } = _ref8, rest = _objectWithoutPropertiesLoose(_ref8, _excluded2);
	let path = useResolvedPath(to, { relative: rest.relative });
	let location = useLocation();
	let routerState = import_react.useContext(DataRouterStateContext);
	let { navigator, basename } = import_react.useContext(NavigationContext);
	let isTransitioning = routerState != null && useViewTransitionState(path) && viewTransition === true;
	let toPathname = navigator.encodeLocation ? navigator.encodeLocation(path).pathname : path.pathname;
	let locationPathname = location.pathname;
	let nextLocationPathname = routerState && routerState.navigation && routerState.navigation.location ? routerState.navigation.location.pathname : null;
	if (!caseSensitive) {
		locationPathname = locationPathname.toLowerCase();
		nextLocationPathname = nextLocationPathname ? nextLocationPathname.toLowerCase() : null;
		toPathname = toPathname.toLowerCase();
	}
	if (nextLocationPathname && basename) nextLocationPathname = stripBasename(nextLocationPathname, basename) || nextLocationPathname;
	const endSlashPosition = toPathname !== "/" && toPathname.endsWith("/") ? toPathname.length - 1 : toPathname.length;
	let isActive = locationPathname === toPathname || !end && locationPathname.startsWith(toPathname) && locationPathname.charAt(endSlashPosition) === "/";
	let isPending = nextLocationPathname != null && (nextLocationPathname === toPathname || !end && nextLocationPathname.startsWith(toPathname) && nextLocationPathname.charAt(toPathname.length) === "/");
	let renderProps = {
		isActive,
		isPending,
		isTransitioning
	};
	let ariaCurrent = isActive ? ariaCurrentProp : void 0;
	let className;
	if (typeof classNameProp === "function") className = classNameProp(renderProps);
	else className = [
		classNameProp,
		isActive ? "active" : null,
		isPending ? "pending" : null,
		isTransitioning ? "transitioning" : null
	].filter(Boolean).join(" ");
	let style = typeof styleProp === "function" ? styleProp(renderProps) : styleProp;
	return /*#__PURE__*/ import_react.createElement(Link, _extends({}, rest, {
		"aria-current": ariaCurrent,
		className,
		ref,
		style,
		to,
		viewTransition
	}), typeof children === "function" ? children(renderProps) : children);
});
NavLink.displayName = "NavLink";
/**
* A `@remix-run/router`-aware `<form>`. It behaves like a normal form except
* that the interaction with the server is with `fetch` instead of new document
* requests, allowing components to add nicer UX to the page as the form is
* submitted and returns with data.
*/
var Form = /*#__PURE__*/ import_react.forwardRef((_ref9, forwardedRef) => {
	let { fetcherKey, navigate, reloadDocument, replace, state, method = defaultMethod, action, onSubmit, relative, preventScrollReset, viewTransition } = _ref9, props = _objectWithoutPropertiesLoose(_ref9, _excluded3);
	let submit = useSubmit();
	let formAction = useFormAction(action, { relative });
	let formMethod = method.toLowerCase() === "get" ? "get" : "post";
	let submitHandler = (event) => {
		onSubmit && onSubmit(event);
		if (event.defaultPrevented) return;
		event.preventDefault();
		let submitter = event.nativeEvent.submitter;
		let submitMethod = (submitter == null ? void 0 : submitter.getAttribute("formmethod")) || method;
		submit(submitter || event.currentTarget, {
			fetcherKey,
			method: submitMethod,
			navigate,
			replace,
			state,
			relative,
			preventScrollReset,
			viewTransition
		});
	};
	return /*#__PURE__*/ import_react.createElement("form", _extends({
		ref: forwardedRef,
		method: formMethod,
		action: formAction,
		onSubmit: reloadDocument ? onSubmit : submitHandler
	}, props));
});
Form.displayName = "Form";
/**
* This component will emulate the browser's scroll restoration on location
* changes.
*/
function ScrollRestoration(_ref0) {
	let { getKey, storageKey } = _ref0;
	useScrollRestoration({
		getKey,
		storageKey
	});
	return null;
}
ScrollRestoration.displayName = "ScrollRestoration";
var DataRouterHook;
(function(DataRouterHook) {
	DataRouterHook["UseScrollRestoration"] = "useScrollRestoration";
	DataRouterHook["UseSubmit"] = "useSubmit";
	DataRouterHook["UseSubmitFetcher"] = "useSubmitFetcher";
	DataRouterHook["UseFetcher"] = "useFetcher";
	DataRouterHook["useViewTransitionState"] = "useViewTransitionState";
})(DataRouterHook || (DataRouterHook = {}));
var DataRouterStateHook;
(function(DataRouterStateHook) {
	DataRouterStateHook["UseFetcher"] = "useFetcher";
	DataRouterStateHook["UseFetchers"] = "useFetchers";
	DataRouterStateHook["UseScrollRestoration"] = "useScrollRestoration";
})(DataRouterStateHook || (DataRouterStateHook = {}));
function getDataRouterConsoleError(hookName) {
	return hookName + " must be used within a data router.  See https://reactrouter.com/v6/routers/picking-a-router.";
}
function useDataRouterContext(hookName) {
	let ctx = import_react.useContext(DataRouterContext);
	!ctx && invariant(false, getDataRouterConsoleError(hookName));
	return ctx;
}
function useDataRouterState(hookName) {
	let state = import_react.useContext(DataRouterStateContext);
	!state && invariant(false, getDataRouterConsoleError(hookName));
	return state;
}
/**
* Handles the click behavior for router `<Link>` components. This is useful if
* you need to create custom `<Link>` components with the same click behavior we
* use in our exported `<Link>`.
*/
function useLinkClickHandler(to, _temp) {
	let { target, replace: replaceProp, state, preventScrollReset, relative, viewTransition } = _temp === void 0 ? {} : _temp;
	let navigate = useNavigate();
	let location = useLocation();
	let path = useResolvedPath(to, { relative });
	return import_react.useCallback((event) => {
		if (shouldProcessLinkClick(event, target)) {
			event.preventDefault();
			let replace = replaceProp !== void 0 ? replaceProp : createPath(location) === createPath(path);
			navigate(to, {
				replace,
				state,
				preventScrollReset,
				relative,
				viewTransition
			});
		}
	}, [
		location,
		navigate,
		path,
		replaceProp,
		state,
		target,
		to,
		preventScrollReset,
		relative,
		viewTransition
	]);
}
/**
* A convenient wrapper for reading and writing search parameters via the
* URLSearchParams interface.
*/
function useSearchParams(defaultInit) {
	warning(typeof URLSearchParams !== "undefined", "You cannot use the `useSearchParams` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.");
	let defaultSearchParamsRef = import_react.useRef(createSearchParams(defaultInit));
	let hasSetSearchParamsRef = import_react.useRef(false);
	let location = useLocation();
	let searchParams = import_react.useMemo(() => getSearchParamsForLocation(location.search, hasSetSearchParamsRef.current ? null : defaultSearchParamsRef.current), [location.search]);
	let navigate = useNavigate();
	return [searchParams, import_react.useCallback((nextInit, navigateOptions) => {
		const newSearchParams = createSearchParams(typeof nextInit === "function" ? nextInit(searchParams) : nextInit);
		hasSetSearchParamsRef.current = true;
		navigate("?" + newSearchParams, navigateOptions);
	}, [navigate, searchParams])];
}
function validateClientSideSubmission() {
	if (typeof document === "undefined") throw new Error("You are calling submit during the server render. Try calling submit within a `useEffect` or callback instead.");
}
var fetcherId = 0;
var getUniqueFetcherId = () => "__" + String(++fetcherId) + "__";
/**
* Returns a function that may be used to programmatically submit a form (or
* some arbitrary data) to the server.
*/
function useSubmit() {
	let { router } = useDataRouterContext(DataRouterHook.UseSubmit);
	let { basename } = import_react.useContext(NavigationContext);
	let currentRouteId = useRouteId();
	return import_react.useCallback(function(target, options) {
		if (options === void 0) options = {};
		validateClientSideSubmission();
		let { action, method, encType, formData, body } = getFormSubmissionInfo(target, basename);
		if (options.navigate === false) {
			let key = options.fetcherKey || getUniqueFetcherId();
			router.fetch(key, currentRouteId, options.action || action, {
				preventScrollReset: options.preventScrollReset,
				formData,
				body,
				formMethod: options.method || method,
				formEncType: options.encType || encType,
				flushSync: options.flushSync
			});
		} else router.navigate(options.action || action, {
			preventScrollReset: options.preventScrollReset,
			formData,
			body,
			formMethod: options.method || method,
			formEncType: options.encType || encType,
			replace: options.replace,
			state: options.state,
			fromRouteId: currentRouteId,
			flushSync: options.flushSync,
			viewTransition: options.viewTransition
		});
	}, [
		router,
		basename,
		currentRouteId
	]);
}
function useFormAction(action, _temp2) {
	let { relative } = _temp2 === void 0 ? {} : _temp2;
	let { basename } = import_react.useContext(NavigationContext);
	let routeContext = import_react.useContext(RouteContext);
	!routeContext && invariant(false, "useFormAction must be used inside a RouteContext");
	let [match] = routeContext.matches.slice(-1);
	let path = _extends({}, useResolvedPath(action ? action : ".", { relative }));
	let location = useLocation();
	if (action == null) {
		path.search = location.search;
		let params = new URLSearchParams(path.search);
		let indexValues = params.getAll("index");
		if (indexValues.some((v) => v === "")) {
			params.delete("index");
			indexValues.filter((v) => v).forEach((v) => params.append("index", v));
			let qs = params.toString();
			path.search = qs ? "?" + qs : "";
		}
	}
	if ((!action || action === ".") && match.route.index) path.search = path.search ? path.search.replace(/^\?/, "?index&") : "?index";
	if (basename !== "/") path.pathname = path.pathname === "/" ? basename : joinPaths([basename, path.pathname]);
	return createPath(path);
}
/**
* Interacts with route loaders and actions without causing a navigation. Great
* for any interaction that stays on the same page.
*/
function useFetcher(_temp3) {
	var _route$matches;
	let { key } = _temp3 === void 0 ? {} : _temp3;
	let { router } = useDataRouterContext(DataRouterHook.UseFetcher);
	let state = useDataRouterState(DataRouterStateHook.UseFetcher);
	let fetcherData = import_react.useContext(FetchersContext);
	let route = import_react.useContext(RouteContext);
	let routeId = (_route$matches = route.matches[route.matches.length - 1]) == null ? void 0 : _route$matches.route.id;
	!fetcherData && invariant(false, "useFetcher must be used inside a FetchersContext");
	!route && invariant(false, "useFetcher must be used inside a RouteContext");
	!(routeId != null) && invariant(false, "useFetcher can only be used on routes that contain a unique \"id\"");
	let defaultKey = useIdImpl ? useIdImpl() : "";
	let [fetcherKey, setFetcherKey] = import_react.useState(key || defaultKey);
	if (key && key !== fetcherKey) setFetcherKey(key);
	else if (!fetcherKey) setFetcherKey(getUniqueFetcherId());
	import_react.useEffect(() => {
		router.getFetcher(fetcherKey);
		return () => {
			router.deleteFetcher(fetcherKey);
		};
	}, [router, fetcherKey]);
	let load = import_react.useCallback((href, opts) => {
		!routeId && invariant(false, "No routeId available for fetcher.load()");
		router.fetch(fetcherKey, routeId, href, opts);
	}, [
		fetcherKey,
		routeId,
		router
	]);
	let submitImpl = useSubmit();
	let submit = import_react.useCallback((target, opts) => {
		submitImpl(target, _extends({}, opts, {
			navigate: false,
			fetcherKey
		}));
	}, [fetcherKey, submitImpl]);
	let FetcherForm = import_react.useMemo(() => {
		let FetcherForm = /*#__PURE__*/ import_react.forwardRef((props, ref) => {
			return /*#__PURE__*/ import_react.createElement(Form, _extends({}, props, {
				navigate: false,
				fetcherKey,
				ref
			}));
		});
		FetcherForm.displayName = "fetcher.Form";
		return FetcherForm;
	}, [fetcherKey]);
	let fetcher = state.fetchers.get(fetcherKey) || IDLE_FETCHER;
	let data = fetcherData.get(fetcherKey);
	return import_react.useMemo(() => _extends({
		Form: FetcherForm,
		submit,
		load
	}, fetcher, { data }), [
		FetcherForm,
		submit,
		load,
		fetcher,
		data
	]);
}
/**
* Provides all fetchers currently on the page. Useful for layouts and parent
* routes that need to provide pending/optimistic UI regarding the fetch.
*/
function useFetchers() {
	let state = useDataRouterState(DataRouterStateHook.UseFetchers);
	return Array.from(state.fetchers.entries()).map((_ref1) => {
		let [key, fetcher] = _ref1;
		return _extends({}, fetcher, { key });
	});
}
var SCROLL_RESTORATION_STORAGE_KEY = "react-router-scroll-positions";
var savedScrollPositions = {};
/**
* When rendered inside a RouterProvider, will restore scroll positions on navigations
*/
function useScrollRestoration(_temp4) {
	let { getKey, storageKey } = _temp4 === void 0 ? {} : _temp4;
	let { router } = useDataRouterContext(DataRouterHook.UseScrollRestoration);
	let { restoreScrollPosition, preventScrollReset } = useDataRouterState(DataRouterStateHook.UseScrollRestoration);
	let { basename } = import_react.useContext(NavigationContext);
	let location = useLocation();
	let matches = useMatches();
	let navigation = useNavigation();
	import_react.useEffect(() => {
		window.history.scrollRestoration = "manual";
		return () => {
			window.history.scrollRestoration = "auto";
		};
	}, []);
	usePageHide(import_react.useCallback(() => {
		if (navigation.state === "idle") {
			let key = (getKey ? getKey(location, matches) : null) || location.key;
			savedScrollPositions[key] = window.scrollY;
		}
		try {
			sessionStorage.setItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY, JSON.stringify(savedScrollPositions));
		} catch (error) {
			warning(false, "Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (" + error + ").");
		}
		window.history.scrollRestoration = "auto";
	}, [
		storageKey,
		getKey,
		navigation.state,
		location,
		matches
	]));
	if (typeof document !== "undefined") {
		import_react.useLayoutEffect(() => {
			try {
				let sessionPositions = sessionStorage.getItem(storageKey || SCROLL_RESTORATION_STORAGE_KEY);
				if (sessionPositions) savedScrollPositions = JSON.parse(sessionPositions);
			} catch (e) {}
		}, [storageKey]);
		import_react.useLayoutEffect(() => {
			let getKeyWithoutBasename = getKey && basename !== "/" ? (location, matches) => getKey(_extends({}, location, { pathname: stripBasename(location.pathname, basename) || location.pathname }), matches) : getKey;
			let disableScrollRestoration = router == null ? void 0 : router.enableScrollRestoration(savedScrollPositions, () => window.scrollY, getKeyWithoutBasename);
			return () => disableScrollRestoration && disableScrollRestoration();
		}, [
			router,
			basename,
			getKey
		]);
		import_react.useLayoutEffect(() => {
			if (restoreScrollPosition === false) return;
			if (typeof restoreScrollPosition === "number") {
				window.scrollTo(0, restoreScrollPosition);
				return;
			}
			if (location.hash) {
				let el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
				if (el) {
					el.scrollIntoView();
					return;
				}
			}
			if (preventScrollReset === true) return;
			window.scrollTo(0, 0);
		}, [
			location,
			restoreScrollPosition,
			preventScrollReset
		]);
	}
}
/**
* Setup a callback to be fired on the window's `beforeunload` event. This is
* useful for saving some data to `window.localStorage` just before the page
* refreshes.
*
* Note: The `callback` argument should be a function created with
* `React.useCallback()`.
*/
function useBeforeUnload(callback, options) {
	let { capture } = options || {};
	import_react.useEffect(() => {
		let opts = capture != null ? { capture } : void 0;
		window.addEventListener("beforeunload", callback, opts);
		return () => {
			window.removeEventListener("beforeunload", callback, opts);
		};
	}, [callback, capture]);
}
/**
* Setup a callback to be fired on the window's `pagehide` event. This is
* useful for saving some data to `window.localStorage` just before the page
* refreshes.  This event is better supported than beforeunload across browsers.
*
* Note: The `callback` argument should be a function created with
* `React.useCallback()`.
*/
function usePageHide(callback, options) {
	let { capture } = options || {};
	import_react.useEffect(() => {
		let opts = capture != null ? { capture } : void 0;
		window.addEventListener("pagehide", callback, opts);
		return () => {
			window.removeEventListener("pagehide", callback, opts);
		};
	}, [callback, capture]);
}
/**
* Wrapper around useBlocker to show a window.confirm prompt to users instead
* of building a custom UI with useBlocker.
*
* Warning: This has *a lot of rough edges* and behaves very differently (and
* very incorrectly in some cases) across browsers if user click addition
* back/forward navigations while the confirm is open.  Use at your own risk.
*/
function usePrompt(_ref10) {
	let { when, message } = _ref10;
	let blocker = useBlocker(when);
	import_react.useEffect(() => {
		if (blocker.state === "blocked") {
			if (window.confirm(message)) setTimeout(blocker.proceed, 0);
			else blocker.reset();
		}
	}, [blocker, message]);
	import_react.useEffect(() => {
		if (blocker.state === "blocked" && !when) blocker.reset();
	}, [blocker, when]);
}
/**
* Return a boolean indicating if there is an active view transition to the
* given href.  You can use this value to render CSS classes or viewTransitionName
* styles onto your elements
*
* @param href The destination href
* @param [opts.relative] Relative routing type ("route" | "path")
*/
function useViewTransitionState(to, opts) {
	if (opts === void 0) opts = {};
	let vtContext = import_react.useContext(ViewTransitionContext);
	!(vtContext != null) && invariant(false, "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
	let { basename } = useDataRouterContext(DataRouterHook.useViewTransitionState);
	let path = useResolvedPath(to, { relative: opts.relative });
	if (!vtContext.isTransitioning) return false;
	let currentPath = stripBasename(vtContext.currentLocation.pathname, basename) || vtContext.currentLocation.pathname;
	let nextPath = stripBasename(vtContext.nextLocation.pathname, basename) || vtContext.nextLocation.pathname;
	return matchPath(path.pathname, nextPath) != null || matchPath(path.pathname, currentPath) != null;
}
//#endregion
export { AbortedDeferredError, Await, BrowserRouter, Form, HashRouter, Link, MemoryRouter, NavLink, Navigate, Action as NavigationType, Outlet, Route, Router, RouterProvider, Routes, ScrollRestoration, DataRouterContext as UNSAFE_DataRouterContext, DataRouterStateContext as UNSAFE_DataRouterStateContext, ErrorResponseImpl as UNSAFE_ErrorResponseImpl, FetchersContext as UNSAFE_FetchersContext, LocationContext as UNSAFE_LocationContext, NavigationContext as UNSAFE_NavigationContext, RouteContext as UNSAFE_RouteContext, ViewTransitionContext as UNSAFE_ViewTransitionContext, useRouteId as UNSAFE_useRouteId, useScrollRestoration as UNSAFE_useScrollRestoration, createBrowserRouter, createHashRouter, createMemoryRouter, createPath, createRoutesFromChildren, createRoutesFromChildren as createRoutesFromElements, createSearchParams, defer, generatePath, isRouteErrorResponse, json, matchPath, matchRoutes, parsePath, redirect, redirectDocument, renderMatches, replace, resolvePath, HistoryRouter as unstable_HistoryRouter, usePrompt as unstable_usePrompt, useActionData, useAsyncError, useAsyncValue, useBeforeUnload, useBlocker, useFetcher, useFetchers, useFormAction, useHref, useInRouterContext, useLinkClickHandler, useLoaderData, useLocation, useMatch, useMatches, useNavigate, useNavigation, useNavigationType, useOutlet, useOutletContext, useParams, useResolvedPath, useRevalidator, useRouteError, useRouteLoaderData, useRoutes, useSearchParams, useSubmit, useViewTransitionState };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3Qtcm91dGVyLWRvbS5qcyIsIm5hbWVzIjpbIl9leHRlbmRzIiwiQUJTT0xVVEVfVVJMX1JFR0VYIiwiX2V4dGVuZHMiLCJVTlNBRkVfaW52YXJpYW50IiwiVU5TQUZFX2RlY29kZVBhdGgiLCJVTlNBRkVfZ2V0UmVzb2x2ZVRvTWF0Y2hlcyIsIlVOU0FGRV93YXJuaW5nIiwiRGF0YVJvdXRlckhvb2siLCJEYXRhUm91dGVyU3RhdGVIb29rIiwiZ2V0RGF0YVJvdXRlckNvbnNvbGVFcnJvciIsInVzZURhdGFSb3V0ZXJDb250ZXh0IiwidXNlRGF0YVJvdXRlclN0YXRlIiwiVU5TQUZFX2NvbnZlcnRSb3V0ZU1hdGNoVG9VaU1hdGNoIiwic3RhcnRUcmFuc2l0aW9uSW1wbCIsIlNUQVJUX1RSQU5TSVRJT04iLCJVTlNBRkVfd2FybmluZyIsIlVOU0FGRV9tYXBSb3V0ZVByb3BlcnRpZXMiLCJVTlNBRkVfRXJyb3JSZXNwb25zZUltcGwiLCJTVEFSVF9UUkFOU0lUSU9OIiwiRkxVU0hfU1lOQyIsIlVTRV9JRCIsIlVOU0FGRV9sb2dWNkRlcHJlY2F0aW9uV2FybmluZ3MiLCJVTlNBRkVfRGF0YVJvdXRlckNvbnRleHQiLCJVTlNBRkVfRGF0YVJvdXRlclN0YXRlQ29udGV4dCIsIlVOU0FGRV91c2VSb3V0ZXNJbXBsIiwiVU5TQUZFX05hdmlnYXRpb25Db250ZXh0IiwiVU5TQUZFX2ludmFyaWFudCIsIlVOU0FGRV91c2VSb3V0ZUlkIiwiVU5TQUZFX1JvdXRlQ29udGV4dCJdLCJzb3VyY2VzIjpbIi4uLy4uL0ByZW1peC1ydW4vcm91dGVyL2Rpc3Qvcm91dGVyLmpzIiwiLi4vLi4vcmVhY3Qtcm91dGVyL2Rpc3QvaW5kZXguanMiLCIuLi8uLi9yZWFjdC1yb3V0ZXItZG9tL2Rpc3QvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAcmVtaXgtcnVuL3JvdXRlciB2MS4yMy4zXG4gKlxuICogQ29weXJpZ2h0IChjKSBSZW1peCBTb2Z0d2FyZSBJbmMuXG4gKlxuICogVGhpcyBzb3VyY2UgY29kZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UgZm91bmQgaW4gdGhlXG4gKiBMSUNFTlNFLm1kIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKlxuICogQGxpY2Vuc2UgTUlUXG4gKi9cbmZ1bmN0aW9uIF9leHRlbmRzKCkge1xuICByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikge1xuICAgIGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7XG4gICAgICB2YXIgdCA9IGFyZ3VtZW50c1tlXTtcbiAgICAgIGZvciAodmFyIHIgaW4gdCkgKHt9KS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHQsIHIpICYmIChuW3JdID0gdFtyXSk7XG4gICAgfVxuICAgIHJldHVybiBuO1xuICB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpO1xufVxuXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8jcmVnaW9uIFR5cGVzIGFuZCBDb25zdGFudHNcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vKipcbiAqIEFjdGlvbnMgcmVwcmVzZW50IHRoZSB0eXBlIG9mIGNoYW5nZSB0byBhIGxvY2F0aW9uIHZhbHVlLlxuICovXG52YXIgQWN0aW9uO1xuKGZ1bmN0aW9uIChBY3Rpb24pIHtcbiAgLyoqXG4gICAqIEEgUE9QIGluZGljYXRlcyBhIGNoYW5nZSB0byBhbiBhcmJpdHJhcnkgaW5kZXggaW4gdGhlIGhpc3Rvcnkgc3RhY2ssIHN1Y2hcbiAgICogYXMgYSBiYWNrIG9yIGZvcndhcmQgbmF2aWdhdGlvbi4gSXQgZG9lcyBub3QgZGVzY3JpYmUgdGhlIGRpcmVjdGlvbiBvZiB0aGVcbiAgICogbmF2aWdhdGlvbiwgb25seSB0aGF0IHRoZSBjdXJyZW50IGluZGV4IGNoYW5nZWQuXG4gICAqXG4gICAqIE5vdGU6IFRoaXMgaXMgdGhlIGRlZmF1bHQgYWN0aW9uIGZvciBuZXdseSBjcmVhdGVkIGhpc3Rvcnkgb2JqZWN0cy5cbiAgICovXG4gIEFjdGlvbltcIlBvcFwiXSA9IFwiUE9QXCI7XG4gIC8qKlxuICAgKiBBIFBVU0ggaW5kaWNhdGVzIGEgbmV3IGVudHJ5IGJlaW5nIGFkZGVkIHRvIHRoZSBoaXN0b3J5IHN0YWNrLCBzdWNoIGFzIHdoZW5cbiAgICogYSBsaW5rIGlzIGNsaWNrZWQgYW5kIGEgbmV3IHBhZ2UgbG9hZHMuIFdoZW4gdGhpcyBoYXBwZW5zLCBhbGwgc3Vic2VxdWVudFxuICAgKiBlbnRyaWVzIGluIHRoZSBzdGFjayBhcmUgbG9zdC5cbiAgICovXG4gIEFjdGlvbltcIlB1c2hcIl0gPSBcIlBVU0hcIjtcbiAgLyoqXG4gICAqIEEgUkVQTEFDRSBpbmRpY2F0ZXMgdGhlIGVudHJ5IGF0IHRoZSBjdXJyZW50IGluZGV4IGluIHRoZSBoaXN0b3J5IHN0YWNrXG4gICAqIGJlaW5nIHJlcGxhY2VkIGJ5IGEgbmV3IG9uZS5cbiAgICovXG4gIEFjdGlvbltcIlJlcGxhY2VcIl0gPSBcIlJFUExBQ0VcIjtcbn0pKEFjdGlvbiB8fCAoQWN0aW9uID0ge30pKTtcbmNvbnN0IFBvcFN0YXRlRXZlbnRUeXBlID0gXCJwb3BzdGF0ZVwiO1xuLyoqXG4gKiBNZW1vcnkgaGlzdG9yeSBzdG9yZXMgdGhlIGN1cnJlbnQgbG9jYXRpb24gaW4gbWVtb3J5LiBJdCBpcyBkZXNpZ25lZCBmb3IgdXNlXG4gKiBpbiBzdGF0ZWZ1bCBub24tYnJvd3NlciBlbnZpcm9ubWVudHMgbGlrZSB0ZXN0cyBhbmQgUmVhY3QgTmF0aXZlLlxuICovXG5mdW5jdGlvbiBjcmVhdGVNZW1vcnlIaXN0b3J5KG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICBsZXQge1xuICAgIGluaXRpYWxFbnRyaWVzID0gW1wiL1wiXSxcbiAgICBpbml0aWFsSW5kZXgsXG4gICAgdjVDb21wYXQgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgbGV0IGVudHJpZXM7IC8vIERlY2xhcmUgc28gd2UgY2FuIGFjY2VzcyBmcm9tIGNyZWF0ZU1lbW9yeUxvY2F0aW9uXG4gIGVudHJpZXMgPSBpbml0aWFsRW50cmllcy5tYXAoKGVudHJ5LCBpbmRleCkgPT4gY3JlYXRlTWVtb3J5TG9jYXRpb24oZW50cnksIHR5cGVvZiBlbnRyeSA9PT0gXCJzdHJpbmdcIiA/IG51bGwgOiBlbnRyeS5zdGF0ZSwgaW5kZXggPT09IDAgPyBcImRlZmF1bHRcIiA6IHVuZGVmaW5lZCkpO1xuICBsZXQgaW5kZXggPSBjbGFtcEluZGV4KGluaXRpYWxJbmRleCA9PSBudWxsID8gZW50cmllcy5sZW5ndGggLSAxIDogaW5pdGlhbEluZGV4KTtcbiAgbGV0IGFjdGlvbiA9IEFjdGlvbi5Qb3A7XG4gIGxldCBsaXN0ZW5lciA9IG51bGw7XG4gIGZ1bmN0aW9uIGNsYW1wSW5kZXgobikge1xuICAgIHJldHVybiBNYXRoLm1pbihNYXRoLm1heChuLCAwKSwgZW50cmllcy5sZW5ndGggLSAxKTtcbiAgfVxuICBmdW5jdGlvbiBnZXRDdXJyZW50TG9jYXRpb24oKSB7XG4gICAgcmV0dXJuIGVudHJpZXNbaW5kZXhdO1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZU1lbW9yeUxvY2F0aW9uKHRvLCBzdGF0ZSwga2V5KSB7XG4gICAgaWYgKHN0YXRlID09PSB2b2lkIDApIHtcbiAgICAgIHN0YXRlID0gbnVsbDtcbiAgICB9XG4gICAgbGV0IGxvY2F0aW9uID0gY3JlYXRlTG9jYXRpb24oZW50cmllcyA/IGdldEN1cnJlbnRMb2NhdGlvbigpLnBhdGhuYW1lIDogXCIvXCIsIHRvLCBzdGF0ZSwga2V5KTtcbiAgICB3YXJuaW5nKGxvY2F0aW9uLnBhdGhuYW1lLmNoYXJBdCgwKSA9PT0gXCIvXCIsIFwicmVsYXRpdmUgcGF0aG5hbWVzIGFyZSBub3Qgc3VwcG9ydGVkIGluIG1lbW9yeSBoaXN0b3J5OiBcIiArIEpTT04uc3RyaW5naWZ5KHRvKSk7XG4gICAgcmV0dXJuIGxvY2F0aW9uO1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZUhyZWYodG8pIHtcbiAgICByZXR1cm4gdHlwZW9mIHRvID09PSBcInN0cmluZ1wiID8gdG8gOiBjcmVhdGVQYXRoKHRvKTtcbiAgfVxuICBsZXQgaGlzdG9yeSA9IHtcbiAgICBnZXQgaW5kZXgoKSB7XG4gICAgICByZXR1cm4gaW5kZXg7XG4gICAgfSxcbiAgICBnZXQgYWN0aW9uKCkge1xuICAgICAgcmV0dXJuIGFjdGlvbjtcbiAgICB9LFxuICAgIGdldCBsb2NhdGlvbigpIHtcbiAgICAgIHJldHVybiBnZXRDdXJyZW50TG9jYXRpb24oKTtcbiAgICB9LFxuICAgIGNyZWF0ZUhyZWYsXG4gICAgY3JlYXRlVVJMKHRvKSB7XG4gICAgICByZXR1cm4gbmV3IFVSTChjcmVhdGVIcmVmKHRvKSwgXCJodHRwOi8vbG9jYWxob3N0XCIpO1xuICAgIH0sXG4gICAgZW5jb2RlTG9jYXRpb24odG8pIHtcbiAgICAgIGxldCBwYXRoID0gdHlwZW9mIHRvID09PSBcInN0cmluZ1wiID8gcGFyc2VQYXRoKHRvKSA6IHRvO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcGF0aG5hbWU6IHBhdGgucGF0aG5hbWUgfHwgXCJcIixcbiAgICAgICAgc2VhcmNoOiBwYXRoLnNlYXJjaCB8fCBcIlwiLFxuICAgICAgICBoYXNoOiBwYXRoLmhhc2ggfHwgXCJcIlxuICAgICAgfTtcbiAgICB9LFxuICAgIHB1c2godG8sIHN0YXRlKSB7XG4gICAgICBhY3Rpb24gPSBBY3Rpb24uUHVzaDtcbiAgICAgIGxldCBuZXh0TG9jYXRpb24gPSBjcmVhdGVNZW1vcnlMb2NhdGlvbih0bywgc3RhdGUpO1xuICAgICAgaW5kZXggKz0gMTtcbiAgICAgIGVudHJpZXMuc3BsaWNlKGluZGV4LCBlbnRyaWVzLmxlbmd0aCwgbmV4dExvY2F0aW9uKTtcbiAgICAgIGlmICh2NUNvbXBhdCAmJiBsaXN0ZW5lcikge1xuICAgICAgICBsaXN0ZW5lcih7XG4gICAgICAgICAgYWN0aW9uLFxuICAgICAgICAgIGxvY2F0aW9uOiBuZXh0TG9jYXRpb24sXG4gICAgICAgICAgZGVsdGE6IDFcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgICByZXBsYWNlKHRvLCBzdGF0ZSkge1xuICAgICAgYWN0aW9uID0gQWN0aW9uLlJlcGxhY2U7XG4gICAgICBsZXQgbmV4dExvY2F0aW9uID0gY3JlYXRlTWVtb3J5TG9jYXRpb24odG8sIHN0YXRlKTtcbiAgICAgIGVudHJpZXNbaW5kZXhdID0gbmV4dExvY2F0aW9uO1xuICAgICAgaWYgKHY1Q29tcGF0ICYmIGxpc3RlbmVyKSB7XG4gICAgICAgIGxpc3RlbmVyKHtcbiAgICAgICAgICBhY3Rpb24sXG4gICAgICAgICAgbG9jYXRpb246IG5leHRMb2NhdGlvbixcbiAgICAgICAgICBkZWx0YTogMFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGdvKGRlbHRhKSB7XG4gICAgICBhY3Rpb24gPSBBY3Rpb24uUG9wO1xuICAgICAgbGV0IG5leHRJbmRleCA9IGNsYW1wSW5kZXgoaW5kZXggKyBkZWx0YSk7XG4gICAgICBsZXQgbmV4dExvY2F0aW9uID0gZW50cmllc1tuZXh0SW5kZXhdO1xuICAgICAgaW5kZXggPSBuZXh0SW5kZXg7XG4gICAgICBpZiAobGlzdGVuZXIpIHtcbiAgICAgICAgbGlzdGVuZXIoe1xuICAgICAgICAgIGFjdGlvbixcbiAgICAgICAgICBsb2NhdGlvbjogbmV4dExvY2F0aW9uLFxuICAgICAgICAgIGRlbHRhXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgbGlzdGVuKGZuKSB7XG4gICAgICBsaXN0ZW5lciA9IGZuO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgbGlzdGVuZXIgPSBudWxsO1xuICAgICAgfTtcbiAgICB9XG4gIH07XG4gIHJldHVybiBoaXN0b3J5O1xufVxuLyoqXG4gKiBCcm93c2VyIGhpc3Rvcnkgc3RvcmVzIHRoZSBsb2NhdGlvbiBpbiByZWd1bGFyIFVSTHMuIFRoaXMgaXMgdGhlIHN0YW5kYXJkIGZvclxuICogbW9zdCB3ZWIgYXBwcywgYnV0IGl0IHJlcXVpcmVzIHNvbWUgY29uZmlndXJhdGlvbiBvbiB0aGUgc2VydmVyIHRvIGVuc3VyZSB5b3VcbiAqIHNlcnZlIHRoZSBzYW1lIGFwcCBhdCBtdWx0aXBsZSBVUkxzLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL3JlbWl4LXJ1bi9oaXN0b3J5L3RyZWUvbWFpbi9kb2NzL2FwaS1yZWZlcmVuY2UubWQjY3JlYXRlYnJvd3Nlcmhpc3RvcnlcbiAqL1xuZnVuY3Rpb24gY3JlYXRlQnJvd3Nlckhpc3Rvcnkob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZUJyb3dzZXJMb2NhdGlvbih3aW5kb3csIGdsb2JhbEhpc3RvcnkpIHtcbiAgICBsZXQge1xuICAgICAgcGF0aG5hbWUsXG4gICAgICBzZWFyY2gsXG4gICAgICBoYXNoXG4gICAgfSA9IHdpbmRvdy5sb2NhdGlvbjtcbiAgICByZXR1cm4gY3JlYXRlTG9jYXRpb24oXCJcIiwge1xuICAgICAgcGF0aG5hbWUsXG4gICAgICBzZWFyY2gsXG4gICAgICBoYXNoXG4gICAgfSxcbiAgICAvLyBzdGF0ZSBkZWZhdWx0cyB0byBgbnVsbGAgYmVjYXVzZSBgd2luZG93Lmhpc3Rvcnkuc3RhdGVgIGRvZXNcbiAgICBnbG9iYWxIaXN0b3J5LnN0YXRlICYmIGdsb2JhbEhpc3Rvcnkuc3RhdGUudXNyIHx8IG51bGwsIGdsb2JhbEhpc3Rvcnkuc3RhdGUgJiYgZ2xvYmFsSGlzdG9yeS5zdGF0ZS5rZXkgfHwgXCJkZWZhdWx0XCIpO1xuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZUJyb3dzZXJIcmVmKHdpbmRvdywgdG8pIHtcbiAgICByZXR1cm4gdHlwZW9mIHRvID09PSBcInN0cmluZ1wiID8gdG8gOiBjcmVhdGVQYXRoKHRvKTtcbiAgfVxuICByZXR1cm4gZ2V0VXJsQmFzZWRIaXN0b3J5KGNyZWF0ZUJyb3dzZXJMb2NhdGlvbiwgY3JlYXRlQnJvd3NlckhyZWYsIG51bGwsIG9wdGlvbnMpO1xufVxuLyoqXG4gKiBIYXNoIGhpc3Rvcnkgc3RvcmVzIHRoZSBsb2NhdGlvbiBpbiB3aW5kb3cubG9jYXRpb24uaGFzaC4gVGhpcyBtYWtlcyBpdCBpZGVhbFxuICogZm9yIHNpdHVhdGlvbnMgd2hlcmUgeW91IGRvbid0IHdhbnQgdG8gc2VuZCB0aGUgbG9jYXRpb24gdG8gdGhlIHNlcnZlciBmb3JcbiAqIHNvbWUgcmVhc29uLCBlaXRoZXIgYmVjYXVzZSB5b3UgZG8gY2Fubm90IGNvbmZpZ3VyZSBpdCBvciB0aGUgVVJMIHNwYWNlIGlzXG4gKiByZXNlcnZlZCBmb3Igc29tZXRoaW5nIGVsc2UuXG4gKlxuICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vcmVtaXgtcnVuL2hpc3RvcnkvdHJlZS9tYWluL2RvY3MvYXBpLXJlZmVyZW5jZS5tZCNjcmVhdGVoYXNoaGlzdG9yeVxuICovXG5mdW5jdGlvbiBjcmVhdGVIYXNoSGlzdG9yeShvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgZnVuY3Rpb24gY3JlYXRlSGFzaExvY2F0aW9uKHdpbmRvdywgZ2xvYmFsSGlzdG9yeSkge1xuICAgIGxldCB7XG4gICAgICBwYXRobmFtZSA9IFwiL1wiLFxuICAgICAgc2VhcmNoID0gXCJcIixcbiAgICAgIGhhc2ggPSBcIlwiXG4gICAgfSA9IHBhcnNlUGF0aCh3aW5kb3cubG9jYXRpb24uaGFzaC5zdWJzdHIoMSkpO1xuICAgIC8vIEhhc2ggVVJMIHNob3VsZCBhbHdheXMgaGF2ZSBhIGxlYWRpbmcgLyBqdXN0IGxpa2Ugd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lXG4gICAgLy8gZG9lcywgc28gaWYgYW4gYXBwIGVuZHMgdXAgYXQgYSByb3V0ZSBsaWtlIC8jc29tZXRoaW5nIHRoZW4gd2UgYWRkIGFcbiAgICAvLyBsZWFkaW5nIHNsYXNoIHNvIGFsbCBvZiBvdXIgcGF0aC1tYXRjaGluZyBiZWhhdmVzIHRoZSBzYW1lIGFzIGlmIGl0IHdvdWxkXG4gICAgLy8gaW4gYSBicm93c2VyIHJvdXRlci4gIFRoaXMgaXMgcGFydGljdWxhcmx5IGltcG9ydGFudCB3aGVuIHRoZXJlIGV4aXN0cyBhXG4gICAgLy8gcm9vdCBzcGxhdCByb3V0ZSAoPFJvdXRlIHBhdGg9XCIqXCI+KSBzaW5jZSB0aGF0IG1hdGNoZXMgaW50ZXJuYWxseSBhZ2FpbnN0XG4gICAgLy8gXCIvKlwiIGFuZCB3ZSdkIGV4cGVjdCAvI3NvbWV0aGluZyB0byA0MDQgaW4gYSBoYXNoIHJvdXRlciBhcHAuXG4gICAgaWYgKCFwYXRobmFtZS5zdGFydHNXaXRoKFwiL1wiKSAmJiAhcGF0aG5hbWUuc3RhcnRzV2l0aChcIi5cIikpIHtcbiAgICAgIHBhdGhuYW1lID0gXCIvXCIgKyBwYXRobmFtZTtcbiAgICB9XG4gICAgcmV0dXJuIGNyZWF0ZUxvY2F0aW9uKFwiXCIsIHtcbiAgICAgIHBhdGhuYW1lLFxuICAgICAgc2VhcmNoLFxuICAgICAgaGFzaFxuICAgIH0sXG4gICAgLy8gc3RhdGUgZGVmYXVsdHMgdG8gYG51bGxgIGJlY2F1c2UgYHdpbmRvdy5oaXN0b3J5LnN0YXRlYCBkb2VzXG4gICAgZ2xvYmFsSGlzdG9yeS5zdGF0ZSAmJiBnbG9iYWxIaXN0b3J5LnN0YXRlLnVzciB8fCBudWxsLCBnbG9iYWxIaXN0b3J5LnN0YXRlICYmIGdsb2JhbEhpc3Rvcnkuc3RhdGUua2V5IHx8IFwiZGVmYXVsdFwiKTtcbiAgfVxuICBmdW5jdGlvbiBjcmVhdGVIYXNoSHJlZih3aW5kb3csIHRvKSB7XG4gICAgbGV0IGJhc2UgPSB3aW5kb3cuZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImJhc2VcIik7XG4gICAgbGV0IGhyZWYgPSBcIlwiO1xuICAgIGlmIChiYXNlICYmIGJhc2UuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKSkge1xuICAgICAgbGV0IHVybCA9IHdpbmRvdy5sb2NhdGlvbi5ocmVmO1xuICAgICAgbGV0IGhhc2hJbmRleCA9IHVybC5pbmRleE9mKFwiI1wiKTtcbiAgICAgIGhyZWYgPSBoYXNoSW5kZXggPT09IC0xID8gdXJsIDogdXJsLnNsaWNlKDAsIGhhc2hJbmRleCk7XG4gICAgfVxuICAgIHJldHVybiBocmVmICsgXCIjXCIgKyAodHlwZW9mIHRvID09PSBcInN0cmluZ1wiID8gdG8gOiBjcmVhdGVQYXRoKHRvKSk7XG4gIH1cbiAgZnVuY3Rpb24gdmFsaWRhdGVIYXNoTG9jYXRpb24obG9jYXRpb24sIHRvKSB7XG4gICAgd2FybmluZyhsb2NhdGlvbi5wYXRobmFtZS5jaGFyQXQoMCkgPT09IFwiL1wiLCBcInJlbGF0aXZlIHBhdGhuYW1lcyBhcmUgbm90IHN1cHBvcnRlZCBpbiBoYXNoIGhpc3RvcnkucHVzaChcIiArIEpTT04uc3RyaW5naWZ5KHRvKSArIFwiKVwiKTtcbiAgfVxuICByZXR1cm4gZ2V0VXJsQmFzZWRIaXN0b3J5KGNyZWF0ZUhhc2hMb2NhdGlvbiwgY3JlYXRlSGFzaEhyZWYsIHZhbGlkYXRlSGFzaExvY2F0aW9uLCBvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIGludmFyaWFudCh2YWx1ZSwgbWVzc2FnZSkge1xuICBpZiAodmFsdWUgPT09IGZhbHNlIHx8IHZhbHVlID09PSBudWxsIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgfVxufVxuZnVuY3Rpb24gd2FybmluZyhjb25kLCBtZXNzYWdlKSB7XG4gIGlmICghY29uZCkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgaWYgKHR5cGVvZiBjb25zb2xlICE9PSBcInVuZGVmaW5lZFwiKSBjb25zb2xlLndhcm4obWVzc2FnZSk7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFdlbGNvbWUgdG8gZGVidWdnaW5nIGhpc3RvcnkhXG4gICAgICAvL1xuICAgICAgLy8gVGhpcyBlcnJvciBpcyB0aHJvd24gYXMgYSBjb252ZW5pZW5jZSwgc28geW91IGNhbiBtb3JlIGVhc2lseVxuICAgICAgLy8gZmluZCB0aGUgc291cmNlIGZvciBhIHdhcm5pbmcgdGhhdCBhcHBlYXJzIGluIHRoZSBjb25zb2xlIGJ5XG4gICAgICAvLyBlbmFibGluZyBcInBhdXNlIG9uIGV4Y2VwdGlvbnNcIiBpbiB5b3VyIEphdmFTY3JpcHQgZGVidWdnZXIuXG4gICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZW1wdHlcbiAgICB9IGNhdGNoIChlKSB7fVxuICB9XG59XG5mdW5jdGlvbiBjcmVhdGVLZXkoKSB7XG4gIHJldHVybiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHIoMiwgOCk7XG59XG4vKipcbiAqIEZvciBicm93c2VyLWJhc2VkIGhpc3Rvcmllcywgd2UgY29tYmluZSB0aGUgc3RhdGUgYW5kIGtleSBpbnRvIGFuIG9iamVjdFxuICovXG5mdW5jdGlvbiBnZXRIaXN0b3J5U3RhdGUobG9jYXRpb24sIGluZGV4KSB7XG4gIHJldHVybiB7XG4gICAgdXNyOiBsb2NhdGlvbi5zdGF0ZSxcbiAgICBrZXk6IGxvY2F0aW9uLmtleSxcbiAgICBpZHg6IGluZGV4XG4gIH07XG59XG4vKipcbiAqIENyZWF0ZXMgYSBMb2NhdGlvbiBvYmplY3Qgd2l0aCBhIHVuaXF1ZSBrZXkgZnJvbSB0aGUgZ2l2ZW4gUGF0aFxuICovXG5mdW5jdGlvbiBjcmVhdGVMb2NhdGlvbihjdXJyZW50LCB0bywgc3RhdGUsIGtleSkge1xuICBpZiAoc3RhdGUgPT09IHZvaWQgMCkge1xuICAgIHN0YXRlID0gbnVsbDtcbiAgfVxuICBsZXQgbG9jYXRpb24gPSBfZXh0ZW5kcyh7XG4gICAgcGF0aG5hbWU6IHR5cGVvZiBjdXJyZW50ID09PSBcInN0cmluZ1wiID8gY3VycmVudCA6IGN1cnJlbnQucGF0aG5hbWUsXG4gICAgc2VhcmNoOiBcIlwiLFxuICAgIGhhc2g6IFwiXCJcbiAgfSwgdHlwZW9mIHRvID09PSBcInN0cmluZ1wiID8gcGFyc2VQYXRoKHRvKSA6IHRvLCB7XG4gICAgc3RhdGUsXG4gICAgLy8gVE9ETzogVGhpcyBjb3VsZCBiZSBjbGVhbmVkIHVwLiAgcHVzaC9yZXBsYWNlIHNob3VsZCBwcm9iYWJseSBqdXN0IHRha2VcbiAgICAvLyBmdWxsIExvY2F0aW9ucyBub3cgYW5kIGF2b2lkIHRoZSBuZWVkIHRvIHJ1biB0aHJvdWdoIHRoaXMgZmxvdyBhdCBhbGxcbiAgICAvLyBCdXQgdGhhdCdzIGEgcHJldHR5IGJpZyByZWZhY3RvciB0byB0aGUgY3VycmVudCB0ZXN0IHN1aXRlIHNvIGdvaW5nIHRvXG4gICAgLy8ga2VlcCBhcyBpcyBmb3IgdGhlIHRpbWUgYmVpbmcgYW5kIGp1c3QgbGV0IGFueSBpbmNvbWluZyBrZXlzIHRha2UgcHJlY2VkZW5jZVxuICAgIGtleTogdG8gJiYgdG8ua2V5IHx8IGtleSB8fCBjcmVhdGVLZXkoKVxuICB9KTtcbiAgcmV0dXJuIGxvY2F0aW9uO1xufVxuLyoqXG4gKiBDcmVhdGVzIGEgc3RyaW5nIFVSTCBwYXRoIGZyb20gdGhlIGdpdmVuIHBhdGhuYW1lLCBzZWFyY2gsIGFuZCBoYXNoIGNvbXBvbmVudHMuXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZVBhdGgoX3JlZikge1xuICBsZXQge1xuICAgIHBhdGhuYW1lID0gXCIvXCIsXG4gICAgc2VhcmNoID0gXCJcIixcbiAgICBoYXNoID0gXCJcIlxuICB9ID0gX3JlZjtcbiAgaWYgKHNlYXJjaCAmJiBzZWFyY2ggIT09IFwiP1wiKSBwYXRobmFtZSArPSBzZWFyY2guY2hhckF0KDApID09PSBcIj9cIiA/IHNlYXJjaCA6IFwiP1wiICsgc2VhcmNoO1xuICBpZiAoaGFzaCAmJiBoYXNoICE9PSBcIiNcIikgcGF0aG5hbWUgKz0gaGFzaC5jaGFyQXQoMCkgPT09IFwiI1wiID8gaGFzaCA6IFwiI1wiICsgaGFzaDtcbiAgcmV0dXJuIHBhdGhuYW1lO1xufVxuLyoqXG4gKiBQYXJzZXMgYSBzdHJpbmcgVVJMIHBhdGggaW50byBpdHMgc2VwYXJhdGUgcGF0aG5hbWUsIHNlYXJjaCwgYW5kIGhhc2ggY29tcG9uZW50cy5cbiAqL1xuZnVuY3Rpb24gcGFyc2VQYXRoKHBhdGgpIHtcbiAgbGV0IHBhcnNlZFBhdGggPSB7fTtcbiAgaWYgKHBhdGgpIHtcbiAgICBsZXQgaGFzaEluZGV4ID0gcGF0aC5pbmRleE9mKFwiI1wiKTtcbiAgICBpZiAoaGFzaEluZGV4ID49IDApIHtcbiAgICAgIHBhcnNlZFBhdGguaGFzaCA9IHBhdGguc3Vic3RyKGhhc2hJbmRleCk7XG4gICAgICBwYXRoID0gcGF0aC5zdWJzdHIoMCwgaGFzaEluZGV4KTtcbiAgICB9XG4gICAgbGV0IHNlYXJjaEluZGV4ID0gcGF0aC5pbmRleE9mKFwiP1wiKTtcbiAgICBpZiAoc2VhcmNoSW5kZXggPj0gMCkge1xuICAgICAgcGFyc2VkUGF0aC5zZWFyY2ggPSBwYXRoLnN1YnN0cihzZWFyY2hJbmRleCk7XG4gICAgICBwYXRoID0gcGF0aC5zdWJzdHIoMCwgc2VhcmNoSW5kZXgpO1xuICAgIH1cbiAgICBpZiAocGF0aCkge1xuICAgICAgcGFyc2VkUGF0aC5wYXRobmFtZSA9IHBhdGg7XG4gICAgfVxuICB9XG4gIHJldHVybiBwYXJzZWRQYXRoO1xufVxuZnVuY3Rpb24gZ2V0VXJsQmFzZWRIaXN0b3J5KGdldExvY2F0aW9uLCBjcmVhdGVIcmVmLCB2YWxpZGF0ZUxvY2F0aW9uLCBvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgbGV0IHtcbiAgICB3aW5kb3cgPSBkb2N1bWVudC5kZWZhdWx0VmlldyxcbiAgICB2NUNvbXBhdCA9IGZhbHNlXG4gIH0gPSBvcHRpb25zO1xuICBsZXQgZ2xvYmFsSGlzdG9yeSA9IHdpbmRvdy5oaXN0b3J5O1xuICBsZXQgYWN0aW9uID0gQWN0aW9uLlBvcDtcbiAgbGV0IGxpc3RlbmVyID0gbnVsbDtcbiAgbGV0IGluZGV4ID0gZ2V0SW5kZXgoKTtcbiAgLy8gSW5kZXggc2hvdWxkIG9ubHkgYmUgbnVsbCB3aGVuIHdlIGluaXRpYWxpemUuIElmIG5vdCwgaXQncyBiZWNhdXNlIHRoZVxuICAvLyB1c2VyIGNhbGxlZCBoaXN0b3J5LnB1c2hTdGF0ZSBvciBoaXN0b3J5LnJlcGxhY2VTdGF0ZSBkaXJlY3RseSwgaW4gd2hpY2hcbiAgLy8gY2FzZSB3ZSBzaG91bGQgbG9nIGEgd2FybmluZyBhcyBpdCB3aWxsIHJlc3VsdCBpbiBidWdzLlxuICBpZiAoaW5kZXggPT0gbnVsbCkge1xuICAgIGluZGV4ID0gMDtcbiAgICBnbG9iYWxIaXN0b3J5LnJlcGxhY2VTdGF0ZShfZXh0ZW5kcyh7fSwgZ2xvYmFsSGlzdG9yeS5zdGF0ZSwge1xuICAgICAgaWR4OiBpbmRleFxuICAgIH0pLCBcIlwiKTtcbiAgfVxuICBmdW5jdGlvbiBnZXRJbmRleCgpIHtcbiAgICBsZXQgc3RhdGUgPSBnbG9iYWxIaXN0b3J5LnN0YXRlIHx8IHtcbiAgICAgIGlkeDogbnVsbFxuICAgIH07XG4gICAgcmV0dXJuIHN0YXRlLmlkeDtcbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVQb3AoKSB7XG4gICAgYWN0aW9uID0gQWN0aW9uLlBvcDtcbiAgICBsZXQgbmV4dEluZGV4ID0gZ2V0SW5kZXgoKTtcbiAgICBsZXQgZGVsdGEgPSBuZXh0SW5kZXggPT0gbnVsbCA/IG51bGwgOiBuZXh0SW5kZXggLSBpbmRleDtcbiAgICBpbmRleCA9IG5leHRJbmRleDtcbiAgICBpZiAobGlzdGVuZXIpIHtcbiAgICAgIGxpc3RlbmVyKHtcbiAgICAgICAgYWN0aW9uLFxuICAgICAgICBsb2NhdGlvbjogaGlzdG9yeS5sb2NhdGlvbixcbiAgICAgICAgZGVsdGFcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBwdXNoKHRvLCBzdGF0ZSkge1xuICAgIGFjdGlvbiA9IEFjdGlvbi5QdXNoO1xuICAgIGxldCBsb2NhdGlvbiA9IGNyZWF0ZUxvY2F0aW9uKGhpc3RvcnkubG9jYXRpb24sIHRvLCBzdGF0ZSk7XG4gICAgaWYgKHZhbGlkYXRlTG9jYXRpb24pIHZhbGlkYXRlTG9jYXRpb24obG9jYXRpb24sIHRvKTtcbiAgICBpbmRleCA9IGdldEluZGV4KCkgKyAxO1xuICAgIGxldCBoaXN0b3J5U3RhdGUgPSBnZXRIaXN0b3J5U3RhdGUobG9jYXRpb24sIGluZGV4KTtcbiAgICBsZXQgdXJsID0gaGlzdG9yeS5jcmVhdGVIcmVmKGxvY2F0aW9uKTtcbiAgICAvLyB0cnkuLi5jYXRjaCBiZWNhdXNlIGlPUyBsaW1pdHMgdXMgdG8gMTAwIHB1c2hTdGF0ZSBjYWxscyA6L1xuICAgIHRyeSB7XG4gICAgICBnbG9iYWxIaXN0b3J5LnB1c2hTdGF0ZShoaXN0b3J5U3RhdGUsIFwiXCIsIHVybCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIElmIHRoZSBleGNlcHRpb24gaXMgYmVjYXVzZSBgc3RhdGVgIGNhbid0IGJlIHNlcmlhbGl6ZWQsIGxldCB0aGF0IHRocm93XG4gICAgICAvLyBvdXR3YXJkcyBqdXN0IGxpa2UgYSByZXBsYWNlIGNhbGwgd291bGQgc28gdGhlIGRldiBrbm93cyB0aGUgY2F1c2VcbiAgICAgIC8vIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL25hdi1oaXN0b3J5LWFwaXMuaHRtbCNzaGFyZWQtaGlzdG9yeS1wdXNoL3JlcGxhY2Utc3RhdGUtc3RlcHNcbiAgICAgIC8vIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL3N0cnVjdHVyZWQtZGF0YS5odG1sI3N0cnVjdHVyZWRzZXJpYWxpemVpbnRlcm5hbFxuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRE9NRXhjZXB0aW9uICYmIGVycm9yLm5hbWUgPT09IFwiRGF0YUNsb25lRXJyb3JcIikge1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICAgIC8vIFRoZXkgYXJlIGdvaW5nIHRvIGxvc2Ugc3RhdGUgaGVyZSwgYnV0IHRoZXJlIGlzIG5vIHJlYWxcbiAgICAgIC8vIHdheSB0byB3YXJuIHRoZW0gYWJvdXQgaXQgc2luY2UgdGhlIHBhZ2Ugd2lsbCByZWZyZXNoLi4uXG4gICAgICB3aW5kb3cubG9jYXRpb24uYXNzaWduKHVybCk7XG4gICAgfVxuICAgIGlmICh2NUNvbXBhdCAmJiBsaXN0ZW5lcikge1xuICAgICAgbGlzdGVuZXIoe1xuICAgICAgICBhY3Rpb24sXG4gICAgICAgIGxvY2F0aW9uOiBoaXN0b3J5LmxvY2F0aW9uLFxuICAgICAgICBkZWx0YTogMVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHJlcGxhY2UodG8sIHN0YXRlKSB7XG4gICAgYWN0aW9uID0gQWN0aW9uLlJlcGxhY2U7XG4gICAgbGV0IGxvY2F0aW9uID0gY3JlYXRlTG9jYXRpb24oaGlzdG9yeS5sb2NhdGlvbiwgdG8sIHN0YXRlKTtcbiAgICBpZiAodmFsaWRhdGVMb2NhdGlvbikgdmFsaWRhdGVMb2NhdGlvbihsb2NhdGlvbiwgdG8pO1xuICAgIGluZGV4ID0gZ2V0SW5kZXgoKTtcbiAgICBsZXQgaGlzdG9yeVN0YXRlID0gZ2V0SGlzdG9yeVN0YXRlKGxvY2F0aW9uLCBpbmRleCk7XG4gICAgbGV0IHVybCA9IGhpc3RvcnkuY3JlYXRlSHJlZihsb2NhdGlvbik7XG4gICAgZ2xvYmFsSGlzdG9yeS5yZXBsYWNlU3RhdGUoaGlzdG9yeVN0YXRlLCBcIlwiLCB1cmwpO1xuICAgIGlmICh2NUNvbXBhdCAmJiBsaXN0ZW5lcikge1xuICAgICAgbGlzdGVuZXIoe1xuICAgICAgICBhY3Rpb24sXG4gICAgICAgIGxvY2F0aW9uOiBoaXN0b3J5LmxvY2F0aW9uLFxuICAgICAgICBkZWx0YTogMFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGNyZWF0ZVVSTCh0bykge1xuICAgIC8vIHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gaXMgXCJudWxsXCIgKHRoZSBsaXRlcmFsIHN0cmluZyB2YWx1ZSkgaW4gRmlyZWZveFxuICAgIC8vIHVuZGVyIGNlcnRhaW4gY29uZGl0aW9ucywgbm90YWJseSB3aGVuIHNlcnZpbmcgZnJvbSBhIGxvY2FsIEhUTUwgZmlsZVxuICAgIC8vIFNlZSBodHRwczovL2J1Z3ppbGxhLm1vemlsbGEub3JnL3Nob3dfYnVnLmNnaT9pZD04NzgyOTdcbiAgICBsZXQgYmFzZSA9IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4gIT09IFwibnVsbFwiID8gd2luZG93LmxvY2F0aW9uLm9yaWdpbiA6IHdpbmRvdy5sb2NhdGlvbi5ocmVmO1xuICAgIGxldCBocmVmID0gdHlwZW9mIHRvID09PSBcInN0cmluZ1wiID8gdG8gOiBjcmVhdGVQYXRoKHRvKTtcbiAgICAvLyBUcmVhdGluZyB0aGlzIGFzIGEgZnVsbCBVUkwgd2lsbCBzdHJpcCBhbnkgdHJhaWxpbmcgc3BhY2VzIHNvIHdlIG5lZWQgdG9cbiAgICAvLyBwcmUtZW5jb2RlIHRoZW0gc2luY2UgdGhleSBtaWdodCBiZSBwYXJ0IG9mIGEgbWF0Y2hpbmcgc3BsYXQgcGFyYW0gZnJvbVxuICAgIC8vIGFuIGFuY2VzdG9yIHJvdXRlXG4gICAgaHJlZiA9IGhyZWYucmVwbGFjZSgvICQvLCBcIiUyMFwiKTtcbiAgICBpbnZhcmlhbnQoYmFzZSwgXCJObyB3aW5kb3cubG9jYXRpb24uKG9yaWdpbnxocmVmKSBhdmFpbGFibGUgdG8gY3JlYXRlIFVSTCBmb3IgaHJlZjogXCIgKyBocmVmKTtcbiAgICByZXR1cm4gbmV3IFVSTChocmVmLCBiYXNlKTtcbiAgfVxuICBsZXQgaGlzdG9yeSA9IHtcbiAgICBnZXQgYWN0aW9uKCkge1xuICAgICAgcmV0dXJuIGFjdGlvbjtcbiAgICB9LFxuICAgIGdldCBsb2NhdGlvbigpIHtcbiAgICAgIHJldHVybiBnZXRMb2NhdGlvbih3aW5kb3csIGdsb2JhbEhpc3RvcnkpO1xuICAgIH0sXG4gICAgbGlzdGVuKGZuKSB7XG4gICAgICBpZiAobGlzdGVuZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQSBoaXN0b3J5IG9ubHkgYWNjZXB0cyBvbmUgYWN0aXZlIGxpc3RlbmVyXCIpO1xuICAgICAgfVxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoUG9wU3RhdGVFdmVudFR5cGUsIGhhbmRsZVBvcCk7XG4gICAgICBsaXN0ZW5lciA9IGZuO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoUG9wU3RhdGVFdmVudFR5cGUsIGhhbmRsZVBvcCk7XG4gICAgICAgIGxpc3RlbmVyID0gbnVsbDtcbiAgICAgIH07XG4gICAgfSxcbiAgICBjcmVhdGVIcmVmKHRvKSB7XG4gICAgICByZXR1cm4gY3JlYXRlSHJlZih3aW5kb3csIHRvKTtcbiAgICB9LFxuICAgIGNyZWF0ZVVSTCxcbiAgICBlbmNvZGVMb2NhdGlvbih0bykge1xuICAgICAgLy8gRW5jb2RlIGEgTG9jYXRpb24gdGhlIHNhbWUgd2F5IHdpbmRvdy5sb2NhdGlvbiB3b3VsZFxuICAgICAgbGV0IHVybCA9IGNyZWF0ZVVSTCh0byk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBwYXRobmFtZTogdXJsLnBhdGhuYW1lLFxuICAgICAgICBzZWFyY2g6IHVybC5zZWFyY2gsXG4gICAgICAgIGhhc2g6IHVybC5oYXNoXG4gICAgICB9O1xuICAgIH0sXG4gICAgcHVzaCxcbiAgICByZXBsYWNlLFxuICAgIGdvKG4pIHtcbiAgICAgIHJldHVybiBnbG9iYWxIaXN0b3J5LmdvKG4pO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIGhpc3Rvcnk7XG59XG4vLyNlbmRyZWdpb25cblxudmFyIFJlc3VsdFR5cGU7XG4oZnVuY3Rpb24gKFJlc3VsdFR5cGUpIHtcbiAgUmVzdWx0VHlwZVtcImRhdGFcIl0gPSBcImRhdGFcIjtcbiAgUmVzdWx0VHlwZVtcImRlZmVycmVkXCJdID0gXCJkZWZlcnJlZFwiO1xuICBSZXN1bHRUeXBlW1wicmVkaXJlY3RcIl0gPSBcInJlZGlyZWN0XCI7XG4gIFJlc3VsdFR5cGVbXCJlcnJvclwiXSA9IFwiZXJyb3JcIjtcbn0pKFJlc3VsdFR5cGUgfHwgKFJlc3VsdFR5cGUgPSB7fSkpO1xuY29uc3QgaW1tdXRhYmxlUm91dGVLZXlzID0gbmV3IFNldChbXCJsYXp5XCIsIFwiY2FzZVNlbnNpdGl2ZVwiLCBcInBhdGhcIiwgXCJpZFwiLCBcImluZGV4XCIsIFwiY2hpbGRyZW5cIl0pO1xuZnVuY3Rpb24gaXNJbmRleFJvdXRlKHJvdXRlKSB7XG4gIHJldHVybiByb3V0ZS5pbmRleCA9PT0gdHJ1ZTtcbn1cbi8vIFdhbGsgdGhlIHJvdXRlIHRyZWUgZ2VuZXJhdGluZyB1bmlxdWUgSURzIHdoZXJlIG5lY2Vzc2FyeSwgc28gd2UgYXJlIHdvcmtpbmdcbi8vIHNvbGVseSB3aXRoIEFnbm9zdGljRGF0YVJvdXRlT2JqZWN0J3Mgd2l0aGluIHRoZSBSb3V0ZXJcbmZ1bmN0aW9uIGNvbnZlcnRSb3V0ZXNUb0RhdGFSb3V0ZXMocm91dGVzLCBtYXBSb3V0ZVByb3BlcnRpZXMsIHBhcmVudFBhdGgsIG1hbmlmZXN0KSB7XG4gIGlmIChwYXJlbnRQYXRoID09PSB2b2lkIDApIHtcbiAgICBwYXJlbnRQYXRoID0gW107XG4gIH1cbiAgaWYgKG1hbmlmZXN0ID09PSB2b2lkIDApIHtcbiAgICBtYW5pZmVzdCA9IHt9O1xuICB9XG4gIHJldHVybiByb3V0ZXMubWFwKChyb3V0ZSwgaW5kZXgpID0+IHtcbiAgICBsZXQgdHJlZVBhdGggPSBbLi4ucGFyZW50UGF0aCwgU3RyaW5nKGluZGV4KV07XG4gICAgbGV0IGlkID0gdHlwZW9mIHJvdXRlLmlkID09PSBcInN0cmluZ1wiID8gcm91dGUuaWQgOiB0cmVlUGF0aC5qb2luKFwiLVwiKTtcbiAgICBpbnZhcmlhbnQocm91dGUuaW5kZXggIT09IHRydWUgfHwgIXJvdXRlLmNoaWxkcmVuLCBcIkNhbm5vdCBzcGVjaWZ5IGNoaWxkcmVuIG9uIGFuIGluZGV4IHJvdXRlXCIpO1xuICAgIGludmFyaWFudCghbWFuaWZlc3RbaWRdLCBcIkZvdW5kIGEgcm91dGUgaWQgY29sbGlzaW9uIG9uIGlkIFxcXCJcIiArIGlkICsgXCJcXFwiLiAgUm91dGUgXCIgKyBcImlkJ3MgbXVzdCBiZSBnbG9iYWxseSB1bmlxdWUgd2l0aGluIERhdGEgUm91dGVyIHVzYWdlc1wiKTtcbiAgICBpZiAoaXNJbmRleFJvdXRlKHJvdXRlKSkge1xuICAgICAgbGV0IGluZGV4Um91dGUgPSBfZXh0ZW5kcyh7fSwgcm91dGUsIG1hcFJvdXRlUHJvcGVydGllcyhyb3V0ZSksIHtcbiAgICAgICAgaWRcbiAgICAgIH0pO1xuICAgICAgbWFuaWZlc3RbaWRdID0gaW5kZXhSb3V0ZTtcbiAgICAgIHJldHVybiBpbmRleFJvdXRlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgcGF0aE9yTGF5b3V0Um91dGUgPSBfZXh0ZW5kcyh7fSwgcm91dGUsIG1hcFJvdXRlUHJvcGVydGllcyhyb3V0ZSksIHtcbiAgICAgICAgaWQsXG4gICAgICAgIGNoaWxkcmVuOiB1bmRlZmluZWRcbiAgICAgIH0pO1xuICAgICAgbWFuaWZlc3RbaWRdID0gcGF0aE9yTGF5b3V0Um91dGU7XG4gICAgICBpZiAocm91dGUuY2hpbGRyZW4pIHtcbiAgICAgICAgcGF0aE9yTGF5b3V0Um91dGUuY2hpbGRyZW4gPSBjb252ZXJ0Um91dGVzVG9EYXRhUm91dGVzKHJvdXRlLmNoaWxkcmVuLCBtYXBSb3V0ZVByb3BlcnRpZXMsIHRyZWVQYXRoLCBtYW5pZmVzdCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcGF0aE9yTGF5b3V0Um91dGU7XG4gICAgfVxuICB9KTtcbn1cbi8qKlxuICogTWF0Y2hlcyB0aGUgZ2l2ZW4gcm91dGVzIHRvIGEgbG9jYXRpb24gYW5kIHJldHVybnMgdGhlIG1hdGNoIGRhdGEuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91dGlscy9tYXRjaC1yb3V0ZXNcbiAqL1xuZnVuY3Rpb24gbWF0Y2hSb3V0ZXMocm91dGVzLCBsb2NhdGlvbkFyZywgYmFzZW5hbWUpIHtcbiAgaWYgKGJhc2VuYW1lID09PSB2b2lkIDApIHtcbiAgICBiYXNlbmFtZSA9IFwiL1wiO1xuICB9XG4gIHJldHVybiBtYXRjaFJvdXRlc0ltcGwocm91dGVzLCBsb2NhdGlvbkFyZywgYmFzZW5hbWUsIGZhbHNlKTtcbn1cbmZ1bmN0aW9uIG1hdGNoUm91dGVzSW1wbChyb3V0ZXMsIGxvY2F0aW9uQXJnLCBiYXNlbmFtZSwgYWxsb3dQYXJ0aWFsKSB7XG4gIGxldCBsb2NhdGlvbiA9IHR5cGVvZiBsb2NhdGlvbkFyZyA9PT0gXCJzdHJpbmdcIiA/IHBhcnNlUGF0aChsb2NhdGlvbkFyZykgOiBsb2NhdGlvbkFyZztcbiAgbGV0IHBhdGhuYW1lID0gc3RyaXBCYXNlbmFtZShsb2NhdGlvbi5wYXRobmFtZSB8fCBcIi9cIiwgYmFzZW5hbWUpO1xuICBpZiAocGF0aG5hbWUgPT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGxldCBicmFuY2hlcyA9IGZsYXR0ZW5Sb3V0ZXMocm91dGVzKTtcbiAgcmFua1JvdXRlQnJhbmNoZXMoYnJhbmNoZXMpO1xuICBsZXQgbWF0Y2hlcyA9IG51bGw7XG4gIGxldCBkZWNvZGVkID0gZGVjb2RlUGF0aChwYXRobmFtZSk7XG4gIGZvciAobGV0IGkgPSAwOyBtYXRjaGVzID09IG51bGwgJiYgaSA8IGJyYW5jaGVzLmxlbmd0aDsgKytpKSB7XG4gICAgLy8gSW5jb21pbmcgcGF0aG5hbWVzIGFyZSBnZW5lcmFsbHkgZW5jb2RlZCBmcm9tIGVpdGhlciB3aW5kb3cubG9jYXRpb25cbiAgICAvLyBvciBmcm9tIHJvdXRlci5uYXZpZ2F0ZSwgYnV0IHdlIHdhbnQgdG8gbWF0Y2ggYWdhaW5zdCB0aGUgdW5lbmNvZGVkXG4gICAgLy8gcGF0aHMgaW4gdGhlIHJvdXRlIGRlZmluaXRpb25zLiAgTWVtb3J5IHJvdXRlciBsb2NhdGlvbnMgd29uJ3QgYmVcbiAgICAvLyBlbmNvZGVkIGhlcmUgYnV0IHRoZXJlIGFsc28gc2hvdWxkbid0IGJlIGFueXRoaW5nIHRvIGRlY29kZSBzbyB0aGlzXG4gICAgLy8gc2hvdWxkIGJlIGEgc2FmZSBvcGVyYXRpb24uICBUaGlzIGF2b2lkcyBuZWVkaW5nIG1hdGNoUm91dGVzIHRvIGJlXG4gICAgLy8gaGlzdG9yeS1hd2FyZS5cbiAgICBtYXRjaGVzID0gbWF0Y2hSb3V0ZUJyYW5jaChicmFuY2hlc1tpXSwgZGVjb2RlZCwgYWxsb3dQYXJ0aWFsKTtcbiAgfVxuICByZXR1cm4gbWF0Y2hlcztcbn1cbmZ1bmN0aW9uIGNvbnZlcnRSb3V0ZU1hdGNoVG9VaU1hdGNoKG1hdGNoLCBsb2FkZXJEYXRhKSB7XG4gIGxldCB7XG4gICAgcm91dGUsXG4gICAgcGF0aG5hbWUsXG4gICAgcGFyYW1zXG4gIH0gPSBtYXRjaDtcbiAgcmV0dXJuIHtcbiAgICBpZDogcm91dGUuaWQsXG4gICAgcGF0aG5hbWUsXG4gICAgcGFyYW1zLFxuICAgIGRhdGE6IGxvYWRlckRhdGFbcm91dGUuaWRdLFxuICAgIGhhbmRsZTogcm91dGUuaGFuZGxlXG4gIH07XG59XG5mdW5jdGlvbiBmbGF0dGVuUm91dGVzKHJvdXRlcywgYnJhbmNoZXMsIHBhcmVudHNNZXRhLCBwYXJlbnRQYXRoKSB7XG4gIGlmIChicmFuY2hlcyA9PT0gdm9pZCAwKSB7XG4gICAgYnJhbmNoZXMgPSBbXTtcbiAgfVxuICBpZiAocGFyZW50c01ldGEgPT09IHZvaWQgMCkge1xuICAgIHBhcmVudHNNZXRhID0gW107XG4gIH1cbiAgaWYgKHBhcmVudFBhdGggPT09IHZvaWQgMCkge1xuICAgIHBhcmVudFBhdGggPSBcIlwiO1xuICB9XG4gIGxldCBmbGF0dGVuUm91dGUgPSAocm91dGUsIGluZGV4LCByZWxhdGl2ZVBhdGgpID0+IHtcbiAgICBsZXQgbWV0YSA9IHtcbiAgICAgIHJlbGF0aXZlUGF0aDogcmVsYXRpdmVQYXRoID09PSB1bmRlZmluZWQgPyByb3V0ZS5wYXRoIHx8IFwiXCIgOiByZWxhdGl2ZVBhdGgsXG4gICAgICBjYXNlU2Vuc2l0aXZlOiByb3V0ZS5jYXNlU2Vuc2l0aXZlID09PSB0cnVlLFxuICAgICAgY2hpbGRyZW5JbmRleDogaW5kZXgsXG4gICAgICByb3V0ZVxuICAgIH07XG4gICAgaWYgKG1ldGEucmVsYXRpdmVQYXRoLnN0YXJ0c1dpdGgoXCIvXCIpKSB7XG4gICAgICBpbnZhcmlhbnQobWV0YS5yZWxhdGl2ZVBhdGguc3RhcnRzV2l0aChwYXJlbnRQYXRoKSwgXCJBYnNvbHV0ZSByb3V0ZSBwYXRoIFxcXCJcIiArIG1ldGEucmVsYXRpdmVQYXRoICsgXCJcXFwiIG5lc3RlZCB1bmRlciBwYXRoIFwiICsgKFwiXFxcIlwiICsgcGFyZW50UGF0aCArIFwiXFxcIiBpcyBub3QgdmFsaWQuIEFuIGFic29sdXRlIGNoaWxkIHJvdXRlIHBhdGggXCIpICsgXCJtdXN0IHN0YXJ0IHdpdGggdGhlIGNvbWJpbmVkIHBhdGggb2YgYWxsIGl0cyBwYXJlbnQgcm91dGVzLlwiKTtcbiAgICAgIG1ldGEucmVsYXRpdmVQYXRoID0gbWV0YS5yZWxhdGl2ZVBhdGguc2xpY2UocGFyZW50UGF0aC5sZW5ndGgpO1xuICAgIH1cbiAgICBsZXQgcGF0aCA9IGpvaW5QYXRocyhbcGFyZW50UGF0aCwgbWV0YS5yZWxhdGl2ZVBhdGhdKTtcbiAgICBsZXQgcm91dGVzTWV0YSA9IHBhcmVudHNNZXRhLmNvbmNhdChtZXRhKTtcbiAgICAvLyBBZGQgdGhlIGNoaWxkcmVuIGJlZm9yZSBhZGRpbmcgdGhpcyByb3V0ZSB0byB0aGUgYXJyYXksIHNvIHdlIHRyYXZlcnNlIHRoZVxuICAgIC8vIHJvdXRlIHRyZWUgZGVwdGgtZmlyc3QgYW5kIGNoaWxkIHJvdXRlcyBhcHBlYXIgYmVmb3JlIHRoZWlyIHBhcmVudHMgaW5cbiAgICAvLyB0aGUgXCJmbGF0dGVuZWRcIiB2ZXJzaW9uLlxuICAgIGlmIChyb3V0ZS5jaGlsZHJlbiAmJiByb3V0ZS5jaGlsZHJlbi5sZW5ndGggPiAwKSB7XG4gICAgICBpbnZhcmlhbnQoXG4gICAgICAvLyBPdXIgdHlwZXMga25vdyBiZXR0ZXIsIGJ1dCBydW50aW1lIEpTIG1heSBub3QhXG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICByb3V0ZS5pbmRleCAhPT0gdHJ1ZSwgXCJJbmRleCByb3V0ZXMgbXVzdCBub3QgaGF2ZSBjaGlsZCByb3V0ZXMuIFBsZWFzZSByZW1vdmUgXCIgKyAoXCJhbGwgY2hpbGQgcm91dGVzIGZyb20gcm91dGUgcGF0aCBcXFwiXCIgKyBwYXRoICsgXCJcXFwiLlwiKSk7XG4gICAgICBmbGF0dGVuUm91dGVzKHJvdXRlLmNoaWxkcmVuLCBicmFuY2hlcywgcm91dGVzTWV0YSwgcGF0aCk7XG4gICAgfVxuICAgIC8vIFJvdXRlcyB3aXRob3V0IGEgcGF0aCBzaG91bGRuJ3QgZXZlciBtYXRjaCBieSB0aGVtc2VsdmVzIHVubGVzcyB0aGV5IGFyZVxuICAgIC8vIGluZGV4IHJvdXRlcywgc28gZG9uJ3QgYWRkIHRoZW0gdG8gdGhlIGxpc3Qgb2YgcG9zc2libGUgYnJhbmNoZXMuXG4gICAgaWYgKHJvdXRlLnBhdGggPT0gbnVsbCAmJiAhcm91dGUuaW5kZXgpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYnJhbmNoZXMucHVzaCh7XG4gICAgICBwYXRoLFxuICAgICAgc2NvcmU6IGNvbXB1dGVTY29yZShwYXRoLCByb3V0ZS5pbmRleCksXG4gICAgICByb3V0ZXNNZXRhXG4gICAgfSk7XG4gIH07XG4gIHJvdXRlcy5mb3JFYWNoKChyb3V0ZSwgaW5kZXgpID0+IHtcbiAgICB2YXIgX3JvdXRlJHBhdGg7XG4gICAgLy8gY29hcnNlLWdyYWluIGNoZWNrIGZvciBvcHRpb25hbCBwYXJhbXNcbiAgICBpZiAocm91dGUucGF0aCA9PT0gXCJcIiB8fCAhKChfcm91dGUkcGF0aCA9IHJvdXRlLnBhdGgpICE9IG51bGwgJiYgX3JvdXRlJHBhdGguaW5jbHVkZXMoXCI/XCIpKSkge1xuICAgICAgZmxhdHRlblJvdXRlKHJvdXRlLCBpbmRleCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAobGV0IGV4cGxvZGVkIG9mIGV4cGxvZGVPcHRpb25hbFNlZ21lbnRzKHJvdXRlLnBhdGgpKSB7XG4gICAgICAgIGZsYXR0ZW5Sb3V0ZShyb3V0ZSwgaW5kZXgsIGV4cGxvZGVkKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICByZXR1cm4gYnJhbmNoZXM7XG59XG4vKipcbiAqIENvbXB1dGVzIGFsbCBjb21iaW5hdGlvbnMgb2Ygb3B0aW9uYWwgcGF0aCBzZWdtZW50cyBmb3IgYSBnaXZlbiBwYXRoLFxuICogZXhjbHVkaW5nIGNvbWJpbmF0aW9ucyB0aGF0IGFyZSBhbWJpZ3VvdXMgYW5kIG9mIGxvd2VyIHByaW9yaXR5LlxuICpcbiAqIEZvciBleGFtcGxlLCBgL29uZS86dHdvPy90aHJlZS86Zm91cj8vOmZpdmU/YCBleHBsb2RlcyB0bzpcbiAqIC0gYC9vbmUvdGhyZWVgXG4gKiAtIGAvb25lLzp0d28vdGhyZWVgXG4gKiAtIGAvb25lL3RocmVlLzpmb3VyYFxuICogLSBgL29uZS90aHJlZS86Zml2ZWBcbiAqIC0gYC9vbmUvOnR3by90aHJlZS86Zm91cmBcbiAqIC0gYC9vbmUvOnR3by90aHJlZS86Zml2ZWBcbiAqIC0gYC9vbmUvdGhyZWUvOmZvdXIvOmZpdmVgXG4gKiAtIGAvb25lLzp0d28vdGhyZWUvOmZvdXIvOmZpdmVgXG4gKi9cbmZ1bmN0aW9uIGV4cGxvZGVPcHRpb25hbFNlZ21lbnRzKHBhdGgpIHtcbiAgbGV0IHNlZ21lbnRzID0gcGF0aC5zcGxpdChcIi9cIik7XG4gIGlmIChzZWdtZW50cy5sZW5ndGggPT09IDApIHJldHVybiBbXTtcbiAgbGV0IFtmaXJzdCwgLi4ucmVzdF0gPSBzZWdtZW50cztcbiAgLy8gT3B0aW9uYWwgcGF0aCBzZWdtZW50cyBhcmUgZGVub3RlZCBieSBhIHRyYWlsaW5nIGA/YFxuICBsZXQgaXNPcHRpb25hbCA9IGZpcnN0LmVuZHNXaXRoKFwiP1wiKTtcbiAgLy8gQ29tcHV0ZSB0aGUgY29ycmVzcG9uZGluZyByZXF1aXJlZCBzZWdtZW50OiBgZm9vP2AgLT4gYGZvb2BcbiAgbGV0IHJlcXVpcmVkID0gZmlyc3QucmVwbGFjZSgvXFw/JC8sIFwiXCIpO1xuICBpZiAocmVzdC5sZW5ndGggPT09IDApIHtcbiAgICAvLyBJbnRlcHJldCBlbXB0eSBzdHJpbmcgYXMgb21pdHRpbmcgYW4gb3B0aW9uYWwgc2VnbWVudFxuICAgIC8vIGBbXCJvbmVcIiwgXCJcIiwgXCJ0aHJlZVwiXWAgY29ycmVzcG9uZHMgdG8gb21pdHRpbmcgYDp0d29gIGZyb20gYC9vbmUvOnR3bz8vdGhyZWVgIC0+IGAvb25lL3RocmVlYFxuICAgIHJldHVybiBpc09wdGlvbmFsID8gW3JlcXVpcmVkLCBcIlwiXSA6IFtyZXF1aXJlZF07XG4gIH1cbiAgbGV0IHJlc3RFeHBsb2RlZCA9IGV4cGxvZGVPcHRpb25hbFNlZ21lbnRzKHJlc3Quam9pbihcIi9cIikpO1xuICBsZXQgcmVzdWx0ID0gW107XG4gIC8vIEFsbCBjaGlsZCBwYXRocyB3aXRoIHRoZSBwcmVmaXguICBEbyB0aGlzIGZvciBhbGwgY2hpbGRyZW4gYmVmb3JlIHRoZVxuICAvLyBvcHRpb25hbCB2ZXJzaW9uIGZvciBhbGwgY2hpbGRyZW4sIHNvIHdlIGdldCBjb25zaXN0ZW50IG9yZGVyaW5nIHdoZXJlIHRoZVxuICAvLyBwYXJlbnQgb3B0aW9uYWwgYXNwZWN0IGlzIHByZWZlcnJlZCBhcyByZXF1aXJlZC4gIE90aGVyd2lzZSwgd2UgY2FuIGdldFxuICAvLyBjaGlsZCBzZWN0aW9ucyBpbnRlcnNwZXJzZWQgd2hlcmUgZGVlcGVyIG9wdGlvbmFsIHNlZ21lbnRzIGFyZSBoaWdoZXIgdGhhblxuICAvLyBwYXJlbnQgb3B0aW9uYWwgc2VnbWVudHMsIHdoZXJlIGZvciBleGFtcGxlLCAvOnR3byB3b3VsZCBleHBsb2RlIF9lYXJsaWVyX1xuICAvLyB0aGVuIC86b25lLiAgQnkgYWx3YXlzIGluY2x1ZGluZyB0aGUgcGFyZW50IGFzIHJlcXVpcmVkIF9mb3IgYWxsIGNoaWxkcmVuX1xuICAvLyBmaXJzdCwgd2UgYXZvaWQgdGhpcyBpc3N1ZVxuICByZXN1bHQucHVzaCguLi5yZXN0RXhwbG9kZWQubWFwKHN1YnBhdGggPT4gc3VicGF0aCA9PT0gXCJcIiA/IHJlcXVpcmVkIDogW3JlcXVpcmVkLCBzdWJwYXRoXS5qb2luKFwiL1wiKSkpO1xuICAvLyBUaGVuLCBpZiB0aGlzIGlzIGFuIG9wdGlvbmFsIHZhbHVlLCBhZGQgYWxsIGNoaWxkIHZlcnNpb25zIHdpdGhvdXRcbiAgaWYgKGlzT3B0aW9uYWwpIHtcbiAgICByZXN1bHQucHVzaCguLi5yZXN0RXhwbG9kZWQpO1xuICB9XG4gIC8vIGZvciBhYnNvbHV0ZSBwYXRocywgZW5zdXJlIGAvYCBpbnN0ZWFkIG9mIGVtcHR5IHNlZ21lbnRcbiAgcmV0dXJuIHJlc3VsdC5tYXAoZXhwbG9kZWQgPT4gcGF0aC5zdGFydHNXaXRoKFwiL1wiKSAmJiBleHBsb2RlZCA9PT0gXCJcIiA/IFwiL1wiIDogZXhwbG9kZWQpO1xufVxuZnVuY3Rpb24gcmFua1JvdXRlQnJhbmNoZXMoYnJhbmNoZXMpIHtcbiAgYnJhbmNoZXMuc29ydCgoYSwgYikgPT4gYS5zY29yZSAhPT0gYi5zY29yZSA/IGIuc2NvcmUgLSBhLnNjb3JlIC8vIEhpZ2hlciBzY29yZSBmaXJzdFxuICA6IGNvbXBhcmVJbmRleGVzKGEucm91dGVzTWV0YS5tYXAobWV0YSA9PiBtZXRhLmNoaWxkcmVuSW5kZXgpLCBiLnJvdXRlc01ldGEubWFwKG1ldGEgPT4gbWV0YS5jaGlsZHJlbkluZGV4KSkpO1xufVxuY29uc3QgcGFyYW1SZSA9IC9eOltcXHctXSskLztcbmNvbnN0IGR5bmFtaWNTZWdtZW50VmFsdWUgPSAzO1xuY29uc3QgaW5kZXhSb3V0ZVZhbHVlID0gMjtcbmNvbnN0IGVtcHR5U2VnbWVudFZhbHVlID0gMTtcbmNvbnN0IHN0YXRpY1NlZ21lbnRWYWx1ZSA9IDEwO1xuY29uc3Qgc3BsYXRQZW5hbHR5ID0gLTI7XG5jb25zdCBpc1NwbGF0ID0gcyA9PiBzID09PSBcIipcIjtcbmZ1bmN0aW9uIGNvbXB1dGVTY29yZShwYXRoLCBpbmRleCkge1xuICBsZXQgc2VnbWVudHMgPSBwYXRoLnNwbGl0KFwiL1wiKTtcbiAgbGV0IGluaXRpYWxTY29yZSA9IHNlZ21lbnRzLmxlbmd0aDtcbiAgaWYgKHNlZ21lbnRzLnNvbWUoaXNTcGxhdCkpIHtcbiAgICBpbml0aWFsU2NvcmUgKz0gc3BsYXRQZW5hbHR5O1xuICB9XG4gIGlmIChpbmRleCkge1xuICAgIGluaXRpYWxTY29yZSArPSBpbmRleFJvdXRlVmFsdWU7XG4gIH1cbiAgcmV0dXJuIHNlZ21lbnRzLmZpbHRlcihzID0+ICFpc1NwbGF0KHMpKS5yZWR1Y2UoKHNjb3JlLCBzZWdtZW50KSA9PiBzY29yZSArIChwYXJhbVJlLnRlc3Qoc2VnbWVudCkgPyBkeW5hbWljU2VnbWVudFZhbHVlIDogc2VnbWVudCA9PT0gXCJcIiA/IGVtcHR5U2VnbWVudFZhbHVlIDogc3RhdGljU2VnbWVudFZhbHVlKSwgaW5pdGlhbFNjb3JlKTtcbn1cbmZ1bmN0aW9uIGNvbXBhcmVJbmRleGVzKGEsIGIpIHtcbiAgbGV0IHNpYmxpbmdzID0gYS5sZW5ndGggPT09IGIubGVuZ3RoICYmIGEuc2xpY2UoMCwgLTEpLmV2ZXJ5KChuLCBpKSA9PiBuID09PSBiW2ldKTtcbiAgcmV0dXJuIHNpYmxpbmdzID9cbiAgLy8gSWYgdHdvIHJvdXRlcyBhcmUgc2libGluZ3MsIHdlIHNob3VsZCB0cnkgdG8gbWF0Y2ggdGhlIGVhcmxpZXIgc2libGluZ1xuICAvLyBmaXJzdC4gVGhpcyBhbGxvd3MgcGVvcGxlIHRvIGhhdmUgZmluZS1ncmFpbmVkIGNvbnRyb2wgb3ZlciB0aGUgbWF0Y2hpbmdcbiAgLy8gYmVoYXZpb3IgYnkgc2ltcGx5IHB1dHRpbmcgcm91dGVzIHdpdGggaWRlbnRpY2FsIHBhdGhzIGluIHRoZSBvcmRlciB0aGV5XG4gIC8vIHdhbnQgdGhlbSB0cmllZC5cbiAgYVthLmxlbmd0aCAtIDFdIC0gYltiLmxlbmd0aCAtIDFdIDpcbiAgLy8gT3RoZXJ3aXNlLCBpdCBkb2Vzbid0IHJlYWxseSBtYWtlIHNlbnNlIHRvIHJhbmsgbm9uLXNpYmxpbmdzIGJ5IGluZGV4LFxuICAvLyBzbyB0aGV5IHNvcnQgZXF1YWxseS5cbiAgMDtcbn1cbmZ1bmN0aW9uIG1hdGNoUm91dGVCcmFuY2goYnJhbmNoLCBwYXRobmFtZSwgYWxsb3dQYXJ0aWFsKSB7XG4gIGlmIChhbGxvd1BhcnRpYWwgPT09IHZvaWQgMCkge1xuICAgIGFsbG93UGFydGlhbCA9IGZhbHNlO1xuICB9XG4gIGxldCB7XG4gICAgcm91dGVzTWV0YVxuICB9ID0gYnJhbmNoO1xuICBsZXQgbWF0Y2hlZFBhcmFtcyA9IHt9O1xuICBsZXQgbWF0Y2hlZFBhdGhuYW1lID0gXCIvXCI7XG4gIGxldCBtYXRjaGVzID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcm91dGVzTWV0YS5sZW5ndGg7ICsraSkge1xuICAgIGxldCBtZXRhID0gcm91dGVzTWV0YVtpXTtcbiAgICBsZXQgZW5kID0gaSA9PT0gcm91dGVzTWV0YS5sZW5ndGggLSAxO1xuICAgIGxldCByZW1haW5pbmdQYXRobmFtZSA9IG1hdGNoZWRQYXRobmFtZSA9PT0gXCIvXCIgPyBwYXRobmFtZSA6IHBhdGhuYW1lLnNsaWNlKG1hdGNoZWRQYXRobmFtZS5sZW5ndGgpIHx8IFwiL1wiO1xuICAgIGxldCBtYXRjaCA9IG1hdGNoUGF0aCh7XG4gICAgICBwYXRoOiBtZXRhLnJlbGF0aXZlUGF0aCxcbiAgICAgIGNhc2VTZW5zaXRpdmU6IG1ldGEuY2FzZVNlbnNpdGl2ZSxcbiAgICAgIGVuZFxuICAgIH0sIHJlbWFpbmluZ1BhdGhuYW1lKTtcbiAgICBsZXQgcm91dGUgPSBtZXRhLnJvdXRlO1xuICAgIGlmICghbWF0Y2ggJiYgZW5kICYmIGFsbG93UGFydGlhbCAmJiAhcm91dGVzTWV0YVtyb3V0ZXNNZXRhLmxlbmd0aCAtIDFdLnJvdXRlLmluZGV4KSB7XG4gICAgICBtYXRjaCA9IG1hdGNoUGF0aCh7XG4gICAgICAgIHBhdGg6IG1ldGEucmVsYXRpdmVQYXRoLFxuICAgICAgICBjYXNlU2Vuc2l0aXZlOiBtZXRhLmNhc2VTZW5zaXRpdmUsXG4gICAgICAgIGVuZDogZmFsc2VcbiAgICAgIH0sIHJlbWFpbmluZ1BhdGhuYW1lKTtcbiAgICB9XG4gICAgaWYgKCFtYXRjaCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIE9iamVjdC5hc3NpZ24obWF0Y2hlZFBhcmFtcywgbWF0Y2gucGFyYW1zKTtcbiAgICBtYXRjaGVzLnB1c2goe1xuICAgICAgLy8gVE9ETzogQ2FuIHRoaXMgYXMgYmUgYXZvaWRlZD9cbiAgICAgIHBhcmFtczogbWF0Y2hlZFBhcmFtcyxcbiAgICAgIHBhdGhuYW1lOiBqb2luUGF0aHMoW21hdGNoZWRQYXRobmFtZSwgbWF0Y2gucGF0aG5hbWVdKSxcbiAgICAgIHBhdGhuYW1lQmFzZTogbm9ybWFsaXplUGF0aG5hbWUoam9pblBhdGhzKFttYXRjaGVkUGF0aG5hbWUsIG1hdGNoLnBhdGhuYW1lQmFzZV0pKSxcbiAgICAgIHJvdXRlXG4gICAgfSk7XG4gICAgaWYgKG1hdGNoLnBhdGhuYW1lQmFzZSAhPT0gXCIvXCIpIHtcbiAgICAgIG1hdGNoZWRQYXRobmFtZSA9IGpvaW5QYXRocyhbbWF0Y2hlZFBhdGhuYW1lLCBtYXRjaC5wYXRobmFtZUJhc2VdKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG1hdGNoZXM7XG59XG4vKipcbiAqIFJldHVybnMgYSBwYXRoIHdpdGggcGFyYW1zIGludGVycG9sYXRlZC5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vcmVhY3Ryb3V0ZXIuY29tL3Y2L3V0aWxzL2dlbmVyYXRlLXBhdGhcbiAqL1xuZnVuY3Rpb24gZ2VuZXJhdGVQYXRoKG9yaWdpbmFsUGF0aCwgcGFyYW1zKSB7XG4gIGlmIChwYXJhbXMgPT09IHZvaWQgMCkge1xuICAgIHBhcmFtcyA9IHt9O1xuICB9XG4gIGxldCBwYXRoID0gb3JpZ2luYWxQYXRoO1xuICBpZiAocGF0aC5lbmRzV2l0aChcIipcIikgJiYgcGF0aCAhPT0gXCIqXCIgJiYgIXBhdGguZW5kc1dpdGgoXCIvKlwiKSkge1xuICAgIHdhcm5pbmcoZmFsc2UsIFwiUm91dGUgcGF0aCBcXFwiXCIgKyBwYXRoICsgXCJcXFwiIHdpbGwgYmUgdHJlYXRlZCBhcyBpZiBpdCB3ZXJlIFwiICsgKFwiXFxcIlwiICsgcGF0aC5yZXBsYWNlKC9cXCokLywgXCIvKlwiKSArIFwiXFxcIiBiZWNhdXNlIHRoZSBgKmAgY2hhcmFjdGVyIG11c3QgXCIpICsgXCJhbHdheXMgZm9sbG93IGEgYC9gIGluIHRoZSBwYXR0ZXJuLiBUbyBnZXQgcmlkIG9mIHRoaXMgd2FybmluZywgXCIgKyAoXCJwbGVhc2UgY2hhbmdlIHRoZSByb3V0ZSBwYXRoIHRvIFxcXCJcIiArIHBhdGgucmVwbGFjZSgvXFwqJC8sIFwiLypcIikgKyBcIlxcXCIuXCIpKTtcbiAgICBwYXRoID0gcGF0aC5yZXBsYWNlKC9cXCokLywgXCIvKlwiKTtcbiAgfVxuICAvLyBlbnN1cmUgYC9gIGlzIGFkZGVkIGF0IHRoZSBiZWdpbm5pbmcgaWYgdGhlIHBhdGggaXMgYWJzb2x1dGVcbiAgY29uc3QgcHJlZml4ID0gcGF0aC5zdGFydHNXaXRoKFwiL1wiKSA/IFwiL1wiIDogXCJcIjtcbiAgY29uc3Qgc3RyaW5naWZ5ID0gcCA9PiBwID09IG51bGwgPyBcIlwiIDogdHlwZW9mIHAgPT09IFwic3RyaW5nXCIgPyBwIDogU3RyaW5nKHApO1xuICBjb25zdCBzZWdtZW50cyA9IHBhdGguc3BsaXQoL1xcLysvKS5tYXAoKHNlZ21lbnQsIGluZGV4LCBhcnJheSkgPT4ge1xuICAgIGNvbnN0IGlzTGFzdFNlZ21lbnQgPSBpbmRleCA9PT0gYXJyYXkubGVuZ3RoIC0gMTtcbiAgICAvLyBvbmx5IGFwcGx5IHRoZSBzcGxhdCBpZiBpdCdzIHRoZSBsYXN0IHNlZ21lbnRcbiAgICBpZiAoaXNMYXN0U2VnbWVudCAmJiBzZWdtZW50ID09PSBcIipcIikge1xuICAgICAgY29uc3Qgc3RhciA9IFwiKlwiO1xuICAgICAgLy8gQXBwbHkgdGhlIHNwbGF0XG4gICAgICByZXR1cm4gc3RyaW5naWZ5KHBhcmFtc1tzdGFyXSk7XG4gICAgfVxuICAgIGNvbnN0IGtleU1hdGNoID0gc2VnbWVudC5tYXRjaCgvXjooW1xcdy1dKykoXFw/PykkLyk7XG4gICAgaWYgKGtleU1hdGNoKSB7XG4gICAgICBjb25zdCBbLCBrZXksIG9wdGlvbmFsXSA9IGtleU1hdGNoO1xuICAgICAgbGV0IHBhcmFtID0gcGFyYW1zW2tleV07XG4gICAgICBpbnZhcmlhbnQob3B0aW9uYWwgPT09IFwiP1wiIHx8IHBhcmFtICE9IG51bGwsIFwiTWlzc2luZyBcXFwiOlwiICsga2V5ICsgXCJcXFwiIHBhcmFtXCIpO1xuICAgICAgcmV0dXJuIHN0cmluZ2lmeShwYXJhbSk7XG4gICAgfVxuICAgIC8vIFJlbW92ZSBhbnkgb3B0aW9uYWwgbWFya2VycyBmcm9tIG9wdGlvbmFsIHN0YXRpYyBzZWdtZW50c1xuICAgIHJldHVybiBzZWdtZW50LnJlcGxhY2UoL1xcPyQvZywgXCJcIik7XG4gIH0pXG4gIC8vIFJlbW92ZSBlbXB0eSBzZWdtZW50c1xuICAuZmlsdGVyKHNlZ21lbnQgPT4gISFzZWdtZW50KTtcbiAgcmV0dXJuIHByZWZpeCArIHNlZ21lbnRzLmpvaW4oXCIvXCIpO1xufVxuLyoqXG4gKiBQZXJmb3JtcyBwYXR0ZXJuIG1hdGNoaW5nIG9uIGEgVVJMIHBhdGhuYW1lIGFuZCByZXR1cm5zIGluZm9ybWF0aW9uIGFib3V0XG4gKiB0aGUgbWF0Y2guXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91dGlscy9tYXRjaC1wYXRoXG4gKi9cbmZ1bmN0aW9uIG1hdGNoUGF0aChwYXR0ZXJuLCBwYXRobmFtZSkge1xuICBpZiAodHlwZW9mIHBhdHRlcm4gPT09IFwic3RyaW5nXCIpIHtcbiAgICBwYXR0ZXJuID0ge1xuICAgICAgcGF0aDogcGF0dGVybixcbiAgICAgIGNhc2VTZW5zaXRpdmU6IGZhbHNlLFxuICAgICAgZW5kOiB0cnVlXG4gICAgfTtcbiAgfVxuICBsZXQgW21hdGNoZXIsIGNvbXBpbGVkUGFyYW1zXSA9IGNvbXBpbGVQYXRoKHBhdHRlcm4ucGF0aCwgcGF0dGVybi5jYXNlU2Vuc2l0aXZlLCBwYXR0ZXJuLmVuZCk7XG4gIGxldCBtYXRjaCA9IHBhdGhuYW1lLm1hdGNoKG1hdGNoZXIpO1xuICBpZiAoIW1hdGNoKSByZXR1cm4gbnVsbDtcbiAgbGV0IG1hdGNoZWRQYXRobmFtZSA9IG1hdGNoWzBdO1xuICBsZXQgcGF0aG5hbWVCYXNlID0gbWF0Y2hlZFBhdGhuYW1lLnJlcGxhY2UoLyguKVxcLyskLywgXCIkMVwiKTtcbiAgbGV0IGNhcHR1cmVHcm91cHMgPSBtYXRjaC5zbGljZSgxKTtcbiAgbGV0IHBhcmFtcyA9IGNvbXBpbGVkUGFyYW1zLnJlZHVjZSgobWVtbywgX3JlZiwgaW5kZXgpID0+IHtcbiAgICBsZXQge1xuICAgICAgcGFyYW1OYW1lLFxuICAgICAgaXNPcHRpb25hbFxuICAgIH0gPSBfcmVmO1xuICAgIC8vIFdlIG5lZWQgdG8gY29tcHV0ZSB0aGUgcGF0aG5hbWVCYXNlIGhlcmUgdXNpbmcgdGhlIHJhdyBzcGxhdCB2YWx1ZVxuICAgIC8vIGluc3RlYWQgb2YgdXNpbmcgcGFyYW1zW1wiKlwiXSBsYXRlciBiZWNhdXNlIGl0IHdpbGwgYmUgZGVjb2RlZCB0aGVuXG4gICAgaWYgKHBhcmFtTmFtZSA9PT0gXCIqXCIpIHtcbiAgICAgIGxldCBzcGxhdFZhbHVlID0gY2FwdHVyZUdyb3Vwc1tpbmRleF0gfHwgXCJcIjtcbiAgICAgIHBhdGhuYW1lQmFzZSA9IG1hdGNoZWRQYXRobmFtZS5zbGljZSgwLCBtYXRjaGVkUGF0aG5hbWUubGVuZ3RoIC0gc3BsYXRWYWx1ZS5sZW5ndGgpLnJlcGxhY2UoLyguKVxcLyskLywgXCIkMVwiKTtcbiAgICB9XG4gICAgY29uc3QgdmFsdWUgPSBjYXB0dXJlR3JvdXBzW2luZGV4XTtcbiAgICBpZiAoaXNPcHRpb25hbCAmJiAhdmFsdWUpIHtcbiAgICAgIG1lbW9bcGFyYW1OYW1lXSA9IHVuZGVmaW5lZDtcbiAgICB9IGVsc2Uge1xuICAgICAgbWVtb1twYXJhbU5hbWVdID0gKHZhbHVlIHx8IFwiXCIpLnJlcGxhY2UoLyUyRi9nLCBcIi9cIik7XG4gICAgfVxuICAgIHJldHVybiBtZW1vO1xuICB9LCB7fSk7XG4gIHJldHVybiB7XG4gICAgcGFyYW1zLFxuICAgIHBhdGhuYW1lOiBtYXRjaGVkUGF0aG5hbWUsXG4gICAgcGF0aG5hbWVCYXNlLFxuICAgIHBhdHRlcm5cbiAgfTtcbn1cbmZ1bmN0aW9uIGNvbXBpbGVQYXRoKHBhdGgsIGNhc2VTZW5zaXRpdmUsIGVuZCkge1xuICBpZiAoY2FzZVNlbnNpdGl2ZSA9PT0gdm9pZCAwKSB7XG4gICAgY2FzZVNlbnNpdGl2ZSA9IGZhbHNlO1xuICB9XG4gIGlmIChlbmQgPT09IHZvaWQgMCkge1xuICAgIGVuZCA9IHRydWU7XG4gIH1cbiAgd2FybmluZyhwYXRoID09PSBcIipcIiB8fCAhcGF0aC5lbmRzV2l0aChcIipcIikgfHwgcGF0aC5lbmRzV2l0aChcIi8qXCIpLCBcIlJvdXRlIHBhdGggXFxcIlwiICsgcGF0aCArIFwiXFxcIiB3aWxsIGJlIHRyZWF0ZWQgYXMgaWYgaXQgd2VyZSBcIiArIChcIlxcXCJcIiArIHBhdGgucmVwbGFjZSgvXFwqJC8sIFwiLypcIikgKyBcIlxcXCIgYmVjYXVzZSB0aGUgYCpgIGNoYXJhY3RlciBtdXN0IFwiKSArIFwiYWx3YXlzIGZvbGxvdyBhIGAvYCBpbiB0aGUgcGF0dGVybi4gVG8gZ2V0IHJpZCBvZiB0aGlzIHdhcm5pbmcsIFwiICsgKFwicGxlYXNlIGNoYW5nZSB0aGUgcm91dGUgcGF0aCB0byBcXFwiXCIgKyBwYXRoLnJlcGxhY2UoL1xcKiQvLCBcIi8qXCIpICsgXCJcXFwiLlwiKSk7XG4gIGxldCBwYXJhbXMgPSBbXTtcbiAgbGV0IHJlZ2V4cFNvdXJjZSA9IFwiXlwiICsgcGF0aC5yZXBsYWNlKC9cXC8qXFwqPyQvLCBcIlwiKSAvLyBJZ25vcmUgdHJhaWxpbmcgLyBhbmQgLyosIHdlJ2xsIGhhbmRsZSBpdCBiZWxvd1xuICAucmVwbGFjZSgvXlxcLyovLCBcIi9cIikgLy8gTWFrZSBzdXJlIGl0IGhhcyBhIGxlYWRpbmcgL1xuICAucmVwbGFjZSgvW1xcXFwuKiteJHt9fCgpW1xcXV0vZywgXCJcXFxcJCZcIikgLy8gRXNjYXBlIHNwZWNpYWwgcmVnZXggY2hhcnNcbiAgLnJlcGxhY2UoL1xcLzooW1xcdy1dKykoXFw/KT8vZywgKF8sIHBhcmFtTmFtZSwgaXNPcHRpb25hbCkgPT4ge1xuICAgIHBhcmFtcy5wdXNoKHtcbiAgICAgIHBhcmFtTmFtZSxcbiAgICAgIGlzT3B0aW9uYWw6IGlzT3B0aW9uYWwgIT0gbnVsbFxuICAgIH0pO1xuICAgIHJldHVybiBpc09wdGlvbmFsID8gXCIvPyhbXlxcXFwvXSspP1wiIDogXCIvKFteXFxcXC9dKylcIjtcbiAgfSk7XG4gIGlmIChwYXRoLmVuZHNXaXRoKFwiKlwiKSkge1xuICAgIHBhcmFtcy5wdXNoKHtcbiAgICAgIHBhcmFtTmFtZTogXCIqXCJcbiAgICB9KTtcbiAgICByZWdleHBTb3VyY2UgKz0gcGF0aCA9PT0gXCIqXCIgfHwgcGF0aCA9PT0gXCIvKlwiID8gXCIoLiopJFwiIC8vIEFscmVhZHkgbWF0Y2hlZCB0aGUgaW5pdGlhbCAvLCBqdXN0IG1hdGNoIHRoZSByZXN0XG4gICAgOiBcIig/OlxcXFwvKC4rKXxcXFxcLyopJFwiOyAvLyBEb24ndCBpbmNsdWRlIHRoZSAvIGluIHBhcmFtc1tcIipcIl1cbiAgfSBlbHNlIGlmIChlbmQpIHtcbiAgICAvLyBXaGVuIG1hdGNoaW5nIHRvIHRoZSBlbmQsIGlnbm9yZSB0cmFpbGluZyBzbGFzaGVzXG4gICAgcmVnZXhwU291cmNlICs9IFwiXFxcXC8qJFwiO1xuICB9IGVsc2UgaWYgKHBhdGggIT09IFwiXCIgJiYgcGF0aCAhPT0gXCIvXCIpIHtcbiAgICAvLyBJZiBvdXIgcGF0aCBpcyBub24tZW1wdHkgYW5kIGNvbnRhaW5zIGFueXRoaW5nIGJleW9uZCBhbiBpbml0aWFsIHNsYXNoLFxuICAgIC8vIHRoZW4gd2UgaGF2ZSBfc29tZV8gZm9ybSBvZiBwYXRoIGluIG91ciByZWdleCwgc28gd2Ugc2hvdWxkIGV4cGVjdCB0b1xuICAgIC8vIG1hdGNoIG9ubHkgaWYgd2UgZmluZCB0aGUgZW5kIG9mIHRoaXMgcGF0aCBzZWdtZW50LiAgTG9vayBmb3IgYW4gb3B0aW9uYWxcbiAgICAvLyBub24tY2FwdHVyZWQgdHJhaWxpbmcgc2xhc2ggKHRvIG1hdGNoIGEgcG9ydGlvbiBvZiB0aGUgVVJMKSBvciB0aGUgZW5kXG4gICAgLy8gb2YgdGhlIHBhdGggKGlmIHdlJ3ZlIG1hdGNoZWQgdG8gdGhlIGVuZCkuICBXZSB1c2VkIHRvIGRvIHRoaXMgd2l0aCBhXG4gICAgLy8gd29yZCBib3VuZGFyeSBidXQgdGhhdCBnaXZlcyBmYWxzZSBwb3NpdGl2ZXMgb24gcm91dGVzIGxpa2VcbiAgICAvLyAvdXNlci1wcmVmZXJlbmNlcyBzaW5jZSBgLWAgY291bnRzIGFzIGEgd29yZCBib3VuZGFyeS5cbiAgICByZWdleHBTb3VyY2UgKz0gXCIoPzooPz1cXFxcL3wkKSlcIjtcbiAgfSBlbHNlIDtcbiAgbGV0IG1hdGNoZXIgPSBuZXcgUmVnRXhwKHJlZ2V4cFNvdXJjZSwgY2FzZVNlbnNpdGl2ZSA/IHVuZGVmaW5lZCA6IFwiaVwiKTtcbiAgcmV0dXJuIFttYXRjaGVyLCBwYXJhbXNdO1xufVxuZnVuY3Rpb24gZGVjb2RlUGF0aCh2YWx1ZSkge1xuICB0cnkge1xuICAgIHJldHVybiB2YWx1ZS5zcGxpdChcIi9cIikubWFwKHYgPT4gZGVjb2RlVVJJQ29tcG9uZW50KHYpLnJlcGxhY2UoL1xcLy9nLCBcIiUyRlwiKSkuam9pbihcIi9cIik7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgd2FybmluZyhmYWxzZSwgXCJUaGUgVVJMIHBhdGggXFxcIlwiICsgdmFsdWUgKyBcIlxcXCIgY291bGQgbm90IGJlIGRlY29kZWQgYmVjYXVzZSBpdCBpcyBpcyBhIFwiICsgXCJtYWxmb3JtZWQgVVJMIHNlZ21lbnQuIFRoaXMgaXMgcHJvYmFibHkgZHVlIHRvIGEgYmFkIHBlcmNlbnQgXCIgKyAoXCJlbmNvZGluZyAoXCIgKyBlcnJvciArIFwiKS5cIikpO1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxufVxuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5mdW5jdGlvbiBzdHJpcEJhc2VuYW1lKHBhdGhuYW1lLCBiYXNlbmFtZSkge1xuICBpZiAoYmFzZW5hbWUgPT09IFwiL1wiKSByZXR1cm4gcGF0aG5hbWU7XG4gIGlmICghcGF0aG5hbWUudG9Mb3dlckNhc2UoKS5zdGFydHNXaXRoKGJhc2VuYW1lLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgLy8gV2Ugd2FudCB0byBsZWF2ZSB0cmFpbGluZyBzbGFzaCBiZWhhdmlvciBpbiB0aGUgdXNlcidzIGNvbnRyb2wsIHNvIGlmIHRoZXlcbiAgLy8gc3BlY2lmeSBhIGJhc2VuYW1lIHdpdGggYSB0cmFpbGluZyBzbGFzaCwgd2Ugc2hvdWxkIHN1cHBvcnQgaXRcbiAgbGV0IHN0YXJ0SW5kZXggPSBiYXNlbmFtZS5lbmRzV2l0aChcIi9cIikgPyBiYXNlbmFtZS5sZW5ndGggLSAxIDogYmFzZW5hbWUubGVuZ3RoO1xuICBsZXQgbmV4dENoYXIgPSBwYXRobmFtZS5jaGFyQXQoc3RhcnRJbmRleCk7XG4gIGlmIChuZXh0Q2hhciAmJiBuZXh0Q2hhciAhPT0gXCIvXCIpIHtcbiAgICAvLyBwYXRobmFtZSBkb2VzIG5vdCBzdGFydCB3aXRoIGJhc2VuYW1lL1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiBwYXRobmFtZS5zbGljZShzdGFydEluZGV4KSB8fCBcIi9cIjtcbn1cbmNvbnN0IEFCU09MVVRFX1VSTF9SRUdFWCQxID0gL14oPzpbYS16XVthLXowLTkrLi1dKjp8XFwvXFwvKS9pO1xuY29uc3QgaXNBYnNvbHV0ZVVybCA9IHVybCA9PiBBQlNPTFVURV9VUkxfUkVHRVgkMS50ZXN0KHVybCk7XG4vKipcbiAqIFJldHVybnMgYSByZXNvbHZlZCBwYXRoIG9iamVjdCByZWxhdGl2ZSB0byB0aGUgZ2l2ZW4gcGF0aG5hbWUuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91dGlscy9yZXNvbHZlLXBhdGhcbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZVBhdGgodG8sIGZyb21QYXRobmFtZSkge1xuICBpZiAoZnJvbVBhdGhuYW1lID09PSB2b2lkIDApIHtcbiAgICBmcm9tUGF0aG5hbWUgPSBcIi9cIjtcbiAgfVxuICBsZXQge1xuICAgIHBhdGhuYW1lOiB0b1BhdGhuYW1lLFxuICAgIHNlYXJjaCA9IFwiXCIsXG4gICAgaGFzaCA9IFwiXCJcbiAgfSA9IHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIiA/IHBhcnNlUGF0aCh0bykgOiB0bztcbiAgbGV0IHBhdGhuYW1lO1xuICBpZiAodG9QYXRobmFtZSkge1xuICAgIGlmIChpc0Fic29sdXRlVXJsKHRvUGF0aG5hbWUpKSB7XG4gICAgICBwYXRobmFtZSA9IHRvUGF0aG5hbWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICh0b1BhdGhuYW1lLmluY2x1ZGVzKFwiLy9cIikpIHtcbiAgICAgICAgbGV0IG9sZFBhdGhuYW1lID0gdG9QYXRobmFtZTtcbiAgICAgICAgdG9QYXRobmFtZSA9IHJlbW92ZURvdWJsZVNsYXNoZXModG9QYXRobmFtZSk7XG4gICAgICAgIHdhcm5pbmcoZmFsc2UsIFwiUGF0aG5hbWVzIGNhbm5vdCBoYXZlIGVtYmVkZGVkIGRvdWJsZSBzbGFzaGVzIC0gbm9ybWFsaXppbmcgXCIgKyAob2xkUGF0aG5hbWUgKyBcIiAtPiBcIiArIHRvUGF0aG5hbWUpKTtcbiAgICAgIH1cbiAgICAgIGlmICh0b1BhdGhuYW1lLnN0YXJ0c1dpdGgoXCIvXCIpKSB7XG4gICAgICAgIHBhdGhuYW1lID0gcmVzb2x2ZVBhdGhuYW1lKHRvUGF0aG5hbWUuc3Vic3RyaW5nKDEpLCBcIi9cIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXRobmFtZSA9IHJlc29sdmVQYXRobmFtZSh0b1BhdGhuYW1lLCBmcm9tUGF0aG5hbWUpO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBwYXRobmFtZSA9IGZyb21QYXRobmFtZTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHBhdGhuYW1lLFxuICAgIHNlYXJjaDogbm9ybWFsaXplU2VhcmNoKHNlYXJjaCksXG4gICAgaGFzaDogbm9ybWFsaXplSGFzaChoYXNoKVxuICB9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZVBhdGhuYW1lKHJlbGF0aXZlUGF0aCwgZnJvbVBhdGhuYW1lKSB7XG4gIGxldCBzZWdtZW50cyA9IGZyb21QYXRobmFtZS5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpLnNwbGl0KFwiL1wiKTtcbiAgbGV0IHJlbGF0aXZlU2VnbWVudHMgPSByZWxhdGl2ZVBhdGguc3BsaXQoXCIvXCIpO1xuICByZWxhdGl2ZVNlZ21lbnRzLmZvckVhY2goc2VnbWVudCA9PiB7XG4gICAgaWYgKHNlZ21lbnQgPT09IFwiLi5cIikge1xuICAgICAgLy8gS2VlcCB0aGUgcm9vdCBcIlwiIHNlZ21lbnQgc28gdGhlIHBhdGhuYW1lIHN0YXJ0cyBhdCAvXG4gICAgICBpZiAoc2VnbWVudHMubGVuZ3RoID4gMSkgc2VnbWVudHMucG9wKCk7XG4gICAgfSBlbHNlIGlmIChzZWdtZW50ICE9PSBcIi5cIikge1xuICAgICAgc2VnbWVudHMucHVzaChzZWdtZW50KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gc2VnbWVudHMubGVuZ3RoID4gMSA/IHNlZ21lbnRzLmpvaW4oXCIvXCIpIDogXCIvXCI7XG59XG5mdW5jdGlvbiBnZXRJbnZhbGlkUGF0aEVycm9yKGNoYXIsIGZpZWxkLCBkZXN0LCBwYXRoKSB7XG4gIHJldHVybiBcIkNhbm5vdCBpbmNsdWRlIGEgJ1wiICsgY2hhciArIFwiJyBjaGFyYWN0ZXIgaW4gYSBtYW51YWxseSBzcGVjaWZpZWQgXCIgKyAoXCJgdG8uXCIgKyBmaWVsZCArIFwiYCBmaWVsZCBbXCIgKyBKU09OLnN0cmluZ2lmeShwYXRoKSArIFwiXS4gIFBsZWFzZSBzZXBhcmF0ZSBpdCBvdXQgdG8gdGhlIFwiKSArIChcImB0by5cIiArIGRlc3QgKyBcImAgZmllbGQuIEFsdGVybmF0aXZlbHkgeW91IG1heSBwcm92aWRlIHRoZSBmdWxsIHBhdGggYXMgXCIpICsgXCJhIHN0cmluZyBpbiA8TGluayB0bz1cXFwiLi4uXFxcIj4gYW5kIHRoZSByb3V0ZXIgd2lsbCBwYXJzZSBpdCBmb3IgeW91LlwiO1xufVxuLyoqXG4gKiBAcHJpdmF0ZVxuICpcbiAqIFdoZW4gcHJvY2Vzc2luZyByZWxhdGl2ZSBuYXZpZ2F0aW9uIHdlIHdhbnQgdG8gaWdub3JlIGFuY2VzdG9yIHJvdXRlcyB0aGF0XG4gKiBkbyBub3QgY29udHJpYnV0ZSB0byB0aGUgcGF0aCwgc3VjaCB0aGF0IGluZGV4L3BhdGhsZXNzIGxheW91dCByb3V0ZXMgZG9uJ3RcbiAqIGludGVyZmVyZS5cbiAqXG4gKiBGb3IgZXhhbXBsZSwgd2hlbiBtb3ZpbmcgYSByb3V0ZSBlbGVtZW50IGludG8gYW4gaW5kZXggcm91dGUgYW5kL29yIGFcbiAqIHBhdGhsZXNzIGxheW91dCByb3V0ZSwgcmVsYXRpdmUgbGluayBiZWhhdmlvciBjb250YWluZWQgd2l0aGluIHNob3VsZCBzdGF5XG4gKiB0aGUgc2FtZS4gIEJvdGggb2YgdGhlIGZvbGxvd2luZyBleGFtcGxlcyBzaG91bGQgbGluayBiYWNrIHRvIHRoZSByb290OlxuICpcbiAqICAgPFJvdXRlIHBhdGg9XCIvXCI+XG4gKiAgICAgPFJvdXRlIHBhdGg9XCJhY2NvdW50c1wiIGVsZW1lbnQ9ezxMaW5rIHRvPVwiLi5cIn0+XG4gKiAgIDwvUm91dGU+XG4gKlxuICogICA8Um91dGUgcGF0aD1cIi9cIj5cbiAqICAgICA8Um91dGUgcGF0aD1cImFjY291bnRzXCI+XG4gKiAgICAgICA8Um91dGUgZWxlbWVudD17PEFjY291bnRzTGF5b3V0IC8+fT4gICAgICAgLy8gPC0tIERvZXMgbm90IGNvbnRyaWJ1dGVcbiAqICAgICAgICAgPFJvdXRlIGluZGV4IGVsZW1lbnQ9ezxMaW5rIHRvPVwiLi5cIn0gLz4gIC8vIDwtLSBEb2VzIG5vdCBjb250cmlidXRlXG4gKiAgICAgICA8L1JvdXRlXG4gKiAgICAgPC9Sb3V0ZT5cbiAqICAgPC9Sb3V0ZT5cbiAqL1xuZnVuY3Rpb24gZ2V0UGF0aENvbnRyaWJ1dGluZ01hdGNoZXMobWF0Y2hlcykge1xuICByZXR1cm4gbWF0Y2hlcy5maWx0ZXIoKG1hdGNoLCBpbmRleCkgPT4gaW5kZXggPT09IDAgfHwgbWF0Y2gucm91dGUucGF0aCAmJiBtYXRjaC5yb3V0ZS5wYXRoLmxlbmd0aCA+IDApO1xufVxuLy8gUmV0dXJuIHRoZSBhcnJheSBvZiBwYXRobmFtZXMgZm9yIHRoZSBjdXJyZW50IHJvdXRlIG1hdGNoZXMgLSB1c2VkIHRvXG4vLyBnZW5lcmF0ZSB0aGUgcm91dGVQYXRobmFtZXMgaW5wdXQgZm9yIHJlc29sdmVUbygpXG5mdW5jdGlvbiBnZXRSZXNvbHZlVG9NYXRjaGVzKG1hdGNoZXMsIHY3X3JlbGF0aXZlU3BsYXRQYXRoKSB7XG4gIGxldCBwYXRoTWF0Y2hlcyA9IGdldFBhdGhDb250cmlidXRpbmdNYXRjaGVzKG1hdGNoZXMpO1xuICAvLyBXaGVuIHY3X3JlbGF0aXZlU3BsYXRQYXRoIGlzIGVuYWJsZWQsIHVzZSB0aGUgZnVsbCBwYXRobmFtZSBmb3IgdGhlIGxlYWZcbiAgLy8gbWF0Y2ggc28gd2UgaW5jbHVkZSBzcGxhdCB2YWx1ZXMgZm9yIFwiLlwiIGxpbmtzLiAgU2VlOlxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vcmVtaXgtcnVuL3JlYWN0LXJvdXRlci9pc3N1ZXMvMTEwNTIjaXNzdWVjb21tZW50LTE4MzY1ODkzMjlcbiAgaWYgKHY3X3JlbGF0aXZlU3BsYXRQYXRoKSB7XG4gICAgcmV0dXJuIHBhdGhNYXRjaGVzLm1hcCgobWF0Y2gsIGlkeCkgPT4gaWR4ID09PSBwYXRoTWF0Y2hlcy5sZW5ndGggLSAxID8gbWF0Y2gucGF0aG5hbWUgOiBtYXRjaC5wYXRobmFtZUJhc2UpO1xuICB9XG4gIHJldHVybiBwYXRoTWF0Y2hlcy5tYXAobWF0Y2ggPT4gbWF0Y2gucGF0aG5hbWVCYXNlKTtcbn1cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZVRvKHRvQXJnLCByb3V0ZVBhdGhuYW1lcywgbG9jYXRpb25QYXRobmFtZSwgaXNQYXRoUmVsYXRpdmUpIHtcbiAgaWYgKGlzUGF0aFJlbGF0aXZlID09PSB2b2lkIDApIHtcbiAgICBpc1BhdGhSZWxhdGl2ZSA9IGZhbHNlO1xuICB9XG4gIGxldCB0bztcbiAgaWYgKHR5cGVvZiB0b0FyZyA9PT0gXCJzdHJpbmdcIikge1xuICAgIHRvID0gcGFyc2VQYXRoKHRvQXJnKTtcbiAgfSBlbHNlIHtcbiAgICB0byA9IF9leHRlbmRzKHt9LCB0b0FyZyk7XG4gICAgaW52YXJpYW50KCF0by5wYXRobmFtZSB8fCAhdG8ucGF0aG5hbWUuaW5jbHVkZXMoXCI/XCIpLCBnZXRJbnZhbGlkUGF0aEVycm9yKFwiP1wiLCBcInBhdGhuYW1lXCIsIFwic2VhcmNoXCIsIHRvKSk7XG4gICAgaW52YXJpYW50KCF0by5wYXRobmFtZSB8fCAhdG8ucGF0aG5hbWUuaW5jbHVkZXMoXCIjXCIpLCBnZXRJbnZhbGlkUGF0aEVycm9yKFwiI1wiLCBcInBhdGhuYW1lXCIsIFwiaGFzaFwiLCB0bykpO1xuICAgIGludmFyaWFudCghdG8uc2VhcmNoIHx8ICF0by5zZWFyY2guaW5jbHVkZXMoXCIjXCIpLCBnZXRJbnZhbGlkUGF0aEVycm9yKFwiI1wiLCBcInNlYXJjaFwiLCBcImhhc2hcIiwgdG8pKTtcbiAgfVxuICBsZXQgaXNFbXB0eVBhdGggPSB0b0FyZyA9PT0gXCJcIiB8fCB0by5wYXRobmFtZSA9PT0gXCJcIjtcbiAgbGV0IHRvUGF0aG5hbWUgPSBpc0VtcHR5UGF0aCA/IFwiL1wiIDogdG8ucGF0aG5hbWU7XG4gIGxldCBmcm9tO1xuICAvLyBSb3V0aW5nIGlzIHJlbGF0aXZlIHRvIHRoZSBjdXJyZW50IHBhdGhuYW1lIGlmIGV4cGxpY2l0bHkgcmVxdWVzdGVkLlxuICAvL1xuICAvLyBJZiBhIHBhdGhuYW1lIGlzIGV4cGxpY2l0bHkgcHJvdmlkZWQgaW4gYHRvYCwgaXQgc2hvdWxkIGJlIHJlbGF0aXZlIHRvIHRoZVxuICAvLyByb3V0ZSBjb250ZXh0LiBUaGlzIGlzIGV4cGxhaW5lZCBpbiBgTm90ZSBvbiBgPExpbmsgdG8+YCB2YWx1ZXNgIGluIG91clxuICAvLyBtaWdyYXRpb24gZ3VpZGUgZnJvbSB2NSBhcyBhIG1lYW5zIG9mIGRpc2FtYmlndWF0aW9uIGJldHdlZW4gYHRvYCB2YWx1ZXNcbiAgLy8gdGhhdCBiZWdpbiB3aXRoIGAvYCBhbmQgdGhvc2UgdGhhdCBkbyBub3QuIEhvd2V2ZXIsIHRoaXMgaXMgcHJvYmxlbWF0aWMgZm9yXG4gIC8vIGB0b2AgdmFsdWVzIHRoYXQgZG8gbm90IHByb3ZpZGUgYSBwYXRobmFtZS4gYHRvYCBjYW4gc2ltcGx5IGJlIGEgc2VhcmNoIG9yXG4gIC8vIGhhc2ggc3RyaW5nLCBpbiB3aGljaCBjYXNlIHdlIHNob3VsZCBhc3N1bWUgdGhhdCB0aGUgbmF2aWdhdGlvbiBpcyByZWxhdGl2ZVxuICAvLyB0byB0aGUgY3VycmVudCBsb2NhdGlvbidzIHBhdGhuYW1lIGFuZCAqbm90KiB0aGUgcm91dGUgcGF0aG5hbWUuXG4gIGlmICh0b1BhdGhuYW1lID09IG51bGwpIHtcbiAgICBmcm9tID0gbG9jYXRpb25QYXRobmFtZTtcbiAgfSBlbHNlIHtcbiAgICBsZXQgcm91dGVQYXRobmFtZUluZGV4ID0gcm91dGVQYXRobmFtZXMubGVuZ3RoIC0gMTtcbiAgICAvLyBXaXRoIHJlbGF0aXZlPVwicm91dGVcIiAodGhlIGRlZmF1bHQpLCBlYWNoIGxlYWRpbmcgLi4gc2VnbWVudCBtZWFuc1xuICAgIC8vIFwiZ28gdXAgb25lIHJvdXRlXCIgaW5zdGVhZCBvZiBcImdvIHVwIG9uZSBVUkwgc2VnbWVudFwiLiAgVGhpcyBpcyBhIGtleVxuICAgIC8vIGRpZmZlcmVuY2UgZnJvbSBob3cgPGEgaHJlZj4gd29ya3MgYW5kIGEgbWFqb3IgcmVhc29uIHdlIGNhbGwgdGhpcyBhXG4gICAgLy8gXCJ0b1wiIHZhbHVlIGluc3RlYWQgb2YgYSBcImhyZWZcIi5cbiAgICBpZiAoIWlzUGF0aFJlbGF0aXZlICYmIHRvUGF0aG5hbWUuc3RhcnRzV2l0aChcIi4uXCIpKSB7XG4gICAgICBsZXQgdG9TZWdtZW50cyA9IHRvUGF0aG5hbWUuc3BsaXQoXCIvXCIpO1xuICAgICAgd2hpbGUgKHRvU2VnbWVudHNbMF0gPT09IFwiLi5cIikge1xuICAgICAgICB0b1NlZ21lbnRzLnNoaWZ0KCk7XG4gICAgICAgIHJvdXRlUGF0aG5hbWVJbmRleCAtPSAxO1xuICAgICAgfVxuICAgICAgdG8ucGF0aG5hbWUgPSB0b1NlZ21lbnRzLmpvaW4oXCIvXCIpO1xuICAgIH1cbiAgICBmcm9tID0gcm91dGVQYXRobmFtZUluZGV4ID49IDAgPyByb3V0ZVBhdGhuYW1lc1tyb3V0ZVBhdGhuYW1lSW5kZXhdIDogXCIvXCI7XG4gIH1cbiAgbGV0IHBhdGggPSByZXNvbHZlUGF0aCh0bywgZnJvbSk7XG4gIC8vIEVuc3VyZSB0aGUgcGF0aG5hbWUgaGFzIGEgdHJhaWxpbmcgc2xhc2ggaWYgdGhlIG9yaWdpbmFsIFwidG9cIiBoYWQgb25lXG4gIGxldCBoYXNFeHBsaWNpdFRyYWlsaW5nU2xhc2ggPSB0b1BhdGhuYW1lICYmIHRvUGF0aG5hbWUgIT09IFwiL1wiICYmIHRvUGF0aG5hbWUuZW5kc1dpdGgoXCIvXCIpO1xuICAvLyBPciBpZiB0aGlzIHdhcyBhIGxpbmsgdG8gdGhlIGN1cnJlbnQgcGF0aCB3aGljaCBoYXMgYSB0cmFpbGluZyBzbGFzaFxuICBsZXQgaGFzQ3VycmVudFRyYWlsaW5nU2xhc2ggPSAoaXNFbXB0eVBhdGggfHwgdG9QYXRobmFtZSA9PT0gXCIuXCIpICYmIGxvY2F0aW9uUGF0aG5hbWUuZW5kc1dpdGgoXCIvXCIpO1xuICBpZiAoIXBhdGgucGF0aG5hbWUuZW5kc1dpdGgoXCIvXCIpICYmIChoYXNFeHBsaWNpdFRyYWlsaW5nU2xhc2ggfHwgaGFzQ3VycmVudFRyYWlsaW5nU2xhc2gpKSB7XG4gICAgcGF0aC5wYXRobmFtZSArPSBcIi9cIjtcbiAgfVxuICByZXR1cm4gcGF0aDtcbn1cbi8qKlxuICogQHByaXZhdGVcbiAqL1xuZnVuY3Rpb24gZ2V0VG9QYXRobmFtZSh0bykge1xuICAvLyBFbXB0eSBzdHJpbmdzIHNob3VsZCBiZSB0cmVhdGVkIHRoZSBzYW1lIGFzIC8gcGF0aHNcbiAgcmV0dXJuIHRvID09PSBcIlwiIHx8IHRvLnBhdGhuYW1lID09PSBcIlwiID8gXCIvXCIgOiB0eXBlb2YgdG8gPT09IFwic3RyaW5nXCIgPyBwYXJzZVBhdGgodG8pLnBhdGhuYW1lIDogdG8ucGF0aG5hbWU7XG59XG5jb25zdCByZW1vdmVEb3VibGVTbGFzaGVzID0gcGF0aCA9PiBwYXRoLnJlcGxhY2UoL1xcL1xcLysvZywgXCIvXCIpO1xuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5jb25zdCBqb2luUGF0aHMgPSBwYXRocyA9PiByZW1vdmVEb3VibGVTbGFzaGVzKHBhdGhzLmpvaW4oXCIvXCIpKTtcbi8qKlxuICogQHByaXZhdGVcbiAqL1xuY29uc3Qgbm9ybWFsaXplUGF0aG5hbWUgPSBwYXRobmFtZSA9PiBwYXRobmFtZS5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpLnJlcGxhY2UoL15cXC8qLywgXCIvXCIpO1xuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5jb25zdCBub3JtYWxpemVTZWFyY2ggPSBzZWFyY2ggPT4gIXNlYXJjaCB8fCBzZWFyY2ggPT09IFwiP1wiID8gXCJcIiA6IHNlYXJjaC5zdGFydHNXaXRoKFwiP1wiKSA/IHNlYXJjaCA6IFwiP1wiICsgc2VhcmNoO1xuLyoqXG4gKiBAcHJpdmF0ZVxuICovXG5jb25zdCBub3JtYWxpemVIYXNoID0gaGFzaCA9PiAhaGFzaCB8fCBoYXNoID09PSBcIiNcIiA/IFwiXCIgOiBoYXNoLnN0YXJ0c1dpdGgoXCIjXCIpID8gaGFzaCA6IFwiI1wiICsgaGFzaDtcbi8qKlxuICogVGhpcyBpcyBhIHNob3J0Y3V0IGZvciBjcmVhdGluZyBgYXBwbGljYXRpb24vanNvbmAgcmVzcG9uc2VzLiBDb252ZXJ0cyBgZGF0YWBcbiAqIHRvIEpTT04gYW5kIHNldHMgdGhlIGBDb250ZW50LVR5cGVgIGhlYWRlci5cbiAqXG4gKiBAZGVwcmVjYXRlZCBUaGUgYGpzb25gIG1ldGhvZCBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHJldHVybmluZyByYXcgb2JqZWN0cy5cbiAqIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB2Ny5cbiAqL1xuY29uc3QganNvbiA9IGZ1bmN0aW9uIGpzb24oZGF0YSwgaW5pdCkge1xuICBpZiAoaW5pdCA9PT0gdm9pZCAwKSB7XG4gICAgaW5pdCA9IHt9O1xuICB9XG4gIGxldCByZXNwb25zZUluaXQgPSB0eXBlb2YgaW5pdCA9PT0gXCJudW1iZXJcIiA/IHtcbiAgICBzdGF0dXM6IGluaXRcbiAgfSA6IGluaXQ7XG4gIGxldCBoZWFkZXJzID0gbmV3IEhlYWRlcnMocmVzcG9uc2VJbml0LmhlYWRlcnMpO1xuICBpZiAoIWhlYWRlcnMuaGFzKFwiQ29udGVudC1UeXBlXCIpKSB7XG4gICAgaGVhZGVycy5zZXQoXCJDb250ZW50LVR5cGVcIiwgXCJhcHBsaWNhdGlvbi9qc29uOyBjaGFyc2V0PXV0Zi04XCIpO1xuICB9XG4gIHJldHVybiBuZXcgUmVzcG9uc2UoSlNPTi5zdHJpbmdpZnkoZGF0YSksIF9leHRlbmRzKHt9LCByZXNwb25zZUluaXQsIHtcbiAgICBoZWFkZXJzXG4gIH0pKTtcbn07XG5jbGFzcyBEYXRhV2l0aFJlc3BvbnNlSW5pdCB7XG4gIGNvbnN0cnVjdG9yKGRhdGEsIGluaXQpIHtcbiAgICB0aGlzLnR5cGUgPSBcIkRhdGFXaXRoUmVzcG9uc2VJbml0XCI7XG4gICAgdGhpcy5kYXRhID0gZGF0YTtcbiAgICB0aGlzLmluaXQgPSBpbml0IHx8IG51bGw7XG4gIH1cbn1cbi8qKlxuICogQ3JlYXRlIFwicmVzcG9uc2VzXCIgdGhhdCBjb250YWluIGBzdGF0dXNgL2BoZWFkZXJzYCB3aXRob3V0IGZvcmNpbmdcbiAqIHNlcmlhbGl6YXRpb24gaW50byBhbiBhY3R1YWwgYFJlc3BvbnNlYCAtIHVzZWQgYnkgUmVtaXggc2luZ2xlIGZldGNoXG4gKi9cbmZ1bmN0aW9uIGRhdGEoZGF0YSwgaW5pdCkge1xuICByZXR1cm4gbmV3IERhdGFXaXRoUmVzcG9uc2VJbml0KGRhdGEsIHR5cGVvZiBpbml0ID09PSBcIm51bWJlclwiID8ge1xuICAgIHN0YXR1czogaW5pdFxuICB9IDogaW5pdCk7XG59XG5jbGFzcyBBYm9ydGVkRGVmZXJyZWRFcnJvciBleHRlbmRzIEVycm9yIHt9XG5jbGFzcyBEZWZlcnJlZERhdGEge1xuICBjb25zdHJ1Y3RvcihkYXRhLCByZXNwb25zZUluaXQpIHtcbiAgICB0aGlzLnBlbmRpbmdLZXlzU2V0ID0gbmV3IFNldCgpO1xuICAgIHRoaXMuc3Vic2NyaWJlcnMgPSBuZXcgU2V0KCk7XG4gICAgdGhpcy5kZWZlcnJlZEtleXMgPSBbXTtcbiAgICBpbnZhcmlhbnQoZGF0YSAmJiB0eXBlb2YgZGF0YSA9PT0gXCJvYmplY3RcIiAmJiAhQXJyYXkuaXNBcnJheShkYXRhKSwgXCJkZWZlcigpIG9ubHkgYWNjZXB0cyBwbGFpbiBvYmplY3RzXCIpO1xuICAgIC8vIFNldCB1cCBhbiBBYm9ydENvbnRyb2xsZXIgKyBQcm9taXNlIHdlIGNhbiByYWNlIGFnYWluc3QgdG8gZXhpdCBlYXJseVxuICAgIC8vIGNhbmNlbGxhdGlvblxuICAgIGxldCByZWplY3Q7XG4gICAgdGhpcy5hYm9ydFByb21pc2UgPSBuZXcgUHJvbWlzZSgoXywgcikgPT4gcmVqZWN0ID0gcik7XG4gICAgdGhpcy5jb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGxldCBvbkFib3J0ID0gKCkgPT4gcmVqZWN0KG5ldyBBYm9ydGVkRGVmZXJyZWRFcnJvcihcIkRlZmVycmVkIGRhdGEgYWJvcnRlZFwiKSk7XG4gICAgdGhpcy51bmxpc3RlbkFib3J0U2lnbmFsID0gKCkgPT4gdGhpcy5jb250cm9sbGVyLnNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCk7XG4gICAgdGhpcy5jb250cm9sbGVyLnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCk7XG4gICAgdGhpcy5kYXRhID0gT2JqZWN0LmVudHJpZXMoZGF0YSkucmVkdWNlKChhY2MsIF9yZWYyKSA9PiB7XG4gICAgICBsZXQgW2tleSwgdmFsdWVdID0gX3JlZjI7XG4gICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbihhY2MsIHtcbiAgICAgICAgW2tleV06IHRoaXMudHJhY2tQcm9taXNlKGtleSwgdmFsdWUpXG4gICAgICB9KTtcbiAgICB9LCB7fSk7XG4gICAgaWYgKHRoaXMuZG9uZSkge1xuICAgICAgLy8gQWxsIGluY29taW5nIHZhbHVlcyB3ZXJlIHJlc29sdmVkXG4gICAgICB0aGlzLnVubGlzdGVuQWJvcnRTaWduYWwoKTtcbiAgICB9XG4gICAgdGhpcy5pbml0ID0gcmVzcG9uc2VJbml0O1xuICB9XG4gIHRyYWNrUHJvbWlzZShrZXksIHZhbHVlKSB7XG4gICAgaWYgKCEodmFsdWUgaW5zdGFuY2VvZiBQcm9taXNlKSkge1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICB0aGlzLmRlZmVycmVkS2V5cy5wdXNoKGtleSk7XG4gICAgdGhpcy5wZW5kaW5nS2V5c1NldC5hZGQoa2V5KTtcbiAgICAvLyBXZSBzdG9yZSBhIGxpdHRsZSB3cmFwcGVyIHByb21pc2UgdGhhdCB3aWxsIGJlIGV4dGVuZGVkIHdpdGhcbiAgICAvLyBfZGF0YS9fZXJyb3IgcHJvcHMgdXBvbiByZXNvbHZlL3JlamVjdFxuICAgIGxldCBwcm9taXNlID0gUHJvbWlzZS5yYWNlKFt2YWx1ZSwgdGhpcy5hYm9ydFByb21pc2VdKS50aGVuKGRhdGEgPT4gdGhpcy5vblNldHRsZShwcm9taXNlLCBrZXksIHVuZGVmaW5lZCwgZGF0YSksIGVycm9yID0+IHRoaXMub25TZXR0bGUocHJvbWlzZSwga2V5LCBlcnJvcikpO1xuICAgIC8vIFJlZ2lzdGVyIHJlamVjdGlvbiBsaXN0ZW5lcnMgdG8gYXZvaWQgdW5jYXVnaHQgcHJvbWlzZSByZWplY3Rpb25zIG9uXG4gICAgLy8gZXJyb3JzIG9yIGFib3J0ZWQgZGVmZXJyZWQgdmFsdWVzXG4gICAgcHJvbWlzZS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHByb21pc2UsIFwiX3RyYWNrZWRcIiwge1xuICAgICAgZ2V0OiAoKSA9PiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIHByb21pc2U7XG4gIH1cbiAgb25TZXR0bGUocHJvbWlzZSwga2V5LCBlcnJvciwgZGF0YSkge1xuICAgIGlmICh0aGlzLmNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQgJiYgZXJyb3IgaW5zdGFuY2VvZiBBYm9ydGVkRGVmZXJyZWRFcnJvcikge1xuICAgICAgdGhpcy51bmxpc3RlbkFib3J0U2lnbmFsKCk7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocHJvbWlzZSwgXCJfZXJyb3JcIiwge1xuICAgICAgICBnZXQ6ICgpID0+IGVycm9yXG4gICAgICB9KTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICAgIHRoaXMucGVuZGluZ0tleXNTZXQuZGVsZXRlKGtleSk7XG4gICAgaWYgKHRoaXMuZG9uZSkge1xuICAgICAgLy8gTm90aGluZyBsZWZ0IHRvIGFib3J0IVxuICAgICAgdGhpcy51bmxpc3RlbkFib3J0U2lnbmFsKCk7XG4gICAgfVxuICAgIC8vIElmIHRoZSBwcm9taXNlIHdhcyByZXNvbHZlZC9yZWplY3RlZCB3aXRoIHVuZGVmaW5lZCwgd2UnbGwgdGhyb3cgYW4gZXJyb3IgYXMgeW91XG4gICAgLy8gc2hvdWxkIGFsd2F5cyByZXNvbHZlIHdpdGggYSB2YWx1ZSBvciBudWxsXG4gICAgaWYgKGVycm9yID09PSB1bmRlZmluZWQgJiYgZGF0YSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBsZXQgdW5kZWZpbmVkRXJyb3IgPSBuZXcgRXJyb3IoXCJEZWZlcnJlZCBkYXRhIGZvciBrZXkgXFxcIlwiICsga2V5ICsgXCJcXFwiIHJlc29sdmVkL3JlamVjdGVkIHdpdGggYHVuZGVmaW5lZGAsIFwiICsgXCJ5b3UgbXVzdCByZXNvbHZlL3JlamVjdCB3aXRoIGEgdmFsdWUgb3IgYG51bGxgLlwiKTtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShwcm9taXNlLCBcIl9lcnJvclwiLCB7XG4gICAgICAgIGdldDogKCkgPT4gdW5kZWZpbmVkRXJyb3JcbiAgICAgIH0pO1xuICAgICAgdGhpcy5lbWl0KGZhbHNlLCBrZXkpO1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KHVuZGVmaW5lZEVycm9yKTtcbiAgICB9XG4gICAgaWYgKGRhdGEgPT09IHVuZGVmaW5lZCkge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHByb21pc2UsIFwiX2Vycm9yXCIsIHtcbiAgICAgICAgZ2V0OiAoKSA9PiBlcnJvclxuICAgICAgfSk7XG4gICAgICB0aGlzLmVtaXQoZmFsc2UsIGtleSk7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocHJvbWlzZSwgXCJfZGF0YVwiLCB7XG4gICAgICBnZXQ6ICgpID0+IGRhdGFcbiAgICB9KTtcbiAgICB0aGlzLmVtaXQoZmFsc2UsIGtleSk7XG4gICAgcmV0dXJuIGRhdGE7XG4gIH1cbiAgZW1pdChhYm9ydGVkLCBzZXR0bGVkS2V5KSB7XG4gICAgdGhpcy5zdWJzY3JpYmVycy5mb3JFYWNoKHN1YnNjcmliZXIgPT4gc3Vic2NyaWJlcihhYm9ydGVkLCBzZXR0bGVkS2V5KSk7XG4gIH1cbiAgc3Vic2NyaWJlKGZuKSB7XG4gICAgdGhpcy5zdWJzY3JpYmVycy5hZGQoZm4pO1xuICAgIHJldHVybiAoKSA9PiB0aGlzLnN1YnNjcmliZXJzLmRlbGV0ZShmbik7XG4gIH1cbiAgY2FuY2VsKCkge1xuICAgIHRoaXMuY29udHJvbGxlci5hYm9ydCgpO1xuICAgIHRoaXMucGVuZGluZ0tleXNTZXQuZm9yRWFjaCgodiwgaykgPT4gdGhpcy5wZW5kaW5nS2V5c1NldC5kZWxldGUoaykpO1xuICAgIHRoaXMuZW1pdCh0cnVlKTtcbiAgfVxuICBhc3luYyByZXNvbHZlRGF0YShzaWduYWwpIHtcbiAgICBsZXQgYWJvcnRlZCA9IGZhbHNlO1xuICAgIGlmICghdGhpcy5kb25lKSB7XG4gICAgICBsZXQgb25BYm9ydCA9ICgpID0+IHRoaXMuY2FuY2VsKCk7XG4gICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uQWJvcnQpO1xuICAgICAgYWJvcnRlZCA9IGF3YWl0IG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgICB0aGlzLnN1YnNjcmliZShhYm9ydGVkID0+IHtcbiAgICAgICAgICBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uQWJvcnQpO1xuICAgICAgICAgIGlmIChhYm9ydGVkIHx8IHRoaXMuZG9uZSkge1xuICAgICAgICAgICAgcmVzb2x2ZShhYm9ydGVkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBhYm9ydGVkO1xuICB9XG4gIGdldCBkb25lKCkge1xuICAgIHJldHVybiB0aGlzLnBlbmRpbmdLZXlzU2V0LnNpemUgPT09IDA7XG4gIH1cbiAgZ2V0IHVud3JhcHBlZERhdGEoKSB7XG4gICAgaW52YXJpYW50KHRoaXMuZGF0YSAhPT0gbnVsbCAmJiB0aGlzLmRvbmUsIFwiQ2FuIG9ubHkgdW53cmFwIGRhdGEgb24gaW5pdGlhbGl6ZWQgYW5kIHNldHRsZWQgZGVmZXJyZWRzXCIpO1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyh0aGlzLmRhdGEpLnJlZHVjZSgoYWNjLCBfcmVmMykgPT4ge1xuICAgICAgbGV0IFtrZXksIHZhbHVlXSA9IF9yZWYzO1xuICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oYWNjLCB7XG4gICAgICAgIFtrZXldOiB1bndyYXBUcmFja2VkUHJvbWlzZSh2YWx1ZSlcbiAgICAgIH0pO1xuICAgIH0sIHt9KTtcbiAgfVxuICBnZXQgcGVuZGluZ0tleXMoKSB7XG4gICAgcmV0dXJuIEFycmF5LmZyb20odGhpcy5wZW5kaW5nS2V5c1NldCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGlzVHJhY2tlZFByb21pc2UodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgUHJvbWlzZSAmJiB2YWx1ZS5fdHJhY2tlZCA9PT0gdHJ1ZTtcbn1cbmZ1bmN0aW9uIHVud3JhcFRyYWNrZWRQcm9taXNlKHZhbHVlKSB7XG4gIGlmICghaXNUcmFja2VkUHJvbWlzZSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgaWYgKHZhbHVlLl9lcnJvcikge1xuICAgIHRocm93IHZhbHVlLl9lcnJvcjtcbiAgfVxuICByZXR1cm4gdmFsdWUuX2RhdGE7XG59XG4vKipcbiAqIEBkZXByZWNhdGVkIFRoZSBgZGVmZXJgIG1ldGhvZCBpcyBkZXByZWNhdGVkIGluIGZhdm9yIG9mIHJldHVybmluZyByYXdcbiAqIG9iamVjdHMuIFRoaXMgbWV0aG9kIHdpbGwgYmUgcmVtb3ZlZCBpbiB2Ny5cbiAqL1xuY29uc3QgZGVmZXIgPSBmdW5jdGlvbiBkZWZlcihkYXRhLCBpbml0KSB7XG4gIGlmIChpbml0ID09PSB2b2lkIDApIHtcbiAgICBpbml0ID0ge307XG4gIH1cbiAgbGV0IHJlc3BvbnNlSW5pdCA9IHR5cGVvZiBpbml0ID09PSBcIm51bWJlclwiID8ge1xuICAgIHN0YXR1czogaW5pdFxuICB9IDogaW5pdDtcbiAgcmV0dXJuIG5ldyBEZWZlcnJlZERhdGEoZGF0YSwgcmVzcG9uc2VJbml0KTtcbn07XG4vKipcbiAqIEEgcmVkaXJlY3QgcmVzcG9uc2UuIFNldHMgdGhlIHN0YXR1cyBjb2RlIGFuZCB0aGUgYExvY2F0aW9uYCBoZWFkZXIuXG4gKiBEZWZhdWx0cyB0byBcIjMwMiBGb3VuZFwiLlxuICovXG5jb25zdCByZWRpcmVjdCA9IGZ1bmN0aW9uIHJlZGlyZWN0KHVybCwgaW5pdCkge1xuICBpZiAoaW5pdCA9PT0gdm9pZCAwKSB7XG4gICAgaW5pdCA9IDMwMjtcbiAgfVxuICBsZXQgcmVzcG9uc2VJbml0ID0gaW5pdDtcbiAgaWYgKHR5cGVvZiByZXNwb25zZUluaXQgPT09IFwibnVtYmVyXCIpIHtcbiAgICByZXNwb25zZUluaXQgPSB7XG4gICAgICBzdGF0dXM6IHJlc3BvbnNlSW5pdFxuICAgIH07XG4gIH0gZWxzZSBpZiAodHlwZW9mIHJlc3BvbnNlSW5pdC5zdGF0dXMgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICByZXNwb25zZUluaXQuc3RhdHVzID0gMzAyO1xuICB9XG4gIGxldCBoZWFkZXJzID0gbmV3IEhlYWRlcnMocmVzcG9uc2VJbml0LmhlYWRlcnMpO1xuICBoZWFkZXJzLnNldChcIkxvY2F0aW9uXCIsIHVybCk7XG4gIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwgX2V4dGVuZHMoe30sIHJlc3BvbnNlSW5pdCwge1xuICAgIGhlYWRlcnNcbiAgfSkpO1xufTtcbi8qKlxuICogQSByZWRpcmVjdCByZXNwb25zZSB0aGF0IHdpbGwgZm9yY2UgYSBkb2N1bWVudCByZWxvYWQgdG8gdGhlIG5ldyBsb2NhdGlvbi5cbiAqIFNldHMgdGhlIHN0YXR1cyBjb2RlIGFuZCB0aGUgYExvY2F0aW9uYCBoZWFkZXIuXG4gKiBEZWZhdWx0cyB0byBcIjMwMiBGb3VuZFwiLlxuICovXG5jb25zdCByZWRpcmVjdERvY3VtZW50ID0gKHVybCwgaW5pdCkgPT4ge1xuICBsZXQgcmVzcG9uc2UgPSByZWRpcmVjdCh1cmwsIGluaXQpO1xuICByZXNwb25zZS5oZWFkZXJzLnNldChcIlgtUmVtaXgtUmVsb2FkLURvY3VtZW50XCIsIFwidHJ1ZVwiKTtcbiAgcmV0dXJuIHJlc3BvbnNlO1xufTtcbi8qKlxuICogQSByZWRpcmVjdCByZXNwb25zZSB0aGF0IHdpbGwgcGVyZm9ybSBhIGBoaXN0b3J5LnJlcGxhY2VTdGF0ZWAgaW5zdGVhZCBvZiBhXG4gKiBgaGlzdG9yeS5wdXNoU3RhdGVgIGZvciBjbGllbnQtc2lkZSBuYXZpZ2F0aW9uIHJlZGlyZWN0cy5cbiAqIFNldHMgdGhlIHN0YXR1cyBjb2RlIGFuZCB0aGUgYExvY2F0aW9uYCBoZWFkZXIuXG4gKiBEZWZhdWx0cyB0byBcIjMwMiBGb3VuZFwiLlxuICovXG5jb25zdCByZXBsYWNlID0gKHVybCwgaW5pdCkgPT4ge1xuICBsZXQgcmVzcG9uc2UgPSByZWRpcmVjdCh1cmwsIGluaXQpO1xuICByZXNwb25zZS5oZWFkZXJzLnNldChcIlgtUmVtaXgtUmVwbGFjZVwiLCBcInRydWVcIik7XG4gIHJldHVybiByZXNwb25zZTtcbn07XG4vKipcbiAqIEBwcml2YXRlXG4gKiBVdGlsaXR5IGNsYXNzIHdlIHVzZSB0byBob2xkIGF1dG8tdW53cmFwcGVkIDR4eC81eHggUmVzcG9uc2UgYm9kaWVzXG4gKlxuICogV2UgZG9uJ3QgZXhwb3J0IHRoZSBjbGFzcyBmb3IgcHVibGljIHVzZSBzaW5jZSBpdCdzIGFuIGltcGxlbWVudGF0aW9uXG4gKiBkZXRhaWwsIGJ1dCB3ZSBleHBvcnQgdGhlIGludGVyZmFjZSBhYm92ZSBzbyBmb2xrcyBjYW4gYnVpbGQgdGhlaXIgb3duXG4gKiBhYnN0cmFjdGlvbnMgYXJvdW5kIGluc3RhbmNlcyB2aWEgaXNSb3V0ZUVycm9yUmVzcG9uc2UoKVxuICovXG5jbGFzcyBFcnJvclJlc3BvbnNlSW1wbCB7XG4gIGNvbnN0cnVjdG9yKHN0YXR1cywgc3RhdHVzVGV4dCwgZGF0YSwgaW50ZXJuYWwpIHtcbiAgICBpZiAoaW50ZXJuYWwgPT09IHZvaWQgMCkge1xuICAgICAgaW50ZXJuYWwgPSBmYWxzZTtcbiAgICB9XG4gICAgdGhpcy5zdGF0dXMgPSBzdGF0dXM7XG4gICAgdGhpcy5zdGF0dXNUZXh0ID0gc3RhdHVzVGV4dCB8fCBcIlwiO1xuICAgIHRoaXMuaW50ZXJuYWwgPSBpbnRlcm5hbDtcbiAgICBpZiAoZGF0YSBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICB0aGlzLmRhdGEgPSBkYXRhLnRvU3RyaW5nKCk7XG4gICAgICB0aGlzLmVycm9yID0gZGF0YTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5kYXRhID0gZGF0YTtcbiAgICB9XG4gIH1cbn1cbi8qKlxuICogQ2hlY2sgaWYgdGhlIGdpdmVuIGVycm9yIGlzIGFuIEVycm9yUmVzcG9uc2UgZ2VuZXJhdGVkIGZyb20gYSA0eHgvNXh4XG4gKiBSZXNwb25zZSB0aHJvd24gZnJvbSBhbiBhY3Rpb24vbG9hZGVyXG4gKi9cbmZ1bmN0aW9uIGlzUm91dGVFcnJvclJlc3BvbnNlKGVycm9yKSB7XG4gIHJldHVybiBlcnJvciAhPSBudWxsICYmIHR5cGVvZiBlcnJvci5zdGF0dXMgPT09IFwibnVtYmVyXCIgJiYgdHlwZW9mIGVycm9yLnN0YXR1c1RleHQgPT09IFwic3RyaW5nXCIgJiYgdHlwZW9mIGVycm9yLmludGVybmFsID09PSBcImJvb2xlYW5cIiAmJiBcImRhdGFcIiBpbiBlcnJvcjtcbn1cblxuY29uc3QgdmFsaWRNdXRhdGlvbk1ldGhvZHNBcnIgPSBbXCJwb3N0XCIsIFwicHV0XCIsIFwicGF0Y2hcIiwgXCJkZWxldGVcIl07XG5jb25zdCB2YWxpZE11dGF0aW9uTWV0aG9kcyA9IG5ldyBTZXQodmFsaWRNdXRhdGlvbk1ldGhvZHNBcnIpO1xuY29uc3QgdmFsaWRSZXF1ZXN0TWV0aG9kc0FyciA9IFtcImdldFwiLCAuLi52YWxpZE11dGF0aW9uTWV0aG9kc0Fycl07XG5jb25zdCB2YWxpZFJlcXVlc3RNZXRob2RzID0gbmV3IFNldCh2YWxpZFJlcXVlc3RNZXRob2RzQXJyKTtcbmNvbnN0IHJlZGlyZWN0U3RhdHVzQ29kZXMgPSBuZXcgU2V0KFszMDEsIDMwMiwgMzAzLCAzMDcsIDMwOF0pO1xuY29uc3QgcmVkaXJlY3RQcmVzZXJ2ZU1ldGhvZFN0YXR1c0NvZGVzID0gbmV3IFNldChbMzA3LCAzMDhdKTtcbmNvbnN0IElETEVfTkFWSUdBVElPTiA9IHtcbiAgc3RhdGU6IFwiaWRsZVwiLFxuICBsb2NhdGlvbjogdW5kZWZpbmVkLFxuICBmb3JtTWV0aG9kOiB1bmRlZmluZWQsXG4gIGZvcm1BY3Rpb246IHVuZGVmaW5lZCxcbiAgZm9ybUVuY1R5cGU6IHVuZGVmaW5lZCxcbiAgZm9ybURhdGE6IHVuZGVmaW5lZCxcbiAganNvbjogdW5kZWZpbmVkLFxuICB0ZXh0OiB1bmRlZmluZWRcbn07XG5jb25zdCBJRExFX0ZFVENIRVIgPSB7XG4gIHN0YXRlOiBcImlkbGVcIixcbiAgZGF0YTogdW5kZWZpbmVkLFxuICBmb3JtTWV0aG9kOiB1bmRlZmluZWQsXG4gIGZvcm1BY3Rpb246IHVuZGVmaW5lZCxcbiAgZm9ybUVuY1R5cGU6IHVuZGVmaW5lZCxcbiAgZm9ybURhdGE6IHVuZGVmaW5lZCxcbiAganNvbjogdW5kZWZpbmVkLFxuICB0ZXh0OiB1bmRlZmluZWRcbn07XG5jb25zdCBJRExFX0JMT0NLRVIgPSB7XG4gIHN0YXRlOiBcInVuYmxvY2tlZFwiLFxuICBwcm9jZWVkOiB1bmRlZmluZWQsXG4gIHJlc2V0OiB1bmRlZmluZWQsXG4gIGxvY2F0aW9uOiB1bmRlZmluZWRcbn07XG5jb25zdCBBQlNPTFVURV9VUkxfUkVHRVggPSAvXig/OlthLXpdW2EtejAtOSsuLV0qOnxcXC9cXC8pL2k7XG5jb25zdCBkZWZhdWx0TWFwUm91dGVQcm9wZXJ0aWVzID0gcm91dGUgPT4gKHtcbiAgaGFzRXJyb3JCb3VuZGFyeTogQm9vbGVhbihyb3V0ZS5oYXNFcnJvckJvdW5kYXJ5KVxufSk7XG5jb25zdCBUUkFOU0lUSU9OU19TVE9SQUdFX0tFWSA9IFwicmVtaXgtcm91dGVyLXRyYW5zaXRpb25zXCI7XG4vLyNlbmRyZWdpb25cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyNyZWdpb24gY3JlYXRlUm91dGVyXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLyoqXG4gKiBDcmVhdGUgYSByb3V0ZXIgYW5kIGxpc3RlbiB0byBoaXN0b3J5IFBPUCBuYXZpZ2F0aW9uc1xuICovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXIoaW5pdCkge1xuICBjb25zdCByb3V0ZXJXaW5kb3cgPSBpbml0LndpbmRvdyA/IGluaXQud2luZG93IDogdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHVuZGVmaW5lZDtcbiAgY29uc3QgaXNCcm93c2VyID0gdHlwZW9mIHJvdXRlcldpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB0eXBlb2Ygcm91dGVyV2luZG93LmRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiByb3V0ZXJXaW5kb3cuZG9jdW1lbnQuY3JlYXRlRWxlbWVudCAhPT0gXCJ1bmRlZmluZWRcIjtcbiAgY29uc3QgaXNTZXJ2ZXIgPSAhaXNCcm93c2VyO1xuICBpbnZhcmlhbnQoaW5pdC5yb3V0ZXMubGVuZ3RoID4gMCwgXCJZb3UgbXVzdCBwcm92aWRlIGEgbm9uLWVtcHR5IHJvdXRlcyBhcnJheSB0byBjcmVhdGVSb3V0ZXJcIik7XG4gIGxldCBtYXBSb3V0ZVByb3BlcnRpZXM7XG4gIGlmIChpbml0Lm1hcFJvdXRlUHJvcGVydGllcykge1xuICAgIG1hcFJvdXRlUHJvcGVydGllcyA9IGluaXQubWFwUm91dGVQcm9wZXJ0aWVzO1xuICB9IGVsc2UgaWYgKGluaXQuZGV0ZWN0RXJyb3JCb3VuZGFyeSkge1xuICAgIC8vIElmIHRoZXkgYXJlIHN0aWxsIHVzaW5nIHRoZSBkZXByZWNhdGVkIHZlcnNpb24sIHdyYXAgaXQgd2l0aCB0aGUgbmV3IEFQSVxuICAgIGxldCBkZXRlY3RFcnJvckJvdW5kYXJ5ID0gaW5pdC5kZXRlY3RFcnJvckJvdW5kYXJ5O1xuICAgIG1hcFJvdXRlUHJvcGVydGllcyA9IHJvdXRlID0+ICh7XG4gICAgICBoYXNFcnJvckJvdW5kYXJ5OiBkZXRlY3RFcnJvckJvdW5kYXJ5KHJvdXRlKVxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIG1hcFJvdXRlUHJvcGVydGllcyA9IGRlZmF1bHRNYXBSb3V0ZVByb3BlcnRpZXM7XG4gIH1cbiAgLy8gUm91dGVzIGtleWVkIGJ5IElEXG4gIGxldCBtYW5pZmVzdCA9IHt9O1xuICAvLyBSb3V0ZXMgaW4gdHJlZSBmb3JtYXQgZm9yIG1hdGNoaW5nXG4gIGxldCBkYXRhUm91dGVzID0gY29udmVydFJvdXRlc1RvRGF0YVJvdXRlcyhpbml0LnJvdXRlcywgbWFwUm91dGVQcm9wZXJ0aWVzLCB1bmRlZmluZWQsIG1hbmlmZXN0KTtcbiAgbGV0IGluRmxpZ2h0RGF0YVJvdXRlcztcbiAgbGV0IGJhc2VuYW1lID0gaW5pdC5iYXNlbmFtZSB8fCBcIi9cIjtcbiAgbGV0IGRhdGFTdHJhdGVneUltcGwgPSBpbml0LmRhdGFTdHJhdGVneSB8fCBkZWZhdWx0RGF0YVN0cmF0ZWd5O1xuICBsZXQgcGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb25JbXBsID0gaW5pdC5wYXRjaFJvdXRlc09uTmF2aWdhdGlvbjtcbiAgLy8gQ29uZmlnIGRyaXZlbiBiZWhhdmlvciBmbGFnc1xuICBsZXQgZnV0dXJlID0gX2V4dGVuZHMoe1xuICAgIHY3X2ZldGNoZXJQZXJzaXN0OiBmYWxzZSxcbiAgICB2N19ub3JtYWxpemVGb3JtTWV0aG9kOiBmYWxzZSxcbiAgICB2N19wYXJ0aWFsSHlkcmF0aW9uOiBmYWxzZSxcbiAgICB2N19wcmVwZW5kQmFzZW5hbWU6IGZhbHNlLFxuICAgIHY3X3JlbGF0aXZlU3BsYXRQYXRoOiBmYWxzZSxcbiAgICB2N19za2lwQWN0aW9uRXJyb3JSZXZhbGlkYXRpb246IGZhbHNlXG4gIH0sIGluaXQuZnV0dXJlKTtcbiAgLy8gQ2xlYW51cCBmdW5jdGlvbiBmb3IgaGlzdG9yeVxuICBsZXQgdW5saXN0ZW5IaXN0b3J5ID0gbnVsbDtcbiAgLy8gRXh0ZXJuYWxseS1wcm92aWRlZCBmdW5jdGlvbnMgdG8gY2FsbCBvbiBhbGwgc3RhdGUgY2hhbmdlc1xuICBsZXQgc3Vic2NyaWJlcnMgPSBuZXcgU2V0KCk7XG4gIC8vIEV4dGVybmFsbHktcHJvdmlkZWQgb2JqZWN0IHRvIGhvbGQgc2Nyb2xsIHJlc3RvcmF0aW9uIGxvY2F0aW9ucyBkdXJpbmcgcm91dGluZ1xuICBsZXQgc2F2ZWRTY3JvbGxQb3NpdGlvbnMgPSBudWxsO1xuICAvLyBFeHRlcm5hbGx5LXByb3ZpZGVkIGZ1bmN0aW9uIHRvIGdldCBzY3JvbGwgcmVzdG9yYXRpb24ga2V5c1xuICBsZXQgZ2V0U2Nyb2xsUmVzdG9yYXRpb25LZXkgPSBudWxsO1xuICAvLyBFeHRlcm5hbGx5LXByb3ZpZGVkIGZ1bmN0aW9uIHRvIGdldCBjdXJyZW50IHNjcm9sbCBwb3NpdGlvblxuICBsZXQgZ2V0U2Nyb2xsUG9zaXRpb24gPSBudWxsO1xuICAvLyBPbmUtdGltZSBmbGFnIHRvIGNvbnRyb2wgdGhlIGluaXRpYWwgaHlkcmF0aW9uIHNjcm9sbCByZXN0b3JhdGlvbi4gIEJlY2F1c2VcbiAgLy8gd2UgZG9uJ3QgZ2V0IHRoZSBzYXZlZCBwb3NpdGlvbnMgZnJvbSA8U2Nyb2xsUmVzdG9yYXRpb24gLz4gdW50aWwgX2FmdGVyX1xuICAvLyB0aGUgaW5pdGlhbCByZW5kZXIsIHdlIG5lZWQgdG8gbWFudWFsbHkgdHJpZ2dlciBhIHNlcGFyYXRlIHVwZGF0ZVN0YXRlIHRvXG4gIC8vIHNlbmQgYWxvbmcgdGhlIHJlc3RvcmVTY3JvbGxQb3NpdGlvblxuICAvLyBTZXQgdG8gdHJ1ZSBpZiB3ZSBoYXZlIGBoeWRyYXRpb25EYXRhYCBzaW5jZSB3ZSBhc3N1bWUgd2Ugd2VyZSBTU1InZCBhbmQgdGhhdFxuICAvLyBTU1IgZGlkIHRoZSBpbml0aWFsIHNjcm9sbCByZXN0b3JhdGlvbi5cbiAgbGV0IGluaXRpYWxTY3JvbGxSZXN0b3JlZCA9IGluaXQuaHlkcmF0aW9uRGF0YSAhPSBudWxsO1xuICBsZXQgaW5pdGlhbE1hdGNoZXMgPSBtYXRjaFJvdXRlcyhkYXRhUm91dGVzLCBpbml0Lmhpc3RvcnkubG9jYXRpb24sIGJhc2VuYW1lKTtcbiAgbGV0IGluaXRpYWxNYXRjaGVzSXNGT1cgPSBmYWxzZTtcbiAgbGV0IGluaXRpYWxFcnJvcnMgPSBudWxsO1xuICBpZiAoaW5pdGlhbE1hdGNoZXMgPT0gbnVsbCAmJiAhcGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb25JbXBsKSB7XG4gICAgLy8gSWYgd2UgZG8gbm90IG1hdGNoIGEgdXNlci1wcm92aWRlZC1yb3V0ZSwgZmFsbCBiYWNrIHRvIHRoZSByb290XG4gICAgLy8gdG8gYWxsb3cgdGhlIGVycm9yIGJvdW5kYXJ5IHRvIHRha2Ugb3ZlclxuICAgIGxldCBlcnJvciA9IGdldEludGVybmFsUm91dGVyRXJyb3IoNDA0LCB7XG4gICAgICBwYXRobmFtZTogaW5pdC5oaXN0b3J5LmxvY2F0aW9uLnBhdGhuYW1lXG4gICAgfSk7XG4gICAgbGV0IHtcbiAgICAgIG1hdGNoZXMsXG4gICAgICByb3V0ZVxuICAgIH0gPSBnZXRTaG9ydENpcmN1aXRNYXRjaGVzKGRhdGFSb3V0ZXMpO1xuICAgIGluaXRpYWxNYXRjaGVzID0gbWF0Y2hlcztcbiAgICBpbml0aWFsRXJyb3JzID0ge1xuICAgICAgW3JvdXRlLmlkXTogZXJyb3JcbiAgICB9O1xuICB9XG4gIC8vIEluIFNQQSBhcHBzLCBpZiB0aGUgdXNlciBwcm92aWRlZCBhIHBhdGNoUm91dGVzT25OYXZpZ2F0aW9uIGltcGxlbWVudGF0aW9uIGFuZFxuICAvLyBvdXIgaW5pdGlhbCBtYXRjaCBpcyBhIHNwbGF0IHJvdXRlLCBjbGVhciB0aGVtIG91dCBzbyB3ZSBydW4gdGhyb3VnaCBsYXp5XG4gIC8vIGRpc2NvdmVyeSBvbiBoeWRyYXRpb24gaW4gY2FzZSB0aGVyZSdzIGEgbW9yZSBhY2N1cmF0ZSBsYXp5IHJvdXRlIG1hdGNoLlxuICAvLyBJbiBTU1IgYXBwcyAod2l0aCBgaHlkcmF0aW9uRGF0YWApLCB3ZSBleHBlY3QgdGhhdCB0aGUgc2VydmVyIHdpbGwgc2VuZFxuICAvLyB1cCB0aGUgcHJvcGVyIG1hdGNoZWQgcm91dGVzIHNvIHdlIGRvbid0IHdhbnQgdG8gcnVuIGxhenkgZGlzY292ZXJ5IG9uXG4gIC8vIGluaXRpYWwgaHlkcmF0aW9uIGFuZCB3YW50IHRvIGh5ZHJhdGUgaW50byB0aGUgc3BsYXQgcm91dGUuXG4gIGlmIChpbml0aWFsTWF0Y2hlcyAmJiAhaW5pdC5oeWRyYXRpb25EYXRhKSB7XG4gICAgbGV0IGZvZ09mV2FyID0gY2hlY2tGb2dPZldhcihpbml0aWFsTWF0Y2hlcywgZGF0YVJvdXRlcywgaW5pdC5oaXN0b3J5LmxvY2F0aW9uLnBhdGhuYW1lKTtcbiAgICBpZiAoZm9nT2ZXYXIuYWN0aXZlKSB7XG4gICAgICBpbml0aWFsTWF0Y2hlcyA9IG51bGw7XG4gICAgfVxuICB9XG4gIGxldCBpbml0aWFsaXplZDtcbiAgaWYgKCFpbml0aWFsTWF0Y2hlcykge1xuICAgIGluaXRpYWxpemVkID0gZmFsc2U7XG4gICAgaW5pdGlhbE1hdGNoZXMgPSBbXTtcbiAgICAvLyBJZiBwYXJ0aWFsIGh5ZHJhdGlvbiBhbmQgZm9nIG9mIHdhciBpcyBlbmFibGVkLCB3ZSB3aWxsIGJlIHJ1bm5pbmdcbiAgICAvLyBgcGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb25gIGR1cmluZyBoeWRyYXRpb24gc28gaW5jbHVkZSBhbnkgcGFydGlhbCBtYXRjaGVzIGFzXG4gICAgLy8gdGhlIGluaXRpYWwgbWF0Y2hlcyBzbyB3ZSBjYW4gcHJvcGVybHkgcmVuZGVyIGBIeWRyYXRlRmFsbGJhY2tgJ3NcbiAgICBpZiAoZnV0dXJlLnY3X3BhcnRpYWxIeWRyYXRpb24pIHtcbiAgICAgIGxldCBmb2dPZldhciA9IGNoZWNrRm9nT2ZXYXIobnVsbCwgZGF0YVJvdXRlcywgaW5pdC5oaXN0b3J5LmxvY2F0aW9uLnBhdGhuYW1lKTtcbiAgICAgIGlmIChmb2dPZldhci5hY3RpdmUgJiYgZm9nT2ZXYXIubWF0Y2hlcykge1xuICAgICAgICBpbml0aWFsTWF0Y2hlc0lzRk9XID0gdHJ1ZTtcbiAgICAgICAgaW5pdGlhbE1hdGNoZXMgPSBmb2dPZldhci5tYXRjaGVzO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmIChpbml0aWFsTWF0Y2hlcy5zb21lKG0gPT4gbS5yb3V0ZS5sYXp5KSkge1xuICAgIC8vIEFsbCBpbml0aWFsTWF0Y2hlcyBuZWVkIHRvIGJlIGxvYWRlZCBiZWZvcmUgd2UncmUgcmVhZHkuICBJZiB3ZSBoYXZlIGxhenlcbiAgICAvLyBmdW5jdGlvbnMgYXJvdW5kIHN0aWxsIHRoZW4gd2UnbGwgbmVlZCB0byBydW4gdGhlbSBpbiBpbml0aWFsaXplKClcbiAgICBpbml0aWFsaXplZCA9IGZhbHNlO1xuICB9IGVsc2UgaWYgKCFpbml0aWFsTWF0Y2hlcy5zb21lKG0gPT4gbS5yb3V0ZS5sb2FkZXIpKSB7XG4gICAgLy8gSWYgd2UndmUgZ290IG5vIGxvYWRlcnMgdG8gcnVuLCB0aGVuIHdlJ3JlIGdvb2QgdG8gZ29cbiAgICBpbml0aWFsaXplZCA9IHRydWU7XG4gIH0gZWxzZSBpZiAoZnV0dXJlLnY3X3BhcnRpYWxIeWRyYXRpb24pIHtcbiAgICAvLyBJZiBwYXJ0aWFsIGh5ZHJhdGlvbiBpcyBlbmFibGVkLCB3ZSdyZSBpbml0aWFsaXplZCBzbyBsb25nIGFzIHdlIHdlcmVcbiAgICAvLyBwcm92aWRlZCB3aXRoIGh5ZHJhdGlvbkRhdGEgZm9yIGV2ZXJ5IHJvdXRlIHdpdGggYSBsb2FkZXIsIGFuZCBubyBsb2FkZXJzXG4gICAgLy8gd2VyZSBtYXJrZWQgZm9yIGV4cGxpY2l0IGh5ZHJhdGlvblxuICAgIGxldCBsb2FkZXJEYXRhID0gaW5pdC5oeWRyYXRpb25EYXRhID8gaW5pdC5oeWRyYXRpb25EYXRhLmxvYWRlckRhdGEgOiBudWxsO1xuICAgIGxldCBlcnJvcnMgPSBpbml0Lmh5ZHJhdGlvbkRhdGEgPyBpbml0Lmh5ZHJhdGlvbkRhdGEuZXJyb3JzIDogbnVsbDtcbiAgICAvLyBJZiBlcnJvcnMgZXhpc3QsIGRvbid0IGNvbnNpZGVyIHJvdXRlcyBiZWxvdyB0aGUgYm91bmRhcnlcbiAgICBpZiAoZXJyb3JzKSB7XG4gICAgICBsZXQgaWR4ID0gaW5pdGlhbE1hdGNoZXMuZmluZEluZGV4KG0gPT4gZXJyb3JzW20ucm91dGUuaWRdICE9PSB1bmRlZmluZWQpO1xuICAgICAgaW5pdGlhbGl6ZWQgPSBpbml0aWFsTWF0Y2hlcy5zbGljZSgwLCBpZHggKyAxKS5ldmVyeShtID0+ICFzaG91bGRMb2FkUm91dGVPbkh5ZHJhdGlvbihtLnJvdXRlLCBsb2FkZXJEYXRhLCBlcnJvcnMpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW5pdGlhbGl6ZWQgPSBpbml0aWFsTWF0Y2hlcy5ldmVyeShtID0+ICFzaG91bGRMb2FkUm91dGVPbkh5ZHJhdGlvbihtLnJvdXRlLCBsb2FkZXJEYXRhLCBlcnJvcnMpKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgLy8gV2l0aG91dCBwYXJ0aWFsIGh5ZHJhdGlvbiAtIHdlJ3JlIGluaXRpYWxpemVkIGlmIHdlIHdlcmUgcHJvdmlkZWQgYW55XG4gICAgLy8gaHlkcmF0aW9uRGF0YSAtIHdoaWNoIGlzIGV4cGVjdGVkIHRvIGJlIGNvbXBsZXRlXG4gICAgaW5pdGlhbGl6ZWQgPSBpbml0Lmh5ZHJhdGlvbkRhdGEgIT0gbnVsbDtcbiAgfVxuICBsZXQgcm91dGVyO1xuICBsZXQgc3RhdGUgPSB7XG4gICAgaGlzdG9yeUFjdGlvbjogaW5pdC5oaXN0b3J5LmFjdGlvbixcbiAgICBsb2NhdGlvbjogaW5pdC5oaXN0b3J5LmxvY2F0aW9uLFxuICAgIG1hdGNoZXM6IGluaXRpYWxNYXRjaGVzLFxuICAgIGluaXRpYWxpemVkLFxuICAgIG5hdmlnYXRpb246IElETEVfTkFWSUdBVElPTixcbiAgICAvLyBEb24ndCByZXN0b3JlIG9uIGluaXRpYWwgdXBkYXRlU3RhdGUoKSBpZiB3ZSB3ZXJlIFNTUidkXG4gICAgcmVzdG9yZVNjcm9sbFBvc2l0aW9uOiBpbml0Lmh5ZHJhdGlvbkRhdGEgIT0gbnVsbCA/IGZhbHNlIDogbnVsbCxcbiAgICBwcmV2ZW50U2Nyb2xsUmVzZXQ6IGZhbHNlLFxuICAgIHJldmFsaWRhdGlvbjogXCJpZGxlXCIsXG4gICAgbG9hZGVyRGF0YTogaW5pdC5oeWRyYXRpb25EYXRhICYmIGluaXQuaHlkcmF0aW9uRGF0YS5sb2FkZXJEYXRhIHx8IHt9LFxuICAgIGFjdGlvbkRhdGE6IGluaXQuaHlkcmF0aW9uRGF0YSAmJiBpbml0Lmh5ZHJhdGlvbkRhdGEuYWN0aW9uRGF0YSB8fCBudWxsLFxuICAgIGVycm9yczogaW5pdC5oeWRyYXRpb25EYXRhICYmIGluaXQuaHlkcmF0aW9uRGF0YS5lcnJvcnMgfHwgaW5pdGlhbEVycm9ycyxcbiAgICBmZXRjaGVyczogbmV3IE1hcCgpLFxuICAgIGJsb2NrZXJzOiBuZXcgTWFwKClcbiAgfTtcbiAgLy8gLS0gU3RhdGVmdWwgaW50ZXJuYWwgdmFyaWFibGVzIHRvIG1hbmFnZSBuYXZpZ2F0aW9ucyAtLVxuICAvLyBDdXJyZW50IG5hdmlnYXRpb24gaW4gcHJvZ3Jlc3MgKHRvIGJlIGNvbW1pdHRlZCBpbiBjb21wbGV0ZU5hdmlnYXRpb24pXG4gIGxldCBwZW5kaW5nQWN0aW9uID0gQWN0aW9uLlBvcDtcbiAgLy8gU2hvdWxkIHRoZSBjdXJyZW50IG5hdmlnYXRpb24gcHJldmVudCB0aGUgc2Nyb2xsIHJlc2V0IGlmIHNjcm9sbCBjYW5ub3RcbiAgLy8gYmUgcmVzdG9yZWQ/XG4gIGxldCBwZW5kaW5nUHJldmVudFNjcm9sbFJlc2V0ID0gZmFsc2U7XG4gIC8vIEFib3J0Q29udHJvbGxlciBmb3IgdGhlIGFjdGl2ZSBuYXZpZ2F0aW9uXG4gIGxldCBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXI7XG4gIC8vIFNob3VsZCB0aGUgY3VycmVudCBuYXZpZ2F0aW9uIGVuYWJsZSBkb2N1bWVudC5zdGFydFZpZXdUcmFuc2l0aW9uP1xuICBsZXQgcGVuZGluZ1ZpZXdUcmFuc2l0aW9uRW5hYmxlZCA9IGZhbHNlO1xuICAvLyBTdG9yZSBhcHBsaWVkIHZpZXcgdHJhbnNpdGlvbnMgc28gd2UgY2FuIGFwcGx5IHRoZW0gb24gUE9QXG4gIGxldCBhcHBsaWVkVmlld1RyYW5zaXRpb25zID0gbmV3IE1hcCgpO1xuICAvLyBDbGVhbnVwIGZ1bmN0aW9uIGZvciBwZXJzaXN0aW5nIGFwcGxpZWQgdHJhbnNpdGlvbnMgdG8gc2Vzc2lvblN0b3JhZ2VcbiAgbGV0IHJlbW92ZVBhZ2VIaWRlRXZlbnRMaXN0ZW5lciA9IG51bGw7XG4gIC8vIFdlIHVzZSB0aGlzIHRvIGF2b2lkIHRvdWNoaW5nIGhpc3RvcnkgaW4gY29tcGxldGVOYXZpZ2F0aW9uIGlmIGFcbiAgLy8gcmV2YWxpZGF0aW9uIGlzIGVudGlyZWx5IHVuaW50ZXJydXB0ZWRcbiAgbGV0IGlzVW5pbnRlcnJ1cHRlZFJldmFsaWRhdGlvbiA9IGZhbHNlO1xuICAvLyBVc2UgdGhpcyBpbnRlcm5hbCBmbGFnIHRvIGZvcmNlIHJldmFsaWRhdGlvbiBvZiBhbGwgbG9hZGVyczpcbiAgLy8gIC0gc3VibWlzc2lvbnMgKGNvbXBsZXRlZCBvciBpbnRlcnJ1cHRlZClcbiAgLy8gIC0gdXNlUmV2YWxpZGF0b3IoKVxuICAvLyAgLSBYLVJlbWl4LVJldmFsaWRhdGUgKGZyb20gcmVkaXJlY3QpXG4gIGxldCBpc1JldmFsaWRhdGlvblJlcXVpcmVkID0gZmFsc2U7XG4gIC8vIFVzZSB0aGlzIGludGVybmFsIGFycmF5IHRvIGNhcHR1cmUgcm91dGVzIHRoYXQgcmVxdWlyZSByZXZhbGlkYXRpb24gZHVlXG4gIC8vIHRvIGEgY2FuY2VsbGVkIGRlZmVycmVkIG9uIGFjdGlvbiBzdWJtaXNzaW9uXG4gIGxldCBjYW5jZWxsZWREZWZlcnJlZFJvdXRlcyA9IFtdO1xuICAvLyBVc2UgdGhpcyBpbnRlcm5hbCBhcnJheSB0byBjYXB0dXJlIGZldGNoZXIgbG9hZHMgdGhhdCB3ZXJlIGNhbmNlbGxlZCBieSBhblxuICAvLyBhY3Rpb24gbmF2aWdhdGlvbiBhbmQgcmVxdWlyZSByZXZhbGlkYXRpb25cbiAgbGV0IGNhbmNlbGxlZEZldGNoZXJMb2FkcyA9IG5ldyBTZXQoKTtcbiAgLy8gQWJvcnRDb250cm9sbGVycyBmb3IgYW55IGluLWZsaWdodCBmZXRjaGVyc1xuICBsZXQgZmV0Y2hDb250cm9sbGVycyA9IG5ldyBNYXAoKTtcbiAgLy8gVHJhY2sgbG9hZHMgYmFzZWQgb24gdGhlIG9yZGVyIGluIHdoaWNoIHRoZXkgc3RhcnRlZFxuICBsZXQgaW5jcmVtZW50aW5nTG9hZElkID0gMDtcbiAgLy8gVHJhY2sgdGhlIG91dHN0YW5kaW5nIHBlbmRpbmcgbmF2aWdhdGlvbiBkYXRhIGxvYWQgdG8gYmUgY29tcGFyZWQgYWdhaW5zdFxuICAvLyB0aGUgZ2xvYmFsbHkgaW5jcmVtZW50aW5nIGxvYWQgd2hlbiBhIGZldGNoZXIgbG9hZCBsYW5kcyBhZnRlciBhIGNvbXBsZXRlZFxuICAvLyBuYXZpZ2F0aW9uXG4gIGxldCBwZW5kaW5nTmF2aWdhdGlvbkxvYWRJZCA9IC0xO1xuICAvLyBGZXRjaGVycyB0aGF0IHRyaWdnZXJlZCBkYXRhIHJlbG9hZHMgYXMgYSByZXN1bHQgb2YgdGhlaXIgYWN0aW9uc1xuICBsZXQgZmV0Y2hSZWxvYWRJZHMgPSBuZXcgTWFwKCk7XG4gIC8vIEZldGNoZXJzIHRoYXQgdHJpZ2dlcmVkIHJlZGlyZWN0IG5hdmlnYXRpb25zXG4gIGxldCBmZXRjaFJlZGlyZWN0SWRzID0gbmV3IFNldCgpO1xuICAvLyBNb3N0IHJlY2VudCBocmVmL21hdGNoIGZvciBmZXRjaGVyLmxvYWQgY2FsbHMgZm9yIGZldGNoZXJzXG4gIGxldCBmZXRjaExvYWRNYXRjaGVzID0gbmV3IE1hcCgpO1xuICAvLyBSZWYtY291bnQgbW91bnRlZCBmZXRjaGVycyBzbyB3ZSBrbm93IHdoZW4gaXQncyBvayB0byBjbGVhbiB0aGVtIHVwXG4gIGxldCBhY3RpdmVGZXRjaGVycyA9IG5ldyBNYXAoKTtcbiAgLy8gRmV0Y2hlcnMgdGhhdCBoYXZlIHJlcXVlc3RlZCBhIGRlbGV0ZSB3aGVuIHVzaW5nIHY3X2ZldGNoZXJQZXJzaXN0LFxuICAvLyB0aGV5J2xsIGJlIG9mZmljaWFsbHkgcmVtb3ZlZCBhZnRlciB0aGV5IHJldHVybiB0byBpZGxlXG4gIGxldCBkZWxldGVkRmV0Y2hlcnMgPSBuZXcgU2V0KCk7XG4gIC8vIFN0b3JlIERlZmVycmVkRGF0YSBpbnN0YW5jZXMgZm9yIGFjdGl2ZSByb3V0ZSBtYXRjaGVzLiAgV2hlbiBhXG4gIC8vIHJvdXRlIGxvYWRlciByZXR1cm5zIGRlZmVyKCkgd2Ugc3RpY2sgb25lIGluIGhlcmUuICBUaGVuLCB3aGVuIGEgbmVzdGVkXG4gIC8vIHByb21pc2UgcmVzb2x2ZXMgd2UgdXBkYXRlIGxvYWRlckRhdGEuICBJZiBhIG5ldyBuYXZpZ2F0aW9uIHN0YXJ0cyB3ZVxuICAvLyBjYW5jZWwgYWN0aXZlIGRlZmVycmVkcyBmb3IgZWxpbWluYXRlZCByb3V0ZXMuXG4gIGxldCBhY3RpdmVEZWZlcnJlZHMgPSBuZXcgTWFwKCk7XG4gIC8vIFN0b3JlIGJsb2NrZXIgZnVuY3Rpb25zIGluIGEgc2VwYXJhdGUgTWFwIG91dHNpZGUgb2Ygcm91dGVyIHN0YXRlIHNpbmNlXG4gIC8vIHdlIGRvbid0IG5lZWQgdG8gdXBkYXRlIFVJIHN0YXRlIGlmIHRoZXkgY2hhbmdlXG4gIGxldCBibG9ja2VyRnVuY3Rpb25zID0gbmV3IE1hcCgpO1xuICAvLyBGbGFnIHRvIGlnbm9yZSB0aGUgbmV4dCBoaXN0b3J5IHVwZGF0ZSwgc28gd2UgY2FuIHJldmVydCB0aGUgVVJMIGNoYW5nZSBvblxuICAvLyBhIFBPUCBuYXZpZ2F0aW9uIHRoYXQgd2FzIGJsb2NrZWQgYnkgdGhlIHVzZXIgd2l0aG91dCB0b3VjaGluZyByb3V0ZXIgc3RhdGVcbiAgbGV0IHVuYmxvY2tCbG9ja2VySGlzdG9yeVVwZGF0ZSA9IHVuZGVmaW5lZDtcbiAgLy8gSW5pdGlhbGl6ZSB0aGUgcm91dGVyLCBhbGwgc2lkZSBlZmZlY3RzIHNob3VsZCBiZSBraWNrZWQgb2ZmIGZyb20gaGVyZS5cbiAgLy8gSW1wbGVtZW50ZWQgYXMgYSBGbHVlbnQgQVBJIGZvciBlYXNlIG9mOlxuICAvLyAgIGxldCByb3V0ZXIgPSBjcmVhdGVSb3V0ZXIoaW5pdCkuaW5pdGlhbGl6ZSgpO1xuICBmdW5jdGlvbiBpbml0aWFsaXplKCkge1xuICAgIC8vIElmIGhpc3RvcnkgaW5mb3JtcyB1cyBvZiBhIFBPUCBuYXZpZ2F0aW9uLCBzdGFydCB0aGUgbmF2aWdhdGlvbiBidXQgZG8gbm90IHVwZGF0ZVxuICAgIC8vIHN0YXRlLiAgV2UnbGwgdXBkYXRlIG91ciBvd24gc3RhdGUgb25jZSB0aGUgbmF2aWdhdGlvbiBjb21wbGV0ZXNcbiAgICB1bmxpc3Rlbkhpc3RvcnkgPSBpbml0Lmhpc3RvcnkubGlzdGVuKF9yZWYgPT4ge1xuICAgICAgbGV0IHtcbiAgICAgICAgYWN0aW9uOiBoaXN0b3J5QWN0aW9uLFxuICAgICAgICBsb2NhdGlvbixcbiAgICAgICAgZGVsdGFcbiAgICAgIH0gPSBfcmVmO1xuICAgICAgLy8gSWdub3JlIHRoaXMgZXZlbnQgaWYgaXQgd2FzIGp1c3QgdXMgcmVzZXR0aW5nIHRoZSBVUkwgZnJvbSBhXG4gICAgICAvLyBibG9ja2VkIFBPUCBuYXZpZ2F0aW9uXG4gICAgICBpZiAodW5ibG9ja0Jsb2NrZXJIaXN0b3J5VXBkYXRlKSB7XG4gICAgICAgIHVuYmxvY2tCbG9ja2VySGlzdG9yeVVwZGF0ZSgpO1xuICAgICAgICB1bmJsb2NrQmxvY2tlckhpc3RvcnlVcGRhdGUgPSB1bmRlZmluZWQ7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHdhcm5pbmcoYmxvY2tlckZ1bmN0aW9ucy5zaXplID09PSAwIHx8IGRlbHRhICE9IG51bGwsIFwiWW91IGFyZSB0cnlpbmcgdG8gdXNlIGEgYmxvY2tlciBvbiBhIFBPUCBuYXZpZ2F0aW9uIHRvIGEgbG9jYXRpb24gXCIgKyBcInRoYXQgd2FzIG5vdCBjcmVhdGVkIGJ5IEByZW1peC1ydW4vcm91dGVyLiBUaGlzIHdpbGwgZmFpbCBzaWxlbnRseSBpbiBcIiArIFwicHJvZHVjdGlvbi4gVGhpcyBjYW4gaGFwcGVuIGlmIHlvdSBhcmUgbmF2aWdhdGluZyBvdXRzaWRlIHRoZSByb3V0ZXIgXCIgKyBcInZpYSBgd2luZG93Lmhpc3RvcnkucHVzaFN0YXRlYC9gd2luZG93LmxvY2F0aW9uLmhhc2hgIGluc3RlYWQgb2YgdXNpbmcgXCIgKyBcInJvdXRlciBuYXZpZ2F0aW9uIEFQSXMuICBUaGlzIGNhbiBhbHNvIGhhcHBlbiBpZiB5b3UgYXJlIHVzaW5nIFwiICsgXCJjcmVhdGVIYXNoUm91dGVyIGFuZCB0aGUgdXNlciBtYW51YWxseSBjaGFuZ2VzIHRoZSBVUkwuXCIpO1xuICAgICAgbGV0IGJsb2NrZXJLZXkgPSBzaG91bGRCbG9ja05hdmlnYXRpb24oe1xuICAgICAgICBjdXJyZW50TG9jYXRpb246IHN0YXRlLmxvY2F0aW9uLFxuICAgICAgICBuZXh0TG9jYXRpb246IGxvY2F0aW9uLFxuICAgICAgICBoaXN0b3J5QWN0aW9uXG4gICAgICB9KTtcbiAgICAgIGlmIChibG9ja2VyS2V5ICYmIGRlbHRhICE9IG51bGwpIHtcbiAgICAgICAgLy8gUmVzdG9yZSB0aGUgVVJMIHRvIG1hdGNoIHRoZSBjdXJyZW50IFVJLCBidXQgZG9uJ3QgdXBkYXRlIHJvdXRlciBzdGF0ZVxuICAgICAgICBsZXQgbmV4dEhpc3RvcnlVcGRhdGVQcm9taXNlID0gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgICAgdW5ibG9ja0Jsb2NrZXJIaXN0b3J5VXBkYXRlID0gcmVzb2x2ZTtcbiAgICAgICAgfSk7XG4gICAgICAgIGluaXQuaGlzdG9yeS5nbyhkZWx0YSAqIC0xKTtcbiAgICAgICAgLy8gUHV0IHRoZSBibG9ja2VyIGludG8gYSBibG9ja2VkIHN0YXRlXG4gICAgICAgIHVwZGF0ZUJsb2NrZXIoYmxvY2tlcktleSwge1xuICAgICAgICAgIHN0YXRlOiBcImJsb2NrZWRcIixcbiAgICAgICAgICBsb2NhdGlvbixcbiAgICAgICAgICBwcm9jZWVkKCkge1xuICAgICAgICAgICAgdXBkYXRlQmxvY2tlcihibG9ja2VyS2V5LCB7XG4gICAgICAgICAgICAgIHN0YXRlOiBcInByb2NlZWRpbmdcIixcbiAgICAgICAgICAgICAgcHJvY2VlZDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICByZXNldDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBsb2NhdGlvblxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAvLyBSZS1kbyB0aGUgc2FtZSBQT1AgbmF2aWdhdGlvbiB3ZSBqdXN0IGJsb2NrZWQsIGFmdGVyIHRoZSB1cmxcbiAgICAgICAgICAgIC8vIHJlc3RvcmF0aW9uIGlzIGFsc28gY29tcGxldGUuICBTZWU6XG4gICAgICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vcmVtaXgtcnVuL3JlYWN0LXJvdXRlci9pc3N1ZXMvMTE2MTNcbiAgICAgICAgICAgIG5leHRIaXN0b3J5VXBkYXRlUHJvbWlzZS50aGVuKCgpID0+IGluaXQuaGlzdG9yeS5nbyhkZWx0YSkpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgcmVzZXQoKSB7XG4gICAgICAgICAgICBsZXQgYmxvY2tlcnMgPSBuZXcgTWFwKHN0YXRlLmJsb2NrZXJzKTtcbiAgICAgICAgICAgIGJsb2NrZXJzLnNldChibG9ja2VyS2V5LCBJRExFX0JMT0NLRVIpO1xuICAgICAgICAgICAgdXBkYXRlU3RhdGUoe1xuICAgICAgICAgICAgICBibG9ja2Vyc1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHN0YXJ0TmF2aWdhdGlvbihoaXN0b3J5QWN0aW9uLCBsb2NhdGlvbik7XG4gICAgfSk7XG4gICAgaWYgKGlzQnJvd3Nlcikge1xuICAgICAgLy8gRklYTUU6IFRoaXMgZmVlbHMgZ3Jvc3MuICBIb3cgY2FuIHdlIGNsZWFudXAgdGhlIGxpbmVzIGJldHdlZW5cbiAgICAgIC8vIHNjcm9sbFJlc3RvcmF0aW9uL2FwcGxpZWRUcmFuc2l0aW9ucyBwZXJzaXN0YW5jZT9cbiAgICAgIHJlc3RvcmVBcHBsaWVkVHJhbnNpdGlvbnMocm91dGVyV2luZG93LCBhcHBsaWVkVmlld1RyYW5zaXRpb25zKTtcbiAgICAgIGxldCBfc2F2ZUFwcGxpZWRUcmFuc2l0aW9ucyA9ICgpID0+IHBlcnNpc3RBcHBsaWVkVHJhbnNpdGlvbnMocm91dGVyV2luZG93LCBhcHBsaWVkVmlld1RyYW5zaXRpb25zKTtcbiAgICAgIHJvdXRlcldpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgX3NhdmVBcHBsaWVkVHJhbnNpdGlvbnMpO1xuICAgICAgcmVtb3ZlUGFnZUhpZGVFdmVudExpc3RlbmVyID0gKCkgPT4gcm91dGVyV2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwYWdlaGlkZVwiLCBfc2F2ZUFwcGxpZWRUcmFuc2l0aW9ucyk7XG4gICAgfVxuICAgIC8vIEtpY2sgb2ZmIGluaXRpYWwgZGF0YSBsb2FkIGlmIG5lZWRlZC4gIFVzZSBQb3AgdG8gYXZvaWQgbW9kaWZ5aW5nIGhpc3RvcnlcbiAgICAvLyBOb3RlIHdlIGRvbid0IGRvIGFueSBoYW5kbGluZyBvZiBsYXp5IGhlcmUuICBGb3IgU1BBJ3MgaXQnbGwgZ2V0IGhhbmRsZWRcbiAgICAvLyBpbiB0aGUgbm9ybWFsIG5hdmlnYXRpb24gZmxvdy4gIEZvciBTU1IgaXQncyBleHBlY3RlZCB0aGF0IGxhenkgbW9kdWxlcyBhcmVcbiAgICAvLyByZXNvbHZlZCBwcmlvciB0byByb3V0ZXIgY3JlYXRpb24gc2luY2Ugd2UgY2FuJ3QgZ28gaW50byBhIGZhbGxiYWNrRWxlbWVudFxuICAgIC8vIFVJIGZvciBTU1InZCBhcHBzXG4gICAgaWYgKCFzdGF0ZS5pbml0aWFsaXplZCkge1xuICAgICAgc3RhcnROYXZpZ2F0aW9uKEFjdGlvbi5Qb3AsIHN0YXRlLmxvY2F0aW9uLCB7XG4gICAgICAgIGluaXRpYWxIeWRyYXRpb246IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gcm91dGVyO1xuICB9XG4gIC8vIENsZWFuIHVwIGEgcm91dGVyIGFuZCBpdCdzIHNpZGUgZWZmZWN0c1xuICBmdW5jdGlvbiBkaXNwb3NlKCkge1xuICAgIGlmICh1bmxpc3Rlbkhpc3RvcnkpIHtcbiAgICAgIHVubGlzdGVuSGlzdG9yeSgpO1xuICAgIH1cbiAgICBpZiAocmVtb3ZlUGFnZUhpZGVFdmVudExpc3RlbmVyKSB7XG4gICAgICByZW1vdmVQYWdlSGlkZUV2ZW50TGlzdGVuZXIoKTtcbiAgICB9XG4gICAgc3Vic2NyaWJlcnMuY2xlYXIoKTtcbiAgICBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIgJiYgcGVuZGluZ05hdmlnYXRpb25Db250cm9sbGVyLmFib3J0KCk7XG4gICAgc3RhdGUuZmV0Y2hlcnMuZm9yRWFjaCgoXywga2V5KSA9PiBkZWxldGVGZXRjaGVyKGtleSkpO1xuICAgIHN0YXRlLmJsb2NrZXJzLmZvckVhY2goKF8sIGtleSkgPT4gZGVsZXRlQmxvY2tlcihrZXkpKTtcbiAgfVxuICAvLyBTdWJzY3JpYmUgdG8gc3RhdGUgdXBkYXRlcyBmb3IgdGhlIHJvdXRlclxuICBmdW5jdGlvbiBzdWJzY3JpYmUoZm4pIHtcbiAgICBzdWJzY3JpYmVycy5hZGQoZm4pO1xuICAgIHJldHVybiAoKSA9PiBzdWJzY3JpYmVycy5kZWxldGUoZm4pO1xuICB9XG4gIC8vIFVwZGF0ZSBvdXIgc3RhdGUgYW5kIG5vdGlmeSB0aGUgY2FsbGluZyBjb250ZXh0IG9mIHRoZSBjaGFuZ2VcbiAgZnVuY3Rpb24gdXBkYXRlU3RhdGUobmV3U3RhdGUsIG9wdHMpIHtcbiAgICBpZiAob3B0cyA9PT0gdm9pZCAwKSB7XG4gICAgICBvcHRzID0ge307XG4gICAgfVxuICAgIHN0YXRlID0gX2V4dGVuZHMoe30sIHN0YXRlLCBuZXdTdGF0ZSk7XG4gICAgLy8gUHJlcCBmZXRjaGVyIGNsZWFudXAgc28gd2UgY2FuIHRlbGwgdGhlIFVJIHdoaWNoIGZldGNoZXIgZGF0YSBlbnRyaWVzXG4gICAgLy8gY2FuIGJlIHJlbW92ZWRcbiAgICBsZXQgY29tcGxldGVkRmV0Y2hlcnMgPSBbXTtcbiAgICBsZXQgZGVsZXRlZEZldGNoZXJzS2V5cyA9IFtdO1xuICAgIGlmIChmdXR1cmUudjdfZmV0Y2hlclBlcnNpc3QpIHtcbiAgICAgIHN0YXRlLmZldGNoZXJzLmZvckVhY2goKGZldGNoZXIsIGtleSkgPT4ge1xuICAgICAgICBpZiAoZmV0Y2hlci5zdGF0ZSA9PT0gXCJpZGxlXCIpIHtcbiAgICAgICAgICBpZiAoZGVsZXRlZEZldGNoZXJzLmhhcyhrZXkpKSB7XG4gICAgICAgICAgICAvLyBVbm1vdW50ZWQgZnJvbSB0aGUgVUkgYW5kIGNhbiBiZSB0b3RhbGx5IHJlbW92ZWRcbiAgICAgICAgICAgIGRlbGV0ZWRGZXRjaGVyc0tleXMucHVzaChrZXkpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBSZXR1cm5lZCB0byBpZGxlIGJ1dCBzdGlsbCBtb3VudGVkIGluIHRoZSBVSSwgc28gc2VtaS1yZW1haW5zIGZvclxuICAgICAgICAgICAgLy8gcmV2YWxpZGF0aW9ucyBhbmQgc3VjaFxuICAgICAgICAgICAgY29tcGxldGVkRmV0Y2hlcnMucHVzaChrZXkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIFJlbW92ZSBhbnkgbGluZ2VyaW5nIGRlbGV0ZWQgZmV0Y2hlcnMgdGhhdCBoYXZlIGFscmVhZHkgYmVlbiByZW1vdmVkXG4gICAgLy8gZnJvbSBzdGF0ZS5mZXRjaGVyc1xuICAgIGRlbGV0ZWRGZXRjaGVycy5mb3JFYWNoKGtleSA9PiB7XG4gICAgICBpZiAoIXN0YXRlLmZldGNoZXJzLmhhcyhrZXkpICYmICFmZXRjaENvbnRyb2xsZXJzLmhhcyhrZXkpKSB7XG4gICAgICAgIGRlbGV0ZWRGZXRjaGVyc0tleXMucHVzaChrZXkpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIC8vIEl0ZXJhdGUgb3ZlciBhIGxvY2FsIGNvcHkgc28gdGhhdCBpZiBmbHVzaFN5bmMgaXMgdXNlZCBhbmQgd2UgZW5kIHVwXG4gICAgLy8gcmVtb3ZpbmcgYW5kIGFkZGluZyBhIG5ldyBzdWJzY3JpYmVyIGR1ZSB0byB0aGUgdXNlQ2FsbGJhY2sgZGVwZW5kZW5jaWVzLFxuICAgIC8vIHdlIGRvbid0IGdldCBvdXJzZWx2ZXMgaW50byBhIGxvb3AgY2FsbGluZyB0aGUgbmV3IHN1YnNjcmliZXIgaW1tZWRpYXRlbHlcbiAgICBbLi4uc3Vic2NyaWJlcnNdLmZvckVhY2goc3Vic2NyaWJlciA9PiBzdWJzY3JpYmVyKHN0YXRlLCB7XG4gICAgICBkZWxldGVkRmV0Y2hlcnM6IGRlbGV0ZWRGZXRjaGVyc0tleXMsXG4gICAgICB2aWV3VHJhbnNpdGlvbk9wdHM6IG9wdHMudmlld1RyYW5zaXRpb25PcHRzLFxuICAgICAgZmx1c2hTeW5jOiBvcHRzLmZsdXNoU3luYyA9PT0gdHJ1ZVxuICAgIH0pKTtcbiAgICAvLyBSZW1vdmUgaWRsZSBmZXRjaGVycyBmcm9tIHN0YXRlIHNpbmNlIHdlIG9ubHkgY2FyZSBhYm91dCBpbi1mbGlnaHQgZmV0Y2hlcnMuXG4gICAgaWYgKGZ1dHVyZS52N19mZXRjaGVyUGVyc2lzdCkge1xuICAgICAgY29tcGxldGVkRmV0Y2hlcnMuZm9yRWFjaChrZXkgPT4gc3RhdGUuZmV0Y2hlcnMuZGVsZXRlKGtleSkpO1xuICAgICAgZGVsZXRlZEZldGNoZXJzS2V5cy5mb3JFYWNoKGtleSA9PiBkZWxldGVGZXRjaGVyKGtleSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBXZSBhbHJlYWR5IGNhbGxlZCBkZWxldGVGZXRjaGVyKCkgb24gdGhlc2UsIGNhbiByZW1vdmUgdGhlbSBmcm9tIHRoaXNcbiAgICAgIC8vIFNldCBub3cgdGhhdCB3ZSd2ZSBoYW5kZWQgdGhlIGtleXMgb2ZmIHRvIHRoZSBkYXRhIGxheWVyXG4gICAgICBkZWxldGVkRmV0Y2hlcnNLZXlzLmZvckVhY2goa2V5ID0+IGRlbGV0ZWRGZXRjaGVycy5kZWxldGUoa2V5KSk7XG4gICAgfVxuICB9XG4gIC8vIENvbXBsZXRlIGEgbmF2aWdhdGlvbiByZXR1cm5pbmcgdGhlIHN0YXRlLm5hdmlnYXRpb24gYmFjayB0byB0aGUgSURMRV9OQVZJR0FUSU9OXG4gIC8vIGFuZCBzZXR0aW5nIHN0YXRlLltoaXN0b3J5QWN0aW9uL2xvY2F0aW9uL21hdGNoZXNdIHRvIHRoZSBuZXcgcm91dGUuXG4gIC8vIC0gTG9jYXRpb24gaXMgYSByZXF1aXJlZCBwYXJhbVxuICAvLyAtIE5hdmlnYXRpb24gd2lsbCBhbHdheXMgYmUgc2V0IHRvIElETEVfTkFWSUdBVElPTlxuICAvLyAtIENhbiBwYXNzIGFueSBvdGhlciBzdGF0ZSBpbiBuZXdTdGF0ZVxuICBmdW5jdGlvbiBjb21wbGV0ZU5hdmlnYXRpb24obG9jYXRpb24sIG5ld1N0YXRlLCBfdGVtcCkge1xuICAgIHZhciBfbG9jYXRpb24kc3RhdGUsIF9sb2NhdGlvbiRzdGF0ZTI7XG4gICAgbGV0IHtcbiAgICAgIGZsdXNoU3luY1xuICAgIH0gPSBfdGVtcCA9PT0gdm9pZCAwID8ge30gOiBfdGVtcDtcbiAgICAvLyBEZWR1Y2UgaWYgd2UncmUgaW4gYSBsb2FkaW5nL2FjdGlvblJlbG9hZCBzdGF0ZTpcbiAgICAvLyAtIFdlIGhhdmUgY29tbWl0dGVkIGFjdGlvbkRhdGEgaW4gdGhlIHN0b3JlXG4gICAgLy8gLSBUaGUgY3VycmVudCBuYXZpZ2F0aW9uIHdhcyBhIG11dGF0aW9uIHN1Ym1pc3Npb25cbiAgICAvLyAtIFdlJ3JlIHBhc3QgdGhlIHN1Ym1pdHRpbmcgc3RhdGUgYW5kIGludG8gdGhlIGxvYWRpbmcgc3RhdGVcbiAgICAvLyAtIFRoZSBsb2NhdGlvbiBiZWluZyBsb2FkZWQgaXMgbm90IHRoZSByZXN1bHQgb2YgYSByZWRpcmVjdFxuICAgIGxldCBpc0FjdGlvblJlbG9hZCA9IHN0YXRlLmFjdGlvbkRhdGEgIT0gbnVsbCAmJiBzdGF0ZS5uYXZpZ2F0aW9uLmZvcm1NZXRob2QgIT0gbnVsbCAmJiBpc011dGF0aW9uTWV0aG9kKHN0YXRlLm5hdmlnYXRpb24uZm9ybU1ldGhvZCkgJiYgc3RhdGUubmF2aWdhdGlvbi5zdGF0ZSA9PT0gXCJsb2FkaW5nXCIgJiYgKChfbG9jYXRpb24kc3RhdGUgPSBsb2NhdGlvbi5zdGF0ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9sb2NhdGlvbiRzdGF0ZS5faXNSZWRpcmVjdCkgIT09IHRydWU7XG4gICAgbGV0IGFjdGlvbkRhdGE7XG4gICAgaWYgKG5ld1N0YXRlLmFjdGlvbkRhdGEpIHtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhuZXdTdGF0ZS5hY3Rpb25EYXRhKS5sZW5ndGggPiAwKSB7XG4gICAgICAgIGFjdGlvbkRhdGEgPSBuZXdTdGF0ZS5hY3Rpb25EYXRhO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gRW1wdHkgYWN0aW9uRGF0YSAtPiBjbGVhciBwcmlvciBhY3Rpb25EYXRhIGR1ZSB0byBhbiBhY3Rpb24gZXJyb3JcbiAgICAgICAgYWN0aW9uRGF0YSA9IG51bGw7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChpc0FjdGlvblJlbG9hZCkge1xuICAgICAgLy8gS2VlcCB0aGUgY3VycmVudCBkYXRhIGlmIHdlJ3JlIHdyYXBwaW5nIHVwIHRoZSBhY3Rpb24gcmVsb2FkXG4gICAgICBhY3Rpb25EYXRhID0gc3RhdGUuYWN0aW9uRGF0YTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQ2xlYXIgYWN0aW9uRGF0YSBvbiBhbnkgb3RoZXIgY29tcGxldGVkIG5hdmlnYXRpb25zXG4gICAgICBhY3Rpb25EYXRhID0gbnVsbDtcbiAgICB9XG4gICAgLy8gQWx3YXlzIHByZXNlcnZlIGFueSBleGlzdGluZyBsb2FkZXJEYXRhIGZyb20gcmUtdXNlZCByb3V0ZXNcbiAgICBsZXQgbG9hZGVyRGF0YSA9IG5ld1N0YXRlLmxvYWRlckRhdGEgPyBtZXJnZUxvYWRlckRhdGEoc3RhdGUubG9hZGVyRGF0YSwgbmV3U3RhdGUubG9hZGVyRGF0YSwgbmV3U3RhdGUubWF0Y2hlcyB8fCBbXSwgbmV3U3RhdGUuZXJyb3JzKSA6IHN0YXRlLmxvYWRlckRhdGE7XG4gICAgLy8gT24gYSBzdWNjZXNzZnVsIG5hdmlnYXRpb24gd2UgY2FuIGFzc3VtZSB3ZSBnb3QgdGhyb3VnaCBhbGwgYmxvY2tlcnNcbiAgICAvLyBzbyB3ZSBjYW4gc3RhcnQgZnJlc2hcbiAgICBsZXQgYmxvY2tlcnMgPSBzdGF0ZS5ibG9ja2VycztcbiAgICBpZiAoYmxvY2tlcnMuc2l6ZSA+IDApIHtcbiAgICAgIGJsb2NrZXJzID0gbmV3IE1hcChibG9ja2Vycyk7XG4gICAgICBibG9ja2Vycy5mb3JFYWNoKChfLCBrKSA9PiBibG9ja2Vycy5zZXQoaywgSURMRV9CTE9DS0VSKSk7XG4gICAgfVxuICAgIC8vIEFsd2F5cyByZXNwZWN0IHRoZSB1c2VyIGZsYWcuICBPdGhlcndpc2UgZG9uJ3QgcmVzZXQgb24gbXV0YXRpb25cbiAgICAvLyBzdWJtaXNzaW9uIG5hdmlnYXRpb25zIHVubGVzcyB0aGV5IHJlZGlyZWN0XG4gICAgbGV0IHByZXZlbnRTY3JvbGxSZXNldCA9IHBlbmRpbmdQcmV2ZW50U2Nyb2xsUmVzZXQgPT09IHRydWUgfHwgc3RhdGUubmF2aWdhdGlvbi5mb3JtTWV0aG9kICE9IG51bGwgJiYgaXNNdXRhdGlvbk1ldGhvZChzdGF0ZS5uYXZpZ2F0aW9uLmZvcm1NZXRob2QpICYmICgoX2xvY2F0aW9uJHN0YXRlMiA9IGxvY2F0aW9uLnN0YXRlKSA9PSBudWxsID8gdm9pZCAwIDogX2xvY2F0aW9uJHN0YXRlMi5faXNSZWRpcmVjdCkgIT09IHRydWU7XG4gICAgLy8gQ29tbWl0IGFueSBpbi1mbGlnaHQgcm91dGVzIGF0IHRoZSBlbmQgb2YgdGhlIEhNUiByZXZhbGlkYXRpb24gXCJuYXZpZ2F0aW9uXCJcbiAgICBpZiAoaW5GbGlnaHREYXRhUm91dGVzKSB7XG4gICAgICBkYXRhUm91dGVzID0gaW5GbGlnaHREYXRhUm91dGVzO1xuICAgICAgaW5GbGlnaHREYXRhUm91dGVzID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoaXNVbmludGVycnVwdGVkUmV2YWxpZGF0aW9uKSA7IGVsc2UgaWYgKHBlbmRpbmdBY3Rpb24gPT09IEFjdGlvbi5Qb3ApIDsgZWxzZSBpZiAocGVuZGluZ0FjdGlvbiA9PT0gQWN0aW9uLlB1c2gpIHtcbiAgICAgIGluaXQuaGlzdG9yeS5wdXNoKGxvY2F0aW9uLCBsb2NhdGlvbi5zdGF0ZSk7XG4gICAgfSBlbHNlIGlmIChwZW5kaW5nQWN0aW9uID09PSBBY3Rpb24uUmVwbGFjZSkge1xuICAgICAgaW5pdC5oaXN0b3J5LnJlcGxhY2UobG9jYXRpb24sIGxvY2F0aW9uLnN0YXRlKTtcbiAgICB9XG4gICAgbGV0IHZpZXdUcmFuc2l0aW9uT3B0cztcbiAgICAvLyBPbiBQT1AsIGVuYWJsZSB0cmFuc2l0aW9ucyBpZiB0aGV5IHdlcmUgZW5hYmxlZCBvbiB0aGUgb3JpZ2luYWwgbmF2aWdhdGlvblxuICAgIGlmIChwZW5kaW5nQWN0aW9uID09PSBBY3Rpb24uUG9wKSB7XG4gICAgICAvLyBGb3J3YXJkIHRha2VzIHByZWNlZGVuY2Ugc28gdGhleSBiZWhhdmUgbGlrZSB0aGUgb3JpZ2luYWwgbmF2aWdhdGlvblxuICAgICAgbGV0IHByaW9yUGF0aHMgPSBhcHBsaWVkVmlld1RyYW5zaXRpb25zLmdldChzdGF0ZS5sb2NhdGlvbi5wYXRobmFtZSk7XG4gICAgICBpZiAocHJpb3JQYXRocyAmJiBwcmlvclBhdGhzLmhhcyhsb2NhdGlvbi5wYXRobmFtZSkpIHtcbiAgICAgICAgdmlld1RyYW5zaXRpb25PcHRzID0ge1xuICAgICAgICAgIGN1cnJlbnRMb2NhdGlvbjogc3RhdGUubG9jYXRpb24sXG4gICAgICAgICAgbmV4dExvY2F0aW9uOiBsb2NhdGlvblxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIGlmIChhcHBsaWVkVmlld1RyYW5zaXRpb25zLmhhcyhsb2NhdGlvbi5wYXRobmFtZSkpIHtcbiAgICAgICAgLy8gSWYgd2UgZG9uJ3QgaGF2ZSBhIHByZXZpb3VzIGZvcndhcmQgbmF2LCBhc3N1bWUgd2UncmUgcG9wcGluZyBiYWNrIHRvXG4gICAgICAgIC8vIHRoZSBuZXcgbG9jYXRpb24gYW5kIGVuYWJsZSBpZiB0aGF0IGxvY2F0aW9uIHByZXZpb3VzbHkgZW5hYmxlZFxuICAgICAgICB2aWV3VHJhbnNpdGlvbk9wdHMgPSB7XG4gICAgICAgICAgY3VycmVudExvY2F0aW9uOiBsb2NhdGlvbixcbiAgICAgICAgICBuZXh0TG9jYXRpb246IHN0YXRlLmxvY2F0aW9uXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChwZW5kaW5nVmlld1RyYW5zaXRpb25FbmFibGVkKSB7XG4gICAgICAvLyBTdG9yZSB0aGUgYXBwbGllZCB0cmFuc2l0aW9uIG9uIFBVU0gvUkVQTEFDRVxuICAgICAgbGV0IHRvUGF0aHMgPSBhcHBsaWVkVmlld1RyYW5zaXRpb25zLmdldChzdGF0ZS5sb2NhdGlvbi5wYXRobmFtZSk7XG4gICAgICBpZiAodG9QYXRocykge1xuICAgICAgICB0b1BhdGhzLmFkZChsb2NhdGlvbi5wYXRobmFtZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0b1BhdGhzID0gbmV3IFNldChbbG9jYXRpb24ucGF0aG5hbWVdKTtcbiAgICAgICAgYXBwbGllZFZpZXdUcmFuc2l0aW9ucy5zZXQoc3RhdGUubG9jYXRpb24ucGF0aG5hbWUsIHRvUGF0aHMpO1xuICAgICAgfVxuICAgICAgdmlld1RyYW5zaXRpb25PcHRzID0ge1xuICAgICAgICBjdXJyZW50TG9jYXRpb246IHN0YXRlLmxvY2F0aW9uLFxuICAgICAgICBuZXh0TG9jYXRpb246IGxvY2F0aW9uXG4gICAgICB9O1xuICAgIH1cbiAgICB1cGRhdGVTdGF0ZShfZXh0ZW5kcyh7fSwgbmV3U3RhdGUsIHtcbiAgICAgIGFjdGlvbkRhdGEsXG4gICAgICBsb2FkZXJEYXRhLFxuICAgICAgaGlzdG9yeUFjdGlvbjogcGVuZGluZ0FjdGlvbixcbiAgICAgIGxvY2F0aW9uLFxuICAgICAgaW5pdGlhbGl6ZWQ6IHRydWUsXG4gICAgICBuYXZpZ2F0aW9uOiBJRExFX05BVklHQVRJT04sXG4gICAgICByZXZhbGlkYXRpb246IFwiaWRsZVwiLFxuICAgICAgcmVzdG9yZVNjcm9sbFBvc2l0aW9uOiBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uKGxvY2F0aW9uLCBuZXdTdGF0ZS5tYXRjaGVzIHx8IHN0YXRlLm1hdGNoZXMpLFxuICAgICAgcHJldmVudFNjcm9sbFJlc2V0LFxuICAgICAgYmxvY2tlcnNcbiAgICB9KSwge1xuICAgICAgdmlld1RyYW5zaXRpb25PcHRzLFxuICAgICAgZmx1c2hTeW5jOiBmbHVzaFN5bmMgPT09IHRydWVcbiAgICB9KTtcbiAgICAvLyBSZXNldCBzdGF0ZWZ1bCBuYXZpZ2F0aW9uIHZhcnNcbiAgICBwZW5kaW5nQWN0aW9uID0gQWN0aW9uLlBvcDtcbiAgICBwZW5kaW5nUHJldmVudFNjcm9sbFJlc2V0ID0gZmFsc2U7XG4gICAgcGVuZGluZ1ZpZXdUcmFuc2l0aW9uRW5hYmxlZCA9IGZhbHNlO1xuICAgIGlzVW5pbnRlcnJ1cHRlZFJldmFsaWRhdGlvbiA9IGZhbHNlO1xuICAgIGlzUmV2YWxpZGF0aW9uUmVxdWlyZWQgPSBmYWxzZTtcbiAgICBjYW5jZWxsZWREZWZlcnJlZFJvdXRlcyA9IFtdO1xuICB9XG4gIC8vIFRyaWdnZXIgYSBuYXZpZ2F0aW9uIGV2ZW50LCB3aGljaCBjYW4gZWl0aGVyIGJlIGEgbnVtZXJpY2FsIFBPUCBvciBhIFBVU0hcbiAgLy8gcmVwbGFjZSB3aXRoIGFuIG9wdGlvbmFsIHN1Ym1pc3Npb25cbiAgYXN5bmMgZnVuY3Rpb24gbmF2aWdhdGUodG8sIG9wdHMpIHtcbiAgICBpZiAodHlwZW9mIHRvID09PSBcIm51bWJlclwiKSB7XG4gICAgICBpbml0Lmhpc3RvcnkuZ28odG8pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgbm9ybWFsaXplZFBhdGggPSBub3JtYWxpemVUbyhzdGF0ZS5sb2NhdGlvbiwgc3RhdGUubWF0Y2hlcywgYmFzZW5hbWUsIGZ1dHVyZS52N19wcmVwZW5kQmFzZW5hbWUsIHRvLCBmdXR1cmUudjdfcmVsYXRpdmVTcGxhdFBhdGgsIG9wdHMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdHMuZnJvbVJvdXRlSWQsIG9wdHMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdHMucmVsYXRpdmUpO1xuICAgIGxldCB7XG4gICAgICBwYXRoLFxuICAgICAgc3VibWlzc2lvbixcbiAgICAgIGVycm9yXG4gICAgfSA9IG5vcm1hbGl6ZU5hdmlnYXRlT3B0aW9ucyhmdXR1cmUudjdfbm9ybWFsaXplRm9ybU1ldGhvZCwgZmFsc2UsIG5vcm1hbGl6ZWRQYXRoLCBvcHRzKTtcbiAgICBsZXQgY3VycmVudExvY2F0aW9uID0gc3RhdGUubG9jYXRpb247XG4gICAgbGV0IG5leHRMb2NhdGlvbiA9IGNyZWF0ZUxvY2F0aW9uKHN0YXRlLmxvY2F0aW9uLCBwYXRoLCBvcHRzICYmIG9wdHMuc3RhdGUpO1xuICAgIC8vIFdoZW4gdXNpbmcgbmF2aWdhdGUgYXMgYSBQVVNIL1JFUExBQ0Ugd2UgYXJlbid0IHJlYWRpbmcgYW4gYWxyZWFkeS1lbmNvZGVkXG4gICAgLy8gVVJMIGZyb20gd2luZG93LmxvY2F0aW9uLCBzbyB3ZSBuZWVkIHRvIGVuY29kZSBpdCBoZXJlIHNvIHRoZSBiZWhhdmlvclxuICAgIC8vIHJlbWFpbnMgdGhlIHNhbWUgYXMgUE9QIGFuZCBub24tZGF0YS1yb3V0ZXIgdXNhZ2VzLiAgbmV3IFVSTCgpIGRvZXMgYWxsXG4gICAgLy8gdGhlIHNhbWUgZW5jb2Rpbmcgd2UnZCBnZXQgZnJvbSBhIGhpc3RvcnkucHVzaFN0YXRlL3dpbmRvdy5sb2NhdGlvbiByZWFkXG4gICAgLy8gd2l0aG91dCBoYXZpbmcgdG8gdG91Y2ggaGlzdG9yeVxuICAgIG5leHRMb2NhdGlvbiA9IF9leHRlbmRzKHt9LCBuZXh0TG9jYXRpb24sIGluaXQuaGlzdG9yeS5lbmNvZGVMb2NhdGlvbihuZXh0TG9jYXRpb24pKTtcbiAgICBsZXQgdXNlclJlcGxhY2UgPSBvcHRzICYmIG9wdHMucmVwbGFjZSAhPSBudWxsID8gb3B0cy5yZXBsYWNlIDogdW5kZWZpbmVkO1xuICAgIGxldCBoaXN0b3J5QWN0aW9uID0gQWN0aW9uLlB1c2g7XG4gICAgaWYgKHVzZXJSZXBsYWNlID09PSB0cnVlKSB7XG4gICAgICBoaXN0b3J5QWN0aW9uID0gQWN0aW9uLlJlcGxhY2U7XG4gICAgfSBlbHNlIGlmICh1c2VyUmVwbGFjZSA9PT0gZmFsc2UpIDsgZWxzZSBpZiAoc3VibWlzc2lvbiAhPSBudWxsICYmIGlzTXV0YXRpb25NZXRob2Qoc3VibWlzc2lvbi5mb3JtTWV0aG9kKSAmJiBzdWJtaXNzaW9uLmZvcm1BY3Rpb24gPT09IHN0YXRlLmxvY2F0aW9uLnBhdGhuYW1lICsgc3RhdGUubG9jYXRpb24uc2VhcmNoKSB7XG4gICAgICAvLyBCeSBkZWZhdWx0IG9uIHN1Ym1pc3Npb25zIHRvIHRoZSBjdXJyZW50IGxvY2F0aW9uIHdlIFJFUExBQ0Ugc28gdGhhdFxuICAgICAgLy8gdXNlcnMgZG9uJ3QgaGF2ZSB0byBkb3VibGUtY2xpY2sgdGhlIGJhY2sgYnV0dG9uIHRvIGdldCB0byB0aGUgcHJpb3JcbiAgICAgIC8vIGxvY2F0aW9uLiAgSWYgdGhlIHVzZXIgcmVkaXJlY3RzIHRvIGEgZGlmZmVyZW50IGxvY2F0aW9uIGZyb20gdGhlXG4gICAgICAvLyBhY3Rpb24vbG9hZGVyIHRoaXMgd2lsbCBiZSBpZ25vcmVkIGFuZCB0aGUgcmVkaXJlY3Qgd2lsbCBiZSBhIFBVU0hcbiAgICAgIGhpc3RvcnlBY3Rpb24gPSBBY3Rpb24uUmVwbGFjZTtcbiAgICB9XG4gICAgbGV0IHByZXZlbnRTY3JvbGxSZXNldCA9IG9wdHMgJiYgXCJwcmV2ZW50U2Nyb2xsUmVzZXRcIiBpbiBvcHRzID8gb3B0cy5wcmV2ZW50U2Nyb2xsUmVzZXQgPT09IHRydWUgOiB1bmRlZmluZWQ7XG4gICAgbGV0IGZsdXNoU3luYyA9IChvcHRzICYmIG9wdHMuZmx1c2hTeW5jKSA9PT0gdHJ1ZTtcbiAgICBsZXQgYmxvY2tlcktleSA9IHNob3VsZEJsb2NrTmF2aWdhdGlvbih7XG4gICAgICBjdXJyZW50TG9jYXRpb24sXG4gICAgICBuZXh0TG9jYXRpb24sXG4gICAgICBoaXN0b3J5QWN0aW9uXG4gICAgfSk7XG4gICAgaWYgKGJsb2NrZXJLZXkpIHtcbiAgICAgIC8vIFB1dCB0aGUgYmxvY2tlciBpbnRvIGEgYmxvY2tlZCBzdGF0ZVxuICAgICAgdXBkYXRlQmxvY2tlcihibG9ja2VyS2V5LCB7XG4gICAgICAgIHN0YXRlOiBcImJsb2NrZWRcIixcbiAgICAgICAgbG9jYXRpb246IG5leHRMb2NhdGlvbixcbiAgICAgICAgcHJvY2VlZCgpIHtcbiAgICAgICAgICB1cGRhdGVCbG9ja2VyKGJsb2NrZXJLZXksIHtcbiAgICAgICAgICAgIHN0YXRlOiBcInByb2NlZWRpbmdcIixcbiAgICAgICAgICAgIHByb2NlZWQ6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIHJlc2V0OiB1bmRlZmluZWQsXG4gICAgICAgICAgICBsb2NhdGlvbjogbmV4dExvY2F0aW9uXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgLy8gU2VuZCB0aGUgc2FtZSBuYXZpZ2F0aW9uIHRocm91Z2hcbiAgICAgICAgICBuYXZpZ2F0ZSh0bywgb3B0cyk7XG4gICAgICAgIH0sXG4gICAgICAgIHJlc2V0KCkge1xuICAgICAgICAgIGxldCBibG9ja2VycyA9IG5ldyBNYXAoc3RhdGUuYmxvY2tlcnMpO1xuICAgICAgICAgIGJsb2NrZXJzLnNldChibG9ja2VyS2V5LCBJRExFX0JMT0NLRVIpO1xuICAgICAgICAgIHVwZGF0ZVN0YXRlKHtcbiAgICAgICAgICAgIGJsb2NrZXJzXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gYXdhaXQgc3RhcnROYXZpZ2F0aW9uKGhpc3RvcnlBY3Rpb24sIG5leHRMb2NhdGlvbiwge1xuICAgICAgc3VibWlzc2lvbixcbiAgICAgIC8vIFNlbmQgdGhyb3VnaCB0aGUgZm9ybURhdGEgc2VyaWFsaXphdGlvbiBlcnJvciBpZiB3ZSBoYXZlIG9uZSBzbyB3ZSBjYW5cbiAgICAgIC8vIHJlbmRlciBhdCB0aGUgcmlnaHQgZXJyb3IgYm91bmRhcnkgYWZ0ZXIgd2UgbWF0Y2ggcm91dGVzXG4gICAgICBwZW5kaW5nRXJyb3I6IGVycm9yLFxuICAgICAgcHJldmVudFNjcm9sbFJlc2V0LFxuICAgICAgcmVwbGFjZTogb3B0cyAmJiBvcHRzLnJlcGxhY2UsXG4gICAgICBlbmFibGVWaWV3VHJhbnNpdGlvbjogb3B0cyAmJiBvcHRzLnZpZXdUcmFuc2l0aW9uLFxuICAgICAgZmx1c2hTeW5jXG4gICAgfSk7XG4gIH1cbiAgLy8gUmV2YWxpZGF0ZSBhbGwgY3VycmVudCBsb2FkZXJzLiAgSWYgYSBuYXZpZ2F0aW9uIGlzIGluIHByb2dyZXNzIG9yIGlmIHRoaXNcbiAgLy8gaXMgaW50ZXJydXB0ZWQgYnkgYSBuYXZpZ2F0aW9uLCBhbGxvdyB0aGlzIHRvIFwic3VjY2VlZFwiIGJ5IGNhbGxpbmcgYWxsXG4gIC8vIGxvYWRlcnMgZHVyaW5nIHRoZSBuZXh0IGxvYWRlciByb3VuZFxuICBmdW5jdGlvbiByZXZhbGlkYXRlKCkge1xuICAgIGludGVycnVwdEFjdGl2ZUxvYWRzKCk7XG4gICAgdXBkYXRlU3RhdGUoe1xuICAgICAgcmV2YWxpZGF0aW9uOiBcImxvYWRpbmdcIlxuICAgIH0pO1xuICAgIC8vIElmIHdlJ3JlIGN1cnJlbnRseSBzdWJtaXR0aW5nIGFuIGFjdGlvbiwgd2UgZG9uJ3QgbmVlZCB0byBzdGFydCBhIG5ld1xuICAgIC8vIG5hdmlnYXRpb24sIHdlJ2xsIGp1c3QgbGV0IHRoZSBmb2xsb3cgdXAgbG9hZGVyIGV4ZWN1dGlvbiBjYWxsIGFsbCBsb2FkZXJzXG4gICAgaWYgKHN0YXRlLm5hdmlnYXRpb24uc3RhdGUgPT09IFwic3VibWl0dGluZ1wiKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIElmIHdlJ3JlIGN1cnJlbnRseSBpbiBhbiBpZGxlIHN0YXRlLCBzdGFydCBhIG5ldyBuYXZpZ2F0aW9uIGZvciB0aGUgY3VycmVudFxuICAgIC8vIGFjdGlvbi9sb2NhdGlvbiBhbmQgbWFyayBpdCBhcyB1bmludGVycnVwdGVkLCB3aGljaCB3aWxsIHNraXAgdGhlIGhpc3RvcnlcbiAgICAvLyB1cGRhdGUgaW4gY29tcGxldGVOYXZpZ2F0aW9uXG4gICAgaWYgKHN0YXRlLm5hdmlnYXRpb24uc3RhdGUgPT09IFwiaWRsZVwiKSB7XG4gICAgICBzdGFydE5hdmlnYXRpb24oc3RhdGUuaGlzdG9yeUFjdGlvbiwgc3RhdGUubG9jYXRpb24sIHtcbiAgICAgICAgc3RhcnRVbmludGVycnVwdGVkUmV2YWxpZGF0aW9uOiB0cnVlXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gT3RoZXJ3aXNlLCBpZiB3ZSdyZSBjdXJyZW50bHkgaW4gYSBsb2FkaW5nIHN0YXRlLCBqdXN0IHN0YXJ0IGEgbmV3XG4gICAgLy8gbmF2aWdhdGlvbiB0byB0aGUgbmF2aWdhdGlvbi5sb2NhdGlvbiBidXQgZG8gbm90IHRyaWdnZXIgYW4gdW5pbnRlcnJ1cHRlZFxuICAgIC8vIHJldmFsaWRhdGlvbiBzbyB0aGF0IGhpc3RvcnkgY29ycmVjdGx5IHVwZGF0ZXMgb25jZSB0aGUgbmF2aWdhdGlvbiBjb21wbGV0ZXNcbiAgICBzdGFydE5hdmlnYXRpb24ocGVuZGluZ0FjdGlvbiB8fCBzdGF0ZS5oaXN0b3J5QWN0aW9uLCBzdGF0ZS5uYXZpZ2F0aW9uLmxvY2F0aW9uLCB7XG4gICAgICBvdmVycmlkZU5hdmlnYXRpb246IHN0YXRlLm5hdmlnYXRpb24sXG4gICAgICAvLyBQcm94eSB0aHJvdWdoIGFueSByZW5kaW5nIHZpZXcgdHJhbnNpdGlvblxuICAgICAgZW5hYmxlVmlld1RyYW5zaXRpb246IHBlbmRpbmdWaWV3VHJhbnNpdGlvbkVuYWJsZWQgPT09IHRydWVcbiAgICB9KTtcbiAgfVxuICAvLyBTdGFydCBhIG5hdmlnYXRpb24gdG8gdGhlIGdpdmVuIGFjdGlvbi9sb2NhdGlvbi4gIENhbiBvcHRpb25hbGx5IHByb3ZpZGUgYVxuICAvLyBvdmVycmlkZU5hdmlnYXRpb24gd2hpY2ggd2lsbCBvdmVycmlkZSB0aGUgbm9ybWFsTG9hZCBpbiB0aGUgY2FzZSBvZiBhIHJlZGlyZWN0XG4gIC8vIG5hdmlnYXRpb25cbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnROYXZpZ2F0aW9uKGhpc3RvcnlBY3Rpb24sIGxvY2F0aW9uLCBvcHRzKSB7XG4gICAgLy8gQWJvcnQgYW55IGluLXByb2dyZXNzIG5hdmlnYXRpb25zIGFuZCBzdGFydCBhIG5ldyBvbmUuIFVuc2V0IGFueSBvbmdvaW5nXG4gICAgLy8gdW5pbnRlcnJ1cHRlZCByZXZhbGlkYXRpb25zIHVubGVzcyB0b2xkIG90aGVyd2lzZSwgc2luY2Ugd2Ugd2FudCB0aGlzXG4gICAgLy8gbmV3IG5hdmlnYXRpb24gdG8gdXBkYXRlIGhpc3Rvcnkgbm9ybWFsbHlcbiAgICBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIgJiYgcGVuZGluZ05hdmlnYXRpb25Db250cm9sbGVyLmFib3J0KCk7XG4gICAgcGVuZGluZ05hdmlnYXRpb25Db250cm9sbGVyID0gbnVsbDtcbiAgICBwZW5kaW5nQWN0aW9uID0gaGlzdG9yeUFjdGlvbjtcbiAgICBpc1VuaW50ZXJydXB0ZWRSZXZhbGlkYXRpb24gPSAob3B0cyAmJiBvcHRzLnN0YXJ0VW5pbnRlcnJ1cHRlZFJldmFsaWRhdGlvbikgPT09IHRydWU7XG4gICAgLy8gU2F2ZSB0aGUgY3VycmVudCBzY3JvbGwgcG9zaXRpb24gZXZlcnkgdGltZSB3ZSBzdGFydCBhIG5ldyBuYXZpZ2F0aW9uLFxuICAgIC8vIGFuZCB0cmFjayB3aGV0aGVyIHdlIHNob3VsZCByZXNldCBzY3JvbGwgb24gY29tcGxldGlvblxuICAgIHNhdmVTY3JvbGxQb3NpdGlvbihzdGF0ZS5sb2NhdGlvbiwgc3RhdGUubWF0Y2hlcyk7XG4gICAgcGVuZGluZ1ByZXZlbnRTY3JvbGxSZXNldCA9IChvcHRzICYmIG9wdHMucHJldmVudFNjcm9sbFJlc2V0KSA9PT0gdHJ1ZTtcbiAgICBwZW5kaW5nVmlld1RyYW5zaXRpb25FbmFibGVkID0gKG9wdHMgJiYgb3B0cy5lbmFibGVWaWV3VHJhbnNpdGlvbikgPT09IHRydWU7XG4gICAgbGV0IHJvdXRlc1RvVXNlID0gaW5GbGlnaHREYXRhUm91dGVzIHx8IGRhdGFSb3V0ZXM7XG4gICAgbGV0IGxvYWRpbmdOYXZpZ2F0aW9uID0gb3B0cyAmJiBvcHRzLm92ZXJyaWRlTmF2aWdhdGlvbjtcbiAgICBsZXQgbWF0Y2hlcyA9IG9wdHMgIT0gbnVsbCAmJiBvcHRzLmluaXRpYWxIeWRyYXRpb24gJiYgc3RhdGUubWF0Y2hlcyAmJiBzdGF0ZS5tYXRjaGVzLmxlbmd0aCA+IDAgJiYgIWluaXRpYWxNYXRjaGVzSXNGT1cgP1xuICAgIC8vIGBtYXRjaFJvdXRlcygpYCBoYXMgYWxyZWFkeSBiZWVuIGNhbGxlZCBpZiB3ZSdyZSBpbiBoZXJlIHZpYSBgcm91dGVyLmluaXRpYWxpemUoKWBcbiAgICBzdGF0ZS5tYXRjaGVzIDogbWF0Y2hSb3V0ZXMocm91dGVzVG9Vc2UsIGxvY2F0aW9uLCBiYXNlbmFtZSk7XG4gICAgbGV0IGZsdXNoU3luYyA9IChvcHRzICYmIG9wdHMuZmx1c2hTeW5jKSA9PT0gdHJ1ZTtcbiAgICAvLyBTaG9ydCBjaXJjdWl0IGlmIGl0J3Mgb25seSBhIGhhc2ggY2hhbmdlIGFuZCBub3QgYSByZXZhbGlkYXRpb24gb3JcbiAgICAvLyBtdXRhdGlvbiBzdWJtaXNzaW9uLlxuICAgIC8vXG4gICAgLy8gSWdub3JlIG9uIGluaXRpYWwgcGFnZSBsb2FkcyBiZWNhdXNlIHNpbmNlIHRoZSBpbml0aWFsIGh5ZHJhdGlvbiB3aWxsIGFsd2F5c1xuICAgIC8vIGJlIFwic2FtZSBoYXNoXCIuICBGb3IgZXhhbXBsZSwgb24gL3BhZ2UjaGFzaCBhbmQgc3VibWl0IGEgPEZvcm0gbWV0aG9kPVwicG9zdFwiPlxuICAgIC8vIHdoaWNoIHdpbGwgZGVmYXVsdCB0byBhIG5hdmlnYXRpb24gdG8gL3BhZ2VcbiAgICBpZiAobWF0Y2hlcyAmJiBzdGF0ZS5pbml0aWFsaXplZCAmJiAhaXNSZXZhbGlkYXRpb25SZXF1aXJlZCAmJiBpc0hhc2hDaGFuZ2VPbmx5KHN0YXRlLmxvY2F0aW9uLCBsb2NhdGlvbikgJiYgIShvcHRzICYmIG9wdHMuc3VibWlzc2lvbiAmJiBpc011dGF0aW9uTWV0aG9kKG9wdHMuc3VibWlzc2lvbi5mb3JtTWV0aG9kKSkpIHtcbiAgICAgIGNvbXBsZXRlTmF2aWdhdGlvbihsb2NhdGlvbiwge1xuICAgICAgICBtYXRjaGVzXG4gICAgICB9LCB7XG4gICAgICAgIGZsdXNoU3luY1xuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBmb2dPZldhciA9IGNoZWNrRm9nT2ZXYXIobWF0Y2hlcywgcm91dGVzVG9Vc2UsIGxvY2F0aW9uLnBhdGhuYW1lKTtcbiAgICBpZiAoZm9nT2ZXYXIuYWN0aXZlICYmIGZvZ09mV2FyLm1hdGNoZXMpIHtcbiAgICAgIG1hdGNoZXMgPSBmb2dPZldhci5tYXRjaGVzO1xuICAgIH1cbiAgICAvLyBTaG9ydCBjaXJjdWl0IHdpdGggYSA0MDQgb24gdGhlIHJvb3QgZXJyb3IgYm91bmRhcnkgaWYgd2UgbWF0Y2ggbm90aGluZ1xuICAgIGlmICghbWF0Y2hlcykge1xuICAgICAgbGV0IHtcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIG5vdEZvdW5kTWF0Y2hlcyxcbiAgICAgICAgcm91dGVcbiAgICAgIH0gPSBoYW5kbGVOYXZpZ2F0aW9uYWw0MDQobG9jYXRpb24ucGF0aG5hbWUpO1xuICAgICAgY29tcGxldGVOYXZpZ2F0aW9uKGxvY2F0aW9uLCB7XG4gICAgICAgIG1hdGNoZXM6IG5vdEZvdW5kTWF0Y2hlcyxcbiAgICAgICAgbG9hZGVyRGF0YToge30sXG4gICAgICAgIGVycm9yczoge1xuICAgICAgICAgIFtyb3V0ZS5pZF06IGVycm9yXG4gICAgICAgIH1cbiAgICAgIH0sIHtcbiAgICAgICAgZmx1c2hTeW5jXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ3JlYXRlIGEgY29udHJvbGxlci9SZXF1ZXN0IGZvciB0aGlzIG5hdmlnYXRpb25cbiAgICBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgbGV0IHJlcXVlc3QgPSBjcmVhdGVDbGllbnRTaWRlUmVxdWVzdChpbml0Lmhpc3RvcnksIGxvY2F0aW9uLCBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIuc2lnbmFsLCBvcHRzICYmIG9wdHMuc3VibWlzc2lvbik7XG4gICAgbGV0IHBlbmRpbmdBY3Rpb25SZXN1bHQ7XG4gICAgaWYgKG9wdHMgJiYgb3B0cy5wZW5kaW5nRXJyb3IpIHtcbiAgICAgIC8vIElmIHdlIGhhdmUgYSBwZW5kaW5nRXJyb3IsIGl0IG1lYW5zIHRoZSB1c2VyIGF0dGVtcHRlZCBhIEdFVCBzdWJtaXNzaW9uXG4gICAgICAvLyB3aXRoIGJpbmFyeSBGb3JtRGF0YSBzbyBhc3NpZ24gaGVyZSBhbmQgc2tpcCB0byBoYW5kbGVMb2FkZXJzLiAgVGhhdFxuICAgICAgLy8gd2F5IHdlIGhhbmRsZSBjYWxsaW5nIGxvYWRlcnMgYWJvdmUgdGhlIGJvdW5kYXJ5IGV0Yy4gIEl0J3Mgbm90IHJlYWxseVxuICAgICAgLy8gZGlmZmVyZW50IGZyb20gYW4gYWN0aW9uRXJyb3IgaW4gdGhhdCBzZW5zZS5cbiAgICAgIHBlbmRpbmdBY3Rpb25SZXN1bHQgPSBbZmluZE5lYXJlc3RCb3VuZGFyeShtYXRjaGVzKS5yb3V0ZS5pZCwge1xuICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLmVycm9yLFxuICAgICAgICBlcnJvcjogb3B0cy5wZW5kaW5nRXJyb3JcbiAgICAgIH1dO1xuICAgIH0gZWxzZSBpZiAob3B0cyAmJiBvcHRzLnN1Ym1pc3Npb24gJiYgaXNNdXRhdGlvbk1ldGhvZChvcHRzLnN1Ym1pc3Npb24uZm9ybU1ldGhvZCkpIHtcbiAgICAgIC8vIENhbGwgYWN0aW9uIGlmIHdlIHJlY2VpdmVkIGFuIGFjdGlvbiBzdWJtaXNzaW9uXG4gICAgICBsZXQgYWN0aW9uUmVzdWx0ID0gYXdhaXQgaGFuZGxlQWN0aW9uKHJlcXVlc3QsIGxvY2F0aW9uLCBvcHRzLnN1Ym1pc3Npb24sIG1hdGNoZXMsIGZvZ09mV2FyLmFjdGl2ZSwge1xuICAgICAgICByZXBsYWNlOiBvcHRzLnJlcGxhY2UsXG4gICAgICAgIGZsdXNoU3luY1xuICAgICAgfSk7XG4gICAgICBpZiAoYWN0aW9uUmVzdWx0LnNob3J0Q2lyY3VpdGVkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIC8vIElmIHdlIHJlY2VpdmVkIGEgNDA0IGZyb20gaGFuZGxlQWN0aW9uLCBpdCdzIGJlY2F1c2Ugd2UgY291bGRuJ3QgbGF6aWx5XG4gICAgICAvLyBkaXNjb3ZlciB0aGUgZGVzdGluYXRpb24gcm91dGUgc28gd2UgZG9uJ3Qgd2FudCB0byBjYWxsIGxvYWRlcnNcbiAgICAgIGlmIChhY3Rpb25SZXN1bHQucGVuZGluZ0FjdGlvblJlc3VsdCkge1xuICAgICAgICBsZXQgW3JvdXRlSWQsIHJlc3VsdF0gPSBhY3Rpb25SZXN1bHQucGVuZGluZ0FjdGlvblJlc3VsdDtcbiAgICAgICAgaWYgKGlzRXJyb3JSZXN1bHQocmVzdWx0KSAmJiBpc1JvdXRlRXJyb3JSZXNwb25zZShyZXN1bHQuZXJyb3IpICYmIHJlc3VsdC5lcnJvci5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgICAgIHBlbmRpbmdOYXZpZ2F0aW9uQ29udHJvbGxlciA9IG51bGw7XG4gICAgICAgICAgY29tcGxldGVOYXZpZ2F0aW9uKGxvY2F0aW9uLCB7XG4gICAgICAgICAgICBtYXRjaGVzOiBhY3Rpb25SZXN1bHQubWF0Y2hlcyxcbiAgICAgICAgICAgIGxvYWRlckRhdGE6IHt9LFxuICAgICAgICAgICAgZXJyb3JzOiB7XG4gICAgICAgICAgICAgIFtyb3V0ZUlkXTogcmVzdWx0LmVycm9yXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBtYXRjaGVzID0gYWN0aW9uUmVzdWx0Lm1hdGNoZXMgfHwgbWF0Y2hlcztcbiAgICAgIHBlbmRpbmdBY3Rpb25SZXN1bHQgPSBhY3Rpb25SZXN1bHQucGVuZGluZ0FjdGlvblJlc3VsdDtcbiAgICAgIGxvYWRpbmdOYXZpZ2F0aW9uID0gZ2V0TG9hZGluZ05hdmlnYXRpb24obG9jYXRpb24sIG9wdHMuc3VibWlzc2lvbik7XG4gICAgICBmbHVzaFN5bmMgPSBmYWxzZTtcbiAgICAgIC8vIE5vIG5lZWQgdG8gZG8gZm9nIG9mIHdhciBtYXRjaGluZyBhZ2FpbiBvbiBsb2FkZXIgZXhlY3V0aW9uXG4gICAgICBmb2dPZldhci5hY3RpdmUgPSBmYWxzZTtcbiAgICAgIC8vIENyZWF0ZSBhIEdFVCByZXF1ZXN0IGZvciB0aGUgbG9hZGVyc1xuICAgICAgcmVxdWVzdCA9IGNyZWF0ZUNsaWVudFNpZGVSZXF1ZXN0KGluaXQuaGlzdG9yeSwgcmVxdWVzdC51cmwsIHJlcXVlc3Quc2lnbmFsKTtcbiAgICB9XG4gICAgLy8gQ2FsbCBsb2FkZXJzXG4gICAgbGV0IHtcbiAgICAgIHNob3J0Q2lyY3VpdGVkLFxuICAgICAgbWF0Y2hlczogdXBkYXRlZE1hdGNoZXMsXG4gICAgICBsb2FkZXJEYXRhLFxuICAgICAgZXJyb3JzXG4gICAgfSA9IGF3YWl0IGhhbmRsZUxvYWRlcnMocmVxdWVzdCwgbG9jYXRpb24sIG1hdGNoZXMsIGZvZ09mV2FyLmFjdGl2ZSwgbG9hZGluZ05hdmlnYXRpb24sIG9wdHMgJiYgb3B0cy5zdWJtaXNzaW9uLCBvcHRzICYmIG9wdHMuZmV0Y2hlclN1Ym1pc3Npb24sIG9wdHMgJiYgb3B0cy5yZXBsYWNlLCBvcHRzICYmIG9wdHMuaW5pdGlhbEh5ZHJhdGlvbiA9PT0gdHJ1ZSwgZmx1c2hTeW5jLCBwZW5kaW5nQWN0aW9uUmVzdWx0KTtcbiAgICBpZiAoc2hvcnRDaXJjdWl0ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ2xlYW4gdXAgbm93IHRoYXQgdGhlIGFjdGlvbi9sb2FkZXJzIGhhdmUgY29tcGxldGVkLiAgRG9uJ3QgY2xlYW4gdXAgaWZcbiAgICAvLyB3ZSBzaG9ydCBjaXJjdWl0ZWQgYmVjYXVzZSBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIgd2lsbCBoYXZlIGFscmVhZHlcbiAgICAvLyBiZWVuIGFzc2lnbmVkIHRvIGEgbmV3IGNvbnRyb2xsZXIgZm9yIHRoZSBuZXh0IG5hdmlnYXRpb25cbiAgICBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIgPSBudWxsO1xuICAgIGNvbXBsZXRlTmF2aWdhdGlvbihsb2NhdGlvbiwgX2V4dGVuZHMoe1xuICAgICAgbWF0Y2hlczogdXBkYXRlZE1hdGNoZXMgfHwgbWF0Y2hlc1xuICAgIH0sIGdldEFjdGlvbkRhdGFGb3JDb21taXQocGVuZGluZ0FjdGlvblJlc3VsdCksIHtcbiAgICAgIGxvYWRlckRhdGEsXG4gICAgICBlcnJvcnNcbiAgICB9KSk7XG4gIH1cbiAgLy8gQ2FsbCB0aGUgYWN0aW9uIG1hdGNoZWQgYnkgdGhlIGxlYWYgcm91dGUgZm9yIHRoaXMgbmF2aWdhdGlvbiBhbmQgaGFuZGxlXG4gIC8vIHJlZGlyZWN0cy9lcnJvcnNcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlQWN0aW9uKHJlcXVlc3QsIGxvY2F0aW9uLCBzdWJtaXNzaW9uLCBtYXRjaGVzLCBpc0ZvZ09mV2FyLCBvcHRzKSB7XG4gICAgaWYgKG9wdHMgPT09IHZvaWQgMCkge1xuICAgICAgb3B0cyA9IHt9O1xuICAgIH1cbiAgICBpbnRlcnJ1cHRBY3RpdmVMb2FkcygpO1xuICAgIC8vIFB1dCB1cyBpbiBhIHN1Ym1pdHRpbmcgc3RhdGVcbiAgICBsZXQgbmF2aWdhdGlvbiA9IGdldFN1Ym1pdHRpbmdOYXZpZ2F0aW9uKGxvY2F0aW9uLCBzdWJtaXNzaW9uKTtcbiAgICB1cGRhdGVTdGF0ZSh7XG4gICAgICBuYXZpZ2F0aW9uXG4gICAgfSwge1xuICAgICAgZmx1c2hTeW5jOiBvcHRzLmZsdXNoU3luYyA9PT0gdHJ1ZVxuICAgIH0pO1xuICAgIGlmIChpc0ZvZ09mV2FyKSB7XG4gICAgICBsZXQgZGlzY292ZXJSZXN1bHQgPSBhd2FpdCBkaXNjb3ZlclJvdXRlcyhtYXRjaGVzLCBsb2NhdGlvbi5wYXRobmFtZSwgcmVxdWVzdC5zaWduYWwpO1xuICAgICAgaWYgKGRpc2NvdmVyUmVzdWx0LnR5cGUgPT09IFwiYWJvcnRlZFwiKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc2hvcnRDaXJjdWl0ZWQ6IHRydWVcbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSBpZiAoZGlzY292ZXJSZXN1bHQudHlwZSA9PT0gXCJlcnJvclwiKSB7XG4gICAgICAgIGxldCBib3VuZGFyeUlkID0gZmluZE5lYXJlc3RCb3VuZGFyeShkaXNjb3ZlclJlc3VsdC5wYXJ0aWFsTWF0Y2hlcykucm91dGUuaWQ7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgbWF0Y2hlczogZGlzY292ZXJSZXN1bHQucGFydGlhbE1hdGNoZXMsXG4gICAgICAgICAgcGVuZGluZ0FjdGlvblJlc3VsdDogW2JvdW5kYXJ5SWQsIHtcbiAgICAgICAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZXJyb3IsXG4gICAgICAgICAgICBlcnJvcjogZGlzY292ZXJSZXN1bHQuZXJyb3JcbiAgICAgICAgICB9XVxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIGlmICghZGlzY292ZXJSZXN1bHQubWF0Y2hlcykge1xuICAgICAgICBsZXQge1xuICAgICAgICAgIG5vdEZvdW5kTWF0Y2hlcyxcbiAgICAgICAgICBlcnJvcixcbiAgICAgICAgICByb3V0ZVxuICAgICAgICB9ID0gaGFuZGxlTmF2aWdhdGlvbmFsNDA0KGxvY2F0aW9uLnBhdGhuYW1lKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBtYXRjaGVzOiBub3RGb3VuZE1hdGNoZXMsXG4gICAgICAgICAgcGVuZGluZ0FjdGlvblJlc3VsdDogW3JvdXRlLmlkLCB7XG4gICAgICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLmVycm9yLFxuICAgICAgICAgICAgZXJyb3JcbiAgICAgICAgICB9XVxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWF0Y2hlcyA9IGRpc2NvdmVyUmVzdWx0Lm1hdGNoZXM7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIENhbGwgb3VyIGFjdGlvbiBhbmQgZ2V0IHRoZSByZXN1bHRcbiAgICBsZXQgcmVzdWx0O1xuICAgIGxldCBhY3Rpb25NYXRjaCA9IGdldFRhcmdldE1hdGNoKG1hdGNoZXMsIGxvY2F0aW9uKTtcbiAgICBpZiAoIWFjdGlvbk1hdGNoLnJvdXRlLmFjdGlvbiAmJiAhYWN0aW9uTWF0Y2gucm91dGUubGF6eSkge1xuICAgICAgcmVzdWx0ID0ge1xuICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLmVycm9yLFxuICAgICAgICBlcnJvcjogZ2V0SW50ZXJuYWxSb3V0ZXJFcnJvcig0MDUsIHtcbiAgICAgICAgICBtZXRob2Q6IHJlcXVlc3QubWV0aG9kLFxuICAgICAgICAgIHBhdGhuYW1lOiBsb2NhdGlvbi5wYXRobmFtZSxcbiAgICAgICAgICByb3V0ZUlkOiBhY3Rpb25NYXRjaC5yb3V0ZS5pZFxuICAgICAgICB9KVxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IHJlc3VsdHMgPSBhd2FpdCBjYWxsRGF0YVN0cmF0ZWd5KFwiYWN0aW9uXCIsIHN0YXRlLCByZXF1ZXN0LCBbYWN0aW9uTWF0Y2hdLCBtYXRjaGVzLCBudWxsKTtcbiAgICAgIHJlc3VsdCA9IHJlc3VsdHNbYWN0aW9uTWF0Y2gucm91dGUuaWRdO1xuICAgICAgaWYgKHJlcXVlc3Quc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzaG9ydENpcmN1aXRlZDogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoaXNSZWRpcmVjdFJlc3VsdChyZXN1bHQpKSB7XG4gICAgICBsZXQgcmVwbGFjZTtcbiAgICAgIGlmIChvcHRzICYmIG9wdHMucmVwbGFjZSAhPSBudWxsKSB7XG4gICAgICAgIHJlcGxhY2UgPSBvcHRzLnJlcGxhY2U7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBJZiB0aGUgdXNlciBkaWRuJ3QgZXhwbGljaXR5IGluZGljYXRlIHJlcGxhY2UgYmVoYXZpb3IsIHJlcGxhY2UgaWZcbiAgICAgICAgLy8gd2UgcmVkaXJlY3RlZCB0byB0aGUgZXhhY3Qgc2FtZSBsb2NhdGlvbiB3ZSdyZSBjdXJyZW50bHkgYXQgdG8gYXZvaWRcbiAgICAgICAgLy8gZG91YmxlIGJhY2stYnV0dG9uc1xuICAgICAgICBsZXQgbG9jYXRpb24gPSBub3JtYWxpemVSZWRpcmVjdExvY2F0aW9uKHJlc3VsdC5yZXNwb25zZS5oZWFkZXJzLmdldChcIkxvY2F0aW9uXCIpLCBuZXcgVVJMKHJlcXVlc3QudXJsKSwgYmFzZW5hbWUsIGluaXQuaGlzdG9yeSk7XG4gICAgICAgIHJlcGxhY2UgPSBsb2NhdGlvbiA9PT0gc3RhdGUubG9jYXRpb24ucGF0aG5hbWUgKyBzdGF0ZS5sb2NhdGlvbi5zZWFyY2g7XG4gICAgICB9XG4gICAgICBhd2FpdCBzdGFydFJlZGlyZWN0TmF2aWdhdGlvbihyZXF1ZXN0LCByZXN1bHQsIHRydWUsIHtcbiAgICAgICAgc3VibWlzc2lvbixcbiAgICAgICAgcmVwbGFjZVxuICAgICAgfSk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydENpcmN1aXRlZDogdHJ1ZVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKGlzRGVmZXJyZWRSZXN1bHQocmVzdWx0KSkge1xuICAgICAgdGhyb3cgZ2V0SW50ZXJuYWxSb3V0ZXJFcnJvcig0MDAsIHtcbiAgICAgICAgdHlwZTogXCJkZWZlci1hY3Rpb25cIlxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChpc0Vycm9yUmVzdWx0KHJlc3VsdCkpIHtcbiAgICAgIC8vIFN0b3JlIG9mZiB0aGUgcGVuZGluZyBlcnJvciAtIHdlIHVzZSBpdCB0byBkZXRlcm1pbmUgd2hpY2ggbG9hZGVyc1xuICAgICAgLy8gdG8gY2FsbCBhbmQgd2lsbCBjb21taXQgaXQgd2hlbiB3ZSBjb21wbGV0ZSB0aGUgbmF2aWdhdGlvblxuICAgICAgbGV0IGJvdW5kYXJ5TWF0Y2ggPSBmaW5kTmVhcmVzdEJvdW5kYXJ5KG1hdGNoZXMsIGFjdGlvbk1hdGNoLnJvdXRlLmlkKTtcbiAgICAgIC8vIEJ5IGRlZmF1bHQsIGFsbCBzdWJtaXNzaW9ucyB0byB0aGUgY3VycmVudCBsb2NhdGlvbiBhcmUgUkVQTEFDRVxuICAgICAgLy8gbmF2aWdhdGlvbnMsIGJ1dCBpZiB0aGUgYWN0aW9uIHRocmV3IGFuIGVycm9yIHRoYXQnbGwgYmUgcmVuZGVyZWQgaW5cbiAgICAgIC8vIGFuIGVycm9yRWxlbWVudCwgd2UgZmFsbCBiYWNrIHRvIFBVU0ggc28gdGhhdCB0aGUgdXNlciBjYW4gdXNlIHRoZVxuICAgICAgLy8gYmFjayBidXR0b24gdG8gZ2V0IGJhY2sgdG8gdGhlIHByZS1zdWJtaXNzaW9uIGZvcm0gbG9jYXRpb24gdG8gdHJ5XG4gICAgICAvLyBhZ2FpblxuICAgICAgaWYgKChvcHRzICYmIG9wdHMucmVwbGFjZSkgIT09IHRydWUpIHtcbiAgICAgICAgcGVuZGluZ0FjdGlvbiA9IEFjdGlvbi5QdXNoO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbWF0Y2hlcyxcbiAgICAgICAgcGVuZGluZ0FjdGlvblJlc3VsdDogW2JvdW5kYXJ5TWF0Y2gucm91dGUuaWQsIHJlc3VsdF1cbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBtYXRjaGVzLFxuICAgICAgcGVuZGluZ0FjdGlvblJlc3VsdDogW2FjdGlvbk1hdGNoLnJvdXRlLmlkLCByZXN1bHRdXG4gICAgfTtcbiAgfVxuICAvLyBDYWxsIGFsbCBhcHBsaWNhYmxlIGxvYWRlcnMgZm9yIHRoZSBnaXZlbiBtYXRjaGVzLCBoYW5kbGluZyByZWRpcmVjdHMsXG4gIC8vIGVycm9ycywgZXRjLlxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVMb2FkZXJzKHJlcXVlc3QsIGxvY2F0aW9uLCBtYXRjaGVzLCBpc0ZvZ09mV2FyLCBvdmVycmlkZU5hdmlnYXRpb24sIHN1Ym1pc3Npb24sIGZldGNoZXJTdWJtaXNzaW9uLCByZXBsYWNlLCBpbml0aWFsSHlkcmF0aW9uLCBmbHVzaFN5bmMsIHBlbmRpbmdBY3Rpb25SZXN1bHQpIHtcbiAgICAvLyBGaWd1cmUgb3V0IHRoZSByaWdodCBuYXZpZ2F0aW9uIHdlIHdhbnQgdG8gdXNlIGZvciBkYXRhIGxvYWRpbmdcbiAgICBsZXQgbG9hZGluZ05hdmlnYXRpb24gPSBvdmVycmlkZU5hdmlnYXRpb24gfHwgZ2V0TG9hZGluZ05hdmlnYXRpb24obG9jYXRpb24sIHN1Ym1pc3Npb24pO1xuICAgIC8vIElmIHRoaXMgd2FzIGEgcmVkaXJlY3QgZnJvbSBhbiBhY3Rpb24gd2UgZG9uJ3QgaGF2ZSBhIFwic3VibWlzc2lvblwiIGJ1dFxuICAgIC8vIHdlIGhhdmUgaXQgb24gdGhlIGxvYWRpbmcgbmF2aWdhdGlvbiBzbyB1c2UgdGhhdCBpZiBhdmFpbGFibGVcbiAgICBsZXQgYWN0aXZlU3VibWlzc2lvbiA9IHN1Ym1pc3Npb24gfHwgZmV0Y2hlclN1Ym1pc3Npb24gfHwgZ2V0U3VibWlzc2lvbkZyb21OYXZpZ2F0aW9uKGxvYWRpbmdOYXZpZ2F0aW9uKTtcbiAgICAvLyBJZiB0aGlzIGlzIGFuIHVuaW50ZXJydXB0ZWQgcmV2YWxpZGF0aW9uLCB3ZSByZW1haW4gaW4gb3VyIGN1cnJlbnQgaWRsZVxuICAgIC8vIHN0YXRlLiAgSWYgbm90LCB3ZSBuZWVkIHRvIHN3aXRjaCB0byBvdXIgbG9hZGluZyBzdGF0ZSBhbmQgbG9hZCBkYXRhLFxuICAgIC8vIHByZXNlcnZpbmcgYW55IG5ldyBhY3Rpb24gZGF0YSBvciBleGlzdGluZyBhY3Rpb24gZGF0YSAoaW4gdGhlIGNhc2Ugb2ZcbiAgICAvLyBhIHJldmFsaWRhdGlvbiBpbnRlcnJ1cHRpbmcgYW4gYWN0aW9uUmVsb2FkKVxuICAgIC8vIElmIHdlIGhhdmUgcGFydGlhbEh5ZHJhdGlvbiBlbmFibGVkLCB0aGVuIGRvbid0IHVwZGF0ZSB0aGUgc3RhdGUgZm9yIHRoZVxuICAgIC8vIGluaXRpYWwgZGF0YSBsb2FkIHNpbmNlIGl0J3Mgbm90IGEgXCJuYXZpZ2F0aW9uXCJcbiAgICBsZXQgc2hvdWxkVXBkYXRlTmF2aWdhdGlvblN0YXRlID0gIWlzVW5pbnRlcnJ1cHRlZFJldmFsaWRhdGlvbiAmJiAoIWZ1dHVyZS52N19wYXJ0aWFsSHlkcmF0aW9uIHx8ICFpbml0aWFsSHlkcmF0aW9uKTtcbiAgICAvLyBXaGVuIGZvZyBvZiB3YXIgaXMgZW5hYmxlZCwgd2UgZW50ZXIgb3VyIGBsb2FkaW5nYCBzdGF0ZSBlYXJsaWVyIHNvIHdlXG4gICAgLy8gY2FuIGRpc2NvdmVyIG5ldyByb3V0ZXMgZHVyaW5nIHRoZSBgbG9hZGluZ2Agc3RhdGUuICBXZSBza2lwIHRoaXMgaWZcbiAgICAvLyB3ZSd2ZSBhbHJlYWR5IHJ1biBhY3Rpb25zIHNpbmNlIHdlIHdvdWxkIGhhdmUgZG9uZSBvdXIgbWF0Y2hpbmcgYWxyZWFkeS5cbiAgICAvLyBJZiB0aGUgY2hpbGRyZW4oKSBmdW5jdGlvbiB0aHJldyB0aGVuLCB3ZSB3YW50IHRvIHByb2NlZWQgd2l0aCB0aGVcbiAgICAvLyBwYXJ0aWFsIG1hdGNoZXMgaXQgZGlzY292ZXJlZC5cbiAgICBpZiAoaXNGb2dPZldhcikge1xuICAgICAgaWYgKHNob3VsZFVwZGF0ZU5hdmlnYXRpb25TdGF0ZSkge1xuICAgICAgICBsZXQgYWN0aW9uRGF0YSA9IGdldFVwZGF0ZWRBY3Rpb25EYXRhKHBlbmRpbmdBY3Rpb25SZXN1bHQpO1xuICAgICAgICB1cGRhdGVTdGF0ZShfZXh0ZW5kcyh7XG4gICAgICAgICAgbmF2aWdhdGlvbjogbG9hZGluZ05hdmlnYXRpb25cbiAgICAgICAgfSwgYWN0aW9uRGF0YSAhPT0gdW5kZWZpbmVkID8ge1xuICAgICAgICAgIGFjdGlvbkRhdGFcbiAgICAgICAgfSA6IHt9KSwge1xuICAgICAgICAgIGZsdXNoU3luY1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGxldCBkaXNjb3ZlclJlc3VsdCA9IGF3YWl0IGRpc2NvdmVyUm91dGVzKG1hdGNoZXMsIGxvY2F0aW9uLnBhdGhuYW1lLCByZXF1ZXN0LnNpZ25hbCk7XG4gICAgICBpZiAoZGlzY292ZXJSZXN1bHQudHlwZSA9PT0gXCJhYm9ydGVkXCIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzaG9ydENpcmN1aXRlZDogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIGlmIChkaXNjb3ZlclJlc3VsdC50eXBlID09PSBcImVycm9yXCIpIHtcbiAgICAgICAgbGV0IGJvdW5kYXJ5SWQgPSBmaW5kTmVhcmVzdEJvdW5kYXJ5KGRpc2NvdmVyUmVzdWx0LnBhcnRpYWxNYXRjaGVzKS5yb3V0ZS5pZDtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBtYXRjaGVzOiBkaXNjb3ZlclJlc3VsdC5wYXJ0aWFsTWF0Y2hlcyxcbiAgICAgICAgICBsb2FkZXJEYXRhOiB7fSxcbiAgICAgICAgICBlcnJvcnM6IHtcbiAgICAgICAgICAgIFtib3VuZGFyeUlkXTogZGlzY292ZXJSZXN1bHQuZXJyb3JcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9IGVsc2UgaWYgKCFkaXNjb3ZlclJlc3VsdC5tYXRjaGVzKSB7XG4gICAgICAgIGxldCB7XG4gICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgbm90Rm91bmRNYXRjaGVzLFxuICAgICAgICAgIHJvdXRlXG4gICAgICAgIH0gPSBoYW5kbGVOYXZpZ2F0aW9uYWw0MDQobG9jYXRpb24ucGF0aG5hbWUpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIG1hdGNoZXM6IG5vdEZvdW5kTWF0Y2hlcyxcbiAgICAgICAgICBsb2FkZXJEYXRhOiB7fSxcbiAgICAgICAgICBlcnJvcnM6IHtcbiAgICAgICAgICAgIFtyb3V0ZS5pZF06IGVycm9yXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWF0Y2hlcyA9IGRpc2NvdmVyUmVzdWx0Lm1hdGNoZXM7XG4gICAgICB9XG4gICAgfVxuICAgIGxldCByb3V0ZXNUb1VzZSA9IGluRmxpZ2h0RGF0YVJvdXRlcyB8fCBkYXRhUm91dGVzO1xuICAgIGxldCBbbWF0Y2hlc1RvTG9hZCwgcmV2YWxpZGF0aW5nRmV0Y2hlcnNdID0gZ2V0TWF0Y2hlc1RvTG9hZChpbml0Lmhpc3RvcnksIHN0YXRlLCBtYXRjaGVzLCBhY3RpdmVTdWJtaXNzaW9uLCBsb2NhdGlvbiwgZnV0dXJlLnY3X3BhcnRpYWxIeWRyYXRpb24gJiYgaW5pdGlhbEh5ZHJhdGlvbiA9PT0gdHJ1ZSwgZnV0dXJlLnY3X3NraXBBY3Rpb25FcnJvclJldmFsaWRhdGlvbiwgaXNSZXZhbGlkYXRpb25SZXF1aXJlZCwgY2FuY2VsbGVkRGVmZXJyZWRSb3V0ZXMsIGNhbmNlbGxlZEZldGNoZXJMb2FkcywgZGVsZXRlZEZldGNoZXJzLCBmZXRjaExvYWRNYXRjaGVzLCBmZXRjaFJlZGlyZWN0SWRzLCByb3V0ZXNUb1VzZSwgYmFzZW5hbWUsIHBlbmRpbmdBY3Rpb25SZXN1bHQpO1xuICAgIC8vIENhbmNlbCBwZW5kaW5nIGRlZmVycmVkcyBmb3Igbm8tbG9uZ2VyLW1hdGNoZWQgcm91dGVzIG9yIHJvdXRlcyB3ZSdyZVxuICAgIC8vIGFib3V0IHRvIHJlbG9hZC4gIE5vdGUgdGhhdCBpZiB0aGlzIGlzIGFuIGFjdGlvbiByZWxvYWQgd2Ugd291bGQgaGF2ZVxuICAgIC8vIGFscmVhZHkgY2FuY2VsbGVkIGFsbCBwZW5kaW5nIGRlZmVycmVkcyBzbyB0aGlzIHdvdWxkIGJlIGEgbm8tb3BcbiAgICBjYW5jZWxBY3RpdmVEZWZlcnJlZHMocm91dGVJZCA9PiAhKG1hdGNoZXMgJiYgbWF0Y2hlcy5zb21lKG0gPT4gbS5yb3V0ZS5pZCA9PT0gcm91dGVJZCkpIHx8IG1hdGNoZXNUb0xvYWQgJiYgbWF0Y2hlc1RvTG9hZC5zb21lKG0gPT4gbS5yb3V0ZS5pZCA9PT0gcm91dGVJZCkpO1xuICAgIHBlbmRpbmdOYXZpZ2F0aW9uTG9hZElkID0gKytpbmNyZW1lbnRpbmdMb2FkSWQ7XG4gICAgLy8gU2hvcnQgY2lyY3VpdCBpZiB3ZSBoYXZlIG5vIGxvYWRlcnMgdG8gcnVuXG4gICAgaWYgKG1hdGNoZXNUb0xvYWQubGVuZ3RoID09PSAwICYmIHJldmFsaWRhdGluZ0ZldGNoZXJzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgbGV0IHVwZGF0ZWRGZXRjaGVycyA9IG1hcmtGZXRjaFJlZGlyZWN0c0RvbmUoKTtcbiAgICAgIGNvbXBsZXRlTmF2aWdhdGlvbihsb2NhdGlvbiwgX2V4dGVuZHMoe1xuICAgICAgICBtYXRjaGVzLFxuICAgICAgICBsb2FkZXJEYXRhOiB7fSxcbiAgICAgICAgLy8gQ29tbWl0IHBlbmRpbmcgZXJyb3IgaWYgd2UncmUgc2hvcnQgY2lyY3VpdGluZ1xuICAgICAgICBlcnJvcnM6IHBlbmRpbmdBY3Rpb25SZXN1bHQgJiYgaXNFcnJvclJlc3VsdChwZW5kaW5nQWN0aW9uUmVzdWx0WzFdKSA/IHtcbiAgICAgICAgICBbcGVuZGluZ0FjdGlvblJlc3VsdFswXV06IHBlbmRpbmdBY3Rpb25SZXN1bHRbMV0uZXJyb3JcbiAgICAgICAgfSA6IG51bGxcbiAgICAgIH0sIGdldEFjdGlvbkRhdGFGb3JDb21taXQocGVuZGluZ0FjdGlvblJlc3VsdCksIHVwZGF0ZWRGZXRjaGVycyA/IHtcbiAgICAgICAgZmV0Y2hlcnM6IG5ldyBNYXAoc3RhdGUuZmV0Y2hlcnMpXG4gICAgICB9IDoge30pLCB7XG4gICAgICAgIGZsdXNoU3luY1xuICAgICAgfSk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG9ydENpcmN1aXRlZDogdHJ1ZVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHNob3VsZFVwZGF0ZU5hdmlnYXRpb25TdGF0ZSkge1xuICAgICAgbGV0IHVwZGF0ZXMgPSB7fTtcbiAgICAgIGlmICghaXNGb2dPZldhcikge1xuICAgICAgICAvLyBPbmx5IHVwZGF0ZSBuYXZpZ2F0aW9uL2FjdGlvbk5EYXRhIGlmIHdlIGRpZG4ndCBhbHJlYWR5IGRvIGl0IGFib3ZlXG4gICAgICAgIHVwZGF0ZXMubmF2aWdhdGlvbiA9IGxvYWRpbmdOYXZpZ2F0aW9uO1xuICAgICAgICBsZXQgYWN0aW9uRGF0YSA9IGdldFVwZGF0ZWRBY3Rpb25EYXRhKHBlbmRpbmdBY3Rpb25SZXN1bHQpO1xuICAgICAgICBpZiAoYWN0aW9uRGF0YSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgdXBkYXRlcy5hY3Rpb25EYXRhID0gYWN0aW9uRGF0YTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHJldmFsaWRhdGluZ0ZldGNoZXJzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgdXBkYXRlcy5mZXRjaGVycyA9IGdldFVwZGF0ZWRSZXZhbGlkYXRpbmdGZXRjaGVycyhyZXZhbGlkYXRpbmdGZXRjaGVycyk7XG4gICAgICB9XG4gICAgICB1cGRhdGVTdGF0ZSh1cGRhdGVzLCB7XG4gICAgICAgIGZsdXNoU3luY1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldmFsaWRhdGluZ0ZldGNoZXJzLmZvckVhY2gocmYgPT4ge1xuICAgICAgYWJvcnRGZXRjaGVyKHJmLmtleSk7XG4gICAgICBpZiAocmYuY29udHJvbGxlcikge1xuICAgICAgICAvLyBGZXRjaGVycyB1c2UgYW4gaW5kZXBlbmRlbnQgQWJvcnRDb250cm9sbGVyIHNvIHRoYXQgYWJvcnRpbmcgYSBmZXRjaGVyXG4gICAgICAgIC8vICh2aWEgZGVsZXRlRmV0Y2hlcikgZG9lcyBub3QgYWJvcnQgdGhlIHRyaWdnZXJpbmcgbmF2aWdhdGlvbiB0aGF0XG4gICAgICAgIC8vIHRyaWdnZXJlZCB0aGUgcmV2YWxpZGF0aW9uXG4gICAgICAgIGZldGNoQ29udHJvbGxlcnMuc2V0KHJmLmtleSwgcmYuY29udHJvbGxlcik7XG4gICAgICB9XG4gICAgfSk7XG4gICAgLy8gUHJveHkgbmF2aWdhdGlvbiBhYm9ydCB0aHJvdWdoIHRvIHJldmFsaWRhdGlvbiBmZXRjaGVyc1xuICAgIGxldCBhYm9ydFBlbmRpbmdGZXRjaFJldmFsaWRhdGlvbnMgPSAoKSA9PiByZXZhbGlkYXRpbmdGZXRjaGVycy5mb3JFYWNoKGYgPT4gYWJvcnRGZXRjaGVyKGYua2V5KSk7XG4gICAgaWYgKHBlbmRpbmdOYXZpZ2F0aW9uQ29udHJvbGxlcikge1xuICAgICAgcGVuZGluZ05hdmlnYXRpb25Db250cm9sbGVyLnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnRQZW5kaW5nRmV0Y2hSZXZhbGlkYXRpb25zKTtcbiAgICB9XG4gICAgbGV0IHtcbiAgICAgIGxvYWRlclJlc3VsdHMsXG4gICAgICBmZXRjaGVyUmVzdWx0c1xuICAgIH0gPSBhd2FpdCBjYWxsTG9hZGVyc0FuZE1heWJlUmVzb2x2ZURhdGEoc3RhdGUsIG1hdGNoZXMsIG1hdGNoZXNUb0xvYWQsIHJldmFsaWRhdGluZ0ZldGNoZXJzLCByZXF1ZXN0KTtcbiAgICBpZiAocmVxdWVzdC5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnRDaXJjdWl0ZWQ6IHRydWVcbiAgICAgIH07XG4gICAgfVxuICAgIC8vIENsZWFuIHVwIF9hZnRlcl8gbG9hZGVycyBoYXZlIGNvbXBsZXRlZC4gIERvbid0IGNsZWFuIHVwIGlmIHdlIHNob3J0XG4gICAgLy8gY2lyY3VpdGVkIGJlY2F1c2UgZmV0Y2hDb250cm9sbGVycyB3b3VsZCBoYXZlIGJlZW4gYWJvcnRlZCBhbmRcbiAgICAvLyByZWFzc2lnbmVkIHRvIG5ldyBjb250cm9sbGVycyBmb3IgdGhlIG5leHQgbmF2aWdhdGlvblxuICAgIGlmIChwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIpIHtcbiAgICAgIHBlbmRpbmdOYXZpZ2F0aW9uQ29udHJvbGxlci5zaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGFib3J0UGVuZGluZ0ZldGNoUmV2YWxpZGF0aW9ucyk7XG4gICAgfVxuICAgIHJldmFsaWRhdGluZ0ZldGNoZXJzLmZvckVhY2gocmYgPT4gZmV0Y2hDb250cm9sbGVycy5kZWxldGUocmYua2V5KSk7XG4gICAgLy8gSWYgYW55IGxvYWRlcnMgcmV0dXJuZWQgYSByZWRpcmVjdCBSZXNwb25zZSwgc3RhcnQgYSBuZXcgUkVQTEFDRSBuYXZpZ2F0aW9uXG4gICAgbGV0IHJlZGlyZWN0ID0gZmluZFJlZGlyZWN0KGxvYWRlclJlc3VsdHMpO1xuICAgIGlmIChyZWRpcmVjdCkge1xuICAgICAgYXdhaXQgc3RhcnRSZWRpcmVjdE5hdmlnYXRpb24ocmVxdWVzdCwgcmVkaXJlY3QucmVzdWx0LCB0cnVlLCB7XG4gICAgICAgIHJlcGxhY2VcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnRDaXJjdWl0ZWQ6IHRydWVcbiAgICAgIH07XG4gICAgfVxuICAgIHJlZGlyZWN0ID0gZmluZFJlZGlyZWN0KGZldGNoZXJSZXN1bHRzKTtcbiAgICBpZiAocmVkaXJlY3QpIHtcbiAgICAgIC8vIElmIHRoaXMgcmVkaXJlY3QgY2FtZSBmcm9tIGEgZmV0Y2hlciBtYWtlIHN1cmUgd2UgbWFyayBpdCBpblxuICAgICAgLy8gZmV0Y2hSZWRpcmVjdElkcyBzbyBpdCBkb2Vzbid0IGdldCByZXZhbGlkYXRlZCBvbiB0aGUgbmV4dCBzZXQgb2ZcbiAgICAgIC8vIGxvYWRlciBleGVjdXRpb25zXG4gICAgICBmZXRjaFJlZGlyZWN0SWRzLmFkZChyZWRpcmVjdC5rZXkpO1xuICAgICAgYXdhaXQgc3RhcnRSZWRpcmVjdE5hdmlnYXRpb24ocmVxdWVzdCwgcmVkaXJlY3QucmVzdWx0LCB0cnVlLCB7XG4gICAgICAgIHJlcGxhY2VcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvcnRDaXJjdWl0ZWQ6IHRydWVcbiAgICAgIH07XG4gICAgfVxuICAgIC8vIFByb2Nlc3MgYW5kIGNvbW1pdCBvdXRwdXQgZnJvbSBsb2FkZXJzXG4gICAgbGV0IHtcbiAgICAgIGxvYWRlckRhdGEsXG4gICAgICBlcnJvcnNcbiAgICB9ID0gcHJvY2Vzc0xvYWRlckRhdGEoc3RhdGUsIG1hdGNoZXMsIGxvYWRlclJlc3VsdHMsIHBlbmRpbmdBY3Rpb25SZXN1bHQsIHJldmFsaWRhdGluZ0ZldGNoZXJzLCBmZXRjaGVyUmVzdWx0cywgYWN0aXZlRGVmZXJyZWRzKTtcbiAgICAvLyBXaXJlIHVwIHN1YnNjcmliZXJzIHRvIHVwZGF0ZSBsb2FkZXJEYXRhIGFzIHByb21pc2VzIHNldHRsZVxuICAgIGFjdGl2ZURlZmVycmVkcy5mb3JFYWNoKChkZWZlcnJlZERhdGEsIHJvdXRlSWQpID0+IHtcbiAgICAgIGRlZmVycmVkRGF0YS5zdWJzY3JpYmUoYWJvcnRlZCA9PiB7XG4gICAgICAgIC8vIE5vdGU6IE5vIG5lZWQgdG8gdXBkYXRlU3RhdGUgaGVyZSBzaW5jZSB0aGUgVHJhY2tlZFByb21pc2Ugb25cbiAgICAgICAgLy8gbG9hZGVyRGF0YSBpcyBzdGFibGUgYWNyb3NzIHJlc29sdmUvcmVqZWN0XG4gICAgICAgIC8vIFJlbW92ZSB0aGlzIGluc3RhbmNlIGlmIHdlIHdlcmUgYWJvcnRlZCBvciBpZiBwcm9taXNlcyBoYXZlIHNldHRsZWRcbiAgICAgICAgaWYgKGFib3J0ZWQgfHwgZGVmZXJyZWREYXRhLmRvbmUpIHtcbiAgICAgICAgICBhY3RpdmVEZWZlcnJlZHMuZGVsZXRlKHJvdXRlSWQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICAvLyBQcmVzZXJ2ZSBTU1IgZXJyb3JzIGR1cmluZyBwYXJ0aWFsIGh5ZHJhdGlvblxuICAgIGlmIChmdXR1cmUudjdfcGFydGlhbEh5ZHJhdGlvbiAmJiBpbml0aWFsSHlkcmF0aW9uICYmIHN0YXRlLmVycm9ycykge1xuICAgICAgZXJyb3JzID0gX2V4dGVuZHMoe30sIHN0YXRlLmVycm9ycywgZXJyb3JzKTtcbiAgICB9XG4gICAgbGV0IHVwZGF0ZWRGZXRjaGVycyA9IG1hcmtGZXRjaFJlZGlyZWN0c0RvbmUoKTtcbiAgICBsZXQgZGlkQWJvcnRGZXRjaExvYWRzID0gYWJvcnRTdGFsZUZldGNoTG9hZHMocGVuZGluZ05hdmlnYXRpb25Mb2FkSWQpO1xuICAgIGxldCBzaG91bGRVcGRhdGVGZXRjaGVycyA9IHVwZGF0ZWRGZXRjaGVycyB8fCBkaWRBYm9ydEZldGNoTG9hZHMgfHwgcmV2YWxpZGF0aW5nRmV0Y2hlcnMubGVuZ3RoID4gMDtcbiAgICByZXR1cm4gX2V4dGVuZHMoe1xuICAgICAgbWF0Y2hlcyxcbiAgICAgIGxvYWRlckRhdGEsXG4gICAgICBlcnJvcnNcbiAgICB9LCBzaG91bGRVcGRhdGVGZXRjaGVycyA/IHtcbiAgICAgIGZldGNoZXJzOiBuZXcgTWFwKHN0YXRlLmZldGNoZXJzKVxuICAgIH0gOiB7fSk7XG4gIH1cbiAgZnVuY3Rpb24gZ2V0VXBkYXRlZEFjdGlvbkRhdGEocGVuZGluZ0FjdGlvblJlc3VsdCkge1xuICAgIGlmIChwZW5kaW5nQWN0aW9uUmVzdWx0ICYmICFpc0Vycm9yUmVzdWx0KHBlbmRpbmdBY3Rpb25SZXN1bHRbMV0pKSB7XG4gICAgICAvLyBUaGlzIGlzIGNhc3QgdG8gYGFueWAgY3VycmVudGx5IGJlY2F1c2UgYFJvdXRlRGF0YWB1c2VzIGFueSBhbmQgaXRcbiAgICAgIC8vIHdvdWxkIGJlIGEgYnJlYWtpbmcgY2hhbmdlIHRvIHVzZSBhbnkuXG4gICAgICAvLyBUT0RPOiB2NyAtIGNoYW5nZSBgUm91dGVEYXRhYCB0byB1c2UgYHVua25vd25gIGluc3RlYWQgb2YgYGFueWBcbiAgICAgIHJldHVybiB7XG4gICAgICAgIFtwZW5kaW5nQWN0aW9uUmVzdWx0WzBdXTogcGVuZGluZ0FjdGlvblJlc3VsdFsxXS5kYXRhXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAoc3RhdGUuYWN0aW9uRGF0YSkge1xuICAgICAgaWYgKE9iamVjdC5rZXlzKHN0YXRlLmFjdGlvbkRhdGEpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBzdGF0ZS5hY3Rpb25EYXRhO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBnZXRVcGRhdGVkUmV2YWxpZGF0aW5nRmV0Y2hlcnMocmV2YWxpZGF0aW5nRmV0Y2hlcnMpIHtcbiAgICByZXZhbGlkYXRpbmdGZXRjaGVycy5mb3JFYWNoKHJmID0+IHtcbiAgICAgIGxldCBmZXRjaGVyID0gc3RhdGUuZmV0Y2hlcnMuZ2V0KHJmLmtleSk7XG4gICAgICBsZXQgcmV2YWxpZGF0aW5nRmV0Y2hlciA9IGdldExvYWRpbmdGZXRjaGVyKHVuZGVmaW5lZCwgZmV0Y2hlciA/IGZldGNoZXIuZGF0YSA6IHVuZGVmaW5lZCk7XG4gICAgICBzdGF0ZS5mZXRjaGVycy5zZXQocmYua2V5LCByZXZhbGlkYXRpbmdGZXRjaGVyKTtcbiAgICB9KTtcbiAgICByZXR1cm4gbmV3IE1hcChzdGF0ZS5mZXRjaGVycyk7XG4gIH1cbiAgLy8gVHJpZ2dlciBhIGZldGNoZXIgbG9hZC9zdWJtaXQgZm9yIHRoZSBnaXZlbiBmZXRjaGVyIGtleVxuICBmdW5jdGlvbiBmZXRjaChrZXksIHJvdXRlSWQsIGhyZWYsIG9wdHMpIHtcbiAgICBpZiAoaXNTZXJ2ZXIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcInJvdXRlci5mZXRjaCgpIHdhcyBjYWxsZWQgZHVyaW5nIHRoZSBzZXJ2ZXIgcmVuZGVyLCBidXQgaXQgc2hvdWxkbid0IGJlLiBcIiArIFwiWW91IGFyZSBsaWtlbHkgY2FsbGluZyBhIHVzZUZldGNoZXIoKSBtZXRob2QgaW4gdGhlIGJvZHkgb2YgeW91ciBjb21wb25lbnQuIFwiICsgXCJUcnkgbW92aW5nIGl0IHRvIGEgdXNlRWZmZWN0IG9yIGEgY2FsbGJhY2suXCIpO1xuICAgIH1cbiAgICBhYm9ydEZldGNoZXIoa2V5KTtcbiAgICBsZXQgZmx1c2hTeW5jID0gKG9wdHMgJiYgb3B0cy5mbHVzaFN5bmMpID09PSB0cnVlO1xuICAgIGxldCByb3V0ZXNUb1VzZSA9IGluRmxpZ2h0RGF0YVJvdXRlcyB8fCBkYXRhUm91dGVzO1xuICAgIGxldCBub3JtYWxpemVkUGF0aCA9IG5vcm1hbGl6ZVRvKHN0YXRlLmxvY2F0aW9uLCBzdGF0ZS5tYXRjaGVzLCBiYXNlbmFtZSwgZnV0dXJlLnY3X3ByZXBlbmRCYXNlbmFtZSwgaHJlZiwgZnV0dXJlLnY3X3JlbGF0aXZlU3BsYXRQYXRoLCByb3V0ZUlkLCBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLnJlbGF0aXZlKTtcbiAgICBsZXQgbWF0Y2hlcyA9IG1hdGNoUm91dGVzKHJvdXRlc1RvVXNlLCBub3JtYWxpemVkUGF0aCwgYmFzZW5hbWUpO1xuICAgIGxldCBmb2dPZldhciA9IGNoZWNrRm9nT2ZXYXIobWF0Y2hlcywgcm91dGVzVG9Vc2UsIG5vcm1hbGl6ZWRQYXRoKTtcbiAgICBpZiAoZm9nT2ZXYXIuYWN0aXZlICYmIGZvZ09mV2FyLm1hdGNoZXMpIHtcbiAgICAgIG1hdGNoZXMgPSBmb2dPZldhci5tYXRjaGVzO1xuICAgIH1cbiAgICBpZiAoIW1hdGNoZXMpIHtcbiAgICAgIHNldEZldGNoZXJFcnJvcihrZXksIHJvdXRlSWQsIGdldEludGVybmFsUm91dGVyRXJyb3IoNDA0LCB7XG4gICAgICAgIHBhdGhuYW1lOiBub3JtYWxpemVkUGF0aFxuICAgICAgfSksIHtcbiAgICAgICAgZmx1c2hTeW5jXG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbGV0IHtcbiAgICAgIHBhdGgsXG4gICAgICBzdWJtaXNzaW9uLFxuICAgICAgZXJyb3JcbiAgICB9ID0gbm9ybWFsaXplTmF2aWdhdGVPcHRpb25zKGZ1dHVyZS52N19ub3JtYWxpemVGb3JtTWV0aG9kLCB0cnVlLCBub3JtYWxpemVkUGF0aCwgb3B0cyk7XG4gICAgaWYgKGVycm9yKSB7XG4gICAgICBzZXRGZXRjaGVyRXJyb3Ioa2V5LCByb3V0ZUlkLCBlcnJvciwge1xuICAgICAgICBmbHVzaFN5bmNcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgbWF0Y2ggPSBnZXRUYXJnZXRNYXRjaChtYXRjaGVzLCBwYXRoKTtcbiAgICBsZXQgcHJldmVudFNjcm9sbFJlc2V0ID0gKG9wdHMgJiYgb3B0cy5wcmV2ZW50U2Nyb2xsUmVzZXQpID09PSB0cnVlO1xuICAgIGlmIChzdWJtaXNzaW9uICYmIGlzTXV0YXRpb25NZXRob2Qoc3VibWlzc2lvbi5mb3JtTWV0aG9kKSkge1xuICAgICAgaGFuZGxlRmV0Y2hlckFjdGlvbihrZXksIHJvdXRlSWQsIHBhdGgsIG1hdGNoLCBtYXRjaGVzLCBmb2dPZldhci5hY3RpdmUsIGZsdXNoU3luYywgcHJldmVudFNjcm9sbFJlc2V0LCBzdWJtaXNzaW9uKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gU3RvcmUgb2ZmIHRoZSBtYXRjaCBzbyB3ZSBjYW4gY2FsbCBpdCdzIHNob3VsZFJldmFsaWRhdGUgb24gc3Vic2VxdWVudFxuICAgIC8vIHJldmFsaWRhdGlvbnNcbiAgICBmZXRjaExvYWRNYXRjaGVzLnNldChrZXksIHtcbiAgICAgIHJvdXRlSWQsXG4gICAgICBwYXRoXG4gICAgfSk7XG4gICAgaGFuZGxlRmV0Y2hlckxvYWRlcihrZXksIHJvdXRlSWQsIHBhdGgsIG1hdGNoLCBtYXRjaGVzLCBmb2dPZldhci5hY3RpdmUsIGZsdXNoU3luYywgcHJldmVudFNjcm9sbFJlc2V0LCBzdWJtaXNzaW9uKTtcbiAgfVxuICAvLyBDYWxsIHRoZSBhY3Rpb24gZm9yIHRoZSBtYXRjaGVkIGZldGNoZXIuc3VibWl0KCksIGFuZCB0aGVuIGhhbmRsZSByZWRpcmVjdHMsXG4gIC8vIGVycm9ycywgYW5kIHJldmFsaWRhdGlvblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVGZXRjaGVyQWN0aW9uKGtleSwgcm91dGVJZCwgcGF0aCwgbWF0Y2gsIHJlcXVlc3RNYXRjaGVzLCBpc0ZvZ09mV2FyLCBmbHVzaFN5bmMsIHByZXZlbnRTY3JvbGxSZXNldCwgc3VibWlzc2lvbikge1xuICAgIGludGVycnVwdEFjdGl2ZUxvYWRzKCk7XG4gICAgZmV0Y2hMb2FkTWF0Y2hlcy5kZWxldGUoa2V5KTtcbiAgICBmdW5jdGlvbiBkZXRlY3RBbmRIYW5kbGU0MDVFcnJvcihtKSB7XG4gICAgICBpZiAoIW0ucm91dGUuYWN0aW9uICYmICFtLnJvdXRlLmxhenkpIHtcbiAgICAgICAgbGV0IGVycm9yID0gZ2V0SW50ZXJuYWxSb3V0ZXJFcnJvcig0MDUsIHtcbiAgICAgICAgICBtZXRob2Q6IHN1Ym1pc3Npb24uZm9ybU1ldGhvZCxcbiAgICAgICAgICBwYXRobmFtZTogcGF0aCxcbiAgICAgICAgICByb3V0ZUlkOiByb3V0ZUlkXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRGZXRjaGVyRXJyb3Ioa2V5LCByb3V0ZUlkLCBlcnJvciwge1xuICAgICAgICAgIGZsdXNoU3luY1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICghaXNGb2dPZldhciAmJiBkZXRlY3RBbmRIYW5kbGU0MDVFcnJvcihtYXRjaCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gUHV0IHRoaXMgZmV0Y2hlciBpbnRvIGl0J3Mgc3VibWl0dGluZyBzdGF0ZVxuICAgIGxldCBleGlzdGluZ0ZldGNoZXIgPSBzdGF0ZS5mZXRjaGVycy5nZXQoa2V5KTtcbiAgICB1cGRhdGVGZXRjaGVyU3RhdGUoa2V5LCBnZXRTdWJtaXR0aW5nRmV0Y2hlcihzdWJtaXNzaW9uLCBleGlzdGluZ0ZldGNoZXIpLCB7XG4gICAgICBmbHVzaFN5bmNcbiAgICB9KTtcbiAgICBsZXQgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGxldCBmZXRjaFJlcXVlc3QgPSBjcmVhdGVDbGllbnRTaWRlUmVxdWVzdChpbml0Lmhpc3RvcnksIHBhdGgsIGFib3J0Q29udHJvbGxlci5zaWduYWwsIHN1Ym1pc3Npb24pO1xuICAgIGlmIChpc0ZvZ09mV2FyKSB7XG4gICAgICBsZXQgZGlzY292ZXJSZXN1bHQgPSBhd2FpdCBkaXNjb3ZlclJvdXRlcyhyZXF1ZXN0TWF0Y2hlcywgbmV3IFVSTChmZXRjaFJlcXVlc3QudXJsKS5wYXRobmFtZSwgZmV0Y2hSZXF1ZXN0LnNpZ25hbCwga2V5KTtcbiAgICAgIGlmIChkaXNjb3ZlclJlc3VsdC50eXBlID09PSBcImFib3J0ZWRcIikge1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2UgaWYgKGRpc2NvdmVyUmVzdWx0LnR5cGUgPT09IFwiZXJyb3JcIikge1xuICAgICAgICBzZXRGZXRjaGVyRXJyb3Ioa2V5LCByb3V0ZUlkLCBkaXNjb3ZlclJlc3VsdC5lcnJvciwge1xuICAgICAgICAgIGZsdXNoU3luY1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIGlmICghZGlzY292ZXJSZXN1bHQubWF0Y2hlcykge1xuICAgICAgICBzZXRGZXRjaGVyRXJyb3Ioa2V5LCByb3V0ZUlkLCBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwNCwge1xuICAgICAgICAgIHBhdGhuYW1lOiBwYXRoXG4gICAgICAgIH0pLCB7XG4gICAgICAgICAgZmx1c2hTeW5jXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXF1ZXN0TWF0Y2hlcyA9IGRpc2NvdmVyUmVzdWx0Lm1hdGNoZXM7XG4gICAgICAgIG1hdGNoID0gZ2V0VGFyZ2V0TWF0Y2gocmVxdWVzdE1hdGNoZXMsIHBhdGgpO1xuICAgICAgICBpZiAoZGV0ZWN0QW5kSGFuZGxlNDA1RXJyb3IobWF0Y2gpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIC8vIENhbGwgdGhlIGFjdGlvbiBmb3IgdGhlIGZldGNoZXJcbiAgICBmZXRjaENvbnRyb2xsZXJzLnNldChrZXksIGFib3J0Q29udHJvbGxlcik7XG4gICAgbGV0IG9yaWdpbmF0aW5nTG9hZElkID0gaW5jcmVtZW50aW5nTG9hZElkO1xuICAgIGxldCBhY3Rpb25SZXN1bHRzID0gYXdhaXQgY2FsbERhdGFTdHJhdGVneShcImFjdGlvblwiLCBzdGF0ZSwgZmV0Y2hSZXF1ZXN0LCBbbWF0Y2hdLCByZXF1ZXN0TWF0Y2hlcywga2V5KTtcbiAgICBsZXQgYWN0aW9uUmVzdWx0ID0gYWN0aW9uUmVzdWx0c1ttYXRjaC5yb3V0ZS5pZF07XG4gICAgaWYgKGZldGNoUmVxdWVzdC5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgLy8gV2UgY2FuIGRlbGV0ZSB0aGlzIHNvIGxvbmcgYXMgd2Ugd2VyZW4ndCBhYm9ydGVkIGJ5IG91ciBvd24gZmV0Y2hlclxuICAgICAgLy8gcmUtc3VibWl0IHdoaWNoIHdvdWxkIGhhdmUgcHV0IF9uZXdfIGNvbnRyb2xsZXIgaXMgaW4gZmV0Y2hDb250cm9sbGVyc1xuICAgICAgaWYgKGZldGNoQ29udHJvbGxlcnMuZ2V0KGtleSkgPT09IGFib3J0Q29udHJvbGxlcikge1xuICAgICAgICBmZXRjaENvbnRyb2xsZXJzLmRlbGV0ZShrZXkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBXaGVuIHVzaW5nIHY3X2ZldGNoZXJQZXJzaXN0LCB3ZSBkb24ndCB3YW50IGVycm9ycyBidWJibGluZyB1cCB0byB0aGUgVUlcbiAgICAvLyBvciByZWRpcmVjdHMgcHJvY2Vzc2VkIGZvciB1bm1vdW50ZWQgZmV0Y2hlcnMgc28gd2UganVzdCByZXZlcnQgdGhlbSB0b1xuICAgIC8vIGlkbGVcbiAgICBpZiAoZnV0dXJlLnY3X2ZldGNoZXJQZXJzaXN0ICYmIGRlbGV0ZWRGZXRjaGVycy5oYXMoa2V5KSkge1xuICAgICAgaWYgKGlzUmVkaXJlY3RSZXN1bHQoYWN0aW9uUmVzdWx0KSB8fCBpc0Vycm9yUmVzdWx0KGFjdGlvblJlc3VsdCkpIHtcbiAgICAgICAgdXBkYXRlRmV0Y2hlclN0YXRlKGtleSwgZ2V0RG9uZUZldGNoZXIodW5kZWZpbmVkKSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIC8vIExldCBTdWNjZXNzUmVzdWx0J3MgZmFsbCB0aHJvdWdoIGZvciByZXZhbGlkYXRpb25cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGlzUmVkaXJlY3RSZXN1bHQoYWN0aW9uUmVzdWx0KSkge1xuICAgICAgICBmZXRjaENvbnRyb2xsZXJzLmRlbGV0ZShrZXkpO1xuICAgICAgICBpZiAocGVuZGluZ05hdmlnYXRpb25Mb2FkSWQgPiBvcmlnaW5hdGluZ0xvYWRJZCkge1xuICAgICAgICAgIC8vIEEgbmV3IG5hdmlnYXRpb24gd2FzIGtpY2tlZCBvZmYgYWZ0ZXIgb3VyIGFjdGlvbiBzdGFydGVkLCBzbyB0aGF0XG4gICAgICAgICAgLy8gc2hvdWxkIHRha2UgcHJlY2VkZW5jZSBvdmVyIHRoaXMgcmVkaXJlY3QgbmF2aWdhdGlvbi4gIFdlIGFscmVhZHlcbiAgICAgICAgICAvLyBzZXQgaXNSZXZhbGlkYXRpb25SZXF1aXJlZCBzbyBhbGwgbG9hZGVycyBmb3IgdGhlIG5ldyByb3V0ZSBzaG91bGRcbiAgICAgICAgICAvLyBmaXJlIHVubGVzcyBvcHRlZCBvdXQgdmlhIHNob3VsZFJldmFsaWRhdGVcbiAgICAgICAgICB1cGRhdGVGZXRjaGVyU3RhdGUoa2V5LCBnZXREb25lRmV0Y2hlcih1bmRlZmluZWQpKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZmV0Y2hSZWRpcmVjdElkcy5hZGQoa2V5KTtcbiAgICAgICAgICB1cGRhdGVGZXRjaGVyU3RhdGUoa2V5LCBnZXRMb2FkaW5nRmV0Y2hlcihzdWJtaXNzaW9uKSk7XG4gICAgICAgICAgcmV0dXJuIHN0YXJ0UmVkaXJlY3ROYXZpZ2F0aW9uKGZldGNoUmVxdWVzdCwgYWN0aW9uUmVzdWx0LCBmYWxzZSwge1xuICAgICAgICAgICAgZmV0Y2hlclN1Ym1pc3Npb246IHN1Ym1pc3Npb24sXG4gICAgICAgICAgICBwcmV2ZW50U2Nyb2xsUmVzZXRcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLy8gUHJvY2VzcyBhbnkgbm9uLXJlZGlyZWN0IGVycm9ycyB0aHJvd25cbiAgICAgIGlmIChpc0Vycm9yUmVzdWx0KGFjdGlvblJlc3VsdCkpIHtcbiAgICAgICAgc2V0RmV0Y2hlckVycm9yKGtleSwgcm91dGVJZCwgYWN0aW9uUmVzdWx0LmVycm9yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoaXNEZWZlcnJlZFJlc3VsdChhY3Rpb25SZXN1bHQpKSB7XG4gICAgICB0aHJvdyBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwMCwge1xuICAgICAgICB0eXBlOiBcImRlZmVyLWFjdGlvblwiXG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gU3RhcnQgdGhlIGRhdGEgbG9hZCBmb3IgY3VycmVudCBtYXRjaGVzLCBvciB0aGUgbmV4dCBsb2NhdGlvbiBpZiB3ZSdyZVxuICAgIC8vIGluIHRoZSBtaWRkbGUgb2YgYSBuYXZpZ2F0aW9uXG4gICAgbGV0IG5leHRMb2NhdGlvbiA9IHN0YXRlLm5hdmlnYXRpb24ubG9jYXRpb24gfHwgc3RhdGUubG9jYXRpb247XG4gICAgbGV0IHJldmFsaWRhdGlvblJlcXVlc3QgPSBjcmVhdGVDbGllbnRTaWRlUmVxdWVzdChpbml0Lmhpc3RvcnksIG5leHRMb2NhdGlvbiwgYWJvcnRDb250cm9sbGVyLnNpZ25hbCk7XG4gICAgbGV0IHJvdXRlc1RvVXNlID0gaW5GbGlnaHREYXRhUm91dGVzIHx8IGRhdGFSb3V0ZXM7XG4gICAgbGV0IG1hdGNoZXMgPSBzdGF0ZS5uYXZpZ2F0aW9uLnN0YXRlICE9PSBcImlkbGVcIiA/IG1hdGNoUm91dGVzKHJvdXRlc1RvVXNlLCBzdGF0ZS5uYXZpZ2F0aW9uLmxvY2F0aW9uLCBiYXNlbmFtZSkgOiBzdGF0ZS5tYXRjaGVzO1xuICAgIGludmFyaWFudChtYXRjaGVzLCBcIkRpZG4ndCBmaW5kIGFueSBtYXRjaGVzIGFmdGVyIGZldGNoZXIgYWN0aW9uXCIpO1xuICAgIGxldCBsb2FkSWQgPSArK2luY3JlbWVudGluZ0xvYWRJZDtcbiAgICBmZXRjaFJlbG9hZElkcy5zZXQoa2V5LCBsb2FkSWQpO1xuICAgIGxldCBsb2FkRmV0Y2hlciA9IGdldExvYWRpbmdGZXRjaGVyKHN1Ym1pc3Npb24sIGFjdGlvblJlc3VsdC5kYXRhKTtcbiAgICBzdGF0ZS5mZXRjaGVycy5zZXQoa2V5LCBsb2FkRmV0Y2hlcik7XG4gICAgbGV0IFttYXRjaGVzVG9Mb2FkLCByZXZhbGlkYXRpbmdGZXRjaGVyc10gPSBnZXRNYXRjaGVzVG9Mb2FkKGluaXQuaGlzdG9yeSwgc3RhdGUsIG1hdGNoZXMsIHN1Ym1pc3Npb24sIG5leHRMb2NhdGlvbiwgZmFsc2UsIGZ1dHVyZS52N19za2lwQWN0aW9uRXJyb3JSZXZhbGlkYXRpb24sIGlzUmV2YWxpZGF0aW9uUmVxdWlyZWQsIGNhbmNlbGxlZERlZmVycmVkUm91dGVzLCBjYW5jZWxsZWRGZXRjaGVyTG9hZHMsIGRlbGV0ZWRGZXRjaGVycywgZmV0Y2hMb2FkTWF0Y2hlcywgZmV0Y2hSZWRpcmVjdElkcywgcm91dGVzVG9Vc2UsIGJhc2VuYW1lLCBbbWF0Y2gucm91dGUuaWQsIGFjdGlvblJlc3VsdF0pO1xuICAgIC8vIFB1dCBhbGwgcmV2YWxpZGF0aW5nIGZldGNoZXJzIGludG8gdGhlIGxvYWRpbmcgc3RhdGUsIGV4Y2VwdCBmb3IgdGhlXG4gICAgLy8gY3VycmVudCBmZXRjaGVyIHdoaWNoIHdlIHdhbnQgdG8ga2VlcCBpbiBpdCdzIGN1cnJlbnQgbG9hZGluZyBzdGF0ZSB3aGljaFxuICAgIC8vIGNvbnRhaW5zIGl0J3MgYWN0aW9uIHN1Ym1pc3Npb24gaW5mbyArIGFjdGlvbiBkYXRhXG4gICAgcmV2YWxpZGF0aW5nRmV0Y2hlcnMuZmlsdGVyKHJmID0+IHJmLmtleSAhPT0ga2V5KS5mb3JFYWNoKHJmID0+IHtcbiAgICAgIGxldCBzdGFsZUtleSA9IHJmLmtleTtcbiAgICAgIGxldCBleGlzdGluZ0ZldGNoZXIgPSBzdGF0ZS5mZXRjaGVycy5nZXQoc3RhbGVLZXkpO1xuICAgICAgbGV0IHJldmFsaWRhdGluZ0ZldGNoZXIgPSBnZXRMb2FkaW5nRmV0Y2hlcih1bmRlZmluZWQsIGV4aXN0aW5nRmV0Y2hlciA/IGV4aXN0aW5nRmV0Y2hlci5kYXRhIDogdW5kZWZpbmVkKTtcbiAgICAgIHN0YXRlLmZldGNoZXJzLnNldChzdGFsZUtleSwgcmV2YWxpZGF0aW5nRmV0Y2hlcik7XG4gICAgICBhYm9ydEZldGNoZXIoc3RhbGVLZXkpO1xuICAgICAgaWYgKHJmLmNvbnRyb2xsZXIpIHtcbiAgICAgICAgZmV0Y2hDb250cm9sbGVycy5zZXQoc3RhbGVLZXksIHJmLmNvbnRyb2xsZXIpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHVwZGF0ZVN0YXRlKHtcbiAgICAgIGZldGNoZXJzOiBuZXcgTWFwKHN0YXRlLmZldGNoZXJzKVxuICAgIH0pO1xuICAgIGxldCBhYm9ydFBlbmRpbmdGZXRjaFJldmFsaWRhdGlvbnMgPSAoKSA9PiByZXZhbGlkYXRpbmdGZXRjaGVycy5mb3JFYWNoKHJmID0+IGFib3J0RmV0Y2hlcihyZi5rZXkpKTtcbiAgICBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydFBlbmRpbmdGZXRjaFJldmFsaWRhdGlvbnMpO1xuICAgIGxldCB7XG4gICAgICBsb2FkZXJSZXN1bHRzLFxuICAgICAgZmV0Y2hlclJlc3VsdHNcbiAgICB9ID0gYXdhaXQgY2FsbExvYWRlcnNBbmRNYXliZVJlc29sdmVEYXRhKHN0YXRlLCBtYXRjaGVzLCBtYXRjaGVzVG9Mb2FkLCByZXZhbGlkYXRpbmdGZXRjaGVycywgcmV2YWxpZGF0aW9uUmVxdWVzdCk7XG4gICAgaWYgKGFib3J0Q29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydFBlbmRpbmdGZXRjaFJldmFsaWRhdGlvbnMpO1xuICAgIGZldGNoUmVsb2FkSWRzLmRlbGV0ZShrZXkpO1xuICAgIGZldGNoQ29udHJvbGxlcnMuZGVsZXRlKGtleSk7XG4gICAgcmV2YWxpZGF0aW5nRmV0Y2hlcnMuZm9yRWFjaChyID0+IGZldGNoQ29udHJvbGxlcnMuZGVsZXRlKHIua2V5KSk7XG4gICAgbGV0IHJlZGlyZWN0ID0gZmluZFJlZGlyZWN0KGxvYWRlclJlc3VsdHMpO1xuICAgIGlmIChyZWRpcmVjdCkge1xuICAgICAgcmV0dXJuIHN0YXJ0UmVkaXJlY3ROYXZpZ2F0aW9uKHJldmFsaWRhdGlvblJlcXVlc3QsIHJlZGlyZWN0LnJlc3VsdCwgZmFsc2UsIHtcbiAgICAgICAgcHJldmVudFNjcm9sbFJlc2V0XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmVkaXJlY3QgPSBmaW5kUmVkaXJlY3QoZmV0Y2hlclJlc3VsdHMpO1xuICAgIGlmIChyZWRpcmVjdCkge1xuICAgICAgLy8gSWYgdGhpcyByZWRpcmVjdCBjYW1lIGZyb20gYSBmZXRjaGVyIG1ha2Ugc3VyZSB3ZSBtYXJrIGl0IGluXG4gICAgICAvLyBmZXRjaFJlZGlyZWN0SWRzIHNvIGl0IGRvZXNuJ3QgZ2V0IHJldmFsaWRhdGVkIG9uIHRoZSBuZXh0IHNldCBvZlxuICAgICAgLy8gbG9hZGVyIGV4ZWN1dGlvbnNcbiAgICAgIGZldGNoUmVkaXJlY3RJZHMuYWRkKHJlZGlyZWN0LmtleSk7XG4gICAgICByZXR1cm4gc3RhcnRSZWRpcmVjdE5hdmlnYXRpb24ocmV2YWxpZGF0aW9uUmVxdWVzdCwgcmVkaXJlY3QucmVzdWx0LCBmYWxzZSwge1xuICAgICAgICBwcmV2ZW50U2Nyb2xsUmVzZXRcbiAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBQcm9jZXNzIGFuZCBjb21taXQgb3V0cHV0IGZyb20gbG9hZGVyc1xuICAgIGxldCB7XG4gICAgICBsb2FkZXJEYXRhLFxuICAgICAgZXJyb3JzXG4gICAgfSA9IHByb2Nlc3NMb2FkZXJEYXRhKHN0YXRlLCBtYXRjaGVzLCBsb2FkZXJSZXN1bHRzLCB1bmRlZmluZWQsIHJldmFsaWRhdGluZ0ZldGNoZXJzLCBmZXRjaGVyUmVzdWx0cywgYWN0aXZlRGVmZXJyZWRzKTtcbiAgICAvLyBTaW5jZSB3ZSBsZXQgcmV2YWxpZGF0aW9ucyBjb21wbGV0ZSBldmVuIGlmIHRoZSBzdWJtaXR0aW5nIGZldGNoZXIgd2FzXG4gICAgLy8gZGVsZXRlZCwgb25seSBwdXQgaXQgYmFjayB0byBpZGxlIGlmIGl0IGhhc24ndCBiZWVuIGRlbGV0ZWRcbiAgICBpZiAoc3RhdGUuZmV0Y2hlcnMuaGFzKGtleSkpIHtcbiAgICAgIGxldCBkb25lRmV0Y2hlciA9IGdldERvbmVGZXRjaGVyKGFjdGlvblJlc3VsdC5kYXRhKTtcbiAgICAgIHN0YXRlLmZldGNoZXJzLnNldChrZXksIGRvbmVGZXRjaGVyKTtcbiAgICB9XG4gICAgYWJvcnRTdGFsZUZldGNoTG9hZHMobG9hZElkKTtcbiAgICAvLyBJZiB3ZSBhcmUgY3VycmVudGx5IGluIGEgbmF2aWdhdGlvbiBsb2FkaW5nIHN0YXRlIGFuZCB0aGlzIGZldGNoZXIgaXNcbiAgICAvLyBtb3JlIHJlY2VudCB0aGFuIHRoZSBuYXZpZ2F0aW9uLCB3ZSB3YW50IHRoZSBuZXdlciBkYXRhIHNvIGFib3J0IHRoZVxuICAgIC8vIG5hdmlnYXRpb24gYW5kIGNvbXBsZXRlIGl0IHdpdGggdGhlIGZldGNoZXIgZGF0YVxuICAgIGlmIChzdGF0ZS5uYXZpZ2F0aW9uLnN0YXRlID09PSBcImxvYWRpbmdcIiAmJiBsb2FkSWQgPiBwZW5kaW5nTmF2aWdhdGlvbkxvYWRJZCkge1xuICAgICAgaW52YXJpYW50KHBlbmRpbmdBY3Rpb24sIFwiRXhwZWN0ZWQgcGVuZGluZyBhY3Rpb25cIik7XG4gICAgICBwZW5kaW5nTmF2aWdhdGlvbkNvbnRyb2xsZXIgJiYgcGVuZGluZ05hdmlnYXRpb25Db250cm9sbGVyLmFib3J0KCk7XG4gICAgICBjb21wbGV0ZU5hdmlnYXRpb24oc3RhdGUubmF2aWdhdGlvbi5sb2NhdGlvbiwge1xuICAgICAgICBtYXRjaGVzLFxuICAgICAgICBsb2FkZXJEYXRhLFxuICAgICAgICBlcnJvcnMsXG4gICAgICAgIGZldGNoZXJzOiBuZXcgTWFwKHN0YXRlLmZldGNoZXJzKVxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIG90aGVyd2lzZSBqdXN0IHVwZGF0ZSB3aXRoIHRoZSBmZXRjaGVyIGRhdGEsIHByZXNlcnZpbmcgYW55IGV4aXN0aW5nXG4gICAgICAvLyBsb2FkZXJEYXRhIGZvciBsb2FkZXJzIHRoYXQgZGlkIG5vdCBuZWVkIHRvIHJlbG9hZC4gIFdlIGhhdmUgdG9cbiAgICAgIC8vIG1hbnVhbGx5IG1lcmdlIGhlcmUgc2luY2Ugd2UgYXJlbid0IGdvaW5nIHRocm91Z2ggY29tcGxldGVOYXZpZ2F0aW9uXG4gICAgICB1cGRhdGVTdGF0ZSh7XG4gICAgICAgIGVycm9ycyxcbiAgICAgICAgbG9hZGVyRGF0YTogbWVyZ2VMb2FkZXJEYXRhKHN0YXRlLmxvYWRlckRhdGEsIGxvYWRlckRhdGEsIG1hdGNoZXMsIGVycm9ycyksXG4gICAgICAgIGZldGNoZXJzOiBuZXcgTWFwKHN0YXRlLmZldGNoZXJzKVxuICAgICAgfSk7XG4gICAgICBpc1JldmFsaWRhdGlvblJlcXVpcmVkID0gZmFsc2U7XG4gICAgfVxuICB9XG4gIC8vIENhbGwgdGhlIG1hdGNoZWQgbG9hZGVyIGZvciBmZXRjaGVyLmxvYWQoKSwgaGFuZGxpbmcgcmVkaXJlY3RzLCBlcnJvcnMsIGV0Yy5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlRmV0Y2hlckxvYWRlcihrZXksIHJvdXRlSWQsIHBhdGgsIG1hdGNoLCBtYXRjaGVzLCBpc0ZvZ09mV2FyLCBmbHVzaFN5bmMsIHByZXZlbnRTY3JvbGxSZXNldCwgc3VibWlzc2lvbikge1xuICAgIGxldCBleGlzdGluZ0ZldGNoZXIgPSBzdGF0ZS5mZXRjaGVycy5nZXQoa2V5KTtcbiAgICB1cGRhdGVGZXRjaGVyU3RhdGUoa2V5LCBnZXRMb2FkaW5nRmV0Y2hlcihzdWJtaXNzaW9uLCBleGlzdGluZ0ZldGNoZXIgPyBleGlzdGluZ0ZldGNoZXIuZGF0YSA6IHVuZGVmaW5lZCksIHtcbiAgICAgIGZsdXNoU3luY1xuICAgIH0pO1xuICAgIGxldCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgbGV0IGZldGNoUmVxdWVzdCA9IGNyZWF0ZUNsaWVudFNpZGVSZXF1ZXN0KGluaXQuaGlzdG9yeSwgcGF0aCwgYWJvcnRDb250cm9sbGVyLnNpZ25hbCk7XG4gICAgaWYgKGlzRm9nT2ZXYXIpIHtcbiAgICAgIGxldCBkaXNjb3ZlclJlc3VsdCA9IGF3YWl0IGRpc2NvdmVyUm91dGVzKG1hdGNoZXMsIG5ldyBVUkwoZmV0Y2hSZXF1ZXN0LnVybCkucGF0aG5hbWUsIGZldGNoUmVxdWVzdC5zaWduYWwsIGtleSk7XG4gICAgICBpZiAoZGlzY292ZXJSZXN1bHQudHlwZSA9PT0gXCJhYm9ydGVkXCIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIGlmIChkaXNjb3ZlclJlc3VsdC50eXBlID09PSBcImVycm9yXCIpIHtcbiAgICAgICAgc2V0RmV0Y2hlckVycm9yKGtleSwgcm91dGVJZCwgZGlzY292ZXJSZXN1bHQuZXJyb3IsIHtcbiAgICAgICAgICBmbHVzaFN5bmNcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gZWxzZSBpZiAoIWRpc2NvdmVyUmVzdWx0Lm1hdGNoZXMpIHtcbiAgICAgICAgc2V0RmV0Y2hlckVycm9yKGtleSwgcm91dGVJZCwgZ2V0SW50ZXJuYWxSb3V0ZXJFcnJvcig0MDQsIHtcbiAgICAgICAgICBwYXRobmFtZTogcGF0aFxuICAgICAgICB9KSwge1xuICAgICAgICAgIGZsdXNoU3luY1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWF0Y2hlcyA9IGRpc2NvdmVyUmVzdWx0Lm1hdGNoZXM7XG4gICAgICAgIG1hdGNoID0gZ2V0VGFyZ2V0TWF0Y2gobWF0Y2hlcywgcGF0aCk7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIENhbGwgdGhlIGxvYWRlciBmb3IgdGhpcyBmZXRjaGVyIHJvdXRlIG1hdGNoXG4gICAgZmV0Y2hDb250cm9sbGVycy5zZXQoa2V5LCBhYm9ydENvbnRyb2xsZXIpO1xuICAgIGxldCBvcmlnaW5hdGluZ0xvYWRJZCA9IGluY3JlbWVudGluZ0xvYWRJZDtcbiAgICBsZXQgcmVzdWx0cyA9IGF3YWl0IGNhbGxEYXRhU3RyYXRlZ3koXCJsb2FkZXJcIiwgc3RhdGUsIGZldGNoUmVxdWVzdCwgW21hdGNoXSwgbWF0Y2hlcywga2V5KTtcbiAgICBsZXQgcmVzdWx0ID0gcmVzdWx0c1ttYXRjaC5yb3V0ZS5pZF07XG4gICAgLy8gRGVmZXJyZWQgaXNuJ3Qgc3VwcG9ydGVkIGZvciBmZXRjaGVyIGxvYWRzLCBhd2FpdCBldmVyeXRoaW5nIGFuZCB0cmVhdCBpdFxuICAgIC8vIGFzIGEgbm9ybWFsIGxvYWQuICByZXNvbHZlRGVmZXJyZWREYXRhIHdpbGwgcmV0dXJuIHVuZGVmaW5lZCBpZiB0aGlzXG4gICAgLy8gZmV0Y2hlciBnZXRzIGFib3J0ZWQsIHNvIHdlIGp1c3QgbGVhdmUgcmVzdWx0IHVudG91Y2hlZCBhbmQgc2hvcnQgY2lyY3VpdFxuICAgIC8vIGJlbG93IGlmIHRoYXQgaGFwcGVuc1xuICAgIGlmIChpc0RlZmVycmVkUmVzdWx0KHJlc3VsdCkpIHtcbiAgICAgIHJlc3VsdCA9IChhd2FpdCByZXNvbHZlRGVmZXJyZWREYXRhKHJlc3VsdCwgZmV0Y2hSZXF1ZXN0LnNpZ25hbCwgdHJ1ZSkpIHx8IHJlc3VsdDtcbiAgICB9XG4gICAgLy8gV2UgY2FuIGRlbGV0ZSB0aGlzIHNvIGxvbmcgYXMgd2Ugd2VyZW4ndCBhYm9ydGVkIGJ5IG91ciBvdXIgb3duIGZldGNoZXJcbiAgICAvLyByZS1sb2FkIHdoaWNoIHdvdWxkIGhhdmUgcHV0IF9uZXdfIGNvbnRyb2xsZXIgaXMgaW4gZmV0Y2hDb250cm9sbGVyc1xuICAgIGlmIChmZXRjaENvbnRyb2xsZXJzLmdldChrZXkpID09PSBhYm9ydENvbnRyb2xsZXIpIHtcbiAgICAgIGZldGNoQ29udHJvbGxlcnMuZGVsZXRlKGtleSk7XG4gICAgfVxuICAgIGlmIChmZXRjaFJlcXVlc3Quc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gV2UgZG9uJ3Qgd2FudCBlcnJvcnMgYnViYmxpbmcgdXAgb3IgcmVkaXJlY3RzIGZvbGxvd2VkIGZvciB1bm1vdW50ZWRcbiAgICAvLyBmZXRjaGVycywgc28gc2hvcnQgY2lyY3VpdCBoZXJlIGlmIGl0IHdhcyByZW1vdmVkIGZyb20gdGhlIFVJXG4gICAgaWYgKGRlbGV0ZWRGZXRjaGVycy5oYXMoa2V5KSkge1xuICAgICAgdXBkYXRlRmV0Y2hlclN0YXRlKGtleSwgZ2V0RG9uZUZldGNoZXIodW5kZWZpbmVkKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIElmIHRoZSBsb2FkZXIgdGhyZXcgYSByZWRpcmVjdCBSZXNwb25zZSwgc3RhcnQgYSBuZXcgUkVQTEFDRSBuYXZpZ2F0aW9uXG4gICAgaWYgKGlzUmVkaXJlY3RSZXN1bHQocmVzdWx0KSkge1xuICAgICAgaWYgKHBlbmRpbmdOYXZpZ2F0aW9uTG9hZElkID4gb3JpZ2luYXRpbmdMb2FkSWQpIHtcbiAgICAgICAgLy8gQSBuZXcgbmF2aWdhdGlvbiB3YXMga2lja2VkIG9mZiBhZnRlciBvdXIgbG9hZGVyIHN0YXJ0ZWQsIHNvIHRoYXRcbiAgICAgICAgLy8gc2hvdWxkIHRha2UgcHJlY2VkZW5jZSBvdmVyIHRoaXMgcmVkaXJlY3QgbmF2aWdhdGlvblxuICAgICAgICB1cGRhdGVGZXRjaGVyU3RhdGUoa2V5LCBnZXREb25lRmV0Y2hlcih1bmRlZmluZWQpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZmV0Y2hSZWRpcmVjdElkcy5hZGQoa2V5KTtcbiAgICAgICAgYXdhaXQgc3RhcnRSZWRpcmVjdE5hdmlnYXRpb24oZmV0Y2hSZXF1ZXN0LCByZXN1bHQsIGZhbHNlLCB7XG4gICAgICAgICAgcHJldmVudFNjcm9sbFJlc2V0XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFByb2Nlc3MgYW55IG5vbi1yZWRpcmVjdCBlcnJvcnMgdGhyb3duXG4gICAgaWYgKGlzRXJyb3JSZXN1bHQocmVzdWx0KSkge1xuICAgICAgc2V0RmV0Y2hlckVycm9yKGtleSwgcm91dGVJZCwgcmVzdWx0LmVycm9yKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaW52YXJpYW50KCFpc0RlZmVycmVkUmVzdWx0KHJlc3VsdCksIFwiVW5oYW5kbGVkIGZldGNoZXIgZGVmZXJyZWQgZGF0YVwiKTtcbiAgICAvLyBQdXQgdGhlIGZldGNoZXIgYmFjayBpbnRvIGFuIGlkbGUgc3RhdGVcbiAgICB1cGRhdGVGZXRjaGVyU3RhdGUoa2V5LCBnZXREb25lRmV0Y2hlcihyZXN1bHQuZGF0YSkpO1xuICB9XG4gIC8qKlxuICAgKiBVdGlsaXR5IGZ1bmN0aW9uIHRvIGhhbmRsZSByZWRpcmVjdHMgcmV0dXJuZWQgZnJvbSBhbiBhY3Rpb24gb3IgbG9hZGVyLlxuICAgKiBOb3JtYWxseSwgYSByZWRpcmVjdCBcInJlcGxhY2VzXCIgdGhlIG5hdmlnYXRpb24gdGhhdCB0cmlnZ2VyZWQgaXQuICBTbywgZm9yXG4gICAqIGV4YW1wbGU6XG4gICAqXG4gICAqICAtIHVzZXIgaXMgb24gL2FcbiAgICogIC0gdXNlciBjbGlja3MgYSBsaW5rIHRvIC9iXG4gICAqICAtIGxvYWRlciBmb3IgL2IgcmVkaXJlY3RzIHRvIC9jXG4gICAqXG4gICAqIEluIGEgbm9uLUpTIGFwcCB0aGUgYnJvd3NlciB3b3VsZCB0cmFjayB0aGUgaW4tZmxpZ2h0IG5hdmlnYXRpb24gdG8gL2IgYW5kXG4gICAqIHRoZW4gcmVwbGFjZSBpdCB3aXRoIC9jIHdoZW4gaXQgZW5jb3VudGVyZWQgdGhlIHJlZGlyZWN0IHJlc3BvbnNlLiAgSW5cbiAgICogdGhlIGVuZCBpdCB3b3VsZCBvbmx5IGV2ZXIgdXBkYXRlIHRoZSBVUkwgYmFyIHdpdGggL2MuXG4gICAqXG4gICAqIEluIGNsaWVudC1zaWRlIHJvdXRpbmcgdXNpbmcgcHVzaFN0YXRlL3JlcGxhY2VTdGF0ZSwgd2UgYWltIHRvIGVtdWxhdGVcbiAgICogdGhpcyBiZWhhdmlvciBhbmQgd2UgYWxzbyBkbyBub3QgdXBkYXRlIGhpc3RvcnkgdW50aWwgdGhlIGVuZCBvZiB0aGVcbiAgICogbmF2aWdhdGlvbiAoaW5jbHVkaW5nIHByb2Nlc3NlZCByZWRpcmVjdHMpLiAgVGhpcyBtZWFucyB0aGF0IHdlIG5ldmVyXG4gICAqIGFjdHVhbGx5IHRvdWNoIGhpc3RvcnkgdW50aWwgd2UndmUgcHJvY2Vzc2VkIHJlZGlyZWN0cywgc28gd2UganVzdCB1c2VcbiAgICogdGhlIGhpc3RvcnkgYWN0aW9uIGZyb20gdGhlIG9yaWdpbmFsIG5hdmlnYXRpb24gKFBVU0ggb3IgUkVQTEFDRSkuXG4gICAqL1xuICBhc3luYyBmdW5jdGlvbiBzdGFydFJlZGlyZWN0TmF2aWdhdGlvbihyZXF1ZXN0LCByZWRpcmVjdCwgaXNOYXZpZ2F0aW9uLCBfdGVtcDIpIHtcbiAgICBsZXQge1xuICAgICAgc3VibWlzc2lvbixcbiAgICAgIGZldGNoZXJTdWJtaXNzaW9uLFxuICAgICAgcHJldmVudFNjcm9sbFJlc2V0LFxuICAgICAgcmVwbGFjZVxuICAgIH0gPSBfdGVtcDIgPT09IHZvaWQgMCA/IHt9IDogX3RlbXAyO1xuICAgIGlmIChyZWRpcmVjdC5yZXNwb25zZS5oZWFkZXJzLmhhcyhcIlgtUmVtaXgtUmV2YWxpZGF0ZVwiKSkge1xuICAgICAgaXNSZXZhbGlkYXRpb25SZXF1aXJlZCA9IHRydWU7XG4gICAgfVxuICAgIGxldCBsb2NhdGlvbiA9IHJlZGlyZWN0LnJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiTG9jYXRpb25cIik7XG4gICAgaW52YXJpYW50KGxvY2F0aW9uLCBcIkV4cGVjdGVkIGEgTG9jYXRpb24gaGVhZGVyIG9uIHRoZSByZWRpcmVjdCBSZXNwb25zZVwiKTtcbiAgICBsb2NhdGlvbiA9IG5vcm1hbGl6ZVJlZGlyZWN0TG9jYXRpb24obG9jYXRpb24sIG5ldyBVUkwocmVxdWVzdC51cmwpLCBiYXNlbmFtZSwgaW5pdC5oaXN0b3J5KTtcbiAgICBsZXQgcmVkaXJlY3RMb2NhdGlvbiA9IGNyZWF0ZUxvY2F0aW9uKHN0YXRlLmxvY2F0aW9uLCBsb2NhdGlvbiwge1xuICAgICAgX2lzUmVkaXJlY3Q6IHRydWVcbiAgICB9KTtcbiAgICBpZiAoaXNCcm93c2VyKSB7XG4gICAgICBsZXQgaXNEb2N1bWVudFJlbG9hZCA9IGZhbHNlO1xuICAgICAgaWYgKHJlZGlyZWN0LnJlc3BvbnNlLmhlYWRlcnMuaGFzKFwiWC1SZW1peC1SZWxvYWQtRG9jdW1lbnRcIikpIHtcbiAgICAgICAgLy8gSGFyZCByZWxvYWQgaWYgdGhlIHJlc3BvbnNlIGNvbnRhaW5lZCBYLVJlbWl4LVJlbG9hZC1Eb2N1bWVudFxuICAgICAgICBpc0RvY3VtZW50UmVsb2FkID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSBpZiAoQUJTT0xVVEVfVVJMX1JFR0VYLnRlc3QobG9jYXRpb24pKSB7XG4gICAgICAgIGNvbnN0IHVybCA9IGluaXQuaGlzdG9yeS5jcmVhdGVVUkwobG9jYXRpb24pO1xuICAgICAgICBpc0RvY3VtZW50UmVsb2FkID1cbiAgICAgICAgLy8gSGFyZCByZWxvYWQgaWYgaXQncyBhbiBhYnNvbHV0ZSBVUkwgdG8gYSBuZXcgb3JpZ2luXG4gICAgICAgIHVybC5vcmlnaW4gIT09IHJvdXRlcldpbmRvdy5sb2NhdGlvbi5vcmlnaW4gfHxcbiAgICAgICAgLy8gSGFyZCByZWxvYWQgaWYgaXQncyBhbiBhYnNvbHV0ZSBVUkwgdGhhdCBkb2VzIG5vdCBtYXRjaCBvdXIgYmFzZW5hbWVcbiAgICAgICAgc3RyaXBCYXNlbmFtZSh1cmwucGF0aG5hbWUsIGJhc2VuYW1lKSA9PSBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKGlzRG9jdW1lbnRSZWxvYWQpIHtcbiAgICAgICAgaWYgKHJlcGxhY2UpIHtcbiAgICAgICAgICByb3V0ZXJXaW5kb3cubG9jYXRpb24ucmVwbGFjZShsb2NhdGlvbik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcm91dGVyV2luZG93LmxvY2F0aW9uLmFzc2lnbihsb2NhdGlvbik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICAvLyBUaGVyZSdzIG5vIG5lZWQgdG8gYWJvcnQgb24gcmVkaXJlY3RzLCBzaW5jZSB3ZSBkb24ndCBkZXRlY3QgdGhlXG4gICAgLy8gcmVkaXJlY3QgdW50aWwgdGhlIGFjdGlvbi9sb2FkZXJzIGhhdmUgc2V0dGxlZFxuICAgIHBlbmRpbmdOYXZpZ2F0aW9uQ29udHJvbGxlciA9IG51bGw7XG4gICAgbGV0IHJlZGlyZWN0SGlzdG9yeUFjdGlvbiA9IHJlcGxhY2UgPT09IHRydWUgfHwgcmVkaXJlY3QucmVzcG9uc2UuaGVhZGVycy5oYXMoXCJYLVJlbWl4LVJlcGxhY2VcIikgPyBBY3Rpb24uUmVwbGFjZSA6IEFjdGlvbi5QdXNoO1xuICAgIC8vIFVzZSB0aGUgaW5jb21pbmcgc3VibWlzc2lvbiBpZiBwcm92aWRlZCwgZmFsbGJhY2sgb24gdGhlIGFjdGl2ZSBvbmUgaW5cbiAgICAvLyBzdGF0ZS5uYXZpZ2F0aW9uXG4gICAgbGV0IHtcbiAgICAgIGZvcm1NZXRob2QsXG4gICAgICBmb3JtQWN0aW9uLFxuICAgICAgZm9ybUVuY1R5cGVcbiAgICB9ID0gc3RhdGUubmF2aWdhdGlvbjtcbiAgICBpZiAoIXN1Ym1pc3Npb24gJiYgIWZldGNoZXJTdWJtaXNzaW9uICYmIGZvcm1NZXRob2QgJiYgZm9ybUFjdGlvbiAmJiBmb3JtRW5jVHlwZSkge1xuICAgICAgc3VibWlzc2lvbiA9IGdldFN1Ym1pc3Npb25Gcm9tTmF2aWdhdGlvbihzdGF0ZS5uYXZpZ2F0aW9uKTtcbiAgICB9XG4gICAgLy8gSWYgdGhpcyB3YXMgYSAzMDcvMzA4IHN1Ym1pc3Npb24gd2Ugd2FudCB0byBwcmVzZXJ2ZSB0aGUgSFRUUCBtZXRob2QgYW5kXG4gICAgLy8gcmUtc3VibWl0IHRoZSBHRVQvUE9TVC9QVVQvUEFUQ0gvREVMRVRFIGFzIGEgc3VibWlzc2lvbiBuYXZpZ2F0aW9uIHRvIHRoZVxuICAgIC8vIHJlZGlyZWN0ZWQgbG9jYXRpb25cbiAgICBsZXQgYWN0aXZlU3VibWlzc2lvbiA9IHN1Ym1pc3Npb24gfHwgZmV0Y2hlclN1Ym1pc3Npb247XG4gICAgaWYgKHJlZGlyZWN0UHJlc2VydmVNZXRob2RTdGF0dXNDb2Rlcy5oYXMocmVkaXJlY3QucmVzcG9uc2Uuc3RhdHVzKSAmJiBhY3RpdmVTdWJtaXNzaW9uICYmIGlzTXV0YXRpb25NZXRob2QoYWN0aXZlU3VibWlzc2lvbi5mb3JtTWV0aG9kKSkge1xuICAgICAgYXdhaXQgc3RhcnROYXZpZ2F0aW9uKHJlZGlyZWN0SGlzdG9yeUFjdGlvbiwgcmVkaXJlY3RMb2NhdGlvbiwge1xuICAgICAgICBzdWJtaXNzaW9uOiBfZXh0ZW5kcyh7fSwgYWN0aXZlU3VibWlzc2lvbiwge1xuICAgICAgICAgIGZvcm1BY3Rpb246IGxvY2F0aW9uXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBQcmVzZXJ2ZSB0aGVzZSBmbGFncyBhY3Jvc3MgcmVkaXJlY3RzXG4gICAgICAgIHByZXZlbnRTY3JvbGxSZXNldDogcHJldmVudFNjcm9sbFJlc2V0IHx8IHBlbmRpbmdQcmV2ZW50U2Nyb2xsUmVzZXQsXG4gICAgICAgIGVuYWJsZVZpZXdUcmFuc2l0aW9uOiBpc05hdmlnYXRpb24gPyBwZW5kaW5nVmlld1RyYW5zaXRpb25FbmFibGVkIDogdW5kZWZpbmVkXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gSWYgd2UgaGF2ZSBhIG5hdmlnYXRpb24gc3VibWlzc2lvbiwgd2Ugd2lsbCBwcmVzZXJ2ZSBpdCB0aHJvdWdoIHRoZVxuICAgICAgLy8gcmVkaXJlY3QgbmF2aWdhdGlvblxuICAgICAgbGV0IG92ZXJyaWRlTmF2aWdhdGlvbiA9IGdldExvYWRpbmdOYXZpZ2F0aW9uKHJlZGlyZWN0TG9jYXRpb24sIHN1Ym1pc3Npb24pO1xuICAgICAgYXdhaXQgc3RhcnROYXZpZ2F0aW9uKHJlZGlyZWN0SGlzdG9yeUFjdGlvbiwgcmVkaXJlY3RMb2NhdGlvbiwge1xuICAgICAgICBvdmVycmlkZU5hdmlnYXRpb24sXG4gICAgICAgIC8vIFNlbmQgZmV0Y2hlciBzdWJtaXNzaW9ucyB0aHJvdWdoIGZvciBzaG91bGRSZXZhbGlkYXRlXG4gICAgICAgIGZldGNoZXJTdWJtaXNzaW9uLFxuICAgICAgICAvLyBQcmVzZXJ2ZSB0aGVzZSBmbGFncyBhY3Jvc3MgcmVkaXJlY3RzXG4gICAgICAgIHByZXZlbnRTY3JvbGxSZXNldDogcHJldmVudFNjcm9sbFJlc2V0IHx8IHBlbmRpbmdQcmV2ZW50U2Nyb2xsUmVzZXQsXG4gICAgICAgIGVuYWJsZVZpZXdUcmFuc2l0aW9uOiBpc05hdmlnYXRpb24gPyBwZW5kaW5nVmlld1RyYW5zaXRpb25FbmFibGVkIDogdW5kZWZpbmVkXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgLy8gVXRpbGl0eSB3cmFwcGVyIGZvciBjYWxsaW5nIGRhdGFTdHJhdGVneSBjbGllbnQtc2lkZSB3aXRob3V0IGhhdmluZyB0b1xuICAvLyBwYXNzIGFyb3VuZCB0aGUgbWFuaWZlc3QsIG1hcFJvdXRlUHJvcGVydGllcywgZXRjLlxuICBhc3luYyBmdW5jdGlvbiBjYWxsRGF0YVN0cmF0ZWd5KHR5cGUsIHN0YXRlLCByZXF1ZXN0LCBtYXRjaGVzVG9Mb2FkLCBtYXRjaGVzLCBmZXRjaGVyS2V5KSB7XG4gICAgbGV0IHJlc3VsdHM7XG4gICAgbGV0IGRhdGFSZXN1bHRzID0ge307XG4gICAgdHJ5IHtcbiAgICAgIHJlc3VsdHMgPSBhd2FpdCBjYWxsRGF0YVN0cmF0ZWd5SW1wbChkYXRhU3RyYXRlZ3lJbXBsLCB0eXBlLCBzdGF0ZSwgcmVxdWVzdCwgbWF0Y2hlc1RvTG9hZCwgbWF0Y2hlcywgZmV0Y2hlcktleSwgbWFuaWZlc3QsIG1hcFJvdXRlUHJvcGVydGllcyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gSWYgdGhlIG91dGVyIGRhdGFTdHJhdGVneSBtZXRob2QgdGhyb3dzLCBqdXN0IHJldHVybiB0aGUgZXJyb3IgZm9yIGFsbFxuICAgICAgLy8gbWF0Y2hlcyAtIGFuZCBpdCdsbCBuYXR1cmFsbHkgYnViYmxlIHRvIHRoZSByb290XG4gICAgICBtYXRjaGVzVG9Mb2FkLmZvckVhY2gobSA9PiB7XG4gICAgICAgIGRhdGFSZXN1bHRzW20ucm91dGUuaWRdID0ge1xuICAgICAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZXJyb3IsXG4gICAgICAgICAgZXJyb3I6IGVcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGRhdGFSZXN1bHRzO1xuICAgIH1cbiAgICBmb3IgKGxldCBbcm91dGVJZCwgcmVzdWx0XSBvZiBPYmplY3QuZW50cmllcyhyZXN1bHRzKSkge1xuICAgICAgaWYgKGlzUmVkaXJlY3REYXRhU3RyYXRlZ3lSZXN1bHRSZXN1bHQocmVzdWx0KSkge1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSByZXN1bHQucmVzdWx0O1xuICAgICAgICBkYXRhUmVzdWx0c1tyb3V0ZUlkXSA9IHtcbiAgICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLnJlZGlyZWN0LFxuICAgICAgICAgIHJlc3BvbnNlOiBub3JtYWxpemVSZWxhdGl2ZVJvdXRpbmdSZWRpcmVjdFJlc3BvbnNlKHJlc3BvbnNlLCByZXF1ZXN0LCByb3V0ZUlkLCBtYXRjaGVzLCBiYXNlbmFtZSwgZnV0dXJlLnY3X3JlbGF0aXZlU3BsYXRQYXRoKVxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZGF0YVJlc3VsdHNbcm91dGVJZF0gPSBhd2FpdCBjb252ZXJ0RGF0YVN0cmF0ZWd5UmVzdWx0VG9EYXRhUmVzdWx0KHJlc3VsdCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBkYXRhUmVzdWx0cztcbiAgfVxuICBhc3luYyBmdW5jdGlvbiBjYWxsTG9hZGVyc0FuZE1heWJlUmVzb2x2ZURhdGEoc3RhdGUsIG1hdGNoZXMsIG1hdGNoZXNUb0xvYWQsIGZldGNoZXJzVG9Mb2FkLCByZXF1ZXN0KSB7XG4gICAgbGV0IGN1cnJlbnRNYXRjaGVzID0gc3RhdGUubWF0Y2hlcztcbiAgICAvLyBLaWNrIG9mZiBsb2FkZXJzIGFuZCBmZXRjaGVycyBpbiBwYXJhbGxlbFxuICAgIGxldCBsb2FkZXJSZXN1bHRzUHJvbWlzZSA9IGNhbGxEYXRhU3RyYXRlZ3koXCJsb2FkZXJcIiwgc3RhdGUsIHJlcXVlc3QsIG1hdGNoZXNUb0xvYWQsIG1hdGNoZXMsIG51bGwpO1xuICAgIGxldCBmZXRjaGVyUmVzdWx0c1Byb21pc2UgPSBQcm9taXNlLmFsbChmZXRjaGVyc1RvTG9hZC5tYXAoYXN5bmMgZiA9PiB7XG4gICAgICBpZiAoZi5tYXRjaGVzICYmIGYubWF0Y2ggJiYgZi5jb250cm9sbGVyKSB7XG4gICAgICAgIGxldCByZXN1bHRzID0gYXdhaXQgY2FsbERhdGFTdHJhdGVneShcImxvYWRlclwiLCBzdGF0ZSwgY3JlYXRlQ2xpZW50U2lkZVJlcXVlc3QoaW5pdC5oaXN0b3J5LCBmLnBhdGgsIGYuY29udHJvbGxlci5zaWduYWwpLCBbZi5tYXRjaF0sIGYubWF0Y2hlcywgZi5rZXkpO1xuICAgICAgICBsZXQgcmVzdWx0ID0gcmVzdWx0c1tmLm1hdGNoLnJvdXRlLmlkXTtcbiAgICAgICAgLy8gRmV0Y2hlciByZXN1bHRzIGFyZSBrZXllZCBieSBmZXRjaGVyIGtleSBmcm9tIGhlcmUgb24gb3V0LCBub3Qgcm91dGVJZFxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIFtmLmtleV06IHJlc3VsdFxuICAgICAgICB9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7XG4gICAgICAgICAgW2Yua2V5XToge1xuICAgICAgICAgICAgdHlwZTogUmVzdWx0VHlwZS5lcnJvcixcbiAgICAgICAgICAgIGVycm9yOiBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwNCwge1xuICAgICAgICAgICAgICBwYXRobmFtZTogZi5wYXRoXG4gICAgICAgICAgICB9KVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSkpO1xuICAgIGxldCBsb2FkZXJSZXN1bHRzID0gYXdhaXQgbG9hZGVyUmVzdWx0c1Byb21pc2U7XG4gICAgbGV0IGZldGNoZXJSZXN1bHRzID0gKGF3YWl0IGZldGNoZXJSZXN1bHRzUHJvbWlzZSkucmVkdWNlKChhY2MsIHIpID0+IE9iamVjdC5hc3NpZ24oYWNjLCByKSwge30pO1xuICAgIGF3YWl0IFByb21pc2UuYWxsKFtyZXNvbHZlTmF2aWdhdGlvbkRlZmVycmVkUmVzdWx0cyhtYXRjaGVzLCBsb2FkZXJSZXN1bHRzLCByZXF1ZXN0LnNpZ25hbCwgY3VycmVudE1hdGNoZXMsIHN0YXRlLmxvYWRlckRhdGEpLCByZXNvbHZlRmV0Y2hlckRlZmVycmVkUmVzdWx0cyhtYXRjaGVzLCBmZXRjaGVyUmVzdWx0cywgZmV0Y2hlcnNUb0xvYWQpXSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvYWRlclJlc3VsdHMsXG4gICAgICBmZXRjaGVyUmVzdWx0c1xuICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gaW50ZXJydXB0QWN0aXZlTG9hZHMoKSB7XG4gICAgLy8gRXZlcnkgaW50ZXJydXB0aW9uIHRyaWdnZXJzIGEgcmV2YWxpZGF0aW9uXG4gICAgaXNSZXZhbGlkYXRpb25SZXF1aXJlZCA9IHRydWU7XG4gICAgLy8gQ2FuY2VsIHBlbmRpbmcgcm91dGUtbGV2ZWwgZGVmZXJyZWRzIGFuZCBtYXJrIGNhbmNlbGxlZCByb3V0ZXMgZm9yXG4gICAgLy8gcmV2YWxpZGF0aW9uXG4gICAgY2FuY2VsbGVkRGVmZXJyZWRSb3V0ZXMucHVzaCguLi5jYW5jZWxBY3RpdmVEZWZlcnJlZHMoKSk7XG4gICAgLy8gQWJvcnQgaW4tZmxpZ2h0IGZldGNoZXIgbG9hZHNcbiAgICBmZXRjaExvYWRNYXRjaGVzLmZvckVhY2goKF8sIGtleSkgPT4ge1xuICAgICAgaWYgKGZldGNoQ29udHJvbGxlcnMuaGFzKGtleSkpIHtcbiAgICAgICAgY2FuY2VsbGVkRmV0Y2hlckxvYWRzLmFkZChrZXkpO1xuICAgICAgfVxuICAgICAgYWJvcnRGZXRjaGVyKGtleSk7XG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gdXBkYXRlRmV0Y2hlclN0YXRlKGtleSwgZmV0Y2hlciwgb3B0cykge1xuICAgIGlmIChvcHRzID09PSB2b2lkIDApIHtcbiAgICAgIG9wdHMgPSB7fTtcbiAgICB9XG4gICAgc3RhdGUuZmV0Y2hlcnMuc2V0KGtleSwgZmV0Y2hlcik7XG4gICAgdXBkYXRlU3RhdGUoe1xuICAgICAgZmV0Y2hlcnM6IG5ldyBNYXAoc3RhdGUuZmV0Y2hlcnMpXG4gICAgfSwge1xuICAgICAgZmx1c2hTeW5jOiAob3B0cyAmJiBvcHRzLmZsdXNoU3luYykgPT09IHRydWVcbiAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBzZXRGZXRjaGVyRXJyb3Ioa2V5LCByb3V0ZUlkLCBlcnJvciwgb3B0cykge1xuICAgIGlmIChvcHRzID09PSB2b2lkIDApIHtcbiAgICAgIG9wdHMgPSB7fTtcbiAgICB9XG4gICAgbGV0IGJvdW5kYXJ5TWF0Y2ggPSBmaW5kTmVhcmVzdEJvdW5kYXJ5KHN0YXRlLm1hdGNoZXMsIHJvdXRlSWQpO1xuICAgIGRlbGV0ZUZldGNoZXIoa2V5KTtcbiAgICB1cGRhdGVTdGF0ZSh7XG4gICAgICBlcnJvcnM6IHtcbiAgICAgICAgW2JvdW5kYXJ5TWF0Y2gucm91dGUuaWRdOiBlcnJvclxuICAgICAgfSxcbiAgICAgIGZldGNoZXJzOiBuZXcgTWFwKHN0YXRlLmZldGNoZXJzKVxuICAgIH0sIHtcbiAgICAgIGZsdXNoU3luYzogKG9wdHMgJiYgb3B0cy5mbHVzaFN5bmMpID09PSB0cnVlXG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gZ2V0RmV0Y2hlcihrZXkpIHtcbiAgICBhY3RpdmVGZXRjaGVycy5zZXQoa2V5LCAoYWN0aXZlRmV0Y2hlcnMuZ2V0KGtleSkgfHwgMCkgKyAxKTtcbiAgICAvLyBJZiB0aGlzIGZldGNoZXIgd2FzIHByZXZpb3VzbHkgbWFya2VkIGZvciBkZWxldGlvbiwgdW5tYXJrIGl0IHNpbmNlIHdlXG4gICAgLy8gaGF2ZSBhIG5ldyBpbnN0YW5jZVxuICAgIGlmIChkZWxldGVkRmV0Y2hlcnMuaGFzKGtleSkpIHtcbiAgICAgIGRlbGV0ZWRGZXRjaGVycy5kZWxldGUoa2V5KTtcbiAgICB9XG4gICAgcmV0dXJuIHN0YXRlLmZldGNoZXJzLmdldChrZXkpIHx8IElETEVfRkVUQ0hFUjtcbiAgfVxuICBmdW5jdGlvbiBkZWxldGVGZXRjaGVyKGtleSkge1xuICAgIGxldCBmZXRjaGVyID0gc3RhdGUuZmV0Y2hlcnMuZ2V0KGtleSk7XG4gICAgLy8gRG9uJ3QgYWJvcnQgdGhlIGNvbnRyb2xsZXIgaWYgdGhpcyBpcyBhIGRlbGV0aW9uIG9mIGEgZmV0Y2hlci5zdWJtaXQoKVxuICAgIC8vIGluIGl0J3MgbG9hZGluZyBwaGFzZSBzaW5jZSAtIHdlIGRvbid0IHdhbnQgdG8gYWJvcnQgdGhlIGNvcnJlc3BvbmRpbmdcbiAgICAvLyByZXZhbGlkYXRpb24gYW5kIHdhbnQgdGhlbSB0byBjb21wbGV0ZSBhbmQgbGFuZFxuICAgIGlmIChmZXRjaENvbnRyb2xsZXJzLmhhcyhrZXkpICYmICEoZmV0Y2hlciAmJiBmZXRjaGVyLnN0YXRlID09PSBcImxvYWRpbmdcIiAmJiBmZXRjaFJlbG9hZElkcy5oYXMoa2V5KSkpIHtcbiAgICAgIGFib3J0RmV0Y2hlcihrZXkpO1xuICAgIH1cbiAgICBmZXRjaExvYWRNYXRjaGVzLmRlbGV0ZShrZXkpO1xuICAgIGZldGNoUmVsb2FkSWRzLmRlbGV0ZShrZXkpO1xuICAgIGZldGNoUmVkaXJlY3RJZHMuZGVsZXRlKGtleSk7XG4gICAgLy8gSWYgd2Ugb3B0ZWQgaW50byB0aGUgZmxhZyB3ZSBjYW4gY2xlYXIgdGhpcyBub3cgc2luY2Ugd2UncmUgY2FsbGluZ1xuICAgIC8vIGRlbGV0ZUZldGNoZXIoKSBhdCB0aGUgZW5kIG9mIHVwZGF0ZVN0YXRlKCkgYW5kIHdlJ3ZlIGFscmVhZHkgaGFuZGVkIHRoZVxuICAgIC8vIGRlbGV0ZWQgZmV0Y2hlciBrZXlzIG9mZiB0byB0aGUgZGF0YSBsYXllci5cbiAgICAvLyBJZiBub3QsIHdlJ3JlIGVhZ2VybHkgY2FsbGluZyBkZWxldGVGZXRjaGVyKCkgYW5kIHdlIG5lZWQgdG8ga2VlcCB0aGlzXG4gICAgLy8gU2V0IHBvcHVsYXRlZCB1bnRpbCB0aGUgbmV4dCB1cGRhdGVTdGF0ZSBjYWxsLCBhbmQgd2UnbGwgY2xlYXJcbiAgICAvLyBgZGVsZXRlZEZldGNoZXJzYCB0aGVuXG4gICAgaWYgKGZ1dHVyZS52N19mZXRjaGVyUGVyc2lzdCkge1xuICAgICAgZGVsZXRlZEZldGNoZXJzLmRlbGV0ZShrZXkpO1xuICAgIH1cbiAgICBjYW5jZWxsZWRGZXRjaGVyTG9hZHMuZGVsZXRlKGtleSk7XG4gICAgc3RhdGUuZmV0Y2hlcnMuZGVsZXRlKGtleSk7XG4gIH1cbiAgZnVuY3Rpb24gZGVsZXRlRmV0Y2hlckFuZFVwZGF0ZVN0YXRlKGtleSkge1xuICAgIGxldCBjb3VudCA9IChhY3RpdmVGZXRjaGVycy5nZXQoa2V5KSB8fCAwKSAtIDE7XG4gICAgaWYgKGNvdW50IDw9IDApIHtcbiAgICAgIGFjdGl2ZUZldGNoZXJzLmRlbGV0ZShrZXkpO1xuICAgICAgZGVsZXRlZEZldGNoZXJzLmFkZChrZXkpO1xuICAgICAgaWYgKCFmdXR1cmUudjdfZmV0Y2hlclBlcnNpc3QpIHtcbiAgICAgICAgZGVsZXRlRmV0Y2hlcihrZXkpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBhY3RpdmVGZXRjaGVycy5zZXQoa2V5LCBjb3VudCk7XG4gICAgfVxuICAgIHVwZGF0ZVN0YXRlKHtcbiAgICAgIGZldGNoZXJzOiBuZXcgTWFwKHN0YXRlLmZldGNoZXJzKVxuICAgIH0pO1xuICB9XG4gIGZ1bmN0aW9uIGFib3J0RmV0Y2hlcihrZXkpIHtcbiAgICBsZXQgY29udHJvbGxlciA9IGZldGNoQ29udHJvbGxlcnMuZ2V0KGtleSk7XG4gICAgaWYgKGNvbnRyb2xsZXIpIHtcbiAgICAgIGNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgIGZldGNoQ29udHJvbGxlcnMuZGVsZXRlKGtleSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIG1hcmtGZXRjaGVyc0RvbmUoa2V5cykge1xuICAgIGZvciAobGV0IGtleSBvZiBrZXlzKSB7XG4gICAgICBsZXQgZmV0Y2hlciA9IGdldEZldGNoZXIoa2V5KTtcbiAgICAgIGxldCBkb25lRmV0Y2hlciA9IGdldERvbmVGZXRjaGVyKGZldGNoZXIuZGF0YSk7XG4gICAgICBzdGF0ZS5mZXRjaGVycy5zZXQoa2V5LCBkb25lRmV0Y2hlcik7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIG1hcmtGZXRjaFJlZGlyZWN0c0RvbmUoKSB7XG4gICAgbGV0IGRvbmVLZXlzID0gW107XG4gICAgbGV0IHVwZGF0ZWRGZXRjaGVycyA9IGZhbHNlO1xuICAgIGZvciAobGV0IGtleSBvZiBmZXRjaFJlZGlyZWN0SWRzKSB7XG4gICAgICBsZXQgZmV0Y2hlciA9IHN0YXRlLmZldGNoZXJzLmdldChrZXkpO1xuICAgICAgaW52YXJpYW50KGZldGNoZXIsIFwiRXhwZWN0ZWQgZmV0Y2hlcjogXCIgKyBrZXkpO1xuICAgICAgaWYgKGZldGNoZXIuc3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgICAgIGZldGNoUmVkaXJlY3RJZHMuZGVsZXRlKGtleSk7XG4gICAgICAgIGRvbmVLZXlzLnB1c2goa2V5KTtcbiAgICAgICAgdXBkYXRlZEZldGNoZXJzID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgbWFya0ZldGNoZXJzRG9uZShkb25lS2V5cyk7XG4gICAgcmV0dXJuIHVwZGF0ZWRGZXRjaGVycztcbiAgfVxuICBmdW5jdGlvbiBhYm9ydFN0YWxlRmV0Y2hMb2FkcyhsYW5kZWRJZCkge1xuICAgIGxldCB5ZWV0ZWRLZXlzID0gW107XG4gICAgZm9yIChsZXQgW2tleSwgaWRdIG9mIGZldGNoUmVsb2FkSWRzKSB7XG4gICAgICBpZiAoaWQgPCBsYW5kZWRJZCkge1xuICAgICAgICBsZXQgZmV0Y2hlciA9IHN0YXRlLmZldGNoZXJzLmdldChrZXkpO1xuICAgICAgICBpbnZhcmlhbnQoZmV0Y2hlciwgXCJFeHBlY3RlZCBmZXRjaGVyOiBcIiArIGtleSk7XG4gICAgICAgIGlmIChmZXRjaGVyLnN0YXRlID09PSBcImxvYWRpbmdcIikge1xuICAgICAgICAgIGFib3J0RmV0Y2hlcihrZXkpO1xuICAgICAgICAgIGZldGNoUmVsb2FkSWRzLmRlbGV0ZShrZXkpO1xuICAgICAgICAgIHllZXRlZEtleXMucHVzaChrZXkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIG1hcmtGZXRjaGVyc0RvbmUoeWVldGVkS2V5cyk7XG4gICAgcmV0dXJuIHllZXRlZEtleXMubGVuZ3RoID4gMDtcbiAgfVxuICBmdW5jdGlvbiBnZXRCbG9ja2VyKGtleSwgZm4pIHtcbiAgICBsZXQgYmxvY2tlciA9IHN0YXRlLmJsb2NrZXJzLmdldChrZXkpIHx8IElETEVfQkxPQ0tFUjtcbiAgICBpZiAoYmxvY2tlckZ1bmN0aW9ucy5nZXQoa2V5KSAhPT0gZm4pIHtcbiAgICAgIGJsb2NrZXJGdW5jdGlvbnMuc2V0KGtleSwgZm4pO1xuICAgIH1cbiAgICByZXR1cm4gYmxvY2tlcjtcbiAgfVxuICBmdW5jdGlvbiBkZWxldGVCbG9ja2VyKGtleSkge1xuICAgIHN0YXRlLmJsb2NrZXJzLmRlbGV0ZShrZXkpO1xuICAgIGJsb2NrZXJGdW5jdGlvbnMuZGVsZXRlKGtleSk7XG4gIH1cbiAgLy8gVXRpbGl0eSBmdW5jdGlvbiB0byB1cGRhdGUgYmxvY2tlcnMsIGVuc3VyaW5nIHZhbGlkIHN0YXRlIHRyYW5zaXRpb25zXG4gIGZ1bmN0aW9uIHVwZGF0ZUJsb2NrZXIoa2V5LCBuZXdCbG9ja2VyKSB7XG4gICAgbGV0IGJsb2NrZXIgPSBzdGF0ZS5ibG9ja2Vycy5nZXQoa2V5KSB8fCBJRExFX0JMT0NLRVI7XG4gICAgLy8gUG9vciBtYW5zIHN0YXRlIG1hY2hpbmUgOilcbiAgICAvLyBodHRwczovL21lcm1haWQubGl2ZS9lZGl0I3Bha286ZU5xVmtjOU93ekFNeGw4bDhubmpBWXJFdERJT0hFQklnd3ZLSlRSZUd5M19sRHBJcU8yN2s2YXdNRzBYY3JMbG56ODdud2RvbkVTb2dLWFhCdUU3OXJxNzVYWk8zLXlIZHMwUkpWdXY3MFlyUGxVckNFZTJIZnJPUlMzcnVicVpmdWh0cGc1Qzl3azV0WjRWS2NSVXE4OHE5WjhSUzAtNDhjRTFpSEprTDB1Z2JIdUZMdXM5TDZzcFp5OG5YOU1QMkNOZG9tVmFwb3NxdTNmR2F5VDhUOC1qSlF3aGVwb19VdHBnQlFhREVVb20wNGRaaEFOMWFKQkRsVUtKQnhFMWNlQjJTbWowTWxuLUlCVzVBRlUyZHdVaWt0dF8yUWFxMmRCZmFLZEV1cDg1VVY3WWQtZEtqbG5rYWJsMlB2cjBEVGtUcmVNXG4gICAgaW52YXJpYW50KGJsb2NrZXIuc3RhdGUgPT09IFwidW5ibG9ja2VkXCIgJiYgbmV3QmxvY2tlci5zdGF0ZSA9PT0gXCJibG9ja2VkXCIgfHwgYmxvY2tlci5zdGF0ZSA9PT0gXCJibG9ja2VkXCIgJiYgbmV3QmxvY2tlci5zdGF0ZSA9PT0gXCJibG9ja2VkXCIgfHwgYmxvY2tlci5zdGF0ZSA9PT0gXCJibG9ja2VkXCIgJiYgbmV3QmxvY2tlci5zdGF0ZSA9PT0gXCJwcm9jZWVkaW5nXCIgfHwgYmxvY2tlci5zdGF0ZSA9PT0gXCJibG9ja2VkXCIgJiYgbmV3QmxvY2tlci5zdGF0ZSA9PT0gXCJ1bmJsb2NrZWRcIiB8fCBibG9ja2VyLnN0YXRlID09PSBcInByb2NlZWRpbmdcIiAmJiBuZXdCbG9ja2VyLnN0YXRlID09PSBcInVuYmxvY2tlZFwiLCBcIkludmFsaWQgYmxvY2tlciBzdGF0ZSB0cmFuc2l0aW9uOiBcIiArIGJsb2NrZXIuc3RhdGUgKyBcIiAtPiBcIiArIG5ld0Jsb2NrZXIuc3RhdGUpO1xuICAgIGxldCBibG9ja2VycyA9IG5ldyBNYXAoc3RhdGUuYmxvY2tlcnMpO1xuICAgIGJsb2NrZXJzLnNldChrZXksIG5ld0Jsb2NrZXIpO1xuICAgIHVwZGF0ZVN0YXRlKHtcbiAgICAgIGJsb2NrZXJzXG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gc2hvdWxkQmxvY2tOYXZpZ2F0aW9uKF9yZWYyKSB7XG4gICAgbGV0IHtcbiAgICAgIGN1cnJlbnRMb2NhdGlvbixcbiAgICAgIG5leHRMb2NhdGlvbixcbiAgICAgIGhpc3RvcnlBY3Rpb25cbiAgICB9ID0gX3JlZjI7XG4gICAgaWYgKGJsb2NrZXJGdW5jdGlvbnMuc2l6ZSA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBXZSBvbnkgc3VwcG9ydCBhIHNpbmdsZSBhY3RpdmUgYmxvY2tlciBhdCB0aGUgbW9tZW50IHNpbmNlIHdlIGRvbid0IGhhdmVcbiAgICAvLyBhbnkgY29tcGVsbGluZyB1c2UgY2FzZXMgZm9yIG11bHRpLWJsb2NrZXIgeWV0XG4gICAgaWYgKGJsb2NrZXJGdW5jdGlvbnMuc2l6ZSA+IDEpIHtcbiAgICAgIHdhcm5pbmcoZmFsc2UsIFwiQSByb3V0ZXIgb25seSBzdXBwb3J0cyBvbmUgYmxvY2tlciBhdCBhIHRpbWVcIik7XG4gICAgfVxuICAgIGxldCBlbnRyaWVzID0gQXJyYXkuZnJvbShibG9ja2VyRnVuY3Rpb25zLmVudHJpZXMoKSk7XG4gICAgbGV0IFtibG9ja2VyS2V5LCBibG9ja2VyRnVuY3Rpb25dID0gZW50cmllc1tlbnRyaWVzLmxlbmd0aCAtIDFdO1xuICAgIGxldCBibG9ja2VyID0gc3RhdGUuYmxvY2tlcnMuZ2V0KGJsb2NrZXJLZXkpO1xuICAgIGlmIChibG9ja2VyICYmIGJsb2NrZXIuc3RhdGUgPT09IFwicHJvY2VlZGluZ1wiKSB7XG4gICAgICAvLyBJZiB0aGUgYmxvY2tlciBpcyBjdXJyZW50bHkgcHJvY2VlZGluZywgd2UgZG9uJ3QgbmVlZCB0byByZS1jaGVja1xuICAgICAgLy8gaXQgYW5kIGNhbiBsZXQgdGhpcyBuYXZpZ2F0aW9uIGNvbnRpbnVlXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIEF0IHRoaXMgcG9pbnQsIHdlIGtub3cgd2UncmUgdW5ibG9ja2VkL2Jsb2NrZWQgc28gd2UgbmVlZCB0byBjaGVjayB0aGVcbiAgICAvLyB1c2VyLXByb3ZpZGVkIGJsb2NrZXIgZnVuY3Rpb25cbiAgICBpZiAoYmxvY2tlckZ1bmN0aW9uKHtcbiAgICAgIGN1cnJlbnRMb2NhdGlvbixcbiAgICAgIG5leHRMb2NhdGlvbixcbiAgICAgIGhpc3RvcnlBY3Rpb25cbiAgICB9KSkge1xuICAgICAgcmV0dXJuIGJsb2NrZXJLZXk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZU5hdmlnYXRpb25hbDQwNChwYXRobmFtZSkge1xuICAgIGxldCBlcnJvciA9IGdldEludGVybmFsUm91dGVyRXJyb3IoNDA0LCB7XG4gICAgICBwYXRobmFtZVxuICAgIH0pO1xuICAgIGxldCByb3V0ZXNUb1VzZSA9IGluRmxpZ2h0RGF0YVJvdXRlcyB8fCBkYXRhUm91dGVzO1xuICAgIGxldCB7XG4gICAgICBtYXRjaGVzLFxuICAgICAgcm91dGVcbiAgICB9ID0gZ2V0U2hvcnRDaXJjdWl0TWF0Y2hlcyhyb3V0ZXNUb1VzZSk7XG4gICAgLy8gQ2FuY2VsIGFsbCBwZW5kaW5nIGRlZmVycmVkIG9uIDQwNHMgc2luY2Ugd2UgZG9uJ3Qga2VlcCBhbnkgcm91dGVzXG4gICAgY2FuY2VsQWN0aXZlRGVmZXJyZWRzKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIG5vdEZvdW5kTWF0Y2hlczogbWF0Y2hlcyxcbiAgICAgIHJvdXRlLFxuICAgICAgZXJyb3JcbiAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIGNhbmNlbEFjdGl2ZURlZmVycmVkcyhwcmVkaWNhdGUpIHtcbiAgICBsZXQgY2FuY2VsbGVkUm91dGVJZHMgPSBbXTtcbiAgICBhY3RpdmVEZWZlcnJlZHMuZm9yRWFjaCgoZGZkLCByb3V0ZUlkKSA9PiB7XG4gICAgICBpZiAoIXByZWRpY2F0ZSB8fCBwcmVkaWNhdGUocm91dGVJZCkpIHtcbiAgICAgICAgLy8gQ2FuY2VsIHRoZSBkZWZlcnJlZCAtIGJ1dCBkbyBub3QgcmVtb3ZlIGZyb20gYWN0aXZlRGVmZXJyZWRzIGhlcmUgLVxuICAgICAgICAvLyB3ZSByZWx5IG9uIHRoZSBzdWJzY3JpYmVycyB0byBkbyB0aGF0IHNvIG91ciB0ZXN0cyBjYW4gYXNzZXJ0IHByb3BlclxuICAgICAgICAvLyBjbGVhbnVwIHZpYSBfaW50ZXJuYWxBY3RpdmVEZWZlcnJlZHNcbiAgICAgICAgZGZkLmNhbmNlbCgpO1xuICAgICAgICBjYW5jZWxsZWRSb3V0ZUlkcy5wdXNoKHJvdXRlSWQpO1xuICAgICAgICBhY3RpdmVEZWZlcnJlZHMuZGVsZXRlKHJvdXRlSWQpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBjYW5jZWxsZWRSb3V0ZUlkcztcbiAgfVxuICAvLyBPcHQgaW4gdG8gY2FwdHVyaW5nIGFuZCByZXBvcnRpbmcgc2Nyb2xsIHBvc2l0aW9ucyBkdXJpbmcgbmF2aWdhdGlvbnMsXG4gIC8vIHVzZWQgYnkgdGhlIDxTY3JvbGxSZXN0b3JhdGlvbj4gY29tcG9uZW50XG4gIGZ1bmN0aW9uIGVuYWJsZVNjcm9sbFJlc3RvcmF0aW9uKHBvc2l0aW9ucywgZ2V0UG9zaXRpb24sIGdldEtleSkge1xuICAgIHNhdmVkU2Nyb2xsUG9zaXRpb25zID0gcG9zaXRpb25zO1xuICAgIGdldFNjcm9sbFBvc2l0aW9uID0gZ2V0UG9zaXRpb247XG4gICAgZ2V0U2Nyb2xsUmVzdG9yYXRpb25LZXkgPSBnZXRLZXkgfHwgbnVsbDtcbiAgICAvLyBQZXJmb3JtIGluaXRpYWwgaHlkcmF0aW9uIHNjcm9sbCByZXN0b3JhdGlvbiwgc2luY2Ugd2UgbWlzcyB0aGUgYm9hdCBvblxuICAgIC8vIHRoZSBpbml0aWFsIHVwZGF0ZVN0YXRlKCkgYmVjYXVzZSB3ZSd2ZSBub3QgeWV0IHJlbmRlcmVkIDxTY3JvbGxSZXN0b3JhdGlvbi8+XG4gICAgLy8gYW5kIHRoZXJlZm9yZSBoYXZlIG5vIHNhdmVkU2Nyb2xsUG9zaXRpb25zIGF2YWlsYWJsZVxuICAgIGlmICghaW5pdGlhbFNjcm9sbFJlc3RvcmVkICYmIHN0YXRlLm5hdmlnYXRpb24gPT09IElETEVfTkFWSUdBVElPTikge1xuICAgICAgaW5pdGlhbFNjcm9sbFJlc3RvcmVkID0gdHJ1ZTtcbiAgICAgIGxldCB5ID0gZ2V0U2F2ZWRTY3JvbGxQb3NpdGlvbihzdGF0ZS5sb2NhdGlvbiwgc3RhdGUubWF0Y2hlcyk7XG4gICAgICBpZiAoeSAhPSBudWxsKSB7XG4gICAgICAgIHVwZGF0ZVN0YXRlKHtcbiAgICAgICAgICByZXN0b3JlU2Nyb2xsUG9zaXRpb246IHlcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBzYXZlZFNjcm9sbFBvc2l0aW9ucyA9IG51bGw7XG4gICAgICBnZXRTY3JvbGxQb3NpdGlvbiA9IG51bGw7XG4gICAgICBnZXRTY3JvbGxSZXN0b3JhdGlvbktleSA9IG51bGw7XG4gICAgfTtcbiAgfVxuICBmdW5jdGlvbiBnZXRTY3JvbGxLZXkobG9jYXRpb24sIG1hdGNoZXMpIHtcbiAgICBpZiAoZ2V0U2Nyb2xsUmVzdG9yYXRpb25LZXkpIHtcbiAgICAgIGxldCBrZXkgPSBnZXRTY3JvbGxSZXN0b3JhdGlvbktleShsb2NhdGlvbiwgbWF0Y2hlcy5tYXAobSA9PiBjb252ZXJ0Um91dGVNYXRjaFRvVWlNYXRjaChtLCBzdGF0ZS5sb2FkZXJEYXRhKSkpO1xuICAgICAgcmV0dXJuIGtleSB8fCBsb2NhdGlvbi5rZXk7XG4gICAgfVxuICAgIHJldHVybiBsb2NhdGlvbi5rZXk7XG4gIH1cbiAgZnVuY3Rpb24gc2F2ZVNjcm9sbFBvc2l0aW9uKGxvY2F0aW9uLCBtYXRjaGVzKSB7XG4gICAgaWYgKHNhdmVkU2Nyb2xsUG9zaXRpb25zICYmIGdldFNjcm9sbFBvc2l0aW9uKSB7XG4gICAgICBsZXQga2V5ID0gZ2V0U2Nyb2xsS2V5KGxvY2F0aW9uLCBtYXRjaGVzKTtcbiAgICAgIHNhdmVkU2Nyb2xsUG9zaXRpb25zW2tleV0gPSBnZXRTY3JvbGxQb3NpdGlvbigpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uKGxvY2F0aW9uLCBtYXRjaGVzKSB7XG4gICAgaWYgKHNhdmVkU2Nyb2xsUG9zaXRpb25zKSB7XG4gICAgICBsZXQga2V5ID0gZ2V0U2Nyb2xsS2V5KGxvY2F0aW9uLCBtYXRjaGVzKTtcbiAgICAgIGxldCB5ID0gc2F2ZWRTY3JvbGxQb3NpdGlvbnNba2V5XTtcbiAgICAgIGlmICh0eXBlb2YgeSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgICByZXR1cm4geTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgZnVuY3Rpb24gY2hlY2tGb2dPZldhcihtYXRjaGVzLCByb3V0ZXNUb1VzZSwgcGF0aG5hbWUpIHtcbiAgICBpZiAocGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb25JbXBsKSB7XG4gICAgICBpZiAoIW1hdGNoZXMpIHtcbiAgICAgICAgbGV0IGZvZ01hdGNoZXMgPSBtYXRjaFJvdXRlc0ltcGwocm91dGVzVG9Vc2UsIHBhdGhuYW1lLCBiYXNlbmFtZSwgdHJ1ZSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgYWN0aXZlOiB0cnVlLFxuICAgICAgICAgIG1hdGNoZXM6IGZvZ01hdGNoZXMgfHwgW11cbiAgICAgICAgfTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhtYXRjaGVzWzBdLnBhcmFtcykubGVuZ3RoID4gMCkge1xuICAgICAgICAgIC8vIElmIHdlIG1hdGNoZWQgYSBkeW5hbWljIHBhcmFtIG9yIGEgc3BsYXQsIGl0IG1pZ2h0IG9ubHkgYmUgYmVjYXVzZVxuICAgICAgICAgIC8vIHdlIGhhdmVuJ3QgeWV0IGRpc2NvdmVyZWQgb3RoZXIgcm91dGVzIHRoYXQgd291bGQgbWF0Y2ggd2l0aCBhXG4gICAgICAgICAgLy8gaGlnaGVyIHNjb3JlLiAgQ2FsbCBwYXRjaFJvdXRlc09uTmF2aWdhdGlvbiBqdXN0IHRvIGJlIHN1cmVcbiAgICAgICAgICBsZXQgcGFydGlhbE1hdGNoZXMgPSBtYXRjaFJvdXRlc0ltcGwocm91dGVzVG9Vc2UsIHBhdGhuYW1lLCBiYXNlbmFtZSwgdHJ1ZSk7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGFjdGl2ZTogdHJ1ZSxcbiAgICAgICAgICAgIG1hdGNoZXM6IHBhcnRpYWxNYXRjaGVzXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgYWN0aXZlOiBmYWxzZSxcbiAgICAgIG1hdGNoZXM6IG51bGxcbiAgICB9O1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIGRpc2NvdmVyUm91dGVzKG1hdGNoZXMsIHBhdGhuYW1lLCBzaWduYWwsIGZldGNoZXJLZXkpIHtcbiAgICBpZiAoIXBhdGNoUm91dGVzT25OYXZpZ2F0aW9uSW1wbCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXG4gICAgICAgIG1hdGNoZXNcbiAgICAgIH07XG4gICAgfVxuICAgIGxldCBwYXJ0aWFsTWF0Y2hlcyA9IG1hdGNoZXM7XG4gICAgd2hpbGUgKHRydWUpIHtcbiAgICAgIGxldCBpc05vbkhNUiA9IGluRmxpZ2h0RGF0YVJvdXRlcyA9PSBudWxsO1xuICAgICAgbGV0IHJvdXRlc1RvVXNlID0gaW5GbGlnaHREYXRhUm91dGVzIHx8IGRhdGFSb3V0ZXM7XG4gICAgICBsZXQgbG9jYWxNYW5pZmVzdCA9IG1hbmlmZXN0O1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgcGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb25JbXBsKHtcbiAgICAgICAgICBzaWduYWwsXG4gICAgICAgICAgcGF0aDogcGF0aG5hbWUsXG4gICAgICAgICAgbWF0Y2hlczogcGFydGlhbE1hdGNoZXMsXG4gICAgICAgICAgZmV0Y2hlcktleSxcbiAgICAgICAgICBwYXRjaDogKHJvdXRlSWQsIGNoaWxkcmVuKSA9PiB7XG4gICAgICAgICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpIHJldHVybjtcbiAgICAgICAgICAgIHBhdGNoUm91dGVzSW1wbChyb3V0ZUlkLCBjaGlsZHJlbiwgcm91dGVzVG9Vc2UsIGxvY2FsTWFuaWZlc3QsIG1hcFJvdXRlUHJvcGVydGllcyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXG4gICAgICAgICAgZXJyb3I6IGUsXG4gICAgICAgICAgcGFydGlhbE1hdGNoZXNcbiAgICAgICAgfTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIC8vIElmIHdlIGFyZSBub3QgaW4gdGhlIG1pZGRsZSBvZiBhbiBITVIgcmV2YWxpZGF0aW9uIGFuZCB3ZSBjaGFuZ2VkIHRoZVxuICAgICAgICAvLyByb3V0ZXMsIHByb3ZpZGUgYSBuZXcgaWRlbnRpdHkgc28gd2hlbiB3ZSBgdXBkYXRlU3RhdGVgIGF0IHRoZSBlbmQgb2ZcbiAgICAgICAgLy8gdGhpcyBuYXZpZ2F0aW9uL2ZldGNoIGByb3V0ZXIucm91dGVzYCB3aWxsIGJlIGEgbmV3IGlkZW50aXR5IGFuZFxuICAgICAgICAvLyB0cmlnZ2VyIGEgcmUtcnVuIG9mIG1lbW9pemVkIGByb3V0ZXIucm91dGVzYCBkZXBlbmRlbmNpZXMuXG4gICAgICAgIC8vIEhNUiB3aWxsIGFscmVhZHkgdXBkYXRlIHRoZSBpZGVudGl0eSBhbmQgcmVmbG93IHdoZW4gaXQgbGFuZHNcbiAgICAgICAgLy8gYGluRmxpZ2h0RGF0YVJvdXRlc2AgaW4gYGNvbXBsZXRlTmF2aWdhdGlvbmBcbiAgICAgICAgaWYgKGlzTm9uSE1SICYmICFzaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgIGRhdGFSb3V0ZXMgPSBbLi4uZGF0YVJvdXRlc107XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChzaWduYWwuYWJvcnRlZCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHR5cGU6IFwiYWJvcnRlZFwiXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBsZXQgbmV3TWF0Y2hlcyA9IG1hdGNoUm91dGVzKHJvdXRlc1RvVXNlLCBwYXRobmFtZSwgYmFzZW5hbWUpO1xuICAgICAgaWYgKG5ld01hdGNoZXMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcbiAgICAgICAgICBtYXRjaGVzOiBuZXdNYXRjaGVzXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBsZXQgbmV3UGFydGlhbE1hdGNoZXMgPSBtYXRjaFJvdXRlc0ltcGwocm91dGVzVG9Vc2UsIHBhdGhuYW1lLCBiYXNlbmFtZSwgdHJ1ZSk7XG4gICAgICAvLyBBdm9pZCBsb29wcyBpZiB0aGUgc2Vjb25kIHBhc3MgcmVzdWx0cyBpbiB0aGUgc2FtZSBwYXJ0aWFsIG1hdGNoZXNcbiAgICAgIGlmICghbmV3UGFydGlhbE1hdGNoZXMgfHwgcGFydGlhbE1hdGNoZXMubGVuZ3RoID09PSBuZXdQYXJ0aWFsTWF0Y2hlcy5sZW5ndGggJiYgcGFydGlhbE1hdGNoZXMuZXZlcnkoKG0sIGkpID0+IG0ucm91dGUuaWQgPT09IG5ld1BhcnRpYWxNYXRjaGVzW2ldLnJvdXRlLmlkKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxuICAgICAgICAgIG1hdGNoZXM6IG51bGxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHBhcnRpYWxNYXRjaGVzID0gbmV3UGFydGlhbE1hdGNoZXM7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIF9pbnRlcm5hbFNldFJvdXRlcyhuZXdSb3V0ZXMpIHtcbiAgICBtYW5pZmVzdCA9IHt9O1xuICAgIGluRmxpZ2h0RGF0YVJvdXRlcyA9IGNvbnZlcnRSb3V0ZXNUb0RhdGFSb3V0ZXMobmV3Um91dGVzLCBtYXBSb3V0ZVByb3BlcnRpZXMsIHVuZGVmaW5lZCwgbWFuaWZlc3QpO1xuICB9XG4gIGZ1bmN0aW9uIHBhdGNoUm91dGVzKHJvdXRlSWQsIGNoaWxkcmVuKSB7XG4gICAgbGV0IGlzTm9uSE1SID0gaW5GbGlnaHREYXRhUm91dGVzID09IG51bGw7XG4gICAgbGV0IHJvdXRlc1RvVXNlID0gaW5GbGlnaHREYXRhUm91dGVzIHx8IGRhdGFSb3V0ZXM7XG4gICAgcGF0Y2hSb3V0ZXNJbXBsKHJvdXRlSWQsIGNoaWxkcmVuLCByb3V0ZXNUb1VzZSwgbWFuaWZlc3QsIG1hcFJvdXRlUHJvcGVydGllcyk7XG4gICAgLy8gSWYgd2UgYXJlIG5vdCBpbiB0aGUgbWlkZGxlIG9mIGFuIEhNUiByZXZhbGlkYXRpb24gYW5kIHdlIGNoYW5nZWQgdGhlXG4gICAgLy8gcm91dGVzLCBwcm92aWRlIGEgbmV3IGlkZW50aXR5IGFuZCB0cmlnZ2VyIGEgcmVmbG93IHZpYSBgdXBkYXRlU3RhdGVgXG4gICAgLy8gdG8gcmUtcnVuIG1lbW9pemVkIGByb3V0ZXIucm91dGVzYCBkZXBlbmRlbmNpZXMuXG4gICAgLy8gSE1SIHdpbGwgYWxyZWFkeSB1cGRhdGUgdGhlIGlkZW50aXR5IGFuZCByZWZsb3cgd2hlbiBpdCBsYW5kc1xuICAgIC8vIGBpbkZsaWdodERhdGFSb3V0ZXNgIGluIGBjb21wbGV0ZU5hdmlnYXRpb25gXG4gICAgaWYgKGlzTm9uSE1SKSB7XG4gICAgICBkYXRhUm91dGVzID0gWy4uLmRhdGFSb3V0ZXNdO1xuICAgICAgdXBkYXRlU3RhdGUoe30pO1xuICAgIH1cbiAgfVxuICByb3V0ZXIgPSB7XG4gICAgZ2V0IGJhc2VuYW1lKCkge1xuICAgICAgcmV0dXJuIGJhc2VuYW1lO1xuICAgIH0sXG4gICAgZ2V0IGZ1dHVyZSgpIHtcbiAgICAgIHJldHVybiBmdXR1cmU7XG4gICAgfSxcbiAgICBnZXQgc3RhdGUoKSB7XG4gICAgICByZXR1cm4gc3RhdGU7XG4gICAgfSxcbiAgICBnZXQgcm91dGVzKCkge1xuICAgICAgcmV0dXJuIGRhdGFSb3V0ZXM7XG4gICAgfSxcbiAgICBnZXQgd2luZG93KCkge1xuICAgICAgcmV0dXJuIHJvdXRlcldpbmRvdztcbiAgICB9LFxuICAgIGluaXRpYWxpemUsXG4gICAgc3Vic2NyaWJlLFxuICAgIGVuYWJsZVNjcm9sbFJlc3RvcmF0aW9uLFxuICAgIG5hdmlnYXRlLFxuICAgIGZldGNoLFxuICAgIHJldmFsaWRhdGUsXG4gICAgLy8gUGFzc3Rocm91Z2ggdG8gaGlzdG9yeS1hd2FyZSBjcmVhdGVIcmVmIHVzZWQgYnkgdXNlSHJlZiBzbyB3ZSBnZXQgcHJvcGVyXG4gICAgLy8gaGFzaC1hd2FyZSBVUkxzIGluIERPTSBwYXRoc1xuICAgIGNyZWF0ZUhyZWY6IHRvID0+IGluaXQuaGlzdG9yeS5jcmVhdGVIcmVmKHRvKSxcbiAgICBlbmNvZGVMb2NhdGlvbjogdG8gPT4gaW5pdC5oaXN0b3J5LmVuY29kZUxvY2F0aW9uKHRvKSxcbiAgICBnZXRGZXRjaGVyLFxuICAgIGRlbGV0ZUZldGNoZXI6IGRlbGV0ZUZldGNoZXJBbmRVcGRhdGVTdGF0ZSxcbiAgICBkaXNwb3NlLFxuICAgIGdldEJsb2NrZXIsXG4gICAgZGVsZXRlQmxvY2tlcixcbiAgICBwYXRjaFJvdXRlcyxcbiAgICBfaW50ZXJuYWxGZXRjaENvbnRyb2xsZXJzOiBmZXRjaENvbnRyb2xsZXJzLFxuICAgIF9pbnRlcm5hbEFjdGl2ZURlZmVycmVkczogYWN0aXZlRGVmZXJyZWRzLFxuICAgIC8vIFRPRE86IFJlbW92ZSBzZXRSb3V0ZXMsIGl0J3MgdGVtcG9yYXJ5IHRvIGF2b2lkIGRlYWxpbmcgd2l0aFxuICAgIC8vIHVwZGF0aW5nIHRoZSB0cmVlIHdoaWxlIHZhbGlkYXRpbmcgdGhlIHVwZGF0ZSBhbGdvcml0aG0uXG4gICAgX2ludGVybmFsU2V0Um91dGVzXG4gIH07XG4gIHJldHVybiByb3V0ZXI7XG59XG4vLyNlbmRyZWdpb25cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyNyZWdpb24gY3JlYXRlU3RhdGljSGFuZGxlclxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbmNvbnN0IFVOU0FGRV9ERUZFUlJFRF9TWU1CT0wgPSBTeW1ib2woXCJkZWZlcnJlZFwiKTtcbmZ1bmN0aW9uIGNyZWF0ZVN0YXRpY0hhbmRsZXIocm91dGVzLCBvcHRzKSB7XG4gIGludmFyaWFudChyb3V0ZXMubGVuZ3RoID4gMCwgXCJZb3UgbXVzdCBwcm92aWRlIGEgbm9uLWVtcHR5IHJvdXRlcyBhcnJheSB0byBjcmVhdGVTdGF0aWNIYW5kbGVyXCIpO1xuICBsZXQgbWFuaWZlc3QgPSB7fTtcbiAgbGV0IGJhc2VuYW1lID0gKG9wdHMgPyBvcHRzLmJhc2VuYW1lIDogbnVsbCkgfHwgXCIvXCI7XG4gIGxldCBtYXBSb3V0ZVByb3BlcnRpZXM7XG4gIGlmIChvcHRzICE9IG51bGwgJiYgb3B0cy5tYXBSb3V0ZVByb3BlcnRpZXMpIHtcbiAgICBtYXBSb3V0ZVByb3BlcnRpZXMgPSBvcHRzLm1hcFJvdXRlUHJvcGVydGllcztcbiAgfSBlbHNlIGlmIChvcHRzICE9IG51bGwgJiYgb3B0cy5kZXRlY3RFcnJvckJvdW5kYXJ5KSB7XG4gICAgLy8gSWYgdGhleSBhcmUgc3RpbGwgdXNpbmcgdGhlIGRlcHJlY2F0ZWQgdmVyc2lvbiwgd3JhcCBpdCB3aXRoIHRoZSBuZXcgQVBJXG4gICAgbGV0IGRldGVjdEVycm9yQm91bmRhcnkgPSBvcHRzLmRldGVjdEVycm9yQm91bmRhcnk7XG4gICAgbWFwUm91dGVQcm9wZXJ0aWVzID0gcm91dGUgPT4gKHtcbiAgICAgIGhhc0Vycm9yQm91bmRhcnk6IGRldGVjdEVycm9yQm91bmRhcnkocm91dGUpXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgbWFwUm91dGVQcm9wZXJ0aWVzID0gZGVmYXVsdE1hcFJvdXRlUHJvcGVydGllcztcbiAgfVxuICAvLyBDb25maWcgZHJpdmVuIGJlaGF2aW9yIGZsYWdzXG4gIGxldCBmdXR1cmUgPSBfZXh0ZW5kcyh7XG4gICAgdjdfcmVsYXRpdmVTcGxhdFBhdGg6IGZhbHNlLFxuICAgIHY3X3Rocm93QWJvcnRSZWFzb246IGZhbHNlXG4gIH0sIG9wdHMgPyBvcHRzLmZ1dHVyZSA6IG51bGwpO1xuICBsZXQgZGF0YVJvdXRlcyA9IGNvbnZlcnRSb3V0ZXNUb0RhdGFSb3V0ZXMocm91dGVzLCBtYXBSb3V0ZVByb3BlcnRpZXMsIHVuZGVmaW5lZCwgbWFuaWZlc3QpO1xuICAvKipcbiAgICogVGhlIHF1ZXJ5KCkgbWV0aG9kIGlzIGludGVuZGVkIGZvciBkb2N1bWVudCByZXF1ZXN0cywgaW4gd2hpY2ggd2Ugd2FudCB0b1xuICAgKiBjYWxsIGFuIG9wdGlvbmFsIGFjdGlvbiBhbmQgcG90ZW50aWFsbHkgbXVsdGlwbGUgbG9hZGVycyBmb3IgYWxsIG5lc3RlZFxuICAgKiByb3V0ZXMuICBJdCByZXR1cm5zIGEgU3RhdGljSGFuZGxlckNvbnRleHQgb2JqZWN0LCB3aGljaCBpcyB2ZXJ5IHNpbWlsYXJcbiAgICogdG8gdGhlIHJvdXRlciBzdGF0ZSAobG9jYXRpb24sIGxvYWRlckRhdGEsIGFjdGlvbkRhdGEsIGVycm9ycywgZXRjLikgYW5kXG4gICAqIGFsc28gYWRkcyBTU1Itc3BlY2lmaWMgaW5mb3JtYXRpb24gc3VjaCBhcyB0aGUgc3RhdHVzQ29kZSBhbmQgaGVhZGVyc1xuICAgKiBmcm9tIGFjdGlvbi9sb2FkZXJzIFJlc3BvbnNlcy5cbiAgICpcbiAgICogSXQgX3Nob3VsZF8gbmV2ZXIgdGhyb3cgYW5kIHNob3VsZCByZXBvcnQgYWxsIGVycm9ycyB0aHJvdWdoIHRoZVxuICAgKiByZXR1cm5lZCBjb250ZXh0LmVycm9ycyBvYmplY3QsIHByb3Blcmx5IGFzc29jaWF0aW5nIGVycm9ycyB0byB0aGVpciBlcnJvclxuICAgKiBib3VuZGFyeS4gIEFkZGl0aW9uYWxseSwgaXQgdHJhY2tzIF9kZWVwZXN0UmVuZGVyZWRCb3VuZGFyeUlkIHdoaWNoIGNhbiBiZVxuICAgKiB1c2VkIHRvIGVtdWxhdGUgUmVhY3QgZXJyb3IgYm91bmRhcmllcyBkdXJpbmcgU1NyIGJ5IHBlcmZvcm1pbmcgYSBzZWNvbmRcbiAgICogcGFzcyBvbmx5IGRvd24gdG8gdGhlIGJvdW5kYXJ5SWQuXG4gICAqXG4gICAqIFRoZSBvbmUgZXhjZXB0aW9uIHdoZXJlIHdlIGRvIG5vdCByZXR1cm4gYSBTdGF0aWNIYW5kbGVyQ29udGV4dCBpcyB3aGVuIGFcbiAgICogcmVkaXJlY3QgcmVzcG9uc2UgaXMgcmV0dXJuZWQgb3IgdGhyb3duIGZyb20gYW55IGFjdGlvbi9sb2FkZXIuICBXZVxuICAgKiBwcm9wYWdhdGUgdGhhdCBvdXQgYW5kIHJldHVybiB0aGUgcmF3IFJlc3BvbnNlIHNvIHRoZSBIVFRQIHNlcnZlciBjYW5cbiAgICogcmV0dXJuIGl0IGRpcmVjdGx5LlxuICAgKlxuICAgKiAtIGBvcHRzLnJlcXVlc3RDb250ZXh0YCBpcyBhbiBvcHRpb25hbCBzZXJ2ZXIgY29udGV4dCB0aGF0IHdpbGwgYmUgcGFzc2VkXG4gICAqICAgdG8gYWN0aW9ucy9sb2FkZXJzIGluIHRoZSBgY29udGV4dGAgcGFyYW1ldGVyXG4gICAqIC0gYG9wdHMuc2tpcExvYWRlckVycm9yQnViYmxpbmdgIGlzIGFuIG9wdGlvbmFsIHBhcmFtZXRlciB0aGF0IHdpbGwgcHJldmVudFxuICAgKiAgIHRoZSBidWJibGluZyBvZiBlcnJvcnMgd2hpY2ggYWxsb3dzIHNpbmdsZS1mZXRjaC10eXBlIGltcGxlbWVudGF0aW9uc1xuICAgKiAgIHdoZXJlIHRoZSBjbGllbnQgd2lsbCBoYW5kbGUgdGhlIGJ1YmJsaW5nIGFuZCB3ZSBtYXkgbmVlZCB0byByZXR1cm4gZGF0YVxuICAgKiAgIGZvciB0aGUgaGFuZGxpbmcgcm91dGVcbiAgICovXG4gIGFzeW5jIGZ1bmN0aW9uIHF1ZXJ5KHJlcXVlc3QsIF90ZW1wMykge1xuICAgIGxldCB7XG4gICAgICByZXF1ZXN0Q29udGV4dCxcbiAgICAgIHNraXBMb2FkZXJFcnJvckJ1YmJsaW5nLFxuICAgICAgZGF0YVN0cmF0ZWd5XG4gICAgfSA9IF90ZW1wMyA9PT0gdm9pZCAwID8ge30gOiBfdGVtcDM7XG4gICAgbGV0IHVybCA9IG5ldyBVUkwocmVxdWVzdC51cmwpO1xuICAgIGxldCBtZXRob2QgPSByZXF1ZXN0Lm1ldGhvZDtcbiAgICBsZXQgbG9jYXRpb24gPSBjcmVhdGVMb2NhdGlvbihcIlwiLCBjcmVhdGVQYXRoKHVybCksIG51bGwsIFwiZGVmYXVsdFwiKTtcbiAgICBsZXQgbWF0Y2hlcyA9IG1hdGNoUm91dGVzKGRhdGFSb3V0ZXMsIGxvY2F0aW9uLCBiYXNlbmFtZSk7XG4gICAgLy8gU1NSIHN1cHBvcnRzIEhFQUQgcmVxdWVzdHMgd2hpbGUgU1BBIGRvZXNuJ3RcbiAgICBpZiAoIWlzVmFsaWRNZXRob2QobWV0aG9kKSAmJiBtZXRob2QgIT09IFwiSEVBRFwiKSB7XG4gICAgICBsZXQgZXJyb3IgPSBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwNSwge1xuICAgICAgICBtZXRob2RcbiAgICAgIH0pO1xuICAgICAgbGV0IHtcbiAgICAgICAgbWF0Y2hlczogbWV0aG9kTm90QWxsb3dlZE1hdGNoZXMsXG4gICAgICAgIHJvdXRlXG4gICAgICB9ID0gZ2V0U2hvcnRDaXJjdWl0TWF0Y2hlcyhkYXRhUm91dGVzKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGJhc2VuYW1lLFxuICAgICAgICBsb2NhdGlvbixcbiAgICAgICAgbWF0Y2hlczogbWV0aG9kTm90QWxsb3dlZE1hdGNoZXMsXG4gICAgICAgIGxvYWRlckRhdGE6IHt9LFxuICAgICAgICBhY3Rpb25EYXRhOiBudWxsLFxuICAgICAgICBlcnJvcnM6IHtcbiAgICAgICAgICBbcm91dGUuaWRdOiBlcnJvclxuICAgICAgICB9LFxuICAgICAgICBzdGF0dXNDb2RlOiBlcnJvci5zdGF0dXMsXG4gICAgICAgIGxvYWRlckhlYWRlcnM6IHt9LFxuICAgICAgICBhY3Rpb25IZWFkZXJzOiB7fSxcbiAgICAgICAgYWN0aXZlRGVmZXJyZWRzOiBudWxsXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAoIW1hdGNoZXMpIHtcbiAgICAgIGxldCBlcnJvciA9IGdldEludGVybmFsUm91dGVyRXJyb3IoNDA0LCB7XG4gICAgICAgIHBhdGhuYW1lOiBsb2NhdGlvbi5wYXRobmFtZVxuICAgICAgfSk7XG4gICAgICBsZXQge1xuICAgICAgICBtYXRjaGVzOiBub3RGb3VuZE1hdGNoZXMsXG4gICAgICAgIHJvdXRlXG4gICAgICB9ID0gZ2V0U2hvcnRDaXJjdWl0TWF0Y2hlcyhkYXRhUm91dGVzKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGJhc2VuYW1lLFxuICAgICAgICBsb2NhdGlvbixcbiAgICAgICAgbWF0Y2hlczogbm90Rm91bmRNYXRjaGVzLFxuICAgICAgICBsb2FkZXJEYXRhOiB7fSxcbiAgICAgICAgYWN0aW9uRGF0YTogbnVsbCxcbiAgICAgICAgZXJyb3JzOiB7XG4gICAgICAgICAgW3JvdXRlLmlkXTogZXJyb3JcbiAgICAgICAgfSxcbiAgICAgICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzLFxuICAgICAgICBsb2FkZXJIZWFkZXJzOiB7fSxcbiAgICAgICAgYWN0aW9uSGVhZGVyczoge30sXG4gICAgICAgIGFjdGl2ZURlZmVycmVkczogbnVsbFxuICAgICAgfTtcbiAgICB9XG4gICAgbGV0IHJlc3VsdCA9IGF3YWl0IHF1ZXJ5SW1wbChyZXF1ZXN0LCBsb2NhdGlvbiwgbWF0Y2hlcywgcmVxdWVzdENvbnRleHQsIGRhdGFTdHJhdGVneSB8fCBudWxsLCBza2lwTG9hZGVyRXJyb3JCdWJibGluZyA9PT0gdHJ1ZSwgbnVsbCk7XG4gICAgaWYgKGlzUmVzcG9uc2UocmVzdWx0KSkge1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgLy8gV2hlbiByZXR1cm5pbmcgU3RhdGljSGFuZGxlckNvbnRleHQsIHdlIHBhdGNoIGJhY2sgaW4gdGhlIGxvY2F0aW9uIGhlcmVcbiAgICAvLyBzaW5jZSB3ZSBuZWVkIGl0IGZvciBSZWFjdCBDb250ZXh0LiAgQnV0IHRoaXMgaGVscHMga2VlcCBvdXIgc3VibWl0IGFuZFxuICAgIC8vIGxvYWRSb3V0ZURhdGEgb3BlcmF0aW5nIG9uIGEgUmVxdWVzdCBpbnN0ZWFkIG9mIGEgTG9jYXRpb25cbiAgICByZXR1cm4gX2V4dGVuZHMoe1xuICAgICAgbG9jYXRpb24sXG4gICAgICBiYXNlbmFtZVxuICAgIH0sIHJlc3VsdCk7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBxdWVyeVJvdXRlKCkgbWV0aG9kIGlzIGludGVuZGVkIGZvciB0YXJnZXRlZCByb3V0ZSByZXF1ZXN0cywgZWl0aGVyXG4gICAqIGZvciBmZXRjaCA/X2RhdGEgcmVxdWVzdHMgb3IgcmVzb3VyY2Ugcm91dGUgcmVxdWVzdHMuICBJbiB0aGlzIGNhc2UsIHdlXG4gICAqIGFyZSBvbmx5IGV2ZXIgY2FsbGluZyBhIHNpbmdsZSBhY3Rpb24gb3IgbG9hZGVyLCBhbmQgd2UgYXJlIHJldHVybmluZyB0aGVcbiAgICogcmV0dXJuZWQgdmFsdWUgZGlyZWN0bHkuICBJbiBtb3N0IGNhc2VzLCB0aGlzIHdpbGwgYmUgYSBSZXNwb25zZSByZXR1cm5lZFxuICAgKiBmcm9tIHRoZSBhY3Rpb24vbG9hZGVyLCBidXQgaXQgbWF5IGJlIGEgcHJpbWl0aXZlIG9yIG90aGVyIHZhbHVlIGFzIHdlbGwgLVxuICAgKiBhbmQgaW4gc3VjaCBjYXNlcyB0aGUgY2FsbGluZyBjb250ZXh0IHNob3VsZCBoYW5kbGUgdGhhdCBhY2NvcmRpbmdseS5cbiAgICpcbiAgICogV2UgZG8gcmVzcGVjdCB0aGUgdGhyb3cvcmV0dXJuIGRpZmZlcmVudGlhdGlvbiwgc28gaWYgYW4gYWN0aW9uL2xvYWRlclxuICAgKiB0aHJvd3MsIHRoZW4gdGhpcyBtZXRob2Qgd2lsbCB0aHJvdyB0aGUgdmFsdWUuICBUaGlzIGlzIGltcG9ydGFudCBzbyB3ZVxuICAgKiBjYW4gZG8gcHJvcGVyIGJvdW5kYXJ5IGlkZW50aWZpY2F0aW9uIGluIFJlbWl4IHdoZXJlIGEgdGhyb3duIFJlc3BvbnNlXG4gICAqIG11c3QgZ28gdG8gdGhlIENhdGNoIEJvdW5kYXJ5IGJ1dCBhIHJldHVybmVkIFJlc3BvbnNlIGlzIGhhcHB5LXBhdGguXG4gICAqXG4gICAqIE9uZSB0aGluZyB0byBub3RlIGlzIHRoYXQgYW55IFJvdXRlci1pbml0aWF0ZWQgRXJyb3JzIHRoYXQgbWFrZSBzZW5zZVxuICAgKiB0byBhc3NvY2lhdGUgd2l0aCBhIHN0YXR1cyBjb2RlIHdpbGwgYmUgdGhyb3duIGFzIGFuIEVycm9yUmVzcG9uc2VcbiAgICogaW5zdGFuY2Ugd2hpY2ggaW5jbHVkZSB0aGUgcmF3IEVycm9yLCBzdWNoIHRoYXQgdGhlIGNhbGxpbmcgY29udGV4dCBjYW5cbiAgICogc2VyaWFsaXplIHRoZSBlcnJvciBhcyB0aGV5IHNlZSBmaXQgd2hpbGUgaW5jbHVkaW5nIHRoZSBwcm9wZXIgcmVzcG9uc2VcbiAgICogY29kZS4gIEV4YW1wbGVzIGhlcmUgYXJlIDQwNCBhbmQgNDA1IGVycm9ycyB0aGF0IG9jY3VyIHByaW9yIHRvIHJlYWNoaW5nXG4gICAqIGFueSB1c2VyLWRlZmluZWQgbG9hZGVycy5cbiAgICpcbiAgICogLSBgb3B0cy5yb3V0ZUlkYCBhbGxvd3MgeW91IHRvIHNwZWNpZnkgdGhlIHNwZWNpZmljIHJvdXRlIGhhbmRsZXIgdG8gY2FsbC5cbiAgICogICBJZiBub3QgcHJvdmlkZWQgdGhlIGhhbmRsZXIgd2lsbCBkZXRlcm1pbmUgdGhlIHByb3BlciByb3V0ZSBieSBtYXRjaGluZ1xuICAgKiAgIGFnYWluc3QgYHJlcXVlc3QudXJsYFxuICAgKiAtIGBvcHRzLnJlcXVlc3RDb250ZXh0YCBpcyBhbiBvcHRpb25hbCBzZXJ2ZXIgY29udGV4dCB0aGF0IHdpbGwgYmUgcGFzc2VkXG4gICAqICAgIHRvIGFjdGlvbnMvbG9hZGVycyBpbiB0aGUgYGNvbnRleHRgIHBhcmFtZXRlclxuICAgKi9cbiAgYXN5bmMgZnVuY3Rpb24gcXVlcnlSb3V0ZShyZXF1ZXN0LCBfdGVtcDQpIHtcbiAgICBsZXQge1xuICAgICAgcm91dGVJZCxcbiAgICAgIHJlcXVlc3RDb250ZXh0LFxuICAgICAgZGF0YVN0cmF0ZWd5XG4gICAgfSA9IF90ZW1wNCA9PT0gdm9pZCAwID8ge30gOiBfdGVtcDQ7XG4gICAgbGV0IHVybCA9IG5ldyBVUkwocmVxdWVzdC51cmwpO1xuICAgIGxldCBtZXRob2QgPSByZXF1ZXN0Lm1ldGhvZDtcbiAgICBsZXQgbG9jYXRpb24gPSBjcmVhdGVMb2NhdGlvbihcIlwiLCBjcmVhdGVQYXRoKHVybCksIG51bGwsIFwiZGVmYXVsdFwiKTtcbiAgICBsZXQgbWF0Y2hlcyA9IG1hdGNoUm91dGVzKGRhdGFSb3V0ZXMsIGxvY2F0aW9uLCBiYXNlbmFtZSk7XG4gICAgLy8gU1NSIHN1cHBvcnRzIEhFQUQgcmVxdWVzdHMgd2hpbGUgU1BBIGRvZXNuJ3RcbiAgICBpZiAoIWlzVmFsaWRNZXRob2QobWV0aG9kKSAmJiBtZXRob2QgIT09IFwiSEVBRFwiICYmIG1ldGhvZCAhPT0gXCJPUFRJT05TXCIpIHtcbiAgICAgIHRocm93IGdldEludGVybmFsUm91dGVyRXJyb3IoNDA1LCB7XG4gICAgICAgIG1ldGhvZFxuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICghbWF0Y2hlcykge1xuICAgICAgdGhyb3cgZ2V0SW50ZXJuYWxSb3V0ZXJFcnJvcig0MDQsIHtcbiAgICAgICAgcGF0aG5hbWU6IGxvY2F0aW9uLnBhdGhuYW1lXG4gICAgICB9KTtcbiAgICB9XG4gICAgbGV0IG1hdGNoID0gcm91dGVJZCA/IG1hdGNoZXMuZmluZChtID0+IG0ucm91dGUuaWQgPT09IHJvdXRlSWQpIDogZ2V0VGFyZ2V0TWF0Y2gobWF0Y2hlcywgbG9jYXRpb24pO1xuICAgIGlmIChyb3V0ZUlkICYmICFtYXRjaCkge1xuICAgICAgdGhyb3cgZ2V0SW50ZXJuYWxSb3V0ZXJFcnJvcig0MDMsIHtcbiAgICAgICAgcGF0aG5hbWU6IGxvY2F0aW9uLnBhdGhuYW1lLFxuICAgICAgICByb3V0ZUlkXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKCFtYXRjaCkge1xuICAgICAgLy8gVGhpcyBzaG91bGQgbmV2ZXIgaGl0IEkgZG9uJ3QgdGhpbms/XG4gICAgICB0aHJvdyBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwNCwge1xuICAgICAgICBwYXRobmFtZTogbG9jYXRpb24ucGF0aG5hbWVcbiAgICAgIH0pO1xuICAgIH1cbiAgICBsZXQgcmVzdWx0ID0gYXdhaXQgcXVlcnlJbXBsKHJlcXVlc3QsIGxvY2F0aW9uLCBtYXRjaGVzLCByZXF1ZXN0Q29udGV4dCwgZGF0YVN0cmF0ZWd5IHx8IG51bGwsIGZhbHNlLCBtYXRjaCk7XG4gICAgaWYgKGlzUmVzcG9uc2UocmVzdWx0KSkge1xuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgbGV0IGVycm9yID0gcmVzdWx0LmVycm9ycyA/IE9iamVjdC52YWx1ZXMocmVzdWx0LmVycm9ycylbMF0gOiB1bmRlZmluZWQ7XG4gICAgaWYgKGVycm9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIC8vIElmIHdlIGdvdCBiYWNrIHJlc3VsdC5lcnJvcnMsIHRoYXQgbWVhbnMgdGhlIGxvYWRlci9hY3Rpb24gdGhyZXdcbiAgICAgIC8vIF9zb21ldGhpbmdfIHRoYXQgd2Fzbid0IGEgUmVzcG9uc2UsIGJ1dCBpdCdzIG5vdCBndWFyYW50ZWVkL3JlcXVpcmVkXG4gICAgICAvLyB0byBiZSBhbiBgaW5zdGFuY2VvZiBFcnJvcmAgZWl0aGVyLCBzbyB3ZSBoYXZlIHRvIHVzZSB0aHJvdyBoZXJlIHRvXG4gICAgICAvLyBwcmVzZXJ2ZSB0aGUgXCJlcnJvclwiIHN0YXRlIG91dHNpZGUgb2YgcXVlcnlJbXBsLlxuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICAgIC8vIFBpY2sgb2ZmIHRoZSByaWdodCBzdGF0ZSB2YWx1ZSB0byByZXR1cm5cbiAgICBpZiAocmVzdWx0LmFjdGlvbkRhdGEpIHtcbiAgICAgIHJldHVybiBPYmplY3QudmFsdWVzKHJlc3VsdC5hY3Rpb25EYXRhKVswXTtcbiAgICB9XG4gICAgaWYgKHJlc3VsdC5sb2FkZXJEYXRhKSB7XG4gICAgICB2YXIgX3Jlc3VsdCRhY3RpdmVEZWZlcnJlO1xuICAgICAgbGV0IGRhdGEgPSBPYmplY3QudmFsdWVzKHJlc3VsdC5sb2FkZXJEYXRhKVswXTtcbiAgICAgIGlmICgoX3Jlc3VsdCRhY3RpdmVEZWZlcnJlID0gcmVzdWx0LmFjdGl2ZURlZmVycmVkcykgIT0gbnVsbCAmJiBfcmVzdWx0JGFjdGl2ZURlZmVycmVbbWF0Y2gucm91dGUuaWRdKSB7XG4gICAgICAgIGRhdGFbVU5TQUZFX0RFRkVSUkVEX1NZTUJPTF0gPSByZXN1bHQuYWN0aXZlRGVmZXJyZWRzW21hdGNoLnJvdXRlLmlkXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIHF1ZXJ5SW1wbChyZXF1ZXN0LCBsb2NhdGlvbiwgbWF0Y2hlcywgcmVxdWVzdENvbnRleHQsIGRhdGFTdHJhdGVneSwgc2tpcExvYWRlckVycm9yQnViYmxpbmcsIHJvdXRlTWF0Y2gpIHtcbiAgICBpbnZhcmlhbnQocmVxdWVzdC5zaWduYWwsIFwicXVlcnkoKS9xdWVyeVJvdXRlKCkgcmVxdWVzdHMgbXVzdCBjb250YWluIGFuIEFib3J0Q29udHJvbGxlciBzaWduYWxcIik7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChpc011dGF0aW9uTWV0aG9kKHJlcXVlc3QubWV0aG9kLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgICAgIGxldCByZXN1bHQgPSBhd2FpdCBzdWJtaXQocmVxdWVzdCwgbWF0Y2hlcywgcm91dGVNYXRjaCB8fCBnZXRUYXJnZXRNYXRjaChtYXRjaGVzLCBsb2NhdGlvbiksIHJlcXVlc3RDb250ZXh0LCBkYXRhU3RyYXRlZ3ksIHNraXBMb2FkZXJFcnJvckJ1YmJsaW5nLCByb3V0ZU1hdGNoICE9IG51bGwpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfVxuICAgICAgbGV0IHJlc3VsdCA9IGF3YWl0IGxvYWRSb3V0ZURhdGEocmVxdWVzdCwgbWF0Y2hlcywgcmVxdWVzdENvbnRleHQsIGRhdGFTdHJhdGVneSwgc2tpcExvYWRlckVycm9yQnViYmxpbmcsIHJvdXRlTWF0Y2gpO1xuICAgICAgcmV0dXJuIGlzUmVzcG9uc2UocmVzdWx0KSA/IHJlc3VsdCA6IF9leHRlbmRzKHt9LCByZXN1bHQsIHtcbiAgICAgICAgYWN0aW9uRGF0YTogbnVsbCxcbiAgICAgICAgYWN0aW9uSGVhZGVyczoge31cbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIElmIHRoZSB1c2VyIHRocmV3L3JldHVybmVkIGEgUmVzcG9uc2UgaW4gY2FsbExvYWRlck9yQWN0aW9uIGZvciBhXG4gICAgICAvLyBgcXVlcnlSb3V0ZWAgY2FsbCwgd2UgdGhyb3cgdGhlIGBEYXRhU3RyYXRlZ3lSZXN1bHRgIHRvIGJhaWwgb3V0IGVhcmx5XG4gICAgICAvLyBhbmQgdGhlbiByZXR1cm4gb3IgdGhyb3cgdGhlIHJhdyBSZXNwb25zZSBoZXJlIGFjY29yZGluZ2x5XG4gICAgICBpZiAoaXNEYXRhU3RyYXRlZ3lSZXN1bHQoZSkgJiYgaXNSZXNwb25zZShlLnJlc3VsdCkpIHtcbiAgICAgICAgaWYgKGUudHlwZSA9PT0gUmVzdWx0VHlwZS5lcnJvcikge1xuICAgICAgICAgIHRocm93IGUucmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBlLnJlc3VsdDtcbiAgICAgIH1cbiAgICAgIC8vIFJlZGlyZWN0cyBhcmUgYWx3YXlzIHJldHVybmVkIHNpbmNlIHRoZXkgZG9uJ3QgcHJvcGFnYXRlIHRvIGNhdGNoXG4gICAgICAvLyBib3VuZGFyaWVzXG4gICAgICBpZiAoaXNSZWRpcmVjdFJlc3BvbnNlKGUpKSB7XG4gICAgICAgIHJldHVybiBlO1xuICAgICAgfVxuICAgICAgdGhyb3cgZTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gc3VibWl0KHJlcXVlc3QsIG1hdGNoZXMsIGFjdGlvbk1hdGNoLCByZXF1ZXN0Q29udGV4dCwgZGF0YVN0cmF0ZWd5LCBza2lwTG9hZGVyRXJyb3JCdWJibGluZywgaXNSb3V0ZVJlcXVlc3QpIHtcbiAgICBsZXQgcmVzdWx0O1xuICAgIGlmICghYWN0aW9uTWF0Y2gucm91dGUuYWN0aW9uICYmICFhY3Rpb25NYXRjaC5yb3V0ZS5sYXp5KSB7XG4gICAgICBsZXQgZXJyb3IgPSBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwNSwge1xuICAgICAgICBtZXRob2Q6IHJlcXVlc3QubWV0aG9kLFxuICAgICAgICBwYXRobmFtZTogbmV3IFVSTChyZXF1ZXN0LnVybCkucGF0aG5hbWUsXG4gICAgICAgIHJvdXRlSWQ6IGFjdGlvbk1hdGNoLnJvdXRlLmlkXG4gICAgICB9KTtcbiAgICAgIGlmIChpc1JvdXRlUmVxdWVzdCkge1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgIH1cbiAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgdHlwZTogUmVzdWx0VHlwZS5lcnJvcixcbiAgICAgICAgZXJyb3JcbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCByZXN1bHRzID0gYXdhaXQgY2FsbERhdGFTdHJhdGVneShcImFjdGlvblwiLCByZXF1ZXN0LCBbYWN0aW9uTWF0Y2hdLCBtYXRjaGVzLCBpc1JvdXRlUmVxdWVzdCwgcmVxdWVzdENvbnRleHQsIGRhdGFTdHJhdGVneSk7XG4gICAgICByZXN1bHQgPSByZXN1bHRzW2FjdGlvbk1hdGNoLnJvdXRlLmlkXTtcbiAgICAgIGlmIChyZXF1ZXN0LnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgIHRocm93U3RhdGljSGFuZGxlckFib3J0ZWRFcnJvcihyZXF1ZXN0LCBpc1JvdXRlUmVxdWVzdCwgZnV0dXJlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGlzUmVkaXJlY3RSZXN1bHQocmVzdWx0KSkge1xuICAgICAgLy8gVWhoaGggLSB0aGlzIHNob3VsZCBuZXZlciBoYXBwZW4sIHdlIHNob3VsZCBhbHdheXMgdGhyb3cgdGhlc2UgZnJvbVxuICAgICAgLy8gY2FsbExvYWRlck9yQWN0aW9uLCBidXQgdGhlIHR5cGUgbmFycm93aW5nIGhlcmUga2VlcHMgVFMgaGFwcHkgYW5kIHdlXG4gICAgICAvLyBjYW4gZ2V0IGJhY2sgb24gdGhlIFwidGhyb3cgYWxsIHJlZGlyZWN0IHJlc3BvbnNlc1wiIHRyYWluIGhlcmUgc2hvdWxkXG4gICAgICAvLyB0aGlzIGV2ZXIgaGFwcGVuIDovXG4gICAgICB0aHJvdyBuZXcgUmVzcG9uc2UobnVsbCwge1xuICAgICAgICBzdGF0dXM6IHJlc3VsdC5yZXNwb25zZS5zdGF0dXMsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICBMb2NhdGlvbjogcmVzdWx0LnJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiTG9jYXRpb25cIilcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChpc0RlZmVycmVkUmVzdWx0KHJlc3VsdCkpIHtcbiAgICAgIGxldCBlcnJvciA9IGdldEludGVybmFsUm91dGVyRXJyb3IoNDAwLCB7XG4gICAgICAgIHR5cGU6IFwiZGVmZXItYWN0aW9uXCJcbiAgICAgIH0pO1xuICAgICAgaWYgKGlzUm91dGVSZXF1ZXN0KSB7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgICAgcmVzdWx0ID0ge1xuICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLmVycm9yLFxuICAgICAgICBlcnJvclxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKGlzUm91dGVSZXF1ZXN0KSB7XG4gICAgICAvLyBOb3RlOiBUaGlzIHNob3VsZCBvbmx5IGJlIG5vbi1SZXNwb25zZSB2YWx1ZXMgaWYgd2UgZ2V0IGhlcmUsIHNpbmNlXG4gICAgICAvLyBpc1JvdXRlUmVxdWVzdCBzaG91bGQgdGhyb3cgYW55IFJlc3BvbnNlIHJlY2VpdmVkIGluIGNhbGxMb2FkZXJPckFjdGlvblxuICAgICAgaWYgKGlzRXJyb3JSZXN1bHQocmVzdWx0KSkge1xuICAgICAgICB0aHJvdyByZXN1bHQuZXJyb3I7XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICBtYXRjaGVzOiBbYWN0aW9uTWF0Y2hdLFxuICAgICAgICBsb2FkZXJEYXRhOiB7fSxcbiAgICAgICAgYWN0aW9uRGF0YToge1xuICAgICAgICAgIFthY3Rpb25NYXRjaC5yb3V0ZS5pZF06IHJlc3VsdC5kYXRhXG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yczogbnVsbCxcbiAgICAgICAgLy8gTm90ZTogc3RhdHVzQ29kZSArIGhlYWRlcnMgYXJlIHVudXNlZCBoZXJlIHNpbmNlIHF1ZXJ5Um91dGUgd2lsbFxuICAgICAgICAvLyByZXR1cm4gdGhlIHJhdyBSZXNwb25zZSBvciB2YWx1ZVxuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgIGxvYWRlckhlYWRlcnM6IHt9LFxuICAgICAgICBhY3Rpb25IZWFkZXJzOiB7fSxcbiAgICAgICAgYWN0aXZlRGVmZXJyZWRzOiBudWxsXG4gICAgICB9O1xuICAgIH1cbiAgICAvLyBDcmVhdGUgYSBHRVQgcmVxdWVzdCBmb3IgdGhlIGxvYWRlcnNcbiAgICBsZXQgbG9hZGVyUmVxdWVzdCA9IG5ldyBSZXF1ZXN0KHJlcXVlc3QudXJsLCB7XG4gICAgICBoZWFkZXJzOiByZXF1ZXN0LmhlYWRlcnMsXG4gICAgICByZWRpcmVjdDogcmVxdWVzdC5yZWRpcmVjdCxcbiAgICAgIHNpZ25hbDogcmVxdWVzdC5zaWduYWxcbiAgICB9KTtcbiAgICBpZiAoaXNFcnJvclJlc3VsdChyZXN1bHQpKSB7XG4gICAgICAvLyBTdG9yZSBvZmYgdGhlIHBlbmRpbmcgZXJyb3IgLSB3ZSB1c2UgaXQgdG8gZGV0ZXJtaW5lIHdoaWNoIGxvYWRlcnNcbiAgICAgIC8vIHRvIGNhbGwgYW5kIHdpbGwgY29tbWl0IGl0IHdoZW4gd2UgY29tcGxldGUgdGhlIG5hdmlnYXRpb25cbiAgICAgIGxldCBib3VuZGFyeU1hdGNoID0gc2tpcExvYWRlckVycm9yQnViYmxpbmcgPyBhY3Rpb25NYXRjaCA6IGZpbmROZWFyZXN0Qm91bmRhcnkobWF0Y2hlcywgYWN0aW9uTWF0Y2gucm91dGUuaWQpO1xuICAgICAgbGV0IGNvbnRleHQgPSBhd2FpdCBsb2FkUm91dGVEYXRhKGxvYWRlclJlcXVlc3QsIG1hdGNoZXMsIHJlcXVlc3RDb250ZXh0LCBkYXRhU3RyYXRlZ3ksIHNraXBMb2FkZXJFcnJvckJ1YmJsaW5nLCBudWxsLCBbYm91bmRhcnlNYXRjaC5yb3V0ZS5pZCwgcmVzdWx0XSk7XG4gICAgICAvLyBhY3Rpb24gc3RhdHVzIGNvZGVzIHRha2UgcHJlY2VkZW5jZSBvdmVyIGxvYWRlciBzdGF0dXMgY29kZXNcbiAgICAgIHJldHVybiBfZXh0ZW5kcyh7fSwgY29udGV4dCwge1xuICAgICAgICBzdGF0dXNDb2RlOiBpc1JvdXRlRXJyb3JSZXNwb25zZShyZXN1bHQuZXJyb3IpID8gcmVzdWx0LmVycm9yLnN0YXR1cyA6IHJlc3VsdC5zdGF0dXNDb2RlICE9IG51bGwgPyByZXN1bHQuc3RhdHVzQ29kZSA6IDUwMCxcbiAgICAgICAgYWN0aW9uRGF0YTogbnVsbCxcbiAgICAgICAgYWN0aW9uSGVhZGVyczogX2V4dGVuZHMoe30sIHJlc3VsdC5oZWFkZXJzID8ge1xuICAgICAgICAgIFthY3Rpb25NYXRjaC5yb3V0ZS5pZF06IHJlc3VsdC5oZWFkZXJzXG4gICAgICAgIH0gOiB7fSlcbiAgICAgIH0pO1xuICAgIH1cbiAgICBsZXQgY29udGV4dCA9IGF3YWl0IGxvYWRSb3V0ZURhdGEobG9hZGVyUmVxdWVzdCwgbWF0Y2hlcywgcmVxdWVzdENvbnRleHQsIGRhdGFTdHJhdGVneSwgc2tpcExvYWRlckVycm9yQnViYmxpbmcsIG51bGwpO1xuICAgIHJldHVybiBfZXh0ZW5kcyh7fSwgY29udGV4dCwge1xuICAgICAgYWN0aW9uRGF0YToge1xuICAgICAgICBbYWN0aW9uTWF0Y2gucm91dGUuaWRdOiByZXN1bHQuZGF0YVxuICAgICAgfVxuICAgIH0sIHJlc3VsdC5zdGF0dXNDb2RlID8ge1xuICAgICAgc3RhdHVzQ29kZTogcmVzdWx0LnN0YXR1c0NvZGVcbiAgICB9IDoge30sIHtcbiAgICAgIGFjdGlvbkhlYWRlcnM6IHJlc3VsdC5oZWFkZXJzID8ge1xuICAgICAgICBbYWN0aW9uTWF0Y2gucm91dGUuaWRdOiByZXN1bHQuaGVhZGVyc1xuICAgICAgfSA6IHt9XG4gICAgfSk7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gbG9hZFJvdXRlRGF0YShyZXF1ZXN0LCBtYXRjaGVzLCByZXF1ZXN0Q29udGV4dCwgZGF0YVN0cmF0ZWd5LCBza2lwTG9hZGVyRXJyb3JCdWJibGluZywgcm91dGVNYXRjaCwgcGVuZGluZ0FjdGlvblJlc3VsdCkge1xuICAgIGxldCBpc1JvdXRlUmVxdWVzdCA9IHJvdXRlTWF0Y2ggIT0gbnVsbDtcbiAgICAvLyBTaG9ydCBjaXJjdWl0IGlmIHdlIGhhdmUgbm8gbG9hZGVycyB0byBydW4gKHF1ZXJ5Um91dGUoKSlcbiAgICBpZiAoaXNSb3V0ZVJlcXVlc3QgJiYgIShyb3V0ZU1hdGNoICE9IG51bGwgJiYgcm91dGVNYXRjaC5yb3V0ZS5sb2FkZXIpICYmICEocm91dGVNYXRjaCAhPSBudWxsICYmIHJvdXRlTWF0Y2gucm91dGUubGF6eSkpIHtcbiAgICAgIHRocm93IGdldEludGVybmFsUm91dGVyRXJyb3IoNDAwLCB7XG4gICAgICAgIG1ldGhvZDogcmVxdWVzdC5tZXRob2QsXG4gICAgICAgIHBhdGhuYW1lOiBuZXcgVVJMKHJlcXVlc3QudXJsKS5wYXRobmFtZSxcbiAgICAgICAgcm91dGVJZDogcm91dGVNYXRjaCA9PSBudWxsID8gdm9pZCAwIDogcm91dGVNYXRjaC5yb3V0ZS5pZFxuICAgICAgfSk7XG4gICAgfVxuICAgIGxldCByZXF1ZXN0TWF0Y2hlcyA9IHJvdXRlTWF0Y2ggPyBbcm91dGVNYXRjaF0gOiBwZW5kaW5nQWN0aW9uUmVzdWx0ICYmIGlzRXJyb3JSZXN1bHQocGVuZGluZ0FjdGlvblJlc3VsdFsxXSkgPyBnZXRMb2FkZXJNYXRjaGVzVW50aWxCb3VuZGFyeShtYXRjaGVzLCBwZW5kaW5nQWN0aW9uUmVzdWx0WzBdKSA6IG1hdGNoZXM7XG4gICAgbGV0IG1hdGNoZXNUb0xvYWQgPSByZXF1ZXN0TWF0Y2hlcy5maWx0ZXIobSA9PiBtLnJvdXRlLmxvYWRlciB8fCBtLnJvdXRlLmxhenkpO1xuICAgIC8vIFNob3J0IGNpcmN1aXQgaWYgd2UgaGF2ZSBubyBsb2FkZXJzIHRvIHJ1biAocXVlcnkoKSlcbiAgICBpZiAobWF0Y2hlc1RvTG9hZC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG1hdGNoZXMsXG4gICAgICAgIC8vIEFkZCBhIG51bGwgZm9yIGFsbCBtYXRjaGVkIHJvdXRlcyBmb3IgcHJvcGVyIHJldmFsaWRhdGlvbiBvbiB0aGUgY2xpZW50XG4gICAgICAgIGxvYWRlckRhdGE6IG1hdGNoZXMucmVkdWNlKChhY2MsIG0pID0+IE9iamVjdC5hc3NpZ24oYWNjLCB7XG4gICAgICAgICAgW20ucm91dGUuaWRdOiBudWxsXG4gICAgICAgIH0pLCB7fSksXG4gICAgICAgIGVycm9yczogcGVuZGluZ0FjdGlvblJlc3VsdCAmJiBpc0Vycm9yUmVzdWx0KHBlbmRpbmdBY3Rpb25SZXN1bHRbMV0pID8ge1xuICAgICAgICAgIFtwZW5kaW5nQWN0aW9uUmVzdWx0WzBdXTogcGVuZGluZ0FjdGlvblJlc3VsdFsxXS5lcnJvclxuICAgICAgICB9IDogbnVsbCxcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBsb2FkZXJIZWFkZXJzOiB7fSxcbiAgICAgICAgYWN0aXZlRGVmZXJyZWRzOiBudWxsXG4gICAgICB9O1xuICAgIH1cbiAgICBsZXQgcmVzdWx0cyA9IGF3YWl0IGNhbGxEYXRhU3RyYXRlZ3koXCJsb2FkZXJcIiwgcmVxdWVzdCwgbWF0Y2hlc1RvTG9hZCwgbWF0Y2hlcywgaXNSb3V0ZVJlcXVlc3QsIHJlcXVlc3RDb250ZXh0LCBkYXRhU3RyYXRlZ3kpO1xuICAgIGlmIChyZXF1ZXN0LnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICB0aHJvd1N0YXRpY0hhbmRsZXJBYm9ydGVkRXJyb3IocmVxdWVzdCwgaXNSb3V0ZVJlcXVlc3QsIGZ1dHVyZSk7XG4gICAgfVxuICAgIC8vIFByb2Nlc3MgYW5kIGNvbW1pdCBvdXRwdXQgZnJvbSBsb2FkZXJzXG4gICAgbGV0IGFjdGl2ZURlZmVycmVkcyA9IG5ldyBNYXAoKTtcbiAgICBsZXQgY29udGV4dCA9IHByb2Nlc3NSb3V0ZUxvYWRlckRhdGEobWF0Y2hlcywgcmVzdWx0cywgcGVuZGluZ0FjdGlvblJlc3VsdCwgYWN0aXZlRGVmZXJyZWRzLCBza2lwTG9hZGVyRXJyb3JCdWJibGluZyk7XG4gICAgLy8gQWRkIGEgbnVsbCBmb3IgYW55IG5vbi1sb2FkZXIgbWF0Y2hlcyBmb3IgcHJvcGVyIHJldmFsaWRhdGlvbiBvbiB0aGUgY2xpZW50XG4gICAgbGV0IGV4ZWN1dGVkTG9hZGVycyA9IG5ldyBTZXQobWF0Y2hlc1RvTG9hZC5tYXAobWF0Y2ggPT4gbWF0Y2gucm91dGUuaWQpKTtcbiAgICBtYXRjaGVzLmZvckVhY2gobWF0Y2ggPT4ge1xuICAgICAgaWYgKCFleGVjdXRlZExvYWRlcnMuaGFzKG1hdGNoLnJvdXRlLmlkKSkge1xuICAgICAgICBjb250ZXh0LmxvYWRlckRhdGFbbWF0Y2gucm91dGUuaWRdID0gbnVsbDtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gX2V4dGVuZHMoe30sIGNvbnRleHQsIHtcbiAgICAgIG1hdGNoZXMsXG4gICAgICBhY3RpdmVEZWZlcnJlZHM6IGFjdGl2ZURlZmVycmVkcy5zaXplID4gMCA/IE9iamVjdC5mcm9tRW50cmllcyhhY3RpdmVEZWZlcnJlZHMuZW50cmllcygpKSA6IG51bGxcbiAgICB9KTtcbiAgfVxuICAvLyBVdGlsaXR5IHdyYXBwZXIgZm9yIGNhbGxpbmcgZGF0YVN0cmF0ZWd5IHNlcnZlci1zaWRlIHdpdGhvdXQgaGF2aW5nIHRvXG4gIC8vIHBhc3MgYXJvdW5kIHRoZSBtYW5pZmVzdCwgbWFwUm91dGVQcm9wZXJ0aWVzLCBldGMuXG4gIGFzeW5jIGZ1bmN0aW9uIGNhbGxEYXRhU3RyYXRlZ3kodHlwZSwgcmVxdWVzdCwgbWF0Y2hlc1RvTG9hZCwgbWF0Y2hlcywgaXNSb3V0ZVJlcXVlc3QsIHJlcXVlc3RDb250ZXh0LCBkYXRhU3RyYXRlZ3kpIHtcbiAgICBsZXQgcmVzdWx0cyA9IGF3YWl0IGNhbGxEYXRhU3RyYXRlZ3lJbXBsKGRhdGFTdHJhdGVneSB8fCBkZWZhdWx0RGF0YVN0cmF0ZWd5LCB0eXBlLCBudWxsLCByZXF1ZXN0LCBtYXRjaGVzVG9Mb2FkLCBtYXRjaGVzLCBudWxsLCBtYW5pZmVzdCwgbWFwUm91dGVQcm9wZXJ0aWVzLCByZXF1ZXN0Q29udGV4dCk7XG4gICAgbGV0IGRhdGFSZXN1bHRzID0ge307XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwobWF0Y2hlcy5tYXAoYXN5bmMgbWF0Y2ggPT4ge1xuICAgICAgaWYgKCEobWF0Y2gucm91dGUuaWQgaW4gcmVzdWx0cykpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGV0IHJlc3VsdCA9IHJlc3VsdHNbbWF0Y2gucm91dGUuaWRdO1xuICAgICAgaWYgKGlzUmVkaXJlY3REYXRhU3RyYXRlZ3lSZXN1bHRSZXN1bHQocmVzdWx0KSkge1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSByZXN1bHQucmVzdWx0O1xuICAgICAgICAvLyBUaHJvdyByZWRpcmVjdHMgYW5kIGxldCB0aGUgc2VydmVyIGhhbmRsZSB0aGVtIHdpdGggYW4gSFRUUCByZWRpcmVjdFxuICAgICAgICB0aHJvdyBub3JtYWxpemVSZWxhdGl2ZVJvdXRpbmdSZWRpcmVjdFJlc3BvbnNlKHJlc3BvbnNlLCByZXF1ZXN0LCBtYXRjaC5yb3V0ZS5pZCwgbWF0Y2hlcywgYmFzZW5hbWUsIGZ1dHVyZS52N19yZWxhdGl2ZVNwbGF0UGF0aCk7XG4gICAgICB9XG4gICAgICBpZiAoaXNSZXNwb25zZShyZXN1bHQucmVzdWx0KSAmJiBpc1JvdXRlUmVxdWVzdCkge1xuICAgICAgICAvLyBGb3IgU1NSIHNpbmdsZS1yb3V0ZSByZXF1ZXN0cywgd2Ugd2FudCB0byBoYW5kIFJlc3BvbnNlcyBiYWNrXG4gICAgICAgIC8vIGRpcmVjdGx5IHdpdGhvdXQgdW53cmFwcGluZ1xuICAgICAgICB0aHJvdyByZXN1bHQ7XG4gICAgICB9XG4gICAgICBkYXRhUmVzdWx0c1ttYXRjaC5yb3V0ZS5pZF0gPSBhd2FpdCBjb252ZXJ0RGF0YVN0cmF0ZWd5UmVzdWx0VG9EYXRhUmVzdWx0KHJlc3VsdCk7XG4gICAgfSkpO1xuICAgIHJldHVybiBkYXRhUmVzdWx0cztcbiAgfVxuICByZXR1cm4ge1xuICAgIGRhdGFSb3V0ZXMsXG4gICAgcXVlcnksXG4gICAgcXVlcnlSb3V0ZVxuICB9O1xufVxuLy8jZW5kcmVnaW9uXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8jcmVnaW9uIEhlbHBlcnNcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vKipcbiAqIEdpdmVuIGFuIGV4aXN0aW5nIFN0YXRpY0hhbmRsZXJDb250ZXh0IGFuZCBhbiBlcnJvciB0aHJvd24gYXQgcmVuZGVyIHRpbWUsXG4gKiBwcm92aWRlIGFuIHVwZGF0ZWQgU3RhdGljSGFuZGxlckNvbnRleHQgc3VpdGFibGUgZm9yIGEgc2Vjb25kIFNTUiByZW5kZXJcbiAqL1xuZnVuY3Rpb24gZ2V0U3RhdGljQ29udGV4dEZyb21FcnJvcihyb3V0ZXMsIGNvbnRleHQsIGVycm9yKSB7XG4gIGxldCBuZXdDb250ZXh0ID0gX2V4dGVuZHMoe30sIGNvbnRleHQsIHtcbiAgICBzdGF0dXNDb2RlOiBpc1JvdXRlRXJyb3JSZXNwb25zZShlcnJvcikgPyBlcnJvci5zdGF0dXMgOiA1MDAsXG4gICAgZXJyb3JzOiB7XG4gICAgICBbY29udGV4dC5fZGVlcGVzdFJlbmRlcmVkQm91bmRhcnlJZCB8fCByb3V0ZXNbMF0uaWRdOiBlcnJvclxuICAgIH1cbiAgfSk7XG4gIHJldHVybiBuZXdDb250ZXh0O1xufVxuZnVuY3Rpb24gdGhyb3dTdGF0aWNIYW5kbGVyQWJvcnRlZEVycm9yKHJlcXVlc3QsIGlzUm91dGVSZXF1ZXN0LCBmdXR1cmUpIHtcbiAgaWYgKGZ1dHVyZS52N190aHJvd0Fib3J0UmVhc29uICYmIHJlcXVlc3Quc2lnbmFsLnJlYXNvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgcmVxdWVzdC5zaWduYWwucmVhc29uO1xuICB9XG4gIGxldCBtZXRob2QgPSBpc1JvdXRlUmVxdWVzdCA/IFwicXVlcnlSb3V0ZVwiIDogXCJxdWVyeVwiO1xuICB0aHJvdyBuZXcgRXJyb3IobWV0aG9kICsgXCIoKSBjYWxsIGFib3J0ZWQ6IFwiICsgcmVxdWVzdC5tZXRob2QgKyBcIiBcIiArIHJlcXVlc3QudXJsKTtcbn1cbmZ1bmN0aW9uIGlzU3VibWlzc2lvbk5hdmlnYXRpb24ob3B0cykge1xuICByZXR1cm4gb3B0cyAhPSBudWxsICYmIChcImZvcm1EYXRhXCIgaW4gb3B0cyAmJiBvcHRzLmZvcm1EYXRhICE9IG51bGwgfHwgXCJib2R5XCIgaW4gb3B0cyAmJiBvcHRzLmJvZHkgIT09IHVuZGVmaW5lZCk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVUbyhsb2NhdGlvbiwgbWF0Y2hlcywgYmFzZW5hbWUsIHByZXBlbmRCYXNlbmFtZSwgdG8sIHY3X3JlbGF0aXZlU3BsYXRQYXRoLCBmcm9tUm91dGVJZCwgcmVsYXRpdmUpIHtcbiAgbGV0IGNvbnRleHR1YWxNYXRjaGVzO1xuICBsZXQgYWN0aXZlUm91dGVNYXRjaDtcbiAgaWYgKGZyb21Sb3V0ZUlkKSB7XG4gICAgLy8gR3JhYiBtYXRjaGVzIHVwIHRvIHRoZSBjYWxsaW5nIHJvdXRlIHNvIG91ciByb3V0ZS1yZWxhdGl2ZSBsb2dpYyBpc1xuICAgIC8vIHJlbGF0aXZlIHRvIHRoZSBjb3JyZWN0IHNvdXJjZSByb3V0ZVxuICAgIGNvbnRleHR1YWxNYXRjaGVzID0gW107XG4gICAgZm9yIChsZXQgbWF0Y2ggb2YgbWF0Y2hlcykge1xuICAgICAgY29udGV4dHVhbE1hdGNoZXMucHVzaChtYXRjaCk7XG4gICAgICBpZiAobWF0Y2gucm91dGUuaWQgPT09IGZyb21Sb3V0ZUlkKSB7XG4gICAgICAgIGFjdGl2ZVJvdXRlTWF0Y2ggPSBtYXRjaDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGNvbnRleHR1YWxNYXRjaGVzID0gbWF0Y2hlcztcbiAgICBhY3RpdmVSb3V0ZU1hdGNoID0gbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdO1xuICB9XG4gIC8vIFJlc29sdmUgdGhlIHJlbGF0aXZlIHBhdGhcbiAgbGV0IHBhdGggPSByZXNvbHZlVG8odG8gPyB0byA6IFwiLlwiLCBnZXRSZXNvbHZlVG9NYXRjaGVzKGNvbnRleHR1YWxNYXRjaGVzLCB2N19yZWxhdGl2ZVNwbGF0UGF0aCksIHN0cmlwQmFzZW5hbWUobG9jYXRpb24ucGF0aG5hbWUsIGJhc2VuYW1lKSB8fCBsb2NhdGlvbi5wYXRobmFtZSwgcmVsYXRpdmUgPT09IFwicGF0aFwiKTtcbiAgLy8gV2hlbiBgdG9gIGlzIG5vdCBzcGVjaWZpZWQgd2UgaW5oZXJpdCBzZWFyY2gvaGFzaCBmcm9tIHRoZSBjdXJyZW50XG4gIC8vIGxvY2F0aW9uLCB1bmxpa2Ugd2hlbiB0bz1cIi5cIiBhbmQgd2UganVzdCBpbmhlcml0IHRoZSBwYXRoLlxuICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL3JlbWl4LXJ1bi9yZW1peC9pc3N1ZXMvOTI3XG4gIGlmICh0byA9PSBudWxsKSB7XG4gICAgcGF0aC5zZWFyY2ggPSBsb2NhdGlvbi5zZWFyY2g7XG4gICAgcGF0aC5oYXNoID0gbG9jYXRpb24uaGFzaDtcbiAgfVxuICAvLyBBY2NvdW50IGZvciBgP2luZGV4YCBwYXJhbXMgd2hlbiByb3V0aW5nIHRvIHRoZSBjdXJyZW50IGxvY2F0aW9uXG4gIGlmICgodG8gPT0gbnVsbCB8fCB0byA9PT0gXCJcIiB8fCB0byA9PT0gXCIuXCIpICYmIGFjdGl2ZVJvdXRlTWF0Y2gpIHtcbiAgICBsZXQgbmFrZWRJbmRleCA9IGhhc05ha2VkSW5kZXhRdWVyeShwYXRoLnNlYXJjaCk7XG4gICAgaWYgKGFjdGl2ZVJvdXRlTWF0Y2gucm91dGUuaW5kZXggJiYgIW5ha2VkSW5kZXgpIHtcbiAgICAgIC8vIEFkZCBvbmUgd2hlbiB3ZSdyZSB0YXJnZXRpbmcgYW4gaW5kZXggcm91dGVcbiAgICAgIHBhdGguc2VhcmNoID0gcGF0aC5zZWFyY2ggPyBwYXRoLnNlYXJjaC5yZXBsYWNlKC9eXFw/LywgXCI/aW5kZXgmXCIpIDogXCI/aW5kZXhcIjtcbiAgICB9IGVsc2UgaWYgKCFhY3RpdmVSb3V0ZU1hdGNoLnJvdXRlLmluZGV4ICYmIG5ha2VkSW5kZXgpIHtcbiAgICAgIC8vIFJlbW92ZSBleGlzdGluZyBvbmVzIHdoZW4gd2UncmUgbm90XG4gICAgICBsZXQgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXRoLnNlYXJjaCk7XG4gICAgICBsZXQgaW5kZXhWYWx1ZXMgPSBwYXJhbXMuZ2V0QWxsKFwiaW5kZXhcIik7XG4gICAgICBwYXJhbXMuZGVsZXRlKFwiaW5kZXhcIik7XG4gICAgICBpbmRleFZhbHVlcy5maWx0ZXIodiA9PiB2KS5mb3JFYWNoKHYgPT4gcGFyYW1zLmFwcGVuZChcImluZGV4XCIsIHYpKTtcbiAgICAgIGxldCBxcyA9IHBhcmFtcy50b1N0cmluZygpO1xuICAgICAgcGF0aC5zZWFyY2ggPSBxcyA/IFwiP1wiICsgcXMgOiBcIlwiO1xuICAgIH1cbiAgfVxuICAvLyBJZiB3ZSdyZSBvcGVyYXRpbmcgd2l0aGluIGEgYmFzZW5hbWUsIHByZXBlbmQgaXQgdG8gdGhlIHBhdGhuYW1lLiAgSWZcbiAgLy8gdGhpcyBpcyBhIHJvb3QgbmF2aWdhdGlvbiwgdGhlbiBqdXN0IHVzZSB0aGUgcmF3IGJhc2VuYW1lIHdoaWNoIGFsbG93c1xuICAvLyB0aGUgYmFzZW5hbWUgdG8gaGF2ZSBmdWxsIGNvbnRyb2wgb3ZlciB0aGUgcHJlc2VuY2Ugb2YgYSB0cmFpbGluZyBzbGFzaFxuICAvLyBvbiByb290IGFjdGlvbnNcbiAgaWYgKHByZXBlbmRCYXNlbmFtZSAmJiBiYXNlbmFtZSAhPT0gXCIvXCIpIHtcbiAgICBwYXRoLnBhdGhuYW1lID0gcGF0aC5wYXRobmFtZSA9PT0gXCIvXCIgPyBiYXNlbmFtZSA6IGpvaW5QYXRocyhbYmFzZW5hbWUsIHBhdGgucGF0aG5hbWVdKTtcbiAgfVxuICByZXR1cm4gY3JlYXRlUGF0aChwYXRoKTtcbn1cbi8vIE5vcm1hbGl6ZSBuYXZpZ2F0aW9uIG9wdGlvbnMgYnkgY29udmVydGluZyBmb3JtTWV0aG9kPUdFVCBmb3JtRGF0YSBvYmplY3RzIHRvXG4vLyBVUkxTZWFyY2hQYXJhbXMgc28gdGhleSBiZWhhdmUgaWRlbnRpY2FsbHkgdG8gbGlua3Mgd2l0aCBxdWVyeSBwYXJhbXNcbmZ1bmN0aW9uIG5vcm1hbGl6ZU5hdmlnYXRlT3B0aW9ucyhub3JtYWxpemVGb3JtTWV0aG9kLCBpc0ZldGNoZXIsIHBhdGgsIG9wdHMpIHtcbiAgLy8gUmV0dXJuIGxvY2F0aW9uIHZlcmJhdGltIG9uIG5vbi1zdWJtaXNzaW9uIG5hdmlnYXRpb25zXG4gIGlmICghb3B0cyB8fCAhaXNTdWJtaXNzaW9uTmF2aWdhdGlvbihvcHRzKSkge1xuICAgIHJldHVybiB7XG4gICAgICBwYXRoXG4gICAgfTtcbiAgfVxuICBpZiAob3B0cy5mb3JtTWV0aG9kICYmICFpc1ZhbGlkTWV0aG9kKG9wdHMuZm9ybU1ldGhvZCkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgcGF0aCxcbiAgICAgIGVycm9yOiBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwNSwge1xuICAgICAgICBtZXRob2Q6IG9wdHMuZm9ybU1ldGhvZFxuICAgICAgfSlcbiAgICB9O1xuICB9XG4gIGxldCBnZXRJbnZhbGlkQm9keUVycm9yID0gKCkgPT4gKHtcbiAgICBwYXRoLFxuICAgIGVycm9yOiBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwMCwge1xuICAgICAgdHlwZTogXCJpbnZhbGlkLWJvZHlcIlxuICAgIH0pXG4gIH0pO1xuICAvLyBDcmVhdGUgYSBTdWJtaXNzaW9uIG9uIG5vbi1HRVQgbmF2aWdhdGlvbnNcbiAgbGV0IHJhd0Zvcm1NZXRob2QgPSBvcHRzLmZvcm1NZXRob2QgfHwgXCJnZXRcIjtcbiAgbGV0IGZvcm1NZXRob2QgPSBub3JtYWxpemVGb3JtTWV0aG9kID8gcmF3Rm9ybU1ldGhvZC50b1VwcGVyQ2FzZSgpIDogcmF3Rm9ybU1ldGhvZC50b0xvd2VyQ2FzZSgpO1xuICBsZXQgZm9ybUFjdGlvbiA9IHN0cmlwSGFzaEZyb21QYXRoKHBhdGgpO1xuICBpZiAob3B0cy5ib2R5ICE9PSB1bmRlZmluZWQpIHtcbiAgICBpZiAob3B0cy5mb3JtRW5jVHlwZSA9PT0gXCJ0ZXh0L3BsYWluXCIpIHtcbiAgICAgIC8vIHRleHQgb25seSBzdXBwb3J0IFBPU1QvUFVUL1BBVENIL0RFTEVURSBzdWJtaXNzaW9uc1xuICAgICAgaWYgKCFpc011dGF0aW9uTWV0aG9kKGZvcm1NZXRob2QpKSB7XG4gICAgICAgIHJldHVybiBnZXRJbnZhbGlkQm9keUVycm9yKCk7XG4gICAgICB9XG4gICAgICBsZXQgdGV4dCA9IHR5cGVvZiBvcHRzLmJvZHkgPT09IFwic3RyaW5nXCIgPyBvcHRzLmJvZHkgOiBvcHRzLmJvZHkgaW5zdGFuY2VvZiBGb3JtRGF0YSB8fCBvcHRzLmJvZHkgaW5zdGFuY2VvZiBVUkxTZWFyY2hQYXJhbXMgP1xuICAgICAgLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2UvZm9ybS1jb250cm9sLWluZnJhc3RydWN0dXJlLmh0bWwjcGxhaW4tdGV4dC1mb3JtLWRhdGFcbiAgICAgIEFycmF5LmZyb20ob3B0cy5ib2R5LmVudHJpZXMoKSkucmVkdWNlKChhY2MsIF9yZWYzKSA9PiB7XG4gICAgICAgIGxldCBbbmFtZSwgdmFsdWVdID0gX3JlZjM7XG4gICAgICAgIHJldHVybiBcIlwiICsgYWNjICsgbmFtZSArIFwiPVwiICsgdmFsdWUgKyBcIlxcblwiO1xuICAgICAgfSwgXCJcIikgOiBTdHJpbmcob3B0cy5ib2R5KTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHBhdGgsXG4gICAgICAgIHN1Ym1pc3Npb246IHtcbiAgICAgICAgICBmb3JtTWV0aG9kLFxuICAgICAgICAgIGZvcm1BY3Rpb24sXG4gICAgICAgICAgZm9ybUVuY1R5cGU6IG9wdHMuZm9ybUVuY1R5cGUsXG4gICAgICAgICAgZm9ybURhdGE6IHVuZGVmaW5lZCxcbiAgICAgICAgICBqc29uOiB1bmRlZmluZWQsXG4gICAgICAgICAgdGV4dFxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAob3B0cy5mb3JtRW5jVHlwZSA9PT0gXCJhcHBsaWNhdGlvbi9qc29uXCIpIHtcbiAgICAgIC8vIGpzb24gb25seSBzdXBwb3J0cyBQT1NUL1BVVC9QQVRDSC9ERUxFVEUgc3VibWlzc2lvbnNcbiAgICAgIGlmICghaXNNdXRhdGlvbk1ldGhvZChmb3JtTWV0aG9kKSkge1xuICAgICAgICByZXR1cm4gZ2V0SW52YWxpZEJvZHlFcnJvcigpO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgbGV0IGpzb24gPSB0eXBlb2Ygb3B0cy5ib2R5ID09PSBcInN0cmluZ1wiID8gSlNPTi5wYXJzZShvcHRzLmJvZHkpIDogb3B0cy5ib2R5O1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgc3VibWlzc2lvbjoge1xuICAgICAgICAgICAgZm9ybU1ldGhvZCxcbiAgICAgICAgICAgIGZvcm1BY3Rpb24sXG4gICAgICAgICAgICBmb3JtRW5jVHlwZTogb3B0cy5mb3JtRW5jVHlwZSxcbiAgICAgICAgICAgIGZvcm1EYXRhOiB1bmRlZmluZWQsXG4gICAgICAgICAgICBqc29uLFxuICAgICAgICAgICAgdGV4dDogdW5kZWZpbmVkXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gZ2V0SW52YWxpZEJvZHlFcnJvcigpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpbnZhcmlhbnQodHlwZW9mIEZvcm1EYXRhID09PSBcImZ1bmN0aW9uXCIsIFwiRm9ybURhdGEgaXMgbm90IGF2YWlsYWJsZSBpbiB0aGlzIGVudmlyb25tZW50XCIpO1xuICBsZXQgc2VhcmNoUGFyYW1zO1xuICBsZXQgZm9ybURhdGE7XG4gIGlmIChvcHRzLmZvcm1EYXRhKSB7XG4gICAgc2VhcmNoUGFyYW1zID0gY29udmVydEZvcm1EYXRhVG9TZWFyY2hQYXJhbXMob3B0cy5mb3JtRGF0YSk7XG4gICAgZm9ybURhdGEgPSBvcHRzLmZvcm1EYXRhO1xuICB9IGVsc2UgaWYgKG9wdHMuYm9keSBpbnN0YW5jZW9mIEZvcm1EYXRhKSB7XG4gICAgc2VhcmNoUGFyYW1zID0gY29udmVydEZvcm1EYXRhVG9TZWFyY2hQYXJhbXMob3B0cy5ib2R5KTtcbiAgICBmb3JtRGF0YSA9IG9wdHMuYm9keTtcbiAgfSBlbHNlIGlmIChvcHRzLmJvZHkgaW5zdGFuY2VvZiBVUkxTZWFyY2hQYXJhbXMpIHtcbiAgICBzZWFyY2hQYXJhbXMgPSBvcHRzLmJvZHk7XG4gICAgZm9ybURhdGEgPSBjb252ZXJ0U2VhcmNoUGFyYW1zVG9Gb3JtRGF0YShzZWFyY2hQYXJhbXMpO1xuICB9IGVsc2UgaWYgKG9wdHMuYm9keSA9PSBudWxsKSB7XG4gICAgc2VhcmNoUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICAgIGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKCk7XG4gIH0gZWxzZSB7XG4gICAgdHJ5IHtcbiAgICAgIHNlYXJjaFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMob3B0cy5ib2R5KTtcbiAgICAgIGZvcm1EYXRhID0gY29udmVydFNlYXJjaFBhcmFtc1RvRm9ybURhdGEoc2VhcmNoUGFyYW1zKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4gZ2V0SW52YWxpZEJvZHlFcnJvcigpO1xuICAgIH1cbiAgfVxuICBsZXQgc3VibWlzc2lvbiA9IHtcbiAgICBmb3JtTWV0aG9kLFxuICAgIGZvcm1BY3Rpb24sXG4gICAgZm9ybUVuY1R5cGU6IG9wdHMgJiYgb3B0cy5mb3JtRW5jVHlwZSB8fCBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiLFxuICAgIGZvcm1EYXRhLFxuICAgIGpzb246IHVuZGVmaW5lZCxcbiAgICB0ZXh0OiB1bmRlZmluZWRcbiAgfTtcbiAgaWYgKGlzTXV0YXRpb25NZXRob2Qoc3VibWlzc2lvbi5mb3JtTWV0aG9kKSkge1xuICAgIHJldHVybiB7XG4gICAgICBwYXRoLFxuICAgICAgc3VibWlzc2lvblxuICAgIH07XG4gIH1cbiAgLy8gRmxhdHRlbiBzdWJtaXNzaW9uIG9udG8gVVJMU2VhcmNoUGFyYW1zIGZvciBHRVQgc3VibWlzc2lvbnNcbiAgbGV0IHBhcnNlZFBhdGggPSBwYXJzZVBhdGgocGF0aCk7XG4gIC8vIE9uIEdFVCBuYXZpZ2F0aW9uIHN1Ym1pc3Npb25zIHdlIGNhbiBkcm9wIHRoZSA/aW5kZXggcGFyYW0gZnJvbSB0aGVcbiAgLy8gcmVzdWx0aW5nIGxvY2F0aW9uIHNpbmNlIGFsbCBsb2FkZXJzIHdpbGwgcnVuLiAgQnV0IGZldGNoZXIgR0VUIHN1Ym1pc3Npb25zXG4gIC8vIG9ubHkgcnVuIGEgc2luZ2xlIGxvYWRlciBzbyB3ZSBuZWVkIHRvIHByZXNlcnZlIGFueSBpbmNvbWluZyA/aW5kZXggcGFyYW1zXG4gIGlmIChpc0ZldGNoZXIgJiYgcGFyc2VkUGF0aC5zZWFyY2ggJiYgaGFzTmFrZWRJbmRleFF1ZXJ5KHBhcnNlZFBhdGguc2VhcmNoKSkge1xuICAgIHNlYXJjaFBhcmFtcy5hcHBlbmQoXCJpbmRleFwiLCBcIlwiKTtcbiAgfVxuICBwYXJzZWRQYXRoLnNlYXJjaCA9IFwiP1wiICsgc2VhcmNoUGFyYW1zO1xuICByZXR1cm4ge1xuICAgIHBhdGg6IGNyZWF0ZVBhdGgocGFyc2VkUGF0aCksXG4gICAgc3VibWlzc2lvblxuICB9O1xufVxuLy8gRmlsdGVyIG91dCBhbGwgcm91dGVzIGF0L2JlbG93IGFueSBjYXVnaHQgZXJyb3IgYXMgdGhleSBhcmVuJ3QgZ29pbmcgdG9cbi8vIHJlbmRlciBzbyB3ZSBkb24ndCBuZWVkIHRvIGxvYWQgdGhlbVxuZnVuY3Rpb24gZ2V0TG9hZGVyTWF0Y2hlc1VudGlsQm91bmRhcnkobWF0Y2hlcywgYm91bmRhcnlJZCwgaW5jbHVkZUJvdW5kYXJ5KSB7XG4gIGlmIChpbmNsdWRlQm91bmRhcnkgPT09IHZvaWQgMCkge1xuICAgIGluY2x1ZGVCb3VuZGFyeSA9IGZhbHNlO1xuICB9XG4gIGxldCBpbmRleCA9IG1hdGNoZXMuZmluZEluZGV4KG0gPT4gbS5yb3V0ZS5pZCA9PT0gYm91bmRhcnlJZCk7XG4gIGlmIChpbmRleCA+PSAwKSB7XG4gICAgcmV0dXJuIG1hdGNoZXMuc2xpY2UoMCwgaW5jbHVkZUJvdW5kYXJ5ID8gaW5kZXggKyAxIDogaW5kZXgpO1xuICB9XG4gIHJldHVybiBtYXRjaGVzO1xufVxuZnVuY3Rpb24gZ2V0TWF0Y2hlc1RvTG9hZChoaXN0b3J5LCBzdGF0ZSwgbWF0Y2hlcywgc3VibWlzc2lvbiwgbG9jYXRpb24sIGluaXRpYWxIeWRyYXRpb24sIHNraXBBY3Rpb25FcnJvclJldmFsaWRhdGlvbiwgaXNSZXZhbGlkYXRpb25SZXF1aXJlZCwgY2FuY2VsbGVkRGVmZXJyZWRSb3V0ZXMsIGNhbmNlbGxlZEZldGNoZXJMb2FkcywgZGVsZXRlZEZldGNoZXJzLCBmZXRjaExvYWRNYXRjaGVzLCBmZXRjaFJlZGlyZWN0SWRzLCByb3V0ZXNUb1VzZSwgYmFzZW5hbWUsIHBlbmRpbmdBY3Rpb25SZXN1bHQpIHtcbiAgbGV0IGFjdGlvblJlc3VsdCA9IHBlbmRpbmdBY3Rpb25SZXN1bHQgPyBpc0Vycm9yUmVzdWx0KHBlbmRpbmdBY3Rpb25SZXN1bHRbMV0pID8gcGVuZGluZ0FjdGlvblJlc3VsdFsxXS5lcnJvciA6IHBlbmRpbmdBY3Rpb25SZXN1bHRbMV0uZGF0YSA6IHVuZGVmaW5lZDtcbiAgbGV0IGN1cnJlbnRVcmwgPSBoaXN0b3J5LmNyZWF0ZVVSTChzdGF0ZS5sb2NhdGlvbik7XG4gIGxldCBuZXh0VXJsID0gaGlzdG9yeS5jcmVhdGVVUkwobG9jYXRpb24pO1xuICAvLyBQaWNrIG5hdmlnYXRpb24gbWF0Y2hlcyB0aGF0IGFyZSBuZXQtbmV3IG9yIHF1YWxpZnkgZm9yIHJldmFsaWRhdGlvblxuICBsZXQgYm91bmRhcnlNYXRjaGVzID0gbWF0Y2hlcztcbiAgaWYgKGluaXRpYWxIeWRyYXRpb24gJiYgc3RhdGUuZXJyb3JzKSB7XG4gICAgLy8gT24gaW5pdGlhbCBoeWRyYXRpb24sIG9ubHkgY29uc2lkZXIgbWF0Y2hlcyB1cCB0byBfYW5kIGluY2x1ZGluZ18gdGhlIGJvdW5kYXJ5LlxuICAgIC8vIFRoaXMgaXMgaW5jbHVzaXZlIHRvIGhhbmRsZSBjYXNlcyB3aGVyZSBhIHNlcnZlciBsb2FkZXIgcmFuIHN1Y2Nlc3NmdWxseSxcbiAgICAvLyBhIGNoaWxkIHNlcnZlciBsb2FkZXIgYnViYmxlZCB1cCB0byB0aGlzIHJvdXRlLCBidXQgdGhpcyByb3V0ZSBoYXNcbiAgICAvLyBgY2xpZW50TG9hZGVyLmh5ZHJhdGVgIHNvIHdlIHdhbnQgdG8gc3RpbGwgcnVuIHRoZSBgY2xpZW50TG9hZGVyYCBzbyB0aGF0XG4gICAgLy8gd2UgaGF2ZSBhIGNvbXBsZXRlIHZlcnNpb24gb2YgYGxvYWRlckRhdGFgXG4gICAgYm91bmRhcnlNYXRjaGVzID0gZ2V0TG9hZGVyTWF0Y2hlc1VudGlsQm91bmRhcnkobWF0Y2hlcywgT2JqZWN0LmtleXMoc3RhdGUuZXJyb3JzKVswXSwgdHJ1ZSk7XG4gIH0gZWxzZSBpZiAocGVuZGluZ0FjdGlvblJlc3VsdCAmJiBpc0Vycm9yUmVzdWx0KHBlbmRpbmdBY3Rpb25SZXN1bHRbMV0pKSB7XG4gICAgLy8gSWYgYW4gYWN0aW9uIHRocmV3IGFuIGVycm9yLCB3ZSBjYWxsIGxvYWRlcnMgdXAgdG8sIGJ1dCBub3QgaW5jbHVkaW5nIHRoZVxuICAgIC8vIGJvdW5kYXJ5XG4gICAgYm91bmRhcnlNYXRjaGVzID0gZ2V0TG9hZGVyTWF0Y2hlc1VudGlsQm91bmRhcnkobWF0Y2hlcywgcGVuZGluZ0FjdGlvblJlc3VsdFswXSk7XG4gIH1cbiAgLy8gRG9uJ3QgcmV2YWxpZGF0ZSBsb2FkZXJzIGJ5IGRlZmF1bHQgYWZ0ZXIgYWN0aW9uIDR4eC81eHggcmVzcG9uc2VzXG4gIC8vIHdoZW4gdGhlIGZsYWcgaXMgZW5hYmxlZC4gIFRoZXkgY2FuIHN0aWxsIG9wdC1pbnRvIHJldmFsaWRhdGlvbiB2aWFcbiAgLy8gYHNob3VsZFJldmFsaWRhdGVgIHZpYSBgYWN0aW9uUmVzdWx0YFxuICBsZXQgYWN0aW9uU3RhdHVzID0gcGVuZGluZ0FjdGlvblJlc3VsdCA/IHBlbmRpbmdBY3Rpb25SZXN1bHRbMV0uc3RhdHVzQ29kZSA6IHVuZGVmaW5lZDtcbiAgbGV0IHNob3VsZFNraXBSZXZhbGlkYXRpb24gPSBza2lwQWN0aW9uRXJyb3JSZXZhbGlkYXRpb24gJiYgYWN0aW9uU3RhdHVzICYmIGFjdGlvblN0YXR1cyA+PSA0MDA7XG4gIGxldCBuYXZpZ2F0aW9uTWF0Y2hlcyA9IGJvdW5kYXJ5TWF0Y2hlcy5maWx0ZXIoKG1hdGNoLCBpbmRleCkgPT4ge1xuICAgIGxldCB7XG4gICAgICByb3V0ZVxuICAgIH0gPSBtYXRjaDtcbiAgICBpZiAocm91dGUubGF6eSkge1xuICAgICAgLy8gV2UgaGF2ZW4ndCBsb2FkZWQgdGhpcyByb3V0ZSB5ZXQgc28gd2UgZG9uJ3Qga25vdyBpZiBpdCdzIGdvdCBhIGxvYWRlciFcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAocm91dGUubG9hZGVyID09IG51bGwpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGluaXRpYWxIeWRyYXRpb24pIHtcbiAgICAgIHJldHVybiBzaG91bGRMb2FkUm91dGVPbkh5ZHJhdGlvbihyb3V0ZSwgc3RhdGUubG9hZGVyRGF0YSwgc3RhdGUuZXJyb3JzKTtcbiAgICB9XG4gICAgLy8gQWx3YXlzIGNhbGwgdGhlIGxvYWRlciBvbiBuZXcgcm91dGUgaW5zdGFuY2VzIGFuZCBwZW5kaW5nIGRlZmVyIGNhbmNlbGxhdGlvbnNcbiAgICBpZiAoaXNOZXdMb2FkZXIoc3RhdGUubG9hZGVyRGF0YSwgc3RhdGUubWF0Y2hlc1tpbmRleF0sIG1hdGNoKSB8fCBjYW5jZWxsZWREZWZlcnJlZFJvdXRlcy5zb21lKGlkID0+IGlkID09PSBtYXRjaC5yb3V0ZS5pZCkpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICAvLyBUaGlzIGlzIHRoZSBkZWZhdWx0IGltcGxlbWVudGF0aW9uIGZvciB3aGVuIHdlIHJldmFsaWRhdGUuICBJZiB0aGUgcm91dGVcbiAgICAvLyBwcm92aWRlcyBpdCdzIG93biBpbXBsZW1lbnRhdGlvbiwgdGhlbiB3ZSBnaXZlIHRoZW0gZnVsbCBjb250cm9sIGJ1dFxuICAgIC8vIHByb3ZpZGUgdGhpcyB2YWx1ZSBzbyB0aGV5IGNhbiBsZXZlcmFnZSBpdCBpZiBuZWVkZWQgYWZ0ZXIgdGhleSBjaGVja1xuICAgIC8vIHRoZWlyIG93biBzcGVjaWZpYyB1c2UgY2FzZXNcbiAgICBsZXQgY3VycmVudFJvdXRlTWF0Y2ggPSBzdGF0ZS5tYXRjaGVzW2luZGV4XTtcbiAgICBsZXQgbmV4dFJvdXRlTWF0Y2ggPSBtYXRjaDtcbiAgICByZXR1cm4gc2hvdWxkUmV2YWxpZGF0ZUxvYWRlcihtYXRjaCwgX2V4dGVuZHMoe1xuICAgICAgY3VycmVudFVybCxcbiAgICAgIGN1cnJlbnRQYXJhbXM6IGN1cnJlbnRSb3V0ZU1hdGNoLnBhcmFtcyxcbiAgICAgIG5leHRVcmwsXG4gICAgICBuZXh0UGFyYW1zOiBuZXh0Um91dGVNYXRjaC5wYXJhbXNcbiAgICB9LCBzdWJtaXNzaW9uLCB7XG4gICAgICBhY3Rpb25SZXN1bHQsXG4gICAgICBhY3Rpb25TdGF0dXMsXG4gICAgICBkZWZhdWx0U2hvdWxkUmV2YWxpZGF0ZTogc2hvdWxkU2tpcFJldmFsaWRhdGlvbiA/IGZhbHNlIDpcbiAgICAgIC8vIEZvcmNlZCByZXZhbGlkYXRpb24gZHVlIHRvIHN1Ym1pc3Npb24sIHVzZVJldmFsaWRhdG9yLCBvciBYLVJlbWl4LVJldmFsaWRhdGVcbiAgICAgIGlzUmV2YWxpZGF0aW9uUmVxdWlyZWQgfHwgY3VycmVudFVybC5wYXRobmFtZSArIGN1cnJlbnRVcmwuc2VhcmNoID09PSBuZXh0VXJsLnBhdGhuYW1lICsgbmV4dFVybC5zZWFyY2ggfHxcbiAgICAgIC8vIFNlYXJjaCBwYXJhbXMgYWZmZWN0IGFsbCBsb2FkZXJzXG4gICAgICBjdXJyZW50VXJsLnNlYXJjaCAhPT0gbmV4dFVybC5zZWFyY2ggfHwgaXNOZXdSb3V0ZUluc3RhbmNlKGN1cnJlbnRSb3V0ZU1hdGNoLCBuZXh0Um91dGVNYXRjaClcbiAgICB9KSk7XG4gIH0pO1xuICAvLyBQaWNrIGZldGNoZXIubG9hZHMgdGhhdCBuZWVkIHRvIGJlIHJldmFsaWRhdGVkXG4gIGxldCByZXZhbGlkYXRpbmdGZXRjaGVycyA9IFtdO1xuICBmZXRjaExvYWRNYXRjaGVzLmZvckVhY2goKGYsIGtleSkgPT4ge1xuICAgIC8vIERvbid0IHJldmFsaWRhdGU6XG4gICAgLy8gIC0gb24gaW5pdGlhbCBoeWRyYXRpb24gKHNob3VsZG4ndCBiZSBhbnkgZmV0Y2hlcnMgdGhlbiBhbnl3YXkpXG4gICAgLy8gIC0gaWYgZmV0Y2hlciB3b24ndCBiZSBwcmVzZW50IGluIHRoZSBzdWJzZXF1ZW50IHJlbmRlclxuICAgIC8vICAgIC0gbm8gbG9uZ2VyIG1hdGNoZXMgdGhlIFVSTCAodjdfZmV0Y2hlclBlcnNpc3Q9ZmFsc2UpXG4gICAgLy8gICAgLSB3YXMgdW5tb3VudGVkIGJ1dCBwZXJzaXN0ZWQgZHVlIHRvIHY3X2ZldGNoZXJQZXJzaXN0PXRydWVcbiAgICBpZiAoaW5pdGlhbEh5ZHJhdGlvbiB8fCAhbWF0Y2hlcy5zb21lKG0gPT4gbS5yb3V0ZS5pZCA9PT0gZi5yb3V0ZUlkKSB8fCBkZWxldGVkRmV0Y2hlcnMuaGFzKGtleSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgbGV0IGZldGNoZXJNYXRjaGVzID0gbWF0Y2hSb3V0ZXMocm91dGVzVG9Vc2UsIGYucGF0aCwgYmFzZW5hbWUpO1xuICAgIC8vIElmIHRoZSBmZXRjaGVyIHBhdGggbm8gbG9uZ2VyIG1hdGNoZXMsIHB1c2ggaXQgaW4gd2l0aCBudWxsIG1hdGNoZXMgc29cbiAgICAvLyB3ZSBjYW4gdHJpZ2dlciBhIDQwNCBpbiBjYWxsTG9hZGVyc0FuZE1heWJlUmVzb2x2ZURhdGEuICBOb3RlIHRoaXMgaXNcbiAgICAvLyBjdXJyZW50bHkgb25seSBhIHVzZS1jYXNlIGZvciBSZW1peCBITVIgd2hlcmUgdGhlIHJvdXRlIHRyZWUgY2FuIGNoYW5nZVxuICAgIC8vIGF0IHJ1bnRpbWUgYW5kIHJlbW92ZSBhIHJvdXRlIHByZXZpb3VzbHkgbG9hZGVkIHZpYSBhIGZldGNoZXJcbiAgICBpZiAoIWZldGNoZXJNYXRjaGVzKSB7XG4gICAgICByZXZhbGlkYXRpbmdGZXRjaGVycy5wdXNoKHtcbiAgICAgICAga2V5LFxuICAgICAgICByb3V0ZUlkOiBmLnJvdXRlSWQsXG4gICAgICAgIHBhdGg6IGYucGF0aCxcbiAgICAgICAgbWF0Y2hlczogbnVsbCxcbiAgICAgICAgbWF0Y2g6IG51bGwsXG4gICAgICAgIGNvbnRyb2xsZXI6IG51bGxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBSZXZhbGlkYXRpbmcgZmV0Y2hlcnMgYXJlIGRlY291cGxlZCBmcm9tIHRoZSByb3V0ZSBtYXRjaGVzIHNpbmNlIHRoZXlcbiAgICAvLyBsb2FkIGZyb20gYSBzdGF0aWMgaHJlZi4gIFRoZXkgcmV2YWxpZGF0ZSBiYXNlZCBvbiBleHBsaWNpdCByZXZhbGlkYXRpb25cbiAgICAvLyAoc3VibWlzc2lvbiwgdXNlUmV2YWxpZGF0b3IsIG9yIFgtUmVtaXgtUmV2YWxpZGF0ZSlcbiAgICBsZXQgZmV0Y2hlciA9IHN0YXRlLmZldGNoZXJzLmdldChrZXkpO1xuICAgIGxldCBmZXRjaGVyTWF0Y2ggPSBnZXRUYXJnZXRNYXRjaChmZXRjaGVyTWF0Y2hlcywgZi5wYXRoKTtcbiAgICBsZXQgc2hvdWxkUmV2YWxpZGF0ZSA9IGZhbHNlO1xuICAgIGlmIChmZXRjaFJlZGlyZWN0SWRzLmhhcyhrZXkpKSB7XG4gICAgICAvLyBOZXZlciB0cmlnZ2VyIGEgcmV2YWxpZGF0aW9uIG9mIGFuIGFjdGl2ZWx5IHJlZGlyZWN0aW5nIGZldGNoZXJcbiAgICAgIHNob3VsZFJldmFsaWRhdGUgPSBmYWxzZTtcbiAgICB9IGVsc2UgaWYgKGNhbmNlbGxlZEZldGNoZXJMb2Fkcy5oYXMoa2V5KSkge1xuICAgICAgLy8gQWx3YXlzIG1hcmsgZm9yIHJldmFsaWRhdGlvbiBpZiB0aGUgZmV0Y2hlciB3YXMgY2FuY2VsbGVkXG4gICAgICBjYW5jZWxsZWRGZXRjaGVyTG9hZHMuZGVsZXRlKGtleSk7XG4gICAgICBzaG91bGRSZXZhbGlkYXRlID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKGZldGNoZXIgJiYgZmV0Y2hlci5zdGF0ZSAhPT0gXCJpZGxlXCIgJiYgZmV0Y2hlci5kYXRhID09PSB1bmRlZmluZWQpIHtcbiAgICAgIC8vIElmIHRoZSBmZXRjaGVyIGhhc24ndCBldmVyIGNvbXBsZXRlZCBsb2FkaW5nIHlldCwgdGhlbiB0aGlzIGlzbid0IGFcbiAgICAgIC8vIHJldmFsaWRhdGlvbiwgaXQgd291bGQganVzdCBiZSBhIGJyYW5kIG5ldyBsb2FkIGlmIGFuIGV4cGxpY2l0XG4gICAgICAvLyByZXZhbGlkYXRpb24gaXMgcmVxdWlyZWRcbiAgICAgIHNob3VsZFJldmFsaWRhdGUgPSBpc1JldmFsaWRhdGlvblJlcXVpcmVkO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBPdGhlcndpc2UgZmFsbCBiYWNrIG9uIGFueSB1c2VyLWRlZmluZWQgc2hvdWxkUmV2YWxpZGF0ZSwgZGVmYXVsdGluZ1xuICAgICAgLy8gdG8gZXhwbGljaXQgcmV2YWxpZGF0aW9ucyBvbmx5XG4gICAgICBzaG91bGRSZXZhbGlkYXRlID0gc2hvdWxkUmV2YWxpZGF0ZUxvYWRlcihmZXRjaGVyTWF0Y2gsIF9leHRlbmRzKHtcbiAgICAgICAgY3VycmVudFVybCxcbiAgICAgICAgY3VycmVudFBhcmFtczogc3RhdGUubWF0Y2hlc1tzdGF0ZS5tYXRjaGVzLmxlbmd0aCAtIDFdLnBhcmFtcyxcbiAgICAgICAgbmV4dFVybCxcbiAgICAgICAgbmV4dFBhcmFtczogbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdLnBhcmFtc1xuICAgICAgfSwgc3VibWlzc2lvbiwge1xuICAgICAgICBhY3Rpb25SZXN1bHQsXG4gICAgICAgIGFjdGlvblN0YXR1cyxcbiAgICAgICAgZGVmYXVsdFNob3VsZFJldmFsaWRhdGU6IHNob3VsZFNraXBSZXZhbGlkYXRpb24gPyBmYWxzZSA6IGlzUmV2YWxpZGF0aW9uUmVxdWlyZWRcbiAgICAgIH0pKTtcbiAgICB9XG4gICAgaWYgKHNob3VsZFJldmFsaWRhdGUpIHtcbiAgICAgIHJldmFsaWRhdGluZ0ZldGNoZXJzLnB1c2goe1xuICAgICAgICBrZXksXG4gICAgICAgIHJvdXRlSWQ6IGYucm91dGVJZCxcbiAgICAgICAgcGF0aDogZi5wYXRoLFxuICAgICAgICBtYXRjaGVzOiBmZXRjaGVyTWF0Y2hlcyxcbiAgICAgICAgbWF0Y2g6IGZldGNoZXJNYXRjaCxcbiAgICAgICAgY29udHJvbGxlcjogbmV3IEFib3J0Q29udHJvbGxlcigpXG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gW25hdmlnYXRpb25NYXRjaGVzLCByZXZhbGlkYXRpbmdGZXRjaGVyc107XG59XG5mdW5jdGlvbiBzaG91bGRMb2FkUm91dGVPbkh5ZHJhdGlvbihyb3V0ZSwgbG9hZGVyRGF0YSwgZXJyb3JzKSB7XG4gIC8vIFdlIGR1bm5vIGlmIHdlIGhhdmUgYSBsb2FkZXIgLSBnb3R0YSBmaW5kIG91dCFcbiAgaWYgKHJvdXRlLmxhenkpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvLyBObyBsb2FkZXIsIG5vdGhpbmcgdG8gaW5pdGlhbGl6ZVxuICBpZiAoIXJvdXRlLmxvYWRlcikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBsZXQgaGFzRGF0YSA9IGxvYWRlckRhdGEgIT0gbnVsbCAmJiBsb2FkZXJEYXRhW3JvdXRlLmlkXSAhPT0gdW5kZWZpbmVkO1xuICBsZXQgaGFzRXJyb3IgPSBlcnJvcnMgIT0gbnVsbCAmJiBlcnJvcnNbcm91dGUuaWRdICE9PSB1bmRlZmluZWQ7XG4gIC8vIERvbid0IHJ1biBpZiB3ZSBlcnJvcidkIGR1cmluZyBTU1JcbiAgaWYgKCFoYXNEYXRhICYmIGhhc0Vycm9yKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8vIEV4cGxpY2l0bHkgb3B0aW5nLWluIHRvIHJ1bm5pbmcgb24gaHlkcmF0aW9uXG4gIGlmICh0eXBlb2Ygcm91dGUubG9hZGVyID09PSBcImZ1bmN0aW9uXCIgJiYgcm91dGUubG9hZGVyLmh5ZHJhdGUgPT09IHRydWUpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvLyBPdGhlcndpc2UsIHJ1biBpZiB3ZSdyZSBub3QgeWV0IGluaXRpYWxpemVkIHdpdGggYW55dGhpbmdcbiAgcmV0dXJuICFoYXNEYXRhICYmICFoYXNFcnJvcjtcbn1cbmZ1bmN0aW9uIGlzTmV3TG9hZGVyKGN1cnJlbnRMb2FkZXJEYXRhLCBjdXJyZW50TWF0Y2gsIG1hdGNoKSB7XG4gIGxldCBpc05ldyA9XG4gIC8vIFthXSAtPiBbYSwgYl1cbiAgIWN1cnJlbnRNYXRjaCB8fFxuICAvLyBbYSwgYl0gLT4gW2EsIGNdXG4gIG1hdGNoLnJvdXRlLmlkICE9PSBjdXJyZW50TWF0Y2gucm91dGUuaWQ7XG4gIC8vIEhhbmRsZSB0aGUgY2FzZSB0aGF0IHdlIGRvbid0IGhhdmUgZGF0YSBmb3IgYSByZS11c2VkIHJvdXRlLCBwb3RlbnRpYWxseVxuICAvLyBmcm9tIGEgcHJpb3IgZXJyb3Igb3IgZnJvbSBhIGNhbmNlbGxlZCBwZW5kaW5nIGRlZmVycmVkXG4gIGxldCBpc01pc3NpbmdEYXRhID0gY3VycmVudExvYWRlckRhdGFbbWF0Y2gucm91dGUuaWRdID09PSB1bmRlZmluZWQ7XG4gIC8vIEFsd2F5cyBsb2FkIGlmIHRoaXMgaXMgYSBuZXQtbmV3IHJvdXRlIG9yIHdlIGRvbid0IHlldCBoYXZlIGRhdGFcbiAgcmV0dXJuIGlzTmV3IHx8IGlzTWlzc2luZ0RhdGE7XG59XG5mdW5jdGlvbiBpc05ld1JvdXRlSW5zdGFuY2UoY3VycmVudE1hdGNoLCBtYXRjaCkge1xuICBsZXQgY3VycmVudFBhdGggPSBjdXJyZW50TWF0Y2gucm91dGUucGF0aDtcbiAgcmV0dXJuIChcbiAgICAvLyBwYXJhbSBjaGFuZ2UgZm9yIHRoaXMgbWF0Y2gsIC91c2Vycy8xMjMgLT4gL3VzZXJzLzQ1NlxuICAgIGN1cnJlbnRNYXRjaC5wYXRobmFtZSAhPT0gbWF0Y2gucGF0aG5hbWUgfHxcbiAgICAvLyBzcGxhdCBwYXJhbSBjaGFuZ2VkLCB3aGljaCBpcyBub3QgcHJlc2VudCBpbiBtYXRjaC5wYXRoXG4gICAgLy8gZS5nLiAvZmlsZXMvaW1hZ2VzL2F2YXRhci5qcGcgLT4gZmlsZXMvZmluYW5jZXMueGxzXG4gICAgY3VycmVudFBhdGggIT0gbnVsbCAmJiBjdXJyZW50UGF0aC5lbmRzV2l0aChcIipcIikgJiYgY3VycmVudE1hdGNoLnBhcmFtc1tcIipcIl0gIT09IG1hdGNoLnBhcmFtc1tcIipcIl1cbiAgKTtcbn1cbmZ1bmN0aW9uIHNob3VsZFJldmFsaWRhdGVMb2FkZXIobG9hZGVyTWF0Y2gsIGFyZykge1xuICBpZiAobG9hZGVyTWF0Y2gucm91dGUuc2hvdWxkUmV2YWxpZGF0ZSkge1xuICAgIGxldCByb3V0ZUNob2ljZSA9IGxvYWRlck1hdGNoLnJvdXRlLnNob3VsZFJldmFsaWRhdGUoYXJnKTtcbiAgICBpZiAodHlwZW9mIHJvdXRlQ2hvaWNlID09PSBcImJvb2xlYW5cIikge1xuICAgICAgcmV0dXJuIHJvdXRlQ2hvaWNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYXJnLmRlZmF1bHRTaG91bGRSZXZhbGlkYXRlO1xufVxuZnVuY3Rpb24gcGF0Y2hSb3V0ZXNJbXBsKHJvdXRlSWQsIGNoaWxkcmVuLCByb3V0ZXNUb1VzZSwgbWFuaWZlc3QsIG1hcFJvdXRlUHJvcGVydGllcykge1xuICB2YXIgX2NoaWxkcmVuVG9QYXRjaDtcbiAgbGV0IGNoaWxkcmVuVG9QYXRjaDtcbiAgaWYgKHJvdXRlSWQpIHtcbiAgICBsZXQgcm91dGUgPSBtYW5pZmVzdFtyb3V0ZUlkXTtcbiAgICBpbnZhcmlhbnQocm91dGUsIFwiTm8gcm91dGUgZm91bmQgdG8gcGF0Y2ggY2hpbGRyZW4gaW50bzogcm91dGVJZCA9IFwiICsgcm91dGVJZCk7XG4gICAgaWYgKCFyb3V0ZS5jaGlsZHJlbikge1xuICAgICAgcm91dGUuY2hpbGRyZW4gPSBbXTtcbiAgICB9XG4gICAgY2hpbGRyZW5Ub1BhdGNoID0gcm91dGUuY2hpbGRyZW47XG4gIH0gZWxzZSB7XG4gICAgY2hpbGRyZW5Ub1BhdGNoID0gcm91dGVzVG9Vc2U7XG4gIH1cbiAgLy8gRG9uJ3QgcGF0Y2ggaW4gcm91dGVzIHdlIGFscmVhZHkga25vdyBhYm91dCBzbyB0aGF0IGBwYXRjaGAgaXMgaWRlbXBvdGVudFxuICAvLyB0byBzaW1wbGlmeSB1c2VyLWxhbmQgY29kZS4gVGhpcyBpcyB1c2VmdWwgYmVjYXVzZSB3ZSByZS1jYWxsIHRoZVxuICAvLyBgcGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb25gIGZ1bmN0aW9uIGZvciBtYXRjaGVkIHJvdXRlcyB3aXRoIHBhcmFtcy5cbiAgbGV0IHVuaXF1ZUNoaWxkcmVuID0gY2hpbGRyZW4uZmlsdGVyKG5ld1JvdXRlID0+ICFjaGlsZHJlblRvUGF0Y2guc29tZShleGlzdGluZ1JvdXRlID0+IGlzU2FtZVJvdXRlKG5ld1JvdXRlLCBleGlzdGluZ1JvdXRlKSkpO1xuICBsZXQgbmV3Um91dGVzID0gY29udmVydFJvdXRlc1RvRGF0YVJvdXRlcyh1bmlxdWVDaGlsZHJlbiwgbWFwUm91dGVQcm9wZXJ0aWVzLCBbcm91dGVJZCB8fCBcIl9cIiwgXCJwYXRjaFwiLCBTdHJpbmcoKChfY2hpbGRyZW5Ub1BhdGNoID0gY2hpbGRyZW5Ub1BhdGNoKSA9PSBudWxsID8gdm9pZCAwIDogX2NoaWxkcmVuVG9QYXRjaC5sZW5ndGgpIHx8IFwiMFwiKV0sIG1hbmlmZXN0KTtcbiAgY2hpbGRyZW5Ub1BhdGNoLnB1c2goLi4ubmV3Um91dGVzKTtcbn1cbmZ1bmN0aW9uIGlzU2FtZVJvdXRlKG5ld1JvdXRlLCBleGlzdGluZ1JvdXRlKSB7XG4gIC8vIE1vc3Qgb3B0aW1hbCBjaGVjayBpcyBieSBpZFxuICBpZiAoXCJpZFwiIGluIG5ld1JvdXRlICYmIFwiaWRcIiBpbiBleGlzdGluZ1JvdXRlICYmIG5ld1JvdXRlLmlkID09PSBleGlzdGluZ1JvdXRlLmlkKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLy8gU2Vjb25kIGlzIGJ5IHBhdGhpbmcgZGlmZmVyZW5jZXNcbiAgaWYgKCEobmV3Um91dGUuaW5kZXggPT09IGV4aXN0aW5nUm91dGUuaW5kZXggJiYgbmV3Um91dGUucGF0aCA9PT0gZXhpc3RpbmdSb3V0ZS5wYXRoICYmIG5ld1JvdXRlLmNhc2VTZW5zaXRpdmUgPT09IGV4aXN0aW5nUm91dGUuY2FzZVNlbnNpdGl2ZSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgLy8gUGF0aGxlc3MgbGF5b3V0IHJvdXRlcyBhcmUgdHJpY2tpZXIgc2luY2Ugd2UgbmVlZCB0byBjaGVjayBjaGlsZHJlbi5cbiAgLy8gSWYgdGhleSBoYXZlIG5vIGNoaWxkcmVuIHRoZW4gdGhleSdyZSB0aGUgc2FtZSBhcyBmYXIgYXMgd2UgY2FuIHRlbGxcbiAgaWYgKCghbmV3Um91dGUuY2hpbGRyZW4gfHwgbmV3Um91dGUuY2hpbGRyZW4ubGVuZ3RoID09PSAwKSAmJiAoIWV4aXN0aW5nUm91dGUuY2hpbGRyZW4gfHwgZXhpc3RpbmdSb3V0ZS5jaGlsZHJlbi5sZW5ndGggPT09IDApKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLy8gT3RoZXJ3aXNlLCB3ZSBsb29rIHRvIHNlZSBpZiBldmVyeSBjaGlsZCBpbiB0aGUgbmV3IHJvdXRlIGlzIGFscmVhZHlcbiAgLy8gcmVwcmVzZW50ZWQgaW4gdGhlIGV4aXN0aW5nIHJvdXRlJ3MgY2hpbGRyZW5cbiAgcmV0dXJuIG5ld1JvdXRlLmNoaWxkcmVuLmV2ZXJ5KChhQ2hpbGQsIGkpID0+IHtcbiAgICB2YXIgX2V4aXN0aW5nUm91dGUkY2hpbGRyO1xuICAgIHJldHVybiAoX2V4aXN0aW5nUm91dGUkY2hpbGRyID0gZXhpc3RpbmdSb3V0ZS5jaGlsZHJlbikgPT0gbnVsbCA/IHZvaWQgMCA6IF9leGlzdGluZ1JvdXRlJGNoaWxkci5zb21lKGJDaGlsZCA9PiBpc1NhbWVSb3V0ZShhQ2hpbGQsIGJDaGlsZCkpO1xuICB9KTtcbn1cbi8qKlxuICogRXhlY3V0ZSByb3V0ZS5sYXp5KCkgbWV0aG9kcyB0byBsYXppbHkgbG9hZCByb3V0ZSBtb2R1bGVzIChsb2FkZXIsIGFjdGlvbixcbiAqIHNob3VsZFJldmFsaWRhdGUpIGFuZCB1cGRhdGUgdGhlIHJvdXRlTWFuaWZlc3QgaW4gcGxhY2Ugd2hpY2ggc2hhcmVzIG9iamVjdHNcbiAqIHdpdGggZGF0YVJvdXRlcyBzbyB0aG9zZSBnZXQgdXBkYXRlZCBhcyB3ZWxsLlxuICovXG5hc3luYyBmdW5jdGlvbiBsb2FkTGF6eVJvdXRlTW9kdWxlKHJvdXRlLCBtYXBSb3V0ZVByb3BlcnRpZXMsIG1hbmlmZXN0KSB7XG4gIGlmICghcm91dGUubGF6eSkge1xuICAgIHJldHVybjtcbiAgfVxuICBsZXQgbGF6eVJvdXRlID0gYXdhaXQgcm91dGUubGF6eSgpO1xuICAvLyBJZiB0aGUgbGF6eSByb3V0ZSBmdW5jdGlvbiB3YXMgZXhlY3V0ZWQgYW5kIHJlbW92ZWQgYnkgYW5vdGhlciBwYXJhbGxlbFxuICAvLyBjYWxsIHRoZW4gd2UgY2FuIHJldHVybiAtIGZpcnN0IGxhenkoKSB0byBmaW5pc2ggd2lucyBiZWNhdXNlIHRoZSByZXR1cm5cbiAgLy8gdmFsdWUgb2YgbGF6eSBpcyBleHBlY3RlZCB0byBiZSBzdGF0aWNcbiAgaWYgKCFyb3V0ZS5sYXp5KSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGxldCByb3V0ZVRvVXBkYXRlID0gbWFuaWZlc3Rbcm91dGUuaWRdO1xuICBpbnZhcmlhbnQocm91dGVUb1VwZGF0ZSwgXCJObyByb3V0ZSBmb3VuZCBpbiBtYW5pZmVzdFwiKTtcbiAgLy8gVXBkYXRlIHRoZSByb3V0ZSBpbiBwbGFjZS4gIFRoaXMgc2hvdWxkIGJlIHNhZmUgYmVjYXVzZSB0aGVyZSdzIG5vIHdheVxuICAvLyB3ZSBjb3VsZCB5ZXQgYmUgc2l0dGluZyBvbiB0aGlzIHJvdXRlIGFzIHdlIGNhbid0IGdldCB0aGVyZSB3aXRob3V0XG4gIC8vIHJlc29sdmluZyBsYXp5KCkgZmlyc3QuXG4gIC8vXG4gIC8vIFRoaXMgaXMgZGlmZmVyZW50IHRoYW4gdGhlIEhNUiBcInVwZGF0ZVwiIHVzZS1jYXNlIHdoZXJlIHdlIG1heSBhY3RpdmVseSBiZVxuICAvLyBvbiB0aGUgcm91dGUgYmVpbmcgdXBkYXRlZC4gIFRoZSBtYWluIGNvbmNlcm4gYm9pbHMgZG93biB0byBcImRvZXMgdGhpc1xuICAvLyBtdXRhdGlvbiBhZmZlY3QgYW55IG9uZ29pbmcgbmF2aWdhdGlvbnMgb3IgYW55IGN1cnJlbnQgc3RhdGUubWF0Y2hlc1xuICAvLyB2YWx1ZXM/XCIuICBJZiBub3QsIGl0IHNob3VsZCBiZSBzYWZlIHRvIHVwZGF0ZSBpbiBwbGFjZS5cbiAgbGV0IHJvdXRlVXBkYXRlcyA9IHt9O1xuICBmb3IgKGxldCBsYXp5Um91dGVQcm9wZXJ0eSBpbiBsYXp5Um91dGUpIHtcbiAgICBsZXQgc3RhdGljUm91dGVWYWx1ZSA9IHJvdXRlVG9VcGRhdGVbbGF6eVJvdXRlUHJvcGVydHldO1xuICAgIGxldCBpc1Byb3BlcnR5U3RhdGljYWxseURlZmluZWQgPSBzdGF0aWNSb3V0ZVZhbHVlICE9PSB1bmRlZmluZWQgJiZcbiAgICAvLyBUaGlzIHByb3BlcnR5IGlzbid0IHN0YXRpYyBzaW5jZSBpdCBzaG91bGQgYWx3YXlzIGJlIHVwZGF0ZWQgYmFzZWRcbiAgICAvLyBvbiB0aGUgcm91dGUgdXBkYXRlc1xuICAgIGxhenlSb3V0ZVByb3BlcnR5ICE9PSBcImhhc0Vycm9yQm91bmRhcnlcIjtcbiAgICB3YXJuaW5nKCFpc1Byb3BlcnR5U3RhdGljYWxseURlZmluZWQsIFwiUm91dGUgXFxcIlwiICsgcm91dGVUb1VwZGF0ZS5pZCArIFwiXFxcIiBoYXMgYSBzdGF0aWMgcHJvcGVydHkgXFxcIlwiICsgbGF6eVJvdXRlUHJvcGVydHkgKyBcIlxcXCIgXCIgKyBcImRlZmluZWQgYnV0IGl0cyBsYXp5IGZ1bmN0aW9uIGlzIGFsc28gcmV0dXJuaW5nIGEgdmFsdWUgZm9yIHRoaXMgcHJvcGVydHkuIFwiICsgKFwiVGhlIGxhenkgcm91dGUgcHJvcGVydHkgXFxcIlwiICsgbGF6eVJvdXRlUHJvcGVydHkgKyBcIlxcXCIgd2lsbCBiZSBpZ25vcmVkLlwiKSk7XG4gICAgaWYgKCFpc1Byb3BlcnR5U3RhdGljYWxseURlZmluZWQgJiYgIWltbXV0YWJsZVJvdXRlS2V5cy5oYXMobGF6eVJvdXRlUHJvcGVydHkpKSB7XG4gICAgICByb3V0ZVVwZGF0ZXNbbGF6eVJvdXRlUHJvcGVydHldID0gbGF6eVJvdXRlW2xhenlSb3V0ZVByb3BlcnR5XTtcbiAgICB9XG4gIH1cbiAgLy8gTXV0YXRlIHRoZSByb3V0ZSB3aXRoIHRoZSBwcm92aWRlZCB1cGRhdGVzLiAgRG8gdGhpcyBmaXJzdCBzbyB3ZSBwYXNzXG4gIC8vIHRoZSB1cGRhdGVkIHZlcnNpb24gdG8gbWFwUm91dGVQcm9wZXJ0aWVzXG4gIE9iamVjdC5hc3NpZ24ocm91dGVUb1VwZGF0ZSwgcm91dGVVcGRhdGVzKTtcbiAgLy8gTXV0YXRlIHRoZSBgaGFzRXJyb3JCb3VuZGFyeWAgcHJvcGVydHkgb24gdGhlIHJvdXRlIGJhc2VkIG9uIHRoZSByb3V0ZVxuICAvLyB1cGRhdGVzIGFuZCByZW1vdmUgdGhlIGBsYXp5YCBmdW5jdGlvbiBzbyB3ZSBkb24ndCByZXNvbHZlIHRoZSBsYXp5XG4gIC8vIHJvdXRlIGFnYWluLlxuICBPYmplY3QuYXNzaWduKHJvdXRlVG9VcGRhdGUsIF9leHRlbmRzKHt9LCBtYXBSb3V0ZVByb3BlcnRpZXMocm91dGVUb1VwZGF0ZSksIHtcbiAgICBsYXp5OiB1bmRlZmluZWRcbiAgfSkpO1xufVxuLy8gRGVmYXVsdCBpbXBsZW1lbnRhdGlvbiBvZiBgZGF0YVN0cmF0ZWd5YCB3aGljaCBmZXRjaGVzIGFsbCBsb2FkZXJzIGluIHBhcmFsbGVsXG5hc3luYyBmdW5jdGlvbiBkZWZhdWx0RGF0YVN0cmF0ZWd5KF9yZWY0KSB7XG4gIGxldCB7XG4gICAgbWF0Y2hlc1xuICB9ID0gX3JlZjQ7XG4gIGxldCBtYXRjaGVzVG9Mb2FkID0gbWF0Y2hlcy5maWx0ZXIobSA9PiBtLnNob3VsZExvYWQpO1xuICBsZXQgcmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsKG1hdGNoZXNUb0xvYWQubWFwKG0gPT4gbS5yZXNvbHZlKCkpKTtcbiAgcmV0dXJuIHJlc3VsdHMucmVkdWNlKChhY2MsIHJlc3VsdCwgaSkgPT4gT2JqZWN0LmFzc2lnbihhY2MsIHtcbiAgICBbbWF0Y2hlc1RvTG9hZFtpXS5yb3V0ZS5pZF06IHJlc3VsdFxuICB9KSwge30pO1xufVxuYXN5bmMgZnVuY3Rpb24gY2FsbERhdGFTdHJhdGVneUltcGwoZGF0YVN0cmF0ZWd5SW1wbCwgdHlwZSwgc3RhdGUsIHJlcXVlc3QsIG1hdGNoZXNUb0xvYWQsIG1hdGNoZXMsIGZldGNoZXJLZXksIG1hbmlmZXN0LCBtYXBSb3V0ZVByb3BlcnRpZXMsIHJlcXVlc3RDb250ZXh0KSB7XG4gIGxldCBsb2FkUm91dGVEZWZpbml0aW9uc1Byb21pc2VzID0gbWF0Y2hlcy5tYXAobSA9PiBtLnJvdXRlLmxhenkgPyBsb2FkTGF6eVJvdXRlTW9kdWxlKG0ucm91dGUsIG1hcFJvdXRlUHJvcGVydGllcywgbWFuaWZlc3QpIDogdW5kZWZpbmVkKTtcbiAgbGV0IGRzTWF0Y2hlcyA9IG1hdGNoZXMubWFwKChtYXRjaCwgaSkgPT4ge1xuICAgIGxldCBsb2FkUm91dGVQcm9taXNlID0gbG9hZFJvdXRlRGVmaW5pdGlvbnNQcm9taXNlc1tpXTtcbiAgICBsZXQgc2hvdWxkTG9hZCA9IG1hdGNoZXNUb0xvYWQuc29tZShtID0+IG0ucm91dGUuaWQgPT09IG1hdGNoLnJvdXRlLmlkKTtcbiAgICAvLyBgcmVzb2x2ZWAgZW5jYXBzdWxhdGVzIHJvdXRlLmxhenkoKSwgZXhlY3V0aW5nIHRoZSBsb2FkZXIvYWN0aW9uLFxuICAgIC8vIGFuZCBtYXBwaW5nIHJldHVybiB2YWx1ZXMvdGhyb3duIGVycm9ycyB0byBhIGBEYXRhU3RyYXRlZ3lSZXN1bHRgLiAgVXNlcnNcbiAgICAvLyBjYW4gcGFzcyBhIGNhbGxiYWNrIHRvIHRha2UgZmluZS1ncmFpbmVkIGNvbnRyb2wgb3ZlciB0aGUgZXhlY3V0aW9uXG4gICAgLy8gb2YgdGhlIGxvYWRlci9hY3Rpb25cbiAgICBsZXQgcmVzb2x2ZSA9IGFzeW5jIGhhbmRsZXJPdmVycmlkZSA9PiB7XG4gICAgICBpZiAoaGFuZGxlck92ZXJyaWRlICYmIHJlcXVlc3QubWV0aG9kID09PSBcIkdFVFwiICYmIChtYXRjaC5yb3V0ZS5sYXp5IHx8IG1hdGNoLnJvdXRlLmxvYWRlcikpIHtcbiAgICAgICAgc2hvdWxkTG9hZCA9IHRydWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gc2hvdWxkTG9hZCA/IGNhbGxMb2FkZXJPckFjdGlvbih0eXBlLCByZXF1ZXN0LCBtYXRjaCwgbG9hZFJvdXRlUHJvbWlzZSwgaGFuZGxlck92ZXJyaWRlLCByZXF1ZXN0Q29udGV4dCkgOiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLmRhdGEsXG4gICAgICAgIHJlc3VsdDogdW5kZWZpbmVkXG4gICAgICB9KTtcbiAgICB9O1xuICAgIHJldHVybiBfZXh0ZW5kcyh7fSwgbWF0Y2gsIHtcbiAgICAgIHNob3VsZExvYWQsXG4gICAgICByZXNvbHZlXG4gICAgfSk7XG4gIH0pO1xuICAvLyBTZW5kIGFsbCBtYXRjaGVzIGhlcmUgdG8gYWxsb3cgZm9yIGEgbWlkZGxld2FyZS10eXBlIGltcGxlbWVudGF0aW9uLlxuICAvLyBoYW5kbGVyIHdpbGwgYmUgYSBuby1vcCBmb3IgdW5uZWVkZWQgcm91dGVzIGFuZCB3ZSBmaWx0ZXIgdGhvc2UgcmVzdWx0c1xuICAvLyBiYWNrIG91dCBiZWxvdy5cbiAgbGV0IHJlc3VsdHMgPSBhd2FpdCBkYXRhU3RyYXRlZ3lJbXBsKHtcbiAgICBtYXRjaGVzOiBkc01hdGNoZXMsXG4gICAgcmVxdWVzdCxcbiAgICBwYXJhbXM6IG1hdGNoZXNbMF0ucGFyYW1zLFxuICAgIGZldGNoZXJLZXksXG4gICAgY29udGV4dDogcmVxdWVzdENvbnRleHRcbiAgfSk7XG4gIC8vIFdhaXQgZm9yIGFsbCByb3V0ZXMgdG8gbG9hZCBoZXJlIGJ1dCAnc3dhbGxvdyB0aGUgZXJyb3Igc2luY2Ugd2Ugd2FudFxuICAvLyBpdCB0byBidWJibGUgdXAgZnJvbSB0aGUgYGF3YWl0IGxvYWRSb3V0ZVByb21pc2VgIGluIGBjYWxsTG9hZGVyT3JBY3Rpb25gIC1cbiAgLy8gY2FsbGVkIGZyb20gYG1hdGNoLnJlc29sdmUoKWBcbiAgdHJ5IHtcbiAgICBhd2FpdCBQcm9taXNlLmFsbChsb2FkUm91dGVEZWZpbml0aW9uc1Byb21pc2VzKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIC8vIE5vLW9wXG4gIH1cbiAgcmV0dXJuIHJlc3VsdHM7XG59XG4vLyBEZWZhdWx0IGxvZ2ljIGZvciBjYWxsaW5nIGEgbG9hZGVyL2FjdGlvbiBpcyB0aGUgdXNlciBoYXMgbm8gc3BlY2lmaWVkIGEgZGF0YVN0cmF0ZWd5XG5hc3luYyBmdW5jdGlvbiBjYWxsTG9hZGVyT3JBY3Rpb24odHlwZSwgcmVxdWVzdCwgbWF0Y2gsIGxvYWRSb3V0ZVByb21pc2UsIGhhbmRsZXJPdmVycmlkZSwgc3RhdGljQ29udGV4dCkge1xuICBsZXQgcmVzdWx0O1xuICBsZXQgb25SZWplY3Q7XG4gIGxldCBydW5IYW5kbGVyID0gaGFuZGxlciA9PiB7XG4gICAgLy8gU2V0dXAgYSBwcm9taXNlIHdlIGNhbiByYWNlIGFnYWluc3Qgc28gdGhhdCBhYm9ydCBzaWduYWxzIHNob3J0IGNpcmN1aXRcbiAgICBsZXQgcmVqZWN0O1xuICAgIC8vIFRoaXMgd2lsbCBuZXZlciByZXNvbHZlIHNvIHNhZmUgdG8gdHlwZSBpdCBhcyBQcm9taXNlPERhdGFTdHJhdGVneVJlc3VsdD4gdG9cbiAgICAvLyBzYXRpc2Z5IHRoZSBmdW5jdGlvbiByZXR1cm4gdmFsdWVcbiAgICBsZXQgYWJvcnRQcm9taXNlID0gbmV3IFByb21pc2UoKF8sIHIpID0+IHJlamVjdCA9IHIpO1xuICAgIG9uUmVqZWN0ID0gKCkgPT4gcmVqZWN0KCk7XG4gICAgcmVxdWVzdC5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIG9uUmVqZWN0KTtcbiAgICBsZXQgYWN0dWFsSGFuZGxlciA9IGN0eCA9PiB7XG4gICAgICBpZiAodHlwZW9mIGhhbmRsZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKFwiWW91IGNhbm5vdCBjYWxsIHRoZSBoYW5kbGVyIGZvciBhIHJvdXRlIHdoaWNoIGRlZmluZXMgYSBib29sZWFuIFwiICsgKFwiXFxcIlwiICsgdHlwZSArIFwiXFxcIiBbcm91dGVJZDogXCIgKyBtYXRjaC5yb3V0ZS5pZCArIFwiXVwiKSkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGhhbmRsZXIoe1xuICAgICAgICByZXF1ZXN0LFxuICAgICAgICBwYXJhbXM6IG1hdGNoLnBhcmFtcyxcbiAgICAgICAgY29udGV4dDogc3RhdGljQ29udGV4dFxuICAgICAgfSwgLi4uKGN0eCAhPT0gdW5kZWZpbmVkID8gW2N0eF0gOiBbXSkpO1xuICAgIH07XG4gICAgbGV0IGhhbmRsZXJQcm9taXNlID0gKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGxldCB2YWwgPSBhd2FpdCAoaGFuZGxlck92ZXJyaWRlID8gaGFuZGxlck92ZXJyaWRlKGN0eCA9PiBhY3R1YWxIYW5kbGVyKGN0eCkpIDogYWN0dWFsSGFuZGxlcigpKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0eXBlOiBcImRhdGFcIixcbiAgICAgICAgICByZXN1bHQ6IHZhbFxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcbiAgICAgICAgICByZXN1bHQ6IGVcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9KSgpO1xuICAgIHJldHVybiBQcm9taXNlLnJhY2UoW2hhbmRsZXJQcm9taXNlLCBhYm9ydFByb21pc2VdKTtcbiAgfTtcbiAgdHJ5IHtcbiAgICBsZXQgaGFuZGxlciA9IG1hdGNoLnJvdXRlW3R5cGVdO1xuICAgIC8vIElmIHdlIGhhdmUgYSByb3V0ZS5sYXp5IHByb21pc2UsIGF3YWl0IHRoYXQgZmlyc3RcbiAgICBpZiAobG9hZFJvdXRlUHJvbWlzZSkge1xuICAgICAgaWYgKGhhbmRsZXIpIHtcbiAgICAgICAgLy8gUnVuIHN0YXRpY2FsbHkgZGVmaW5lZCBoYW5kbGVyIGluIHBhcmFsbGVsIHdpdGggbGF6eSgpXG4gICAgICAgIGxldCBoYW5kbGVyRXJyb3I7XG4gICAgICAgIGxldCBbdmFsdWVdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgICAvLyBJZiB0aGUgaGFuZGxlciB0aHJvd3MsIGRvbid0IGxldCBpdCBpbW1lZGlhdGVseSBidWJibGUgb3V0LFxuICAgICAgICAvLyBzaW5jZSB3ZSBuZWVkIHRvIGxldCB0aGUgbGF6eSgpIGV4ZWN1dGlvbiBmaW5pc2ggc28gd2Uga25vdyBpZiB0aGlzXG4gICAgICAgIC8vIHJvdXRlIGhhcyBhIGJvdW5kYXJ5IHRoYXQgY2FuIGhhbmRsZSB0aGUgZXJyb3JcbiAgICAgICAgcnVuSGFuZGxlcihoYW5kbGVyKS5jYXRjaChlID0+IHtcbiAgICAgICAgICBoYW5kbGVyRXJyb3IgPSBlO1xuICAgICAgICB9KSwgbG9hZFJvdXRlUHJvbWlzZV0pO1xuICAgICAgICBpZiAoaGFuZGxlckVycm9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB0aHJvdyBoYW5kbGVyRXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0ID0gdmFsdWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBMb2FkIGxhenkgcm91dGUgbW9kdWxlLCB0aGVuIHJ1biBhbnkgcmV0dXJuZWQgaGFuZGxlclxuICAgICAgICBhd2FpdCBsb2FkUm91dGVQcm9taXNlO1xuICAgICAgICBoYW5kbGVyID0gbWF0Y2gucm91dGVbdHlwZV07XG4gICAgICAgIGlmIChoYW5kbGVyKSB7XG4gICAgICAgICAgLy8gSGFuZGxlciBzdGlsbCBydW5zIGV2ZW4gaWYgd2UgZ290IGludGVycnVwdGVkIHRvIG1haW50YWluIGNvbnNpc3RlbmN5XG4gICAgICAgICAgLy8gd2l0aCB1bi1hYm9ydGFibGUgYmVoYXZpb3Igb2YgaGFuZGxlciBleGVjdXRpb24gb24gbm9uLWxhenkgb3JcbiAgICAgICAgICAvLyBwcmV2aW91c2x5LWxhenktbG9hZGVkIHJvdXRlc1xuICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IHJ1bkhhbmRsZXIoaGFuZGxlcik7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJhY3Rpb25cIikge1xuICAgICAgICAgIGxldCB1cmwgPSBuZXcgVVJMKHJlcXVlc3QudXJsKTtcbiAgICAgICAgICBsZXQgcGF0aG5hbWUgPSB1cmwucGF0aG5hbWUgKyB1cmwuc2VhcmNoO1xuICAgICAgICAgIHRocm93IGdldEludGVybmFsUm91dGVyRXJyb3IoNDA1LCB7XG4gICAgICAgICAgICBtZXRob2Q6IHJlcXVlc3QubWV0aG9kLFxuICAgICAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgICAgICByb3V0ZUlkOiBtYXRjaC5yb3V0ZS5pZFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIGxhenkoKSByb3V0ZSBoYXMgbm8gbG9hZGVyIHRvIHJ1bi4gIFNob3J0IGNpcmN1aXQgaGVyZSBzbyB3ZSBkb24ndFxuICAgICAgICAgIC8vIGhpdCB0aGUgaW52YXJpYW50IGJlbG93IHRoYXQgZXJyb3JzIG9uIHJldHVybmluZyB1bmRlZmluZWQuXG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZGF0YSxcbiAgICAgICAgICAgIHJlc3VsdDogdW5kZWZpbmVkXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoIWhhbmRsZXIpIHtcbiAgICAgIGxldCB1cmwgPSBuZXcgVVJMKHJlcXVlc3QudXJsKTtcbiAgICAgIGxldCBwYXRobmFtZSA9IHVybC5wYXRobmFtZSArIHVybC5zZWFyY2g7XG4gICAgICB0aHJvdyBnZXRJbnRlcm5hbFJvdXRlckVycm9yKDQwNCwge1xuICAgICAgICBwYXRobmFtZVxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlc3VsdCA9IGF3YWl0IHJ1bkhhbmRsZXIoaGFuZGxlcik7XG4gICAgfVxuICAgIGludmFyaWFudChyZXN1bHQucmVzdWx0ICE9PSB1bmRlZmluZWQsIFwiWW91IGRlZmluZWQgXCIgKyAodHlwZSA9PT0gXCJhY3Rpb25cIiA/IFwiYW4gYWN0aW9uXCIgOiBcImEgbG9hZGVyXCIpICsgXCIgZm9yIHJvdXRlIFwiICsgKFwiXFxcIlwiICsgbWF0Y2gucm91dGUuaWQgKyBcIlxcXCIgYnV0IGRpZG4ndCByZXR1cm4gYW55dGhpbmcgZnJvbSB5b3VyIGBcIiArIHR5cGUgKyBcImAgXCIpICsgXCJmdW5jdGlvbi4gUGxlYXNlIHJldHVybiBhIHZhbHVlIG9yIGBudWxsYC5cIik7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAvLyBXZSBzaG91bGQgYWxyZWFkeSBiZSBjYXRjaGluZyBhbmQgY29udmVydGluZyBub3JtYWwgaGFuZGxlciBleGVjdXRpb25zIHRvXG4gICAgLy8gRGF0YVN0cmF0ZWd5UmVzdWx0cyBhbmQgcmV0dXJuaW5nIHRoZW0sIHNvIGFueXRoaW5nIHRoYXQgdGhyb3dzIGhlcmUgaXMgYW5cbiAgICAvLyB1bmV4cGVjdGVkIGVycm9yIHdlIHN0aWxsIG5lZWQgdG8gd3JhcFxuICAgIHJldHVybiB7XG4gICAgICB0eXBlOiBSZXN1bHRUeXBlLmVycm9yLFxuICAgICAgcmVzdWx0OiBlXG4gICAgfTtcbiAgfSBmaW5hbGx5IHtcbiAgICBpZiAob25SZWplY3QpIHtcbiAgICAgIHJlcXVlc3Quc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBvblJlamVjdCk7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5hc3luYyBmdW5jdGlvbiBjb252ZXJ0RGF0YVN0cmF0ZWd5UmVzdWx0VG9EYXRhUmVzdWx0KGRhdGFTdHJhdGVneVJlc3VsdCkge1xuICBsZXQge1xuICAgIHJlc3VsdCxcbiAgICB0eXBlXG4gIH0gPSBkYXRhU3RyYXRlZ3lSZXN1bHQ7XG4gIGlmIChpc1Jlc3BvbnNlKHJlc3VsdCkpIHtcbiAgICBsZXQgZGF0YTtcbiAgICB0cnkge1xuICAgICAgbGV0IGNvbnRlbnRUeXBlID0gcmVzdWx0LmhlYWRlcnMuZ2V0KFwiQ29udGVudC1UeXBlXCIpO1xuICAgICAgLy8gQ2hlY2sgYmV0d2VlbiB3b3JkIGJvdW5kYXJpZXMgaW5zdGVhZCBvZiBzdGFydHNXaXRoKCkgZHVlIHRvIHRoZSBsYXN0XG4gICAgICAvLyBwYXJhZ3JhcGggb2YgaHR0cHM6Ly9odHRwd2cub3JnL3NwZWNzL3JmYzkxMTAuaHRtbCNmaWVsZC5jb250ZW50LXR5cGVcbiAgICAgIGlmIChjb250ZW50VHlwZSAmJiAvXFxiYXBwbGljYXRpb25cXC9qc29uXFxiLy50ZXN0KGNvbnRlbnRUeXBlKSkge1xuICAgICAgICBpZiAocmVzdWx0LmJvZHkgPT0gbnVsbCkge1xuICAgICAgICAgIGRhdGEgPSBudWxsO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGRhdGEgPSBhd2FpdCByZXN1bHQuanNvbigpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkYXRhID0gYXdhaXQgcmVzdWx0LnRleHQoKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLmVycm9yLFxuICAgICAgICBlcnJvcjogZVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHR5cGUgPT09IFJlc3VsdFR5cGUuZXJyb3IpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZXJyb3IsXG4gICAgICAgIGVycm9yOiBuZXcgRXJyb3JSZXNwb25zZUltcGwocmVzdWx0LnN0YXR1cywgcmVzdWx0LnN0YXR1c1RleHQsIGRhdGEpLFxuICAgICAgICBzdGF0dXNDb2RlOiByZXN1bHQuc3RhdHVzLFxuICAgICAgICBoZWFkZXJzOiByZXN1bHQuaGVhZGVyc1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZGF0YSxcbiAgICAgIGRhdGEsXG4gICAgICBzdGF0dXNDb2RlOiByZXN1bHQuc3RhdHVzLFxuICAgICAgaGVhZGVyczogcmVzdWx0LmhlYWRlcnNcbiAgICB9O1xuICB9XG4gIGlmICh0eXBlID09PSBSZXN1bHRUeXBlLmVycm9yKSB7XG4gICAgaWYgKGlzRGF0YVdpdGhSZXNwb25zZUluaXQocmVzdWx0KSkge1xuICAgICAgdmFyIF9yZXN1bHQkaW5pdDMsIF9yZXN1bHQkaW5pdDQ7XG4gICAgICBpZiAocmVzdWx0LmRhdGEgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICB2YXIgX3Jlc3VsdCRpbml0LCBfcmVzdWx0JGluaXQyO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZXJyb3IsXG4gICAgICAgICAgZXJyb3I6IHJlc3VsdC5kYXRhLFxuICAgICAgICAgIHN0YXR1c0NvZGU6IChfcmVzdWx0JGluaXQgPSByZXN1bHQuaW5pdCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9yZXN1bHQkaW5pdC5zdGF0dXMsXG4gICAgICAgICAgaGVhZGVyczogKF9yZXN1bHQkaW5pdDIgPSByZXN1bHQuaW5pdCkgIT0gbnVsbCAmJiBfcmVzdWx0JGluaXQyLmhlYWRlcnMgPyBuZXcgSGVhZGVycyhyZXN1bHQuaW5pdC5oZWFkZXJzKSA6IHVuZGVmaW5lZFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgLy8gQ29udmVydCB0aHJvd24gZGF0YSgpIHRvIEVycm9yUmVzcG9uc2UgaW5zdGFuY2VzXG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiBSZXN1bHRUeXBlLmVycm9yLFxuICAgICAgICBlcnJvcjogbmV3IEVycm9yUmVzcG9uc2VJbXBsKCgoX3Jlc3VsdCRpbml0MyA9IHJlc3VsdC5pbml0KSA9PSBudWxsID8gdm9pZCAwIDogX3Jlc3VsdCRpbml0My5zdGF0dXMpIHx8IDUwMCwgdW5kZWZpbmVkLCByZXN1bHQuZGF0YSksXG4gICAgICAgIHN0YXR1c0NvZGU6IGlzUm91dGVFcnJvclJlc3BvbnNlKHJlc3VsdCkgPyByZXN1bHQuc3RhdHVzIDogdW5kZWZpbmVkLFxuICAgICAgICBoZWFkZXJzOiAoX3Jlc3VsdCRpbml0NCA9IHJlc3VsdC5pbml0KSAhPSBudWxsICYmIF9yZXN1bHQkaW5pdDQuaGVhZGVycyA/IG5ldyBIZWFkZXJzKHJlc3VsdC5pbml0LmhlYWRlcnMpIDogdW5kZWZpbmVkXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgdHlwZTogUmVzdWx0VHlwZS5lcnJvcixcbiAgICAgIGVycm9yOiByZXN1bHQsXG4gICAgICBzdGF0dXNDb2RlOiBpc1JvdXRlRXJyb3JSZXNwb25zZShyZXN1bHQpID8gcmVzdWx0LnN0YXR1cyA6IHVuZGVmaW5lZFxuICAgIH07XG4gIH1cbiAgaWYgKGlzRGVmZXJyZWREYXRhKHJlc3VsdCkpIHtcbiAgICB2YXIgX3Jlc3VsdCRpbml0NSwgX3Jlc3VsdCRpbml0NjtcbiAgICByZXR1cm4ge1xuICAgICAgdHlwZTogUmVzdWx0VHlwZS5kZWZlcnJlZCxcbiAgICAgIGRlZmVycmVkRGF0YTogcmVzdWx0LFxuICAgICAgc3RhdHVzQ29kZTogKF9yZXN1bHQkaW5pdDUgPSByZXN1bHQuaW5pdCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9yZXN1bHQkaW5pdDUuc3RhdHVzLFxuICAgICAgaGVhZGVyczogKChfcmVzdWx0JGluaXQ2ID0gcmVzdWx0LmluaXQpID09IG51bGwgPyB2b2lkIDAgOiBfcmVzdWx0JGluaXQ2LmhlYWRlcnMpICYmIG5ldyBIZWFkZXJzKHJlc3VsdC5pbml0LmhlYWRlcnMpXG4gICAgfTtcbiAgfVxuICBpZiAoaXNEYXRhV2l0aFJlc3BvbnNlSW5pdChyZXN1bHQpKSB7XG4gICAgdmFyIF9yZXN1bHQkaW5pdDcsIF9yZXN1bHQkaW5pdDg7XG4gICAgcmV0dXJuIHtcbiAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZGF0YSxcbiAgICAgIGRhdGE6IHJlc3VsdC5kYXRhLFxuICAgICAgc3RhdHVzQ29kZTogKF9yZXN1bHQkaW5pdDcgPSByZXN1bHQuaW5pdCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9yZXN1bHQkaW5pdDcuc3RhdHVzLFxuICAgICAgaGVhZGVyczogKF9yZXN1bHQkaW5pdDggPSByZXN1bHQuaW5pdCkgIT0gbnVsbCAmJiBfcmVzdWx0JGluaXQ4LmhlYWRlcnMgPyBuZXcgSGVhZGVycyhyZXN1bHQuaW5pdC5oZWFkZXJzKSA6IHVuZGVmaW5lZFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB0eXBlOiBSZXN1bHRUeXBlLmRhdGEsXG4gICAgZGF0YTogcmVzdWx0XG4gIH07XG59XG4vLyBTdXBwb3J0IHJlbGF0aXZlIHJvdXRpbmcgaW4gaW50ZXJuYWwgcmVkaXJlY3RzXG5mdW5jdGlvbiBub3JtYWxpemVSZWxhdGl2ZVJvdXRpbmdSZWRpcmVjdFJlc3BvbnNlKHJlc3BvbnNlLCByZXF1ZXN0LCByb3V0ZUlkLCBtYXRjaGVzLCBiYXNlbmFtZSwgdjdfcmVsYXRpdmVTcGxhdFBhdGgpIHtcbiAgbGV0IGxvY2F0aW9uID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoXCJMb2NhdGlvblwiKTtcbiAgaW52YXJpYW50KGxvY2F0aW9uLCBcIlJlZGlyZWN0cyByZXR1cm5lZC90aHJvd24gZnJvbSBsb2FkZXJzL2FjdGlvbnMgbXVzdCBoYXZlIGEgTG9jYXRpb24gaGVhZGVyXCIpO1xuICBpZiAoIUFCU09MVVRFX1VSTF9SRUdFWC50ZXN0KGxvY2F0aW9uKSkge1xuICAgIGxldCB0cmltbWVkTWF0Y2hlcyA9IG1hdGNoZXMuc2xpY2UoMCwgbWF0Y2hlcy5maW5kSW5kZXgobSA9PiBtLnJvdXRlLmlkID09PSByb3V0ZUlkKSArIDEpO1xuICAgIGxvY2F0aW9uID0gbm9ybWFsaXplVG8obmV3IFVSTChyZXF1ZXN0LnVybCksIHRyaW1tZWRNYXRjaGVzLCBiYXNlbmFtZSwgdHJ1ZSwgbG9jYXRpb24sIHY3X3JlbGF0aXZlU3BsYXRQYXRoKTtcbiAgICByZXNwb25zZS5oZWFkZXJzLnNldChcIkxvY2F0aW9uXCIsIGxvY2F0aW9uKTtcbiAgfVxuICByZXR1cm4gcmVzcG9uc2U7XG59XG5mdW5jdGlvbiBub3JtYWxpemVSZWRpcmVjdExvY2F0aW9uKGxvY2F0aW9uLCBjdXJyZW50VXJsLCBiYXNlbmFtZSwgaGlzdG9yeUluc3RhbmNlKSB7XG4gIC8vIE1hdGNoIENocm9tZSdzIGJlaGF2aW9yOlxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vY2hyb21pdW0vY2hyb21pdW0vYmxvYi8yMTZkYmViNjFkYjBjNjY3ZTYyMDgyZTVmNTQwMGEzMmQ2OTgzZGYzL2NvbnRlbnQvcHVibGljL2NvbW1vbi91cmxfdXRpbHMuY2MjTDgyXG4gIGxldCBpbnZhbGlkUHJvdG9jb2xzID0gW1wiYWJvdXQ6XCIsIFwiYmxvYjpcIiwgXCJjaHJvbWU6XCIsIFwiY2hyb21lLXVudHJ1c3RlZDpcIiwgXCJjb250ZW50OlwiLCBcImRhdGE6XCIsIFwiZGV2dG9vbHM6XCIsIFwiZmlsZTpcIiwgXCJmaWxlc3lzdGVtOlwiLFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tc2NyaXB0LXVybFxuICBcImphdmFzY3JpcHQ6XCJdO1xuICBpZiAoQUJTT0xVVEVfVVJMX1JFR0VYLnRlc3QobG9jYXRpb24pKSB7XG4gICAgLy8gU3RyaXAgb2ZmIHRoZSBwcm90b2NvbCtvcmlnaW4gZm9yIHNhbWUtb3JpZ2luICsgc2FtZS1iYXNlbmFtZSBhYnNvbHV0ZSByZWRpcmVjdHNcbiAgICBsZXQgbm9ybWFsaXplZExvY2F0aW9uID0gbG9jYXRpb247XG4gICAgbGV0IHVybCA9IG5vcm1hbGl6ZWRMb2NhdGlvbi5zdGFydHNXaXRoKFwiLy9cIikgPyBuZXcgVVJMKGN1cnJlbnRVcmwucHJvdG9jb2wgKyBub3JtYWxpemVkTG9jYXRpb24pIDogbmV3IFVSTChub3JtYWxpemVkTG9jYXRpb24pO1xuICAgIGlmIChpbnZhbGlkUHJvdG9jb2xzLmluY2x1ZGVzKHVybC5wcm90b2NvbCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcmVkaXJlY3QgbG9jYXRpb25cIik7XG4gICAgfVxuICAgIGxldCBpc1NhbWVCYXNlbmFtZSA9IHN0cmlwQmFzZW5hbWUodXJsLnBhdGhuYW1lLCBiYXNlbmFtZSkgIT0gbnVsbDtcbiAgICBpZiAodXJsLm9yaWdpbiA9PT0gY3VycmVudFVybC5vcmlnaW4gJiYgaXNTYW1lQmFzZW5hbWUpIHtcbiAgICAgIHJldHVybiByZW1vdmVEb3VibGVTbGFzaGVzKHVybC5wYXRobmFtZSkgKyB1cmwuc2VhcmNoICsgdXJsLmhhc2g7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgbGV0IHVybCA9IGhpc3RvcnlJbnN0YW5jZS5jcmVhdGVVUkwobG9jYXRpb24pO1xuICAgIGlmIChpbnZhbGlkUHJvdG9jb2xzLmluY2x1ZGVzKHVybC5wcm90b2NvbCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcmVkaXJlY3QgbG9jYXRpb25cIik7XG4gICAgfVxuICB9IGNhdGNoIChlKSB7fVxuICByZXR1cm4gbG9jYXRpb247XG59XG4vLyBVdGlsaXR5IG1ldGhvZCBmb3IgY3JlYXRpbmcgdGhlIFJlcXVlc3QgaW5zdGFuY2VzIGZvciBsb2FkZXJzL2FjdGlvbnMgZHVyaW5nXG4vLyBjbGllbnQtc2lkZSBuYXZpZ2F0aW9ucyBhbmQgZmV0Y2hlcy4gIER1cmluZyBTU1Igd2Ugd2lsbCBhbHdheXMgaGF2ZSBhXG4vLyBSZXF1ZXN0IGluc3RhbmNlIGZyb20gdGhlIHN0YXRpYyBoYW5kbGVyIChxdWVyeS9xdWVyeVJvdXRlKVxuZnVuY3Rpb24gY3JlYXRlQ2xpZW50U2lkZVJlcXVlc3QoaGlzdG9yeSwgbG9jYXRpb24sIHNpZ25hbCwgc3VibWlzc2lvbikge1xuICBsZXQgdXJsID0gaGlzdG9yeS5jcmVhdGVVUkwoc3RyaXBIYXNoRnJvbVBhdGgobG9jYXRpb24pKS50b1N0cmluZygpO1xuICBsZXQgaW5pdCA9IHtcbiAgICBzaWduYWxcbiAgfTtcbiAgaWYgKHN1Ym1pc3Npb24gJiYgaXNNdXRhdGlvbk1ldGhvZChzdWJtaXNzaW9uLmZvcm1NZXRob2QpKSB7XG4gICAgbGV0IHtcbiAgICAgIGZvcm1NZXRob2QsXG4gICAgICBmb3JtRW5jVHlwZVxuICAgIH0gPSBzdWJtaXNzaW9uO1xuICAgIC8vIERpZG4ndCB0aGluayB3ZSBuZWVkZWQgdGhpcyBidXQgaXQgdHVybnMgb3V0IHVubGlrZSBvdGhlciBtZXRob2RzLCBwYXRjaFxuICAgIC8vIHdvbid0IGJlIHByb3Blcmx5IG5vcm1hbGl6ZWQgdG8gdXBwZXJjYXNlIGFuZCByZXN1bHRzIGluIGEgNDA1IGVycm9yLlxuICAgIC8vIFNlZTogaHR0cHM6Ly9mZXRjaC5zcGVjLndoYXR3Zy5vcmcvI2NvbmNlcHQtbWV0aG9kXG4gICAgaW5pdC5tZXRob2QgPSBmb3JtTWV0aG9kLnRvVXBwZXJDYXNlKCk7XG4gICAgaWYgKGZvcm1FbmNUeXBlID09PSBcImFwcGxpY2F0aW9uL2pzb25cIikge1xuICAgICAgaW5pdC5oZWFkZXJzID0gbmV3IEhlYWRlcnMoe1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBmb3JtRW5jVHlwZVxuICAgICAgfSk7XG4gICAgICBpbml0LmJvZHkgPSBKU09OLnN0cmluZ2lmeShzdWJtaXNzaW9uLmpzb24pO1xuICAgIH0gZWxzZSBpZiAoZm9ybUVuY1R5cGUgPT09IFwidGV4dC9wbGFpblwiKSB7XG4gICAgICAvLyBDb250ZW50LVR5cGUgaXMgaW5mZXJyZWQgKGh0dHBzOi8vZmV0Y2guc3BlYy53aGF0d2cub3JnLyNkb20tcmVxdWVzdClcbiAgICAgIGluaXQuYm9keSA9IHN1Ym1pc3Npb24udGV4dDtcbiAgICB9IGVsc2UgaWYgKGZvcm1FbmNUeXBlID09PSBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiICYmIHN1Ym1pc3Npb24uZm9ybURhdGEpIHtcbiAgICAgIC8vIENvbnRlbnQtVHlwZSBpcyBpbmZlcnJlZCAoaHR0cHM6Ly9mZXRjaC5zcGVjLndoYXR3Zy5vcmcvI2RvbS1yZXF1ZXN0KVxuICAgICAgaW5pdC5ib2R5ID0gY29udmVydEZvcm1EYXRhVG9TZWFyY2hQYXJhbXMoc3VibWlzc2lvbi5mb3JtRGF0YSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIENvbnRlbnQtVHlwZSBpcyBpbmZlcnJlZCAoaHR0cHM6Ly9mZXRjaC5zcGVjLndoYXR3Zy5vcmcvI2RvbS1yZXF1ZXN0KVxuICAgICAgaW5pdC5ib2R5ID0gc3VibWlzc2lvbi5mb3JtRGF0YTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG5ldyBSZXF1ZXN0KHVybCwgaW5pdCk7XG59XG5mdW5jdGlvbiBjb252ZXJ0Rm9ybURhdGFUb1NlYXJjaFBhcmFtcyhmb3JtRGF0YSkge1xuICBsZXQgc2VhcmNoUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xuICBmb3IgKGxldCBba2V5LCB2YWx1ZV0gb2YgZm9ybURhdGEuZW50cmllcygpKSB7XG4gICAgLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2UvZm9ybS1jb250cm9sLWluZnJhc3RydWN0dXJlLmh0bWwjY29udmVydGluZy1hbi1lbnRyeS1saXN0LXRvLWEtbGlzdC1vZi1uYW1lLXZhbHVlLXBhaXJzXG4gICAgc2VhcmNoUGFyYW1zLmFwcGVuZChrZXksIHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIiA/IHZhbHVlIDogdmFsdWUubmFtZSk7XG4gIH1cbiAgcmV0dXJuIHNlYXJjaFBhcmFtcztcbn1cbmZ1bmN0aW9uIGNvbnZlcnRTZWFyY2hQYXJhbXNUb0Zvcm1EYXRhKHNlYXJjaFBhcmFtcykge1xuICBsZXQgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKTtcbiAgZm9yIChsZXQgW2tleSwgdmFsdWVdIG9mIHNlYXJjaFBhcmFtcy5lbnRyaWVzKCkpIHtcbiAgICBmb3JtRGF0YS5hcHBlbmQoa2V5LCB2YWx1ZSk7XG4gIH1cbiAgcmV0dXJuIGZvcm1EYXRhO1xufVxuZnVuY3Rpb24gcHJvY2Vzc1JvdXRlTG9hZGVyRGF0YShtYXRjaGVzLCByZXN1bHRzLCBwZW5kaW5nQWN0aW9uUmVzdWx0LCBhY3RpdmVEZWZlcnJlZHMsIHNraXBMb2FkZXJFcnJvckJ1YmJsaW5nKSB7XG4gIC8vIEZpbGwgaW4gbG9hZGVyRGF0YS9lcnJvcnMgZnJvbSBvdXIgbG9hZGVyc1xuICBsZXQgbG9hZGVyRGF0YSA9IHt9O1xuICBsZXQgZXJyb3JzID0gbnVsbDtcbiAgbGV0IHN0YXR1c0NvZGU7XG4gIGxldCBmb3VuZEVycm9yID0gZmFsc2U7XG4gIGxldCBsb2FkZXJIZWFkZXJzID0ge307XG4gIGxldCBwZW5kaW5nRXJyb3IgPSBwZW5kaW5nQWN0aW9uUmVzdWx0ICYmIGlzRXJyb3JSZXN1bHQocGVuZGluZ0FjdGlvblJlc3VsdFsxXSkgPyBwZW5kaW5nQWN0aW9uUmVzdWx0WzFdLmVycm9yIDogdW5kZWZpbmVkO1xuICAvLyBQcm9jZXNzIGxvYWRlciByZXN1bHRzIGludG8gc3RhdGUubG9hZGVyRGF0YS9zdGF0ZS5lcnJvcnNcbiAgbWF0Y2hlcy5mb3JFYWNoKG1hdGNoID0+IHtcbiAgICBpZiAoIShtYXRjaC5yb3V0ZS5pZCBpbiByZXN1bHRzKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgaWQgPSBtYXRjaC5yb3V0ZS5pZDtcbiAgICBsZXQgcmVzdWx0ID0gcmVzdWx0c1tpZF07XG4gICAgaW52YXJpYW50KCFpc1JlZGlyZWN0UmVzdWx0KHJlc3VsdCksIFwiQ2Fubm90IGhhbmRsZSByZWRpcmVjdCByZXN1bHRzIGluIHByb2Nlc3NMb2FkZXJEYXRhXCIpO1xuICAgIGlmIChpc0Vycm9yUmVzdWx0KHJlc3VsdCkpIHtcbiAgICAgIGxldCBlcnJvciA9IHJlc3VsdC5lcnJvcjtcbiAgICAgIC8vIElmIHdlIGhhdmUgYSBwZW5kaW5nIGFjdGlvbiBlcnJvciwgd2UgcmVwb3J0IGl0IGF0IHRoZSBoaWdoZXN0LXJvdXRlXG4gICAgICAvLyB0aGF0IHRocm93cyBhIGxvYWRlciBlcnJvciwgYW5kIHRoZW4gY2xlYXIgaXQgb3V0IHRvIGluZGljYXRlIHRoYXRcbiAgICAgIC8vIGl0IHdhcyBjb25zdW1lZFxuICAgICAgaWYgKHBlbmRpbmdFcnJvciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGVycm9yID0gcGVuZGluZ0Vycm9yO1xuICAgICAgICBwZW5kaW5nRXJyb3IgPSB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICBlcnJvcnMgPSBlcnJvcnMgfHwge307XG4gICAgICBpZiAoc2tpcExvYWRlckVycm9yQnViYmxpbmcpIHtcbiAgICAgICAgZXJyb3JzW2lkXSA9IGVycm9yO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gTG9vayB1cHdhcmRzIGZyb20gdGhlIG1hdGNoZWQgcm91dGUgZm9yIHRoZSBjbG9zZXN0IGFuY2VzdG9yIGVycm9yXG4gICAgICAgIC8vIGJvdW5kYXJ5LCBkZWZhdWx0aW5nIHRvIHRoZSByb290IG1hdGNoLiAgUHJlZmVyIGhpZ2hlciBlcnJvciB2YWx1ZXNcbiAgICAgICAgLy8gaWYgbG93ZXIgZXJyb3JzIGJ1YmJsZSB0byB0aGUgc2FtZSBib3VuZGFyeVxuICAgICAgICBsZXQgYm91bmRhcnlNYXRjaCA9IGZpbmROZWFyZXN0Qm91bmRhcnkobWF0Y2hlcywgaWQpO1xuICAgICAgICBpZiAoZXJyb3JzW2JvdW5kYXJ5TWF0Y2gucm91dGUuaWRdID09IG51bGwpIHtcbiAgICAgICAgICBlcnJvcnNbYm91bmRhcnlNYXRjaC5yb3V0ZS5pZF0gPSBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLy8gQ2xlYXIgb3VyIGFueSBwcmlvciBsb2FkZXJEYXRhIGZvciB0aGUgdGhyb3dpbmcgcm91dGVcbiAgICAgIGxvYWRlckRhdGFbaWRdID0gdW5kZWZpbmVkO1xuICAgICAgLy8gT25jZSB3ZSBmaW5kIG91ciBmaXJzdCAoaGlnaGVzdCkgZXJyb3IsIHdlIHNldCB0aGUgc3RhdHVzIGNvZGUgYW5kXG4gICAgICAvLyBwcmV2ZW50IGRlZXBlciBzdGF0dXMgY29kZXMgZnJvbSBvdmVycmlkaW5nXG4gICAgICBpZiAoIWZvdW5kRXJyb3IpIHtcbiAgICAgICAgZm91bmRFcnJvciA9IHRydWU7XG4gICAgICAgIHN0YXR1c0NvZGUgPSBpc1JvdXRlRXJyb3JSZXNwb25zZShyZXN1bHQuZXJyb3IpID8gcmVzdWx0LmVycm9yLnN0YXR1cyA6IDUwMDtcbiAgICAgIH1cbiAgICAgIGlmIChyZXN1bHQuaGVhZGVycykge1xuICAgICAgICBsb2FkZXJIZWFkZXJzW2lkXSA9IHJlc3VsdC5oZWFkZXJzO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoaXNEZWZlcnJlZFJlc3VsdChyZXN1bHQpKSB7XG4gICAgICAgIGFjdGl2ZURlZmVycmVkcy5zZXQoaWQsIHJlc3VsdC5kZWZlcnJlZERhdGEpO1xuICAgICAgICBsb2FkZXJEYXRhW2lkXSA9IHJlc3VsdC5kZWZlcnJlZERhdGEuZGF0YTtcbiAgICAgICAgLy8gRXJyb3Igc3RhdHVzIGNvZGVzIGFsd2F5cyBvdmVycmlkZSBzdWNjZXNzIHN0YXR1cyBjb2RlcywgYnV0IGlmIGFsbFxuICAgICAgICAvLyBsb2FkZXJzIGFyZSBzdWNjZXNzZnVsIHdlIHRha2UgdGhlIGRlZXBlc3Qgc3RhdHVzIGNvZGUuXG4gICAgICAgIGlmIChyZXN1bHQuc3RhdHVzQ29kZSAhPSBudWxsICYmIHJlc3VsdC5zdGF0dXNDb2RlICE9PSAyMDAgJiYgIWZvdW5kRXJyb3IpIHtcbiAgICAgICAgICBzdGF0dXNDb2RlID0gcmVzdWx0LnN0YXR1c0NvZGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc3VsdC5oZWFkZXJzKSB7XG4gICAgICAgICAgbG9hZGVySGVhZGVyc1tpZF0gPSByZXN1bHQuaGVhZGVycztcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbG9hZGVyRGF0YVtpZF0gPSByZXN1bHQuZGF0YTtcbiAgICAgICAgLy8gRXJyb3Igc3RhdHVzIGNvZGVzIGFsd2F5cyBvdmVycmlkZSBzdWNjZXNzIHN0YXR1cyBjb2RlcywgYnV0IGlmIGFsbFxuICAgICAgICAvLyBsb2FkZXJzIGFyZSBzdWNjZXNzZnVsIHdlIHRha2UgdGhlIGRlZXBlc3Qgc3RhdHVzIGNvZGUuXG4gICAgICAgIGlmIChyZXN1bHQuc3RhdHVzQ29kZSAmJiByZXN1bHQuc3RhdHVzQ29kZSAhPT0gMjAwICYmICFmb3VuZEVycm9yKSB7XG4gICAgICAgICAgc3RhdHVzQ29kZSA9IHJlc3VsdC5zdGF0dXNDb2RlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXN1bHQuaGVhZGVycykge1xuICAgICAgICAgIGxvYWRlckhlYWRlcnNbaWRdID0gcmVzdWx0LmhlYWRlcnM7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICAvLyBJZiB3ZSBkaWRuJ3QgY29uc3VtZSB0aGUgcGVuZGluZyBhY3Rpb24gZXJyb3IgKGkuZS4sIGFsbCBsb2FkZXJzXG4gIC8vIHJlc29sdmVkKSwgdGhlbiBjb25zdW1lIGl0IGhlcmUuICBBbHNvIGNsZWFyIG91dCBhbnkgbG9hZGVyRGF0YSBmb3IgdGhlXG4gIC8vIHRocm93aW5nIHJvdXRlXG4gIGlmIChwZW5kaW5nRXJyb3IgIT09IHVuZGVmaW5lZCAmJiBwZW5kaW5nQWN0aW9uUmVzdWx0KSB7XG4gICAgZXJyb3JzID0ge1xuICAgICAgW3BlbmRpbmdBY3Rpb25SZXN1bHRbMF1dOiBwZW5kaW5nRXJyb3JcbiAgICB9O1xuICAgIGxvYWRlckRhdGFbcGVuZGluZ0FjdGlvblJlc3VsdFswXV0gPSB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBsb2FkZXJEYXRhLFxuICAgIGVycm9ycyxcbiAgICBzdGF0dXNDb2RlOiBzdGF0dXNDb2RlIHx8IDIwMCxcbiAgICBsb2FkZXJIZWFkZXJzXG4gIH07XG59XG5mdW5jdGlvbiBwcm9jZXNzTG9hZGVyRGF0YShzdGF0ZSwgbWF0Y2hlcywgcmVzdWx0cywgcGVuZGluZ0FjdGlvblJlc3VsdCwgcmV2YWxpZGF0aW5nRmV0Y2hlcnMsIGZldGNoZXJSZXN1bHRzLCBhY3RpdmVEZWZlcnJlZHMpIHtcbiAgbGV0IHtcbiAgICBsb2FkZXJEYXRhLFxuICAgIGVycm9yc1xuICB9ID0gcHJvY2Vzc1JvdXRlTG9hZGVyRGF0YShtYXRjaGVzLCByZXN1bHRzLCBwZW5kaW5nQWN0aW9uUmVzdWx0LCBhY3RpdmVEZWZlcnJlZHMsIGZhbHNlIC8vIFRoaXMgbWV0aG9kIGlzIG9ubHkgY2FsbGVkIGNsaWVudCBzaWRlIHNvIHdlIGFsd2F5cyB3YW50IHRvIGJ1YmJsZVxuICApO1xuICAvLyBQcm9jZXNzIHJlc3VsdHMgZnJvbSBvdXIgcmV2YWxpZGF0aW5nIGZldGNoZXJzXG4gIHJldmFsaWRhdGluZ0ZldGNoZXJzLmZvckVhY2gocmYgPT4ge1xuICAgIGxldCB7XG4gICAgICBrZXksXG4gICAgICBtYXRjaCxcbiAgICAgIGNvbnRyb2xsZXJcbiAgICB9ID0gcmY7XG4gICAgbGV0IHJlc3VsdCA9IGZldGNoZXJSZXN1bHRzW2tleV07XG4gICAgaW52YXJpYW50KHJlc3VsdCwgXCJEaWQgbm90IGZpbmQgY29ycmVzcG9uZGluZyBmZXRjaGVyIHJlc3VsdFwiKTtcbiAgICAvLyBQcm9jZXNzIGZldGNoZXIgbm9uLXJlZGlyZWN0IGVycm9yc1xuICAgIGlmIChjb250cm9sbGVyICYmIGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgIC8vIE5vdGhpbmcgdG8gZG8gZm9yIGFib3J0ZWQgZmV0Y2hlcnNcbiAgICAgIHJldHVybjtcbiAgICB9IGVsc2UgaWYgKGlzRXJyb3JSZXN1bHQocmVzdWx0KSkge1xuICAgICAgbGV0IGJvdW5kYXJ5TWF0Y2ggPSBmaW5kTmVhcmVzdEJvdW5kYXJ5KHN0YXRlLm1hdGNoZXMsIG1hdGNoID09IG51bGwgPyB2b2lkIDAgOiBtYXRjaC5yb3V0ZS5pZCk7XG4gICAgICBpZiAoIShlcnJvcnMgJiYgZXJyb3JzW2JvdW5kYXJ5TWF0Y2gucm91dGUuaWRdKSkge1xuICAgICAgICBlcnJvcnMgPSBfZXh0ZW5kcyh7fSwgZXJyb3JzLCB7XG4gICAgICAgICAgW2JvdW5kYXJ5TWF0Y2gucm91dGUuaWRdOiByZXN1bHQuZXJyb3JcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBzdGF0ZS5mZXRjaGVycy5kZWxldGUoa2V5KTtcbiAgICB9IGVsc2UgaWYgKGlzUmVkaXJlY3RSZXN1bHQocmVzdWx0KSkge1xuICAgICAgLy8gU2hvdWxkIG5ldmVyIGdldCBoZXJlLCByZWRpcmVjdHMgc2hvdWxkIGdldCBwcm9jZXNzZWQgYWJvdmUsIGJ1dCB3ZVxuICAgICAgLy8ga2VlcCB0aGlzIHRvIHR5cGUgbmFycm93IHRvIGEgc3VjY2VzcyByZXN1bHQgaW4gdGhlIGVsc2VcbiAgICAgIGludmFyaWFudChmYWxzZSwgXCJVbmhhbmRsZWQgZmV0Y2hlciByZXZhbGlkYXRpb24gcmVkaXJlY3RcIik7XG4gICAgfSBlbHNlIGlmIChpc0RlZmVycmVkUmVzdWx0KHJlc3VsdCkpIHtcbiAgICAgIC8vIFNob3VsZCBuZXZlciBnZXQgaGVyZSwgZGVmZXJyZWQgZGF0YSBzaG91bGQgYmUgYXdhaXRlZCBmb3IgZmV0Y2hlcnNcbiAgICAgIC8vIGluIHJlc29sdmVEZWZlcnJlZFJlc3VsdHNcbiAgICAgIGludmFyaWFudChmYWxzZSwgXCJVbmhhbmRsZWQgZmV0Y2hlciBkZWZlcnJlZCBkYXRhXCIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgZG9uZUZldGNoZXIgPSBnZXREb25lRmV0Y2hlcihyZXN1bHQuZGF0YSk7XG4gICAgICBzdGF0ZS5mZXRjaGVycy5zZXQoa2V5LCBkb25lRmV0Y2hlcik7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBsb2FkZXJEYXRhLFxuICAgIGVycm9yc1xuICB9O1xufVxuZnVuY3Rpb24gbWVyZ2VMb2FkZXJEYXRhKGxvYWRlckRhdGEsIG5ld0xvYWRlckRhdGEsIG1hdGNoZXMsIGVycm9ycykge1xuICBsZXQgbWVyZ2VkTG9hZGVyRGF0YSA9IF9leHRlbmRzKHt9LCBuZXdMb2FkZXJEYXRhKTtcbiAgZm9yIChsZXQgbWF0Y2ggb2YgbWF0Y2hlcykge1xuICAgIGxldCBpZCA9IG1hdGNoLnJvdXRlLmlkO1xuICAgIGlmIChuZXdMb2FkZXJEYXRhLmhhc093blByb3BlcnR5KGlkKSkge1xuICAgICAgaWYgKG5ld0xvYWRlckRhdGFbaWRdICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgbWVyZ2VkTG9hZGVyRGF0YVtpZF0gPSBuZXdMb2FkZXJEYXRhW2lkXTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGxvYWRlckRhdGFbaWRdICE9PSB1bmRlZmluZWQgJiYgbWF0Y2gucm91dGUubG9hZGVyKSB7XG4gICAgICAvLyBQcmVzZXJ2ZSBleGlzdGluZyBrZXlzIG5vdCBpbmNsdWRlZCBpbiBuZXdMb2FkZXJEYXRhIGFuZCB3aGVyZSBhIGxvYWRlclxuICAgICAgLy8gd2Fzbid0IHJlbW92ZWQgYnkgSE1SXG4gICAgICBtZXJnZWRMb2FkZXJEYXRhW2lkXSA9IGxvYWRlckRhdGFbaWRdO1xuICAgIH1cbiAgICBpZiAoZXJyb3JzICYmIGVycm9ycy5oYXNPd25Qcm9wZXJ0eShpZCkpIHtcbiAgICAgIC8vIERvbid0IGtlZXAgYW55IGxvYWRlciBkYXRhIGJlbG93IHRoZSBib3VuZGFyeVxuICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWRMb2FkZXJEYXRhO1xufVxuZnVuY3Rpb24gZ2V0QWN0aW9uRGF0YUZvckNvbW1pdChwZW5kaW5nQWN0aW9uUmVzdWx0KSB7XG4gIGlmICghcGVuZGluZ0FjdGlvblJlc3VsdCkge1xuICAgIHJldHVybiB7fTtcbiAgfVxuICByZXR1cm4gaXNFcnJvclJlc3VsdChwZW5kaW5nQWN0aW9uUmVzdWx0WzFdKSA/IHtcbiAgICAvLyBDbGVhciBvdXQgcHJpb3IgYWN0aW9uRGF0YSBvbiBlcnJvcnNcbiAgICBhY3Rpb25EYXRhOiB7fVxuICB9IDoge1xuICAgIGFjdGlvbkRhdGE6IHtcbiAgICAgIFtwZW5kaW5nQWN0aW9uUmVzdWx0WzBdXTogcGVuZGluZ0FjdGlvblJlc3VsdFsxXS5kYXRhXG4gICAgfVxuICB9O1xufVxuLy8gRmluZCB0aGUgbmVhcmVzdCBlcnJvciBib3VuZGFyeSwgbG9va2luZyB1cHdhcmRzIGZyb20gdGhlIGxlYWYgcm91dGUgKG9yIHRoZVxuLy8gcm91dGUgc3BlY2lmaWVkIGJ5IHJvdXRlSWQpIGZvciB0aGUgY2xvc2VzdCBhbmNlc3RvciBlcnJvciBib3VuZGFyeSxcbi8vIGRlZmF1bHRpbmcgdG8gdGhlIHJvb3QgbWF0Y2hcbmZ1bmN0aW9uIGZpbmROZWFyZXN0Qm91bmRhcnkobWF0Y2hlcywgcm91dGVJZCkge1xuICBsZXQgZWxpZ2libGVNYXRjaGVzID0gcm91dGVJZCA/IG1hdGNoZXMuc2xpY2UoMCwgbWF0Y2hlcy5maW5kSW5kZXgobSA9PiBtLnJvdXRlLmlkID09PSByb3V0ZUlkKSArIDEpIDogWy4uLm1hdGNoZXNdO1xuICByZXR1cm4gZWxpZ2libGVNYXRjaGVzLnJldmVyc2UoKS5maW5kKG0gPT4gbS5yb3V0ZS5oYXNFcnJvckJvdW5kYXJ5ID09PSB0cnVlKSB8fCBtYXRjaGVzWzBdO1xufVxuZnVuY3Rpb24gZ2V0U2hvcnRDaXJjdWl0TWF0Y2hlcyhyb3V0ZXMpIHtcbiAgLy8gUHJlZmVyIGEgcm9vdCBsYXlvdXQgcm91dGUgaWYgcHJlc2VudCwgb3RoZXJ3aXNlIHNoaW0gaW4gYSByb3V0ZSBvYmplY3RcbiAgbGV0IHJvdXRlID0gcm91dGVzLmxlbmd0aCA9PT0gMSA/IHJvdXRlc1swXSA6IHJvdXRlcy5maW5kKHIgPT4gci5pbmRleCB8fCAhci5wYXRoIHx8IHIucGF0aCA9PT0gXCIvXCIpIHx8IHtcbiAgICBpZDogXCJfX3NoaW0tZXJyb3Itcm91dGVfX1wiXG4gIH07XG4gIHJldHVybiB7XG4gICAgbWF0Y2hlczogW3tcbiAgICAgIHBhcmFtczoge30sXG4gICAgICBwYXRobmFtZTogXCJcIixcbiAgICAgIHBhdGhuYW1lQmFzZTogXCJcIixcbiAgICAgIHJvdXRlXG4gICAgfV0sXG4gICAgcm91dGVcbiAgfTtcbn1cbmZ1bmN0aW9uIGdldEludGVybmFsUm91dGVyRXJyb3Ioc3RhdHVzLCBfdGVtcDUpIHtcbiAgbGV0IHtcbiAgICBwYXRobmFtZSxcbiAgICByb3V0ZUlkLFxuICAgIG1ldGhvZCxcbiAgICB0eXBlLFxuICAgIG1lc3NhZ2VcbiAgfSA9IF90ZW1wNSA9PT0gdm9pZCAwID8ge30gOiBfdGVtcDU7XG4gIGxldCBzdGF0dXNUZXh0ID0gXCJVbmtub3duIFNlcnZlciBFcnJvclwiO1xuICBsZXQgZXJyb3JNZXNzYWdlID0gXCJVbmtub3duIEByZW1peC1ydW4vcm91dGVyIGVycm9yXCI7XG4gIGlmIChzdGF0dXMgPT09IDQwMCkge1xuICAgIHN0YXR1c1RleHQgPSBcIkJhZCBSZXF1ZXN0XCI7XG4gICAgaWYgKG1ldGhvZCAmJiBwYXRobmFtZSAmJiByb3V0ZUlkKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBcIllvdSBtYWRlIGEgXCIgKyBtZXRob2QgKyBcIiByZXF1ZXN0IHRvIFxcXCJcIiArIHBhdGhuYW1lICsgXCJcXFwiIGJ1dCBcIiArIChcImRpZCBub3QgcHJvdmlkZSBhIGBsb2FkZXJgIGZvciByb3V0ZSBcXFwiXCIgKyByb3V0ZUlkICsgXCJcXFwiLCBcIikgKyBcInNvIHRoZXJlIGlzIG5vIHdheSB0byBoYW5kbGUgdGhlIHJlcXVlc3QuXCI7XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSBcImRlZmVyLWFjdGlvblwiKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBcImRlZmVyKCkgaXMgbm90IHN1cHBvcnRlZCBpbiBhY3Rpb25zXCI7XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSBcImludmFsaWQtYm9keVwiKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBcIlVuYWJsZSB0byBlbmNvZGUgc3VibWlzc2lvbiBib2R5XCI7XG4gICAgfVxuICB9IGVsc2UgaWYgKHN0YXR1cyA9PT0gNDAzKSB7XG4gICAgc3RhdHVzVGV4dCA9IFwiRm9yYmlkZGVuXCI7XG4gICAgZXJyb3JNZXNzYWdlID0gXCJSb3V0ZSBcXFwiXCIgKyByb3V0ZUlkICsgXCJcXFwiIGRvZXMgbm90IG1hdGNoIFVSTCBcXFwiXCIgKyBwYXRobmFtZSArIFwiXFxcIlwiO1xuICB9IGVsc2UgaWYgKHN0YXR1cyA9PT0gNDA0KSB7XG4gICAgc3RhdHVzVGV4dCA9IFwiTm90IEZvdW5kXCI7XG4gICAgZXJyb3JNZXNzYWdlID0gXCJObyByb3V0ZSBtYXRjaGVzIFVSTCBcXFwiXCIgKyBwYXRobmFtZSArIFwiXFxcIlwiO1xuICB9IGVsc2UgaWYgKHN0YXR1cyA9PT0gNDA1KSB7XG4gICAgc3RhdHVzVGV4dCA9IFwiTWV0aG9kIE5vdCBBbGxvd2VkXCI7XG4gICAgaWYgKG1ldGhvZCAmJiBwYXRobmFtZSAmJiByb3V0ZUlkKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBcIllvdSBtYWRlIGEgXCIgKyBtZXRob2QudG9VcHBlckNhc2UoKSArIFwiIHJlcXVlc3QgdG8gXFxcIlwiICsgcGF0aG5hbWUgKyBcIlxcXCIgYnV0IFwiICsgKFwiZGlkIG5vdCBwcm92aWRlIGFuIGBhY3Rpb25gIGZvciByb3V0ZSBcXFwiXCIgKyByb3V0ZUlkICsgXCJcXFwiLCBcIikgKyBcInNvIHRoZXJlIGlzIG5vIHdheSB0byBoYW5kbGUgdGhlIHJlcXVlc3QuXCI7XG4gICAgfSBlbHNlIGlmIChtZXRob2QpIHtcbiAgICAgIGVycm9yTWVzc2FnZSA9IFwiSW52YWxpZCByZXF1ZXN0IG1ldGhvZCBcXFwiXCIgKyBtZXRob2QudG9VcHBlckNhc2UoKSArIFwiXFxcIlwiO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbmV3IEVycm9yUmVzcG9uc2VJbXBsKHN0YXR1cyB8fCA1MDAsIHN0YXR1c1RleHQsIG5ldyBFcnJvcihlcnJvck1lc3NhZ2UpLCB0cnVlKTtcbn1cbi8vIEZpbmQgYW55IHJldHVybmVkIHJlZGlyZWN0IGVycm9ycywgc3RhcnRpbmcgZnJvbSB0aGUgbG93ZXN0IG1hdGNoXG5mdW5jdGlvbiBmaW5kUmVkaXJlY3QocmVzdWx0cykge1xuICBsZXQgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKHJlc3VsdHMpO1xuICBmb3IgKGxldCBpID0gZW50cmllcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgIGxldCBba2V5LCByZXN1bHRdID0gZW50cmllc1tpXTtcbiAgICBpZiAoaXNSZWRpcmVjdFJlc3VsdChyZXN1bHQpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBrZXksXG4gICAgICAgIHJlc3VsdFxuICAgICAgfTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHN0cmlwSGFzaEZyb21QYXRoKHBhdGgpIHtcbiAgbGV0IHBhcnNlZFBhdGggPSB0eXBlb2YgcGF0aCA9PT0gXCJzdHJpbmdcIiA/IHBhcnNlUGF0aChwYXRoKSA6IHBhdGg7XG4gIHJldHVybiBjcmVhdGVQYXRoKF9leHRlbmRzKHt9LCBwYXJzZWRQYXRoLCB7XG4gICAgaGFzaDogXCJcIlxuICB9KSk7XG59XG5mdW5jdGlvbiBpc0hhc2hDaGFuZ2VPbmx5KGEsIGIpIHtcbiAgaWYgKGEucGF0aG5hbWUgIT09IGIucGF0aG5hbWUgfHwgYS5zZWFyY2ggIT09IGIuc2VhcmNoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChhLmhhc2ggPT09IFwiXCIpIHtcbiAgICAvLyAvcGFnZSAtPiAvcGFnZSNoYXNoXG4gICAgcmV0dXJuIGIuaGFzaCAhPT0gXCJcIjtcbiAgfSBlbHNlIGlmIChhLmhhc2ggPT09IGIuaGFzaCkge1xuICAgIC8vIC9wYWdlI2hhc2ggLT4gL3BhZ2UjaGFzaFxuICAgIHJldHVybiB0cnVlO1xuICB9IGVsc2UgaWYgKGIuaGFzaCAhPT0gXCJcIikge1xuICAgIC8vIC9wYWdlI2hhc2ggLT4gL3BhZ2Ujb3RoZXJcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvLyBJZiB0aGUgaGFzaCBpcyByZW1vdmVkIHRoZSBicm93c2VyIHdpbGwgcmUtcGVyZm9ybSBhIHJlcXVlc3QgdG8gdGhlIHNlcnZlclxuICAvLyAvcGFnZSNoYXNoIC0+IC9wYWdlXG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzRGF0YVN0cmF0ZWd5UmVzdWx0KHJlc3VsdCkge1xuICByZXR1cm4gcmVzdWx0ICE9IG51bGwgJiYgdHlwZW9mIHJlc3VsdCA9PT0gXCJvYmplY3RcIiAmJiBcInR5cGVcIiBpbiByZXN1bHQgJiYgXCJyZXN1bHRcIiBpbiByZXN1bHQgJiYgKHJlc3VsdC50eXBlID09PSBSZXN1bHRUeXBlLmRhdGEgfHwgcmVzdWx0LnR5cGUgPT09IFJlc3VsdFR5cGUuZXJyb3IpO1xufVxuZnVuY3Rpb24gaXNSZWRpcmVjdERhdGFTdHJhdGVneVJlc3VsdFJlc3VsdChyZXN1bHQpIHtcbiAgcmV0dXJuIGlzUmVzcG9uc2UocmVzdWx0LnJlc3VsdCkgJiYgcmVkaXJlY3RTdGF0dXNDb2Rlcy5oYXMocmVzdWx0LnJlc3VsdC5zdGF0dXMpO1xufVxuZnVuY3Rpb24gaXNEZWZlcnJlZFJlc3VsdChyZXN1bHQpIHtcbiAgcmV0dXJuIHJlc3VsdC50eXBlID09PSBSZXN1bHRUeXBlLmRlZmVycmVkO1xufVxuZnVuY3Rpb24gaXNFcnJvclJlc3VsdChyZXN1bHQpIHtcbiAgcmV0dXJuIHJlc3VsdC50eXBlID09PSBSZXN1bHRUeXBlLmVycm9yO1xufVxuZnVuY3Rpb24gaXNSZWRpcmVjdFJlc3VsdChyZXN1bHQpIHtcbiAgcmV0dXJuIChyZXN1bHQgJiYgcmVzdWx0LnR5cGUpID09PSBSZXN1bHRUeXBlLnJlZGlyZWN0O1xufVxuZnVuY3Rpb24gaXNEYXRhV2l0aFJlc3BvbnNlSW5pdCh2YWx1ZSkge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9IG51bGwgJiYgXCJ0eXBlXCIgaW4gdmFsdWUgJiYgXCJkYXRhXCIgaW4gdmFsdWUgJiYgXCJpbml0XCIgaW4gdmFsdWUgJiYgdmFsdWUudHlwZSA9PT0gXCJEYXRhV2l0aFJlc3BvbnNlSW5pdFwiO1xufVxuZnVuY3Rpb24gaXNEZWZlcnJlZERhdGEodmFsdWUpIHtcbiAgbGV0IGRlZmVycmVkID0gdmFsdWU7XG4gIHJldHVybiBkZWZlcnJlZCAmJiB0eXBlb2YgZGVmZXJyZWQgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIGRlZmVycmVkLmRhdGEgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIGRlZmVycmVkLnN1YnNjcmliZSA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBkZWZlcnJlZC5jYW5jZWwgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgZGVmZXJyZWQucmVzb2x2ZURhdGEgPT09IFwiZnVuY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGlzUmVzcG9uc2UodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlICE9IG51bGwgJiYgdHlwZW9mIHZhbHVlLnN0YXR1cyA9PT0gXCJudW1iZXJcIiAmJiB0eXBlb2YgdmFsdWUuc3RhdHVzVGV4dCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgdmFsdWUuaGVhZGVycyA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUuYm9keSAhPT0gXCJ1bmRlZmluZWRcIjtcbn1cbmZ1bmN0aW9uIGlzUmVkaXJlY3RSZXNwb25zZShyZXN1bHQpIHtcbiAgaWYgKCFpc1Jlc3BvbnNlKHJlc3VsdCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgbGV0IHN0YXR1cyA9IHJlc3VsdC5zdGF0dXM7XG4gIGxldCBsb2NhdGlvbiA9IHJlc3VsdC5oZWFkZXJzLmdldChcIkxvY2F0aW9uXCIpO1xuICByZXR1cm4gc3RhdHVzID49IDMwMCAmJiBzdGF0dXMgPD0gMzk5ICYmIGxvY2F0aW9uICE9IG51bGw7XG59XG5mdW5jdGlvbiBpc1ZhbGlkTWV0aG9kKG1ldGhvZCkge1xuICByZXR1cm4gdmFsaWRSZXF1ZXN0TWV0aG9kcy5oYXMobWV0aG9kLnRvTG93ZXJDYXNlKCkpO1xufVxuZnVuY3Rpb24gaXNNdXRhdGlvbk1ldGhvZChtZXRob2QpIHtcbiAgcmV0dXJuIHZhbGlkTXV0YXRpb25NZXRob2RzLmhhcyhtZXRob2QudG9Mb3dlckNhc2UoKSk7XG59XG5hc3luYyBmdW5jdGlvbiByZXNvbHZlTmF2aWdhdGlvbkRlZmVycmVkUmVzdWx0cyhtYXRjaGVzLCByZXN1bHRzLCBzaWduYWwsIGN1cnJlbnRNYXRjaGVzLCBjdXJyZW50TG9hZGVyRGF0YSkge1xuICBsZXQgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKHJlc3VsdHMpO1xuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgZW50cmllcy5sZW5ndGg7IGluZGV4KyspIHtcbiAgICBsZXQgW3JvdXRlSWQsIHJlc3VsdF0gPSBlbnRyaWVzW2luZGV4XTtcbiAgICBsZXQgbWF0Y2ggPSBtYXRjaGVzLmZpbmQobSA9PiAobSA9PSBudWxsID8gdm9pZCAwIDogbS5yb3V0ZS5pZCkgPT09IHJvdXRlSWQpO1xuICAgIC8vIElmIHdlIGRvbid0IGhhdmUgYSBtYXRjaCwgdGhlbiB3ZSBjYW4gaGF2ZSBhIGRlZmVycmVkIHJlc3VsdCB0byBkb1xuICAgIC8vIGFueXRoaW5nIHdpdGguICBUaGlzIGlzIGZvciByZXZhbGlkYXRpbmcgZmV0Y2hlcnMgd2hlcmUgdGhlIHJvdXRlIHdhc1xuICAgIC8vIHJlbW92ZWQgZHVyaW5nIEhNUlxuICAgIGlmICghbWF0Y2gpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBsZXQgY3VycmVudE1hdGNoID0gY3VycmVudE1hdGNoZXMuZmluZChtID0+IG0ucm91dGUuaWQgPT09IG1hdGNoLnJvdXRlLmlkKTtcbiAgICBsZXQgaXNSZXZhbGlkYXRpbmdMb2FkZXIgPSBjdXJyZW50TWF0Y2ggIT0gbnVsbCAmJiAhaXNOZXdSb3V0ZUluc3RhbmNlKGN1cnJlbnRNYXRjaCwgbWF0Y2gpICYmIChjdXJyZW50TG9hZGVyRGF0YSAmJiBjdXJyZW50TG9hZGVyRGF0YVttYXRjaC5yb3V0ZS5pZF0pICE9PSB1bmRlZmluZWQ7XG4gICAgaWYgKGlzRGVmZXJyZWRSZXN1bHQocmVzdWx0KSAmJiBpc1JldmFsaWRhdGluZ0xvYWRlcikge1xuICAgICAgLy8gTm90ZTogd2UgZG8gbm90IGhhdmUgdG8gdG91Y2ggYWN0aXZlRGVmZXJyZWRzIGhlcmUgc2luY2Ugd2UgcmFjZSB0aGVtXG4gICAgICAvLyBhZ2FpbnN0IHRoZSBzaWduYWwgaW4gcmVzb2x2ZURlZmVycmVkRGF0YSBhbmQgdGhleSdsbCBnZXQgYWJvcnRlZFxuICAgICAgLy8gdGhlcmUgaWYgbmVlZGVkXG4gICAgICBhd2FpdCByZXNvbHZlRGVmZXJyZWREYXRhKHJlc3VsdCwgc2lnbmFsLCBmYWxzZSkudGhlbihyZXN1bHQgPT4ge1xuICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgcmVzdWx0c1tyb3V0ZUlkXSA9IHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5hc3luYyBmdW5jdGlvbiByZXNvbHZlRmV0Y2hlckRlZmVycmVkUmVzdWx0cyhtYXRjaGVzLCByZXN1bHRzLCByZXZhbGlkYXRpbmdGZXRjaGVycykge1xuICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgcmV2YWxpZGF0aW5nRmV0Y2hlcnMubGVuZ3RoOyBpbmRleCsrKSB7XG4gICAgbGV0IHtcbiAgICAgIGtleSxcbiAgICAgIHJvdXRlSWQsXG4gICAgICBjb250cm9sbGVyXG4gICAgfSA9IHJldmFsaWRhdGluZ0ZldGNoZXJzW2luZGV4XTtcbiAgICBsZXQgcmVzdWx0ID0gcmVzdWx0c1trZXldO1xuICAgIGxldCBtYXRjaCA9IG1hdGNoZXMuZmluZChtID0+IChtID09IG51bGwgPyB2b2lkIDAgOiBtLnJvdXRlLmlkKSA9PT0gcm91dGVJZCk7XG4gICAgLy8gSWYgd2UgZG9uJ3QgaGF2ZSBhIG1hdGNoLCB0aGVuIHdlIGNhbiBoYXZlIGEgZGVmZXJyZWQgcmVzdWx0IHRvIGRvXG4gICAgLy8gYW55dGhpbmcgd2l0aC4gIFRoaXMgaXMgZm9yIHJldmFsaWRhdGluZyBmZXRjaGVycyB3aGVyZSB0aGUgcm91dGUgd2FzXG4gICAgLy8gcmVtb3ZlZCBkdXJpbmcgSE1SXG4gICAgaWYgKCFtYXRjaCkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChpc0RlZmVycmVkUmVzdWx0KHJlc3VsdCkpIHtcbiAgICAgIC8vIE5vdGU6IHdlIGRvIG5vdCBoYXZlIHRvIHRvdWNoIGFjdGl2ZURlZmVycmVkcyBoZXJlIHNpbmNlIHdlIHJhY2UgdGhlbVxuICAgICAgLy8gYWdhaW5zdCB0aGUgc2lnbmFsIGluIHJlc29sdmVEZWZlcnJlZERhdGEgYW5kIHRoZXknbGwgZ2V0IGFib3J0ZWRcbiAgICAgIC8vIHRoZXJlIGlmIG5lZWRlZFxuICAgICAgaW52YXJpYW50KGNvbnRyb2xsZXIsIFwiRXhwZWN0ZWQgYW4gQWJvcnRDb250cm9sbGVyIGZvciByZXZhbGlkYXRpbmcgZmV0Y2hlciBkZWZlcnJlZCByZXN1bHRcIik7XG4gICAgICBhd2FpdCByZXNvbHZlRGVmZXJyZWREYXRhKHJlc3VsdCwgY29udHJvbGxlci5zaWduYWwsIHRydWUpLnRoZW4ocmVzdWx0ID0+IHtcbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgIHJlc3VsdHNba2V5XSA9IHJlc3VsdDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5hc3luYyBmdW5jdGlvbiByZXNvbHZlRGVmZXJyZWREYXRhKHJlc3VsdCwgc2lnbmFsLCB1bndyYXApIHtcbiAgaWYgKHVud3JhcCA9PT0gdm9pZCAwKSB7XG4gICAgdW53cmFwID0gZmFsc2U7XG4gIH1cbiAgbGV0IGFib3J0ZWQgPSBhd2FpdCByZXN1bHQuZGVmZXJyZWREYXRhLnJlc29sdmVEYXRhKHNpZ25hbCk7XG4gIGlmIChhYm9ydGVkKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh1bndyYXApIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdHlwZTogUmVzdWx0VHlwZS5kYXRhLFxuICAgICAgICBkYXRhOiByZXN1bHQuZGVmZXJyZWREYXRhLnVud3JhcHBlZERhdGFcbiAgICAgIH07XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gSGFuZGxlIGFueSBUcmFja2VkUHJvbWlzZS5fZXJyb3IgdmFsdWVzIGVuY291bnRlcmVkIHdoaWxlIHVud3JhcHBpbmdcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6IFJlc3VsdFR5cGUuZXJyb3IsXG4gICAgICAgIGVycm9yOiBlXG4gICAgICB9O1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIHR5cGU6IFJlc3VsdFR5cGUuZGF0YSxcbiAgICBkYXRhOiByZXN1bHQuZGVmZXJyZWREYXRhLmRhdGFcbiAgfTtcbn1cbmZ1bmN0aW9uIGhhc05ha2VkSW5kZXhRdWVyeShzZWFyY2gpIHtcbiAgcmV0dXJuIG5ldyBVUkxTZWFyY2hQYXJhbXMoc2VhcmNoKS5nZXRBbGwoXCJpbmRleFwiKS5zb21lKHYgPT4gdiA9PT0gXCJcIik7XG59XG5mdW5jdGlvbiBnZXRUYXJnZXRNYXRjaChtYXRjaGVzLCBsb2NhdGlvbikge1xuICBsZXQgc2VhcmNoID0gdHlwZW9mIGxvY2F0aW9uID09PSBcInN0cmluZ1wiID8gcGFyc2VQYXRoKGxvY2F0aW9uKS5zZWFyY2ggOiBsb2NhdGlvbi5zZWFyY2g7XG4gIGlmIChtYXRjaGVzW21hdGNoZXMubGVuZ3RoIC0gMV0ucm91dGUuaW5kZXggJiYgaGFzTmFrZWRJbmRleFF1ZXJ5KHNlYXJjaCB8fCBcIlwiKSkge1xuICAgIC8vIFJldHVybiB0aGUgbGVhZiBpbmRleCByb3V0ZSB3aGVuIGluZGV4IGlzIHByZXNlbnRcbiAgICByZXR1cm4gbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdO1xuICB9XG4gIC8vIE90aGVyd2lzZSBncmFiIHRoZSBkZWVwZXN0IFwicGF0aCBjb250cmlidXRpbmdcIiBtYXRjaCAoaWdub3JpbmcgaW5kZXggYW5kXG4gIC8vIHBhdGhsZXNzIGxheW91dCByb3V0ZXMpXG4gIGxldCBwYXRoTWF0Y2hlcyA9IGdldFBhdGhDb250cmlidXRpbmdNYXRjaGVzKG1hdGNoZXMpO1xuICByZXR1cm4gcGF0aE1hdGNoZXNbcGF0aE1hdGNoZXMubGVuZ3RoIC0gMV07XG59XG5mdW5jdGlvbiBnZXRTdWJtaXNzaW9uRnJvbU5hdmlnYXRpb24obmF2aWdhdGlvbikge1xuICBsZXQge1xuICAgIGZvcm1NZXRob2QsXG4gICAgZm9ybUFjdGlvbixcbiAgICBmb3JtRW5jVHlwZSxcbiAgICB0ZXh0LFxuICAgIGZvcm1EYXRhLFxuICAgIGpzb25cbiAgfSA9IG5hdmlnYXRpb247XG4gIGlmICghZm9ybU1ldGhvZCB8fCAhZm9ybUFjdGlvbiB8fCAhZm9ybUVuY1R5cGUpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHRleHQgIT0gbnVsbCkge1xuICAgIHJldHVybiB7XG4gICAgICBmb3JtTWV0aG9kLFxuICAgICAgZm9ybUFjdGlvbixcbiAgICAgIGZvcm1FbmNUeXBlLFxuICAgICAgZm9ybURhdGE6IHVuZGVmaW5lZCxcbiAgICAgIGpzb246IHVuZGVmaW5lZCxcbiAgICAgIHRleHRcbiAgICB9O1xuICB9IGVsc2UgaWYgKGZvcm1EYXRhICE9IG51bGwpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZm9ybU1ldGhvZCxcbiAgICAgIGZvcm1BY3Rpb24sXG4gICAgICBmb3JtRW5jVHlwZSxcbiAgICAgIGZvcm1EYXRhLFxuICAgICAganNvbjogdW5kZWZpbmVkLFxuICAgICAgdGV4dDogdW5kZWZpbmVkXG4gICAgfTtcbiAgfSBlbHNlIGlmIChqc29uICE9PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZm9ybU1ldGhvZCxcbiAgICAgIGZvcm1BY3Rpb24sXG4gICAgICBmb3JtRW5jVHlwZSxcbiAgICAgIGZvcm1EYXRhOiB1bmRlZmluZWQsXG4gICAgICBqc29uLFxuICAgICAgdGV4dDogdW5kZWZpbmVkXG4gICAgfTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0TG9hZGluZ05hdmlnYXRpb24obG9jYXRpb24sIHN1Ym1pc3Npb24pIHtcbiAgaWYgKHN1Ym1pc3Npb24pIHtcbiAgICBsZXQgbmF2aWdhdGlvbiA9IHtcbiAgICAgIHN0YXRlOiBcImxvYWRpbmdcIixcbiAgICAgIGxvY2F0aW9uLFxuICAgICAgZm9ybU1ldGhvZDogc3VibWlzc2lvbi5mb3JtTWV0aG9kLFxuICAgICAgZm9ybUFjdGlvbjogc3VibWlzc2lvbi5mb3JtQWN0aW9uLFxuICAgICAgZm9ybUVuY1R5cGU6IHN1Ym1pc3Npb24uZm9ybUVuY1R5cGUsXG4gICAgICBmb3JtRGF0YTogc3VibWlzc2lvbi5mb3JtRGF0YSxcbiAgICAgIGpzb246IHN1Ym1pc3Npb24uanNvbixcbiAgICAgIHRleHQ6IHN1Ym1pc3Npb24udGV4dFxuICAgIH07XG4gICAgcmV0dXJuIG5hdmlnYXRpb247XG4gIH0gZWxzZSB7XG4gICAgbGV0IG5hdmlnYXRpb24gPSB7XG4gICAgICBzdGF0ZTogXCJsb2FkaW5nXCIsXG4gICAgICBsb2NhdGlvbixcbiAgICAgIGZvcm1NZXRob2Q6IHVuZGVmaW5lZCxcbiAgICAgIGZvcm1BY3Rpb246IHVuZGVmaW5lZCxcbiAgICAgIGZvcm1FbmNUeXBlOiB1bmRlZmluZWQsXG4gICAgICBmb3JtRGF0YTogdW5kZWZpbmVkLFxuICAgICAganNvbjogdW5kZWZpbmVkLFxuICAgICAgdGV4dDogdW5kZWZpbmVkXG4gICAgfTtcbiAgICByZXR1cm4gbmF2aWdhdGlvbjtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0U3VibWl0dGluZ05hdmlnYXRpb24obG9jYXRpb24sIHN1Ym1pc3Npb24pIHtcbiAgbGV0IG5hdmlnYXRpb24gPSB7XG4gICAgc3RhdGU6IFwic3VibWl0dGluZ1wiLFxuICAgIGxvY2F0aW9uLFxuICAgIGZvcm1NZXRob2Q6IHN1Ym1pc3Npb24uZm9ybU1ldGhvZCxcbiAgICBmb3JtQWN0aW9uOiBzdWJtaXNzaW9uLmZvcm1BY3Rpb24sXG4gICAgZm9ybUVuY1R5cGU6IHN1Ym1pc3Npb24uZm9ybUVuY1R5cGUsXG4gICAgZm9ybURhdGE6IHN1Ym1pc3Npb24uZm9ybURhdGEsXG4gICAganNvbjogc3VibWlzc2lvbi5qc29uLFxuICAgIHRleHQ6IHN1Ym1pc3Npb24udGV4dFxuICB9O1xuICByZXR1cm4gbmF2aWdhdGlvbjtcbn1cbmZ1bmN0aW9uIGdldExvYWRpbmdGZXRjaGVyKHN1Ym1pc3Npb24sIGRhdGEpIHtcbiAgaWYgKHN1Ym1pc3Npb24pIHtcbiAgICBsZXQgZmV0Y2hlciA9IHtcbiAgICAgIHN0YXRlOiBcImxvYWRpbmdcIixcbiAgICAgIGZvcm1NZXRob2Q6IHN1Ym1pc3Npb24uZm9ybU1ldGhvZCxcbiAgICAgIGZvcm1BY3Rpb246IHN1Ym1pc3Npb24uZm9ybUFjdGlvbixcbiAgICAgIGZvcm1FbmNUeXBlOiBzdWJtaXNzaW9uLmZvcm1FbmNUeXBlLFxuICAgICAgZm9ybURhdGE6IHN1Ym1pc3Npb24uZm9ybURhdGEsXG4gICAgICBqc29uOiBzdWJtaXNzaW9uLmpzb24sXG4gICAgICB0ZXh0OiBzdWJtaXNzaW9uLnRleHQsXG4gICAgICBkYXRhXG4gICAgfTtcbiAgICByZXR1cm4gZmV0Y2hlcjtcbiAgfSBlbHNlIHtcbiAgICBsZXQgZmV0Y2hlciA9IHtcbiAgICAgIHN0YXRlOiBcImxvYWRpbmdcIixcbiAgICAgIGZvcm1NZXRob2Q6IHVuZGVmaW5lZCxcbiAgICAgIGZvcm1BY3Rpb246IHVuZGVmaW5lZCxcbiAgICAgIGZvcm1FbmNUeXBlOiB1bmRlZmluZWQsXG4gICAgICBmb3JtRGF0YTogdW5kZWZpbmVkLFxuICAgICAganNvbjogdW5kZWZpbmVkLFxuICAgICAgdGV4dDogdW5kZWZpbmVkLFxuICAgICAgZGF0YVxuICAgIH07XG4gICAgcmV0dXJuIGZldGNoZXI7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFN1Ym1pdHRpbmdGZXRjaGVyKHN1Ym1pc3Npb24sIGV4aXN0aW5nRmV0Y2hlcikge1xuICBsZXQgZmV0Y2hlciA9IHtcbiAgICBzdGF0ZTogXCJzdWJtaXR0aW5nXCIsXG4gICAgZm9ybU1ldGhvZDogc3VibWlzc2lvbi5mb3JtTWV0aG9kLFxuICAgIGZvcm1BY3Rpb246IHN1Ym1pc3Npb24uZm9ybUFjdGlvbixcbiAgICBmb3JtRW5jVHlwZTogc3VibWlzc2lvbi5mb3JtRW5jVHlwZSxcbiAgICBmb3JtRGF0YTogc3VibWlzc2lvbi5mb3JtRGF0YSxcbiAgICBqc29uOiBzdWJtaXNzaW9uLmpzb24sXG4gICAgdGV4dDogc3VibWlzc2lvbi50ZXh0LFxuICAgIGRhdGE6IGV4aXN0aW5nRmV0Y2hlciA/IGV4aXN0aW5nRmV0Y2hlci5kYXRhIDogdW5kZWZpbmVkXG4gIH07XG4gIHJldHVybiBmZXRjaGVyO1xufVxuZnVuY3Rpb24gZ2V0RG9uZUZldGNoZXIoZGF0YSkge1xuICBsZXQgZmV0Y2hlciA9IHtcbiAgICBzdGF0ZTogXCJpZGxlXCIsXG4gICAgZm9ybU1ldGhvZDogdW5kZWZpbmVkLFxuICAgIGZvcm1BY3Rpb246IHVuZGVmaW5lZCxcbiAgICBmb3JtRW5jVHlwZTogdW5kZWZpbmVkLFxuICAgIGZvcm1EYXRhOiB1bmRlZmluZWQsXG4gICAganNvbjogdW5kZWZpbmVkLFxuICAgIHRleHQ6IHVuZGVmaW5lZCxcbiAgICBkYXRhXG4gIH07XG4gIHJldHVybiBmZXRjaGVyO1xufVxuZnVuY3Rpb24gcmVzdG9yZUFwcGxpZWRUcmFuc2l0aW9ucyhfd2luZG93LCB0cmFuc2l0aW9ucykge1xuICB0cnkge1xuICAgIGxldCBzZXNzaW9uUG9zaXRpb25zID0gX3dpbmRvdy5zZXNzaW9uU3RvcmFnZS5nZXRJdGVtKFRSQU5TSVRJT05TX1NUT1JBR0VfS0VZKTtcbiAgICBpZiAoc2Vzc2lvblBvc2l0aW9ucykge1xuICAgICAgbGV0IGpzb24gPSBKU09OLnBhcnNlKHNlc3Npb25Qb3NpdGlvbnMpO1xuICAgICAgZm9yIChsZXQgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGpzb24gfHwge30pKSB7XG4gICAgICAgIGlmICh2ICYmIEFycmF5LmlzQXJyYXkodikpIHtcbiAgICAgICAgICB0cmFuc2l0aW9ucy5zZXQoaywgbmV3IFNldCh2IHx8IFtdKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAvLyBuby1vcCwgdXNlIGRlZmF1bHQgZW1wdHkgb2JqZWN0XG4gIH1cbn1cbmZ1bmN0aW9uIHBlcnNpc3RBcHBsaWVkVHJhbnNpdGlvbnMoX3dpbmRvdywgdHJhbnNpdGlvbnMpIHtcbiAgaWYgKHRyYW5zaXRpb25zLnNpemUgPiAwKSB7XG4gICAgbGV0IGpzb24gPSB7fTtcbiAgICBmb3IgKGxldCBbaywgdl0gb2YgdHJhbnNpdGlvbnMpIHtcbiAgICAgIGpzb25ba10gPSBbLi4udl07XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBfd2luZG93LnNlc3Npb25TdG9yYWdlLnNldEl0ZW0oVFJBTlNJVElPTlNfU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KGpzb24pKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgd2FybmluZyhmYWxzZSwgXCJGYWlsZWQgdG8gc2F2ZSBhcHBsaWVkIHZpZXcgdHJhbnNpdGlvbnMgaW4gc2Vzc2lvblN0b3JhZ2UgKFwiICsgZXJyb3IgKyBcIikuXCIpO1xuICAgIH1cbiAgfVxufVxuLy8jZW5kcmVnaW9uXG5cbmV4cG9ydCB7IEFib3J0ZWREZWZlcnJlZEVycm9yLCBBY3Rpb24sIElETEVfQkxPQ0tFUiwgSURMRV9GRVRDSEVSLCBJRExFX05BVklHQVRJT04sIFVOU0FGRV9ERUZFUlJFRF9TWU1CT0wsIERlZmVycmVkRGF0YSBhcyBVTlNBRkVfRGVmZXJyZWREYXRhLCBFcnJvclJlc3BvbnNlSW1wbCBhcyBVTlNBRkVfRXJyb3JSZXNwb25zZUltcGwsIGNvbnZlcnRSb3V0ZU1hdGNoVG9VaU1hdGNoIGFzIFVOU0FGRV9jb252ZXJ0Um91dGVNYXRjaFRvVWlNYXRjaCwgY29udmVydFJvdXRlc1RvRGF0YVJvdXRlcyBhcyBVTlNBRkVfY29udmVydFJvdXRlc1RvRGF0YVJvdXRlcywgZGVjb2RlUGF0aCBhcyBVTlNBRkVfZGVjb2RlUGF0aCwgZ2V0UmVzb2x2ZVRvTWF0Y2hlcyBhcyBVTlNBRkVfZ2V0UmVzb2x2ZVRvTWF0Y2hlcywgaW52YXJpYW50IGFzIFVOU0FGRV9pbnZhcmlhbnQsIHdhcm5pbmcgYXMgVU5TQUZFX3dhcm5pbmcsIGNyZWF0ZUJyb3dzZXJIaXN0b3J5LCBjcmVhdGVIYXNoSGlzdG9yeSwgY3JlYXRlTWVtb3J5SGlzdG9yeSwgY3JlYXRlUGF0aCwgY3JlYXRlUm91dGVyLCBjcmVhdGVTdGF0aWNIYW5kbGVyLCBkYXRhLCBkZWZlciwgZ2VuZXJhdGVQYXRoLCBnZXRTdGF0aWNDb250ZXh0RnJvbUVycm9yLCBnZXRUb1BhdGhuYW1lLCBpc0RhdGFXaXRoUmVzcG9uc2VJbml0LCBpc0RlZmVycmVkRGF0YSwgaXNSb3V0ZUVycm9yUmVzcG9uc2UsIGpvaW5QYXRocywganNvbiwgbWF0Y2hQYXRoLCBtYXRjaFJvdXRlcywgbm9ybWFsaXplUGF0aG5hbWUsIHBhcnNlUGF0aCwgcmVkaXJlY3QsIHJlZGlyZWN0RG9jdW1lbnQsIHJlcGxhY2UsIHJlc29sdmVQYXRoLCByZXNvbHZlVG8sIHN0cmlwQmFzZW5hbWUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlci5qcy5tYXBcbiIsIi8qKlxuICogUmVhY3QgUm91dGVyIHY2LjMwLjRcbiAqXG4gKiBDb3B5cmlnaHQgKGMpIFJlbWl4IFNvZnR3YXJlIEluYy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UubWQgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqXG4gKiBAbGljZW5zZSBNSVRcbiAqL1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVU5TQUZFX2ludmFyaWFudCwgam9pblBhdGhzLCBtYXRjaFBhdGgsIFVOU0FGRV9kZWNvZGVQYXRoLCBVTlNBRkVfZ2V0UmVzb2x2ZVRvTWF0Y2hlcywgVU5TQUZFX3dhcm5pbmcsIHJlc29sdmVUbywgcGFyc2VQYXRoLCBtYXRjaFJvdXRlcywgQWN0aW9uLCBVTlNBRkVfY29udmVydFJvdXRlTWF0Y2hUb1VpTWF0Y2gsIHN0cmlwQmFzZW5hbWUsIElETEVfQkxPQ0tFUiwgaXNSb3V0ZUVycm9yUmVzcG9uc2UsIGNyZWF0ZU1lbW9yeUhpc3RvcnksIEFib3J0ZWREZWZlcnJlZEVycm9yLCBjcmVhdGVSb3V0ZXIgfSBmcm9tICdAcmVtaXgtcnVuL3JvdXRlcic7XG5leHBvcnQgeyBBYm9ydGVkRGVmZXJyZWRFcnJvciwgQWN0aW9uIGFzIE5hdmlnYXRpb25UeXBlLCBjcmVhdGVQYXRoLCBkZWZlciwgZ2VuZXJhdGVQYXRoLCBpc1JvdXRlRXJyb3JSZXNwb25zZSwganNvbiwgbWF0Y2hQYXRoLCBtYXRjaFJvdXRlcywgcGFyc2VQYXRoLCByZWRpcmVjdCwgcmVkaXJlY3REb2N1bWVudCwgcmVwbGFjZSwgcmVzb2x2ZVBhdGggfSBmcm9tICdAcmVtaXgtcnVuL3JvdXRlcic7XG5cbmZ1bmN0aW9uIF9leHRlbmRzKCkge1xuICByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikge1xuICAgIGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7XG4gICAgICB2YXIgdCA9IGFyZ3VtZW50c1tlXTtcbiAgICAgIGZvciAodmFyIHIgaW4gdCkgKHt9KS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHQsIHIpICYmIChuW3JdID0gdFtyXSk7XG4gICAgfVxuICAgIHJldHVybiBuO1xuICB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpO1xufVxuXG4vLyBDcmVhdGUgcmVhY3Qtc3BlY2lmaWMgdHlwZXMgZnJvbSB0aGUgYWdub3N0aWMgdHlwZXMgaW4gQHJlbWl4LXJ1bi9yb3V0ZXIgdG9cbi8vIGV4cG9ydCBmcm9tIHJlYWN0LXJvdXRlclxuXG5jb25zdCBEYXRhUm91dGVyQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBEYXRhUm91dGVyQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRGF0YVJvdXRlclwiO1xufVxuY29uc3QgRGF0YVJvdXRlclN0YXRlQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBEYXRhUm91dGVyU3RhdGVDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJEYXRhUm91dGVyU3RhdGVcIjtcbn1cbmNvbnN0IEF3YWl0Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBBd2FpdENvbnRleHQuZGlzcGxheU5hbWUgPSBcIkF3YWl0XCI7XG59XG5cbi8qKlxuICogQSBOYXZpZ2F0b3IgaXMgYSBcImxvY2F0aW9uIGNoYW5nZXJcIjsgaXQncyBob3cgeW91IGdldCB0byBkaWZmZXJlbnQgbG9jYXRpb25zLlxuICpcbiAqIEV2ZXJ5IGhpc3RvcnkgaW5zdGFuY2UgY29uZm9ybXMgdG8gdGhlIE5hdmlnYXRvciBpbnRlcmZhY2UsIGJ1dCB0aGVcbiAqIGRpc3RpbmN0aW9uIGlzIHVzZWZ1bCBwcmltYXJpbHkgd2hlbiBpdCBjb21lcyB0byB0aGUgbG93LWxldmVsIGA8Um91dGVyPmAgQVBJXG4gKiB3aGVyZSBib3RoIHRoZSBsb2NhdGlvbiBhbmQgYSBuYXZpZ2F0b3IgbXVzdCBiZSBwcm92aWRlZCBzZXBhcmF0ZWx5IGluIG9yZGVyXG4gKiB0byBhdm9pZCBcInRlYXJpbmdcIiB0aGF0IG1heSBvY2N1ciBpbiBhIHN1c3BlbnNlLWVuYWJsZWQgYXBwIGlmIHRoZSBhY3Rpb25cbiAqIGFuZC9vciBsb2NhdGlvbiB3ZXJlIHRvIGJlIHJlYWQgZGlyZWN0bHkgZnJvbSB0aGUgaGlzdG9yeSBpbnN0YW5jZS5cbiAqL1xuXG5jb25zdCBOYXZpZ2F0aW9uQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBOYXZpZ2F0aW9uQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiTmF2aWdhdGlvblwiO1xufVxuY29uc3QgTG9jYXRpb25Db250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gIExvY2F0aW9uQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiTG9jYXRpb25cIjtcbn1cbmNvbnN0IFJvdXRlQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHtcbiAgb3V0bGV0OiBudWxsLFxuICBtYXRjaGVzOiBbXSxcbiAgaXNEYXRhUm91dGU6IGZhbHNlXG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgUm91dGVDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJSb3V0ZVwiO1xufVxuY29uc3QgUm91dGVFcnJvckNvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgUm91dGVFcnJvckNvbnRleHQuZGlzcGxheU5hbWUgPSBcIlJvdXRlRXJyb3JcIjtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBmdWxsIGhyZWYgZm9yIHRoZSBnaXZlbiBcInRvXCIgdmFsdWUuIFRoaXMgaXMgdXNlZnVsIGZvciBidWlsZGluZ1xuICogY3VzdG9tIGxpbmtzIHRoYXQgYXJlIGFsc28gYWNjZXNzaWJsZSBhbmQgcHJlc2VydmUgcmlnaHQtY2xpY2sgYmVoYXZpb3IuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9ob29rcy91c2UtaHJlZlxuICovXG5mdW5jdGlvbiB1c2VIcmVmKHRvLCBfdGVtcCkge1xuICBsZXQge1xuICAgIHJlbGF0aXZlXG4gIH0gPSBfdGVtcCA9PT0gdm9pZCAwID8ge30gOiBfdGVtcDtcbiAgIXVzZUluUm91dGVyQ29udGV4dCgpID8gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX2ludmFyaWFudChmYWxzZSwgLy8gVE9ETzogVGhpcyBlcnJvciBpcyBwcm9iYWJseSBiZWNhdXNlIHRoZXkgc29tZWhvdyBoYXZlIDIgdmVyc2lvbnMgb2YgdGhlXG4gIC8vIHJvdXRlciBsb2FkZWQuIFdlIGNhbiBoZWxwIHRoZW0gdW5kZXJzdGFuZCBob3cgdG8gYXZvaWQgdGhhdC5cbiAgXCJ1c2VIcmVmKCkgbWF5IGJlIHVzZWQgb25seSBpbiB0aGUgY29udGV4dCBvZiBhIDxSb3V0ZXI+IGNvbXBvbmVudC5cIikgOiBVTlNBRkVfaW52YXJpYW50KGZhbHNlKSA6IHZvaWQgMDtcbiAgbGV0IHtcbiAgICBiYXNlbmFtZSxcbiAgICBuYXZpZ2F0b3JcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoTmF2aWdhdGlvbkNvbnRleHQpO1xuICBsZXQge1xuICAgIGhhc2gsXG4gICAgcGF0aG5hbWUsXG4gICAgc2VhcmNoXG4gIH0gPSB1c2VSZXNvbHZlZFBhdGgodG8sIHtcbiAgICByZWxhdGl2ZVxuICB9KTtcbiAgbGV0IGpvaW5lZFBhdGhuYW1lID0gcGF0aG5hbWU7XG5cbiAgLy8gSWYgd2UncmUgb3BlcmF0aW5nIHdpdGhpbiBhIGJhc2VuYW1lLCBwcmVwZW5kIGl0IHRvIHRoZSBwYXRobmFtZSBwcmlvclxuICAvLyB0byBjcmVhdGluZyB0aGUgaHJlZi4gIElmIHRoaXMgaXMgYSByb290IG5hdmlnYXRpb24sIHRoZW4ganVzdCB1c2UgdGhlIHJhd1xuICAvLyBiYXNlbmFtZSB3aGljaCBhbGxvd3MgdGhlIGJhc2VuYW1lIHRvIGhhdmUgZnVsbCBjb250cm9sIG92ZXIgdGhlIHByZXNlbmNlXG4gIC8vIG9mIGEgdHJhaWxpbmcgc2xhc2ggb24gcm9vdCBsaW5rc1xuICBpZiAoYmFzZW5hbWUgIT09IFwiL1wiKSB7XG4gICAgam9pbmVkUGF0aG5hbWUgPSBwYXRobmFtZSA9PT0gXCIvXCIgPyBiYXNlbmFtZSA6IGpvaW5QYXRocyhbYmFzZW5hbWUsIHBhdGhuYW1lXSk7XG4gIH1cbiAgcmV0dXJuIG5hdmlnYXRvci5jcmVhdGVIcmVmKHtcbiAgICBwYXRobmFtZTogam9pbmVkUGF0aG5hbWUsXG4gICAgc2VhcmNoLFxuICAgIGhhc2hcbiAgfSk7XG59XG5cbi8qKlxuICogUmV0dXJucyB0cnVlIGlmIHRoaXMgY29tcG9uZW50IGlzIGEgZGVzY2VuZGFudCBvZiBhIGA8Um91dGVyPmAuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9ob29rcy91c2UtaW4tcm91dGVyLWNvbnRleHRcbiAqL1xuZnVuY3Rpb24gdXNlSW5Sb3V0ZXJDb250ZXh0KCkge1xuICByZXR1cm4gUmVhY3QudXNlQ29udGV4dChMb2NhdGlvbkNvbnRleHQpICE9IG51bGw7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgY3VycmVudCBsb2NhdGlvbiBvYmplY3QsIHdoaWNoIHJlcHJlc2VudHMgdGhlIGN1cnJlbnQgVVJMIGluIHdlYlxuICogYnJvd3NlcnMuXG4gKlxuICogTm90ZTogSWYgeW91J3JlIHVzaW5nIHRoaXMgaXQgbWF5IG1lYW4geW91J3JlIGRvaW5nIHNvbWUgb2YgeW91ciBvd25cbiAqIFwicm91dGluZ1wiIGluIHlvdXIgYXBwLCBhbmQgd2UnZCBsaWtlIHRvIGtub3cgd2hhdCB5b3VyIHVzZSBjYXNlIGlzLiBXZSBtYXlcbiAqIGJlIGFibGUgdG8gcHJvdmlkZSBzb21ldGhpbmcgaGlnaGVyLWxldmVsIHRvIGJldHRlciBzdWl0IHlvdXIgbmVlZHMuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9ob29rcy91c2UtbG9jYXRpb25cbiAqL1xuZnVuY3Rpb24gdXNlTG9jYXRpb24oKSB7XG4gICF1c2VJblJvdXRlckNvbnRleHQoKSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIC8vIFRPRE86IFRoaXMgZXJyb3IgaXMgcHJvYmFibHkgYmVjYXVzZSB0aGV5IHNvbWVob3cgaGF2ZSAyIHZlcnNpb25zIG9mIHRoZVxuICAvLyByb3V0ZXIgbG9hZGVkLiBXZSBjYW4gaGVscCB0aGVtIHVuZGVyc3RhbmQgaG93IHRvIGF2b2lkIHRoYXQuXG4gIFwidXNlTG9jYXRpb24oKSBtYXkgYmUgdXNlZCBvbmx5IGluIHRoZSBjb250ZXh0IG9mIGEgPFJvdXRlcj4gY29tcG9uZW50LlwiKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICByZXR1cm4gUmVhY3QudXNlQ29udGV4dChMb2NhdGlvbkNvbnRleHQpLmxvY2F0aW9uO1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGN1cnJlbnQgbmF2aWdhdGlvbiBhY3Rpb24gd2hpY2ggZGVzY3JpYmVzIGhvdyB0aGUgcm91dGVyIGNhbWUgdG9cbiAqIHRoZSBjdXJyZW50IGxvY2F0aW9uLCBlaXRoZXIgYnkgYSBwb3AsIHB1c2gsIG9yIHJlcGxhY2Ugb24gdGhlIGhpc3Rvcnkgc3RhY2suXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9ob29rcy91c2UtbmF2aWdhdGlvbi10eXBlXG4gKi9cbmZ1bmN0aW9uIHVzZU5hdmlnYXRpb25UeXBlKCkge1xuICByZXR1cm4gUmVhY3QudXNlQ29udGV4dChMb2NhdGlvbkNvbnRleHQpLm5hdmlnYXRpb25UeXBlO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSBQYXRoTWF0Y2ggb2JqZWN0IGlmIHRoZSBnaXZlbiBwYXR0ZXJuIG1hdGNoZXMgdGhlIGN1cnJlbnQgVVJMLlxuICogVGhpcyBpcyB1c2VmdWwgZm9yIGNvbXBvbmVudHMgdGhhdCBuZWVkIHRvIGtub3cgXCJhY3RpdmVcIiBzdGF0ZSwgZS5nLlxuICogYDxOYXZMaW5rPmAuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9ob29rcy91c2UtbWF0Y2hcbiAqL1xuZnVuY3Rpb24gdXNlTWF0Y2gocGF0dGVybikge1xuICAhdXNlSW5Sb3V0ZXJDb250ZXh0KCkgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCAvLyBUT0RPOiBUaGlzIGVycm9yIGlzIHByb2JhYmx5IGJlY2F1c2UgdGhleSBzb21laG93IGhhdmUgMiB2ZXJzaW9ucyBvZiB0aGVcbiAgLy8gcm91dGVyIGxvYWRlZC4gV2UgY2FuIGhlbHAgdGhlbSB1bmRlcnN0YW5kIGhvdyB0byBhdm9pZCB0aGF0LlxuICBcInVzZU1hdGNoKCkgbWF5IGJlIHVzZWQgb25seSBpbiB0aGUgY29udGV4dCBvZiBhIDxSb3V0ZXI+IGNvbXBvbmVudC5cIikgOiBVTlNBRkVfaW52YXJpYW50KGZhbHNlKSA6IHZvaWQgMDtcbiAgbGV0IHtcbiAgICBwYXRobmFtZVxuICB9ID0gdXNlTG9jYXRpb24oKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gbWF0Y2hQYXRoKHBhdHRlcm4sIFVOU0FGRV9kZWNvZGVQYXRoKHBhdGhuYW1lKSksIFtwYXRobmFtZSwgcGF0dGVybl0pO1xufVxuXG4vKipcbiAqIFRoZSBpbnRlcmZhY2UgZm9yIHRoZSBuYXZpZ2F0ZSgpIGZ1bmN0aW9uIHJldHVybmVkIGZyb20gdXNlTmF2aWdhdGUoKS5cbiAqL1xuXG5jb25zdCBuYXZpZ2F0ZUVmZmVjdFdhcm5pbmcgPSBcIllvdSBzaG91bGQgY2FsbCBuYXZpZ2F0ZSgpIGluIGEgUmVhY3QudXNlRWZmZWN0KCksIG5vdCB3aGVuIFwiICsgXCJ5b3VyIGNvbXBvbmVudCBpcyBmaXJzdCByZW5kZXJlZC5cIjtcblxuLy8gTXV0ZSB3YXJuaW5ncyBmb3IgY2FsbHMgdG8gdXNlTmF2aWdhdGUgaW4gU1NSIGVudmlyb25tZW50c1xuZnVuY3Rpb24gdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdChjYikge1xuICBsZXQgaXNTdGF0aWMgPSBSZWFjdC51c2VDb250ZXh0KE5hdmlnYXRpb25Db250ZXh0KS5zdGF0aWM7XG4gIGlmICghaXNTdGF0aWMpIHtcbiAgICAvLyBXZSBzaG91bGQgYmUgYWJsZSB0byBnZXQgcmlkIG9mIHRoaXMgb25jZSByZWFjdCAxOC4zIGlzIHJlbGVhc2VkXG4gICAgLy8gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2svcmVhY3QvcHVsbC8yNjM5NVxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICAgIFJlYWN0LnVzZUxheW91dEVmZmVjdChjYik7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFuIGltcGVyYXRpdmUgbWV0aG9kIGZvciBjaGFuZ2luZyB0aGUgbG9jYXRpb24uIFVzZWQgYnkgYDxMaW5rPmBzLCBidXRcbiAqIG1heSBhbHNvIGJlIHVzZWQgYnkgb3RoZXIgZWxlbWVudHMgdG8gY2hhbmdlIHRoZSBsb2NhdGlvbi5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vcmVhY3Ryb3V0ZXIuY29tL3Y2L2hvb2tzL3VzZS1uYXZpZ2F0ZVxuICovXG5mdW5jdGlvbiB1c2VOYXZpZ2F0ZSgpIHtcbiAgbGV0IHtcbiAgICBpc0RhdGFSb3V0ZVxuICB9ID0gUmVhY3QudXNlQ29udGV4dChSb3V0ZUNvbnRleHQpO1xuICAvLyBDb25kaXRpb25hbCB1c2FnZSBpcyBPSyBoZXJlIGJlY2F1c2UgdGhlIHVzYWdlIG9mIGEgZGF0YSByb3V0ZXIgaXMgc3RhdGljXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICByZXR1cm4gaXNEYXRhUm91dGUgPyB1c2VOYXZpZ2F0ZVN0YWJsZSgpIDogdXNlTmF2aWdhdGVVbnN0YWJsZSgpO1xufVxuZnVuY3Rpb24gdXNlTmF2aWdhdGVVbnN0YWJsZSgpIHtcbiAgIXVzZUluUm91dGVyQ29udGV4dCgpID8gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX2ludmFyaWFudChmYWxzZSwgLy8gVE9ETzogVGhpcyBlcnJvciBpcyBwcm9iYWJseSBiZWNhdXNlIHRoZXkgc29tZWhvdyBoYXZlIDIgdmVyc2lvbnMgb2YgdGhlXG4gIC8vIHJvdXRlciBsb2FkZWQuIFdlIGNhbiBoZWxwIHRoZW0gdW5kZXJzdGFuZCBob3cgdG8gYXZvaWQgdGhhdC5cbiAgXCJ1c2VOYXZpZ2F0ZSgpIG1heSBiZSB1c2VkIG9ubHkgaW4gdGhlIGNvbnRleHQgb2YgYSA8Um91dGVyPiBjb21wb25lbnQuXCIpIDogVU5TQUZFX2ludmFyaWFudChmYWxzZSkgOiB2b2lkIDA7XG4gIGxldCBkYXRhUm91dGVyQ29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoRGF0YVJvdXRlckNvbnRleHQpO1xuICBsZXQge1xuICAgIGJhc2VuYW1lLFxuICAgIGZ1dHVyZSxcbiAgICBuYXZpZ2F0b3JcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoTmF2aWdhdGlvbkNvbnRleHQpO1xuICBsZXQge1xuICAgIG1hdGNoZXNcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoUm91dGVDb250ZXh0KTtcbiAgbGV0IHtcbiAgICBwYXRobmFtZTogbG9jYXRpb25QYXRobmFtZVxuICB9ID0gdXNlTG9jYXRpb24oKTtcbiAgbGV0IHJvdXRlUGF0aG5hbWVzSnNvbiA9IEpTT04uc3RyaW5naWZ5KFVOU0FGRV9nZXRSZXNvbHZlVG9NYXRjaGVzKG1hdGNoZXMsIGZ1dHVyZS52N19yZWxhdGl2ZVNwbGF0UGF0aCkpO1xuICBsZXQgYWN0aXZlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgYWN0aXZlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICB9KTtcbiAgbGV0IG5hdmlnYXRlID0gUmVhY3QudXNlQ2FsbGJhY2soZnVuY3Rpb24gKHRvLCBvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgICAgb3B0aW9ucyA9IHt9O1xuICAgIH1cbiAgICBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfd2FybmluZyhhY3RpdmVSZWYuY3VycmVudCwgbmF2aWdhdGVFZmZlY3RXYXJuaW5nKSA6IHZvaWQgMDtcblxuICAgIC8vIFNob3J0IGNpcmN1aXQgaGVyZSBzaW5jZSBpZiB0aGlzIGhhcHBlbnMgb24gZmlyc3QgcmVuZGVyIHRoZSBuYXZpZ2F0ZVxuICAgIC8vIGlzIHVzZWxlc3MgYmVjYXVzZSB3ZSBoYXZlbid0IHdpcmVkIHVwIG91ciBoaXN0b3J5IGxpc3RlbmVyIHlldFxuICAgIGlmICghYWN0aXZlUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBpZiAodHlwZW9mIHRvID09PSBcIm51bWJlclwiKSB7XG4gICAgICBuYXZpZ2F0b3IuZ28odG8pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgcGF0aCA9IHJlc29sdmVUbyh0bywgSlNPTi5wYXJzZShyb3V0ZVBhdGhuYW1lc0pzb24pLCBsb2NhdGlvblBhdGhuYW1lLCBvcHRpb25zLnJlbGF0aXZlID09PSBcInBhdGhcIik7XG5cbiAgICAvLyBJZiB3ZSdyZSBvcGVyYXRpbmcgd2l0aGluIGEgYmFzZW5hbWUsIHByZXBlbmQgaXQgdG8gdGhlIHBhdGhuYW1lIHByaW9yXG4gICAgLy8gdG8gaGFuZGluZyBvZmYgdG8gaGlzdG9yeSAoYnV0IG9ubHkgaWYgd2UncmUgbm90IGluIGEgZGF0YSByb3V0ZXIsXG4gICAgLy8gb3RoZXJ3aXNlIGl0J2xsIHByZXBlbmQgdGhlIGJhc2VuYW1lIGluc2lkZSBvZiB0aGUgcm91dGVyKS5cbiAgICAvLyBJZiB0aGlzIGlzIGEgcm9vdCBuYXZpZ2F0aW9uLCB0aGVuIHdlIG5hdmlnYXRlIHRvIHRoZSByYXcgYmFzZW5hbWVcbiAgICAvLyB3aGljaCBhbGxvd3MgdGhlIGJhc2VuYW1lIHRvIGhhdmUgZnVsbCBjb250cm9sIG92ZXIgdGhlIHByZXNlbmNlIG9mIGFcbiAgICAvLyB0cmFpbGluZyBzbGFzaCBvbiByb290IGxpbmtzXG4gICAgaWYgKGRhdGFSb3V0ZXJDb250ZXh0ID09IG51bGwgJiYgYmFzZW5hbWUgIT09IFwiL1wiKSB7XG4gICAgICBwYXRoLnBhdGhuYW1lID0gcGF0aC5wYXRobmFtZSA9PT0gXCIvXCIgPyBiYXNlbmFtZSA6IGpvaW5QYXRocyhbYmFzZW5hbWUsIHBhdGgucGF0aG5hbWVdKTtcbiAgICB9XG4gICAgKCEhb3B0aW9ucy5yZXBsYWNlID8gbmF2aWdhdG9yLnJlcGxhY2UgOiBuYXZpZ2F0b3IucHVzaCkocGF0aCwgb3B0aW9ucy5zdGF0ZSwgb3B0aW9ucyk7XG4gIH0sIFtiYXNlbmFtZSwgbmF2aWdhdG9yLCByb3V0ZVBhdGhuYW1lc0pzb24sIGxvY2F0aW9uUGF0aG5hbWUsIGRhdGFSb3V0ZXJDb250ZXh0XSk7XG4gIHJldHVybiBuYXZpZ2F0ZTtcbn1cbmNvbnN0IE91dGxldENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBjb250ZXh0IChpZiBwcm92aWRlZCkgZm9yIHRoZSBjaGlsZCByb3V0ZSBhdCB0aGlzIGxldmVsIG9mIHRoZSByb3V0ZVxuICogaGllcmFyY2h5LlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9ob29rcy91c2Utb3V0bGV0LWNvbnRleHRcbiAqL1xuZnVuY3Rpb24gdXNlT3V0bGV0Q29udGV4dCgpIHtcbiAgcmV0dXJuIFJlYWN0LnVzZUNvbnRleHQoT3V0bGV0Q29udGV4dCk7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWxlbWVudCBmb3IgdGhlIGNoaWxkIHJvdXRlIGF0IHRoaXMgbGV2ZWwgb2YgdGhlIHJvdXRlXG4gKiBoaWVyYXJjaHkuIFVzZWQgaW50ZXJuYWxseSBieSBgPE91dGxldD5gIHRvIHJlbmRlciBjaGlsZCByb3V0ZXMuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9ob29rcy91c2Utb3V0bGV0XG4gKi9cbmZ1bmN0aW9uIHVzZU91dGxldChjb250ZXh0KSB7XG4gIGxldCBvdXRsZXQgPSBSZWFjdC51c2VDb250ZXh0KFJvdXRlQ29udGV4dCkub3V0bGV0O1xuICBpZiAob3V0bGV0KSB7XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KE91dGxldENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICAgIHZhbHVlOiBjb250ZXh0XG4gICAgfSwgb3V0bGV0KTtcbiAgfVxuICByZXR1cm4gb3V0bGV0O1xufVxuXG4vKipcbiAqIFJldHVybnMgYW4gb2JqZWN0IG9mIGtleS92YWx1ZSBwYWlycyBvZiB0aGUgZHluYW1pYyBwYXJhbXMgZnJvbSB0aGUgY3VycmVudFxuICogVVJMIHRoYXQgd2VyZSBtYXRjaGVkIGJ5IHRoZSByb3V0ZSBwYXRoLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9yZWFjdHJvdXRlci5jb20vdjYvaG9va3MvdXNlLXBhcmFtc1xuICovXG5mdW5jdGlvbiB1c2VQYXJhbXMoKSB7XG4gIGxldCB7XG4gICAgbWF0Y2hlc1xuICB9ID0gUmVhY3QudXNlQ29udGV4dChSb3V0ZUNvbnRleHQpO1xuICBsZXQgcm91dGVNYXRjaCA9IG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXTtcbiAgcmV0dXJuIHJvdXRlTWF0Y2ggPyByb3V0ZU1hdGNoLnBhcmFtcyA6IHt9O1xufVxuXG4vKipcbiAqIFJlc29sdmVzIHRoZSBwYXRobmFtZSBvZiB0aGUgZ2l2ZW4gYHRvYCB2YWx1ZSBhZ2FpbnN0IHRoZSBjdXJyZW50IGxvY2F0aW9uLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9yZWFjdHJvdXRlci5jb20vdjYvaG9va3MvdXNlLXJlc29sdmVkLXBhdGhcbiAqL1xuZnVuY3Rpb24gdXNlUmVzb2x2ZWRQYXRoKHRvLCBfdGVtcDIpIHtcbiAgbGV0IHtcbiAgICByZWxhdGl2ZVxuICB9ID0gX3RlbXAyID09PSB2b2lkIDAgPyB7fSA6IF90ZW1wMjtcbiAgbGV0IHtcbiAgICBmdXR1cmVcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoTmF2aWdhdGlvbkNvbnRleHQpO1xuICBsZXQge1xuICAgIG1hdGNoZXNcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoUm91dGVDb250ZXh0KTtcbiAgbGV0IHtcbiAgICBwYXRobmFtZTogbG9jYXRpb25QYXRobmFtZVxuICB9ID0gdXNlTG9jYXRpb24oKTtcbiAgbGV0IHJvdXRlUGF0aG5hbWVzSnNvbiA9IEpTT04uc3RyaW5naWZ5KFVOU0FGRV9nZXRSZXNvbHZlVG9NYXRjaGVzKG1hdGNoZXMsIGZ1dHVyZS52N19yZWxhdGl2ZVNwbGF0UGF0aCkpO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiByZXNvbHZlVG8odG8sIEpTT04ucGFyc2Uocm91dGVQYXRobmFtZXNKc29uKSwgbG9jYXRpb25QYXRobmFtZSwgcmVsYXRpdmUgPT09IFwicGF0aFwiKSwgW3RvLCByb3V0ZVBhdGhuYW1lc0pzb24sIGxvY2F0aW9uUGF0aG5hbWUsIHJlbGF0aXZlXSk7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZWxlbWVudCBvZiB0aGUgcm91dGUgdGhhdCBtYXRjaGVkIHRoZSBjdXJyZW50IGxvY2F0aW9uLCBwcmVwYXJlZFxuICogd2l0aCB0aGUgY29ycmVjdCBjb250ZXh0IHRvIHJlbmRlciB0aGUgcmVtYWluZGVyIG9mIHRoZSByb3V0ZSB0cmVlLiBSb3V0ZVxuICogZWxlbWVudHMgaW4gdGhlIHRyZWUgbXVzdCByZW5kZXIgYW4gYDxPdXRsZXQ+YCB0byByZW5kZXIgdGhlaXIgY2hpbGQgcm91dGUnc1xuICogZWxlbWVudC5cbiAqXG4gKiBAc2VlIGh0dHBzOi8vcmVhY3Ryb3V0ZXIuY29tL3Y2L2hvb2tzL3VzZS1yb3V0ZXNcbiAqL1xuZnVuY3Rpb24gdXNlUm91dGVzKHJvdXRlcywgbG9jYXRpb25BcmcpIHtcbiAgcmV0dXJuIHVzZVJvdXRlc0ltcGwocm91dGVzLCBsb2NhdGlvbkFyZyk7XG59XG5cbi8vIEludGVybmFsIGltcGxlbWVudGF0aW9uIHdpdGggYWNjZXB0IG9wdGlvbmFsIHBhcmFtIGZvciBSb3V0ZXJQcm92aWRlciB1c2FnZVxuZnVuY3Rpb24gdXNlUm91dGVzSW1wbChyb3V0ZXMsIGxvY2F0aW9uQXJnLCBkYXRhUm91dGVyU3RhdGUsIGZ1dHVyZSkge1xuICAhdXNlSW5Sb3V0ZXJDb250ZXh0KCkgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCAvLyBUT0RPOiBUaGlzIGVycm9yIGlzIHByb2JhYmx5IGJlY2F1c2UgdGhleSBzb21laG93IGhhdmUgMiB2ZXJzaW9ucyBvZiB0aGVcbiAgLy8gcm91dGVyIGxvYWRlZC4gV2UgY2FuIGhlbHAgdGhlbSB1bmRlcnN0YW5kIGhvdyB0byBhdm9pZCB0aGF0LlxuICBcInVzZVJvdXRlcygpIG1heSBiZSB1c2VkIG9ubHkgaW4gdGhlIGNvbnRleHQgb2YgYSA8Um91dGVyPiBjb21wb25lbnQuXCIpIDogVU5TQUZFX2ludmFyaWFudChmYWxzZSkgOiB2b2lkIDA7XG4gIGxldCB7XG4gICAgbmF2aWdhdG9yXG4gIH0gPSBSZWFjdC51c2VDb250ZXh0KE5hdmlnYXRpb25Db250ZXh0KTtcbiAgbGV0IHtcbiAgICBtYXRjaGVzOiBwYXJlbnRNYXRjaGVzXG4gIH0gPSBSZWFjdC51c2VDb250ZXh0KFJvdXRlQ29udGV4dCk7XG4gIGxldCByb3V0ZU1hdGNoID0gcGFyZW50TWF0Y2hlc1twYXJlbnRNYXRjaGVzLmxlbmd0aCAtIDFdO1xuICBsZXQgcGFyZW50UGFyYW1zID0gcm91dGVNYXRjaCA/IHJvdXRlTWF0Y2gucGFyYW1zIDoge307XG4gIGxldCBwYXJlbnRQYXRobmFtZSA9IHJvdXRlTWF0Y2ggPyByb3V0ZU1hdGNoLnBhdGhuYW1lIDogXCIvXCI7XG4gIGxldCBwYXJlbnRQYXRobmFtZUJhc2UgPSByb3V0ZU1hdGNoID8gcm91dGVNYXRjaC5wYXRobmFtZUJhc2UgOiBcIi9cIjtcbiAgbGV0IHBhcmVudFJvdXRlID0gcm91dGVNYXRjaCAmJiByb3V0ZU1hdGNoLnJvdXRlO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgLy8gWW91IHdvbid0IGdldCBhIHdhcm5pbmcgYWJvdXQgMiBkaWZmZXJlbnQgPFJvdXRlcz4gdW5kZXIgYSA8Um91dGU+XG4gICAgLy8gd2l0aG91dCBhIHRyYWlsaW5nICosIGJ1dCB0aGlzIGlzIGEgYmVzdC1lZmZvcnQgd2FybmluZyBhbnl3YXkgc2luY2Ugd2VcbiAgICAvLyBjYW5ub3QgZXZlbiBnaXZlIHRoZSB3YXJuaW5nIHVubGVzcyB0aGV5IGxhbmQgYXQgdGhlIHBhcmVudCByb3V0ZS5cbiAgICAvL1xuICAgIC8vIEV4YW1wbGU6XG4gICAgLy9cbiAgICAvLyA8Um91dGVzPlxuICAgIC8vICAgey8qIFRoaXMgcm91dGUgcGF0aCBNVVNUIGVuZCB3aXRoIC8qIGJlY2F1c2Ugb3RoZXJ3aXNlXG4gICAgLy8gICAgICAgaXQgd2lsbCBuZXZlciBtYXRjaCAvYmxvZy9wb3N0LzEyMyAqL31cbiAgICAvLyAgIDxSb3V0ZSBwYXRoPVwiYmxvZ1wiIGVsZW1lbnQ9ezxCbG9nIC8+fSAvPlxuICAgIC8vICAgPFJvdXRlIHBhdGg9XCJibG9nL2ZlZWRcIiBlbGVtZW50PXs8QmxvZ0ZlZWQgLz59IC8+XG4gICAgLy8gPC9Sb3V0ZXM+XG4gICAgLy9cbiAgICAvLyBmdW5jdGlvbiBCbG9nKCkge1xuICAgIC8vICAgcmV0dXJuIChcbiAgICAvLyAgICAgPFJvdXRlcz5cbiAgICAvLyAgICAgICA8Um91dGUgcGF0aD1cInBvc3QvOmlkXCIgZWxlbWVudD17PFBvc3QgLz59IC8+XG4gICAgLy8gICAgIDwvUm91dGVzPlxuICAgIC8vICAgKTtcbiAgICAvLyB9XG4gICAgbGV0IHBhcmVudFBhdGggPSBwYXJlbnRSb3V0ZSAmJiBwYXJlbnRSb3V0ZS5wYXRoIHx8IFwiXCI7XG4gICAgd2FybmluZ09uY2UocGFyZW50UGF0aG5hbWUsICFwYXJlbnRSb3V0ZSB8fCBwYXJlbnRQYXRoLmVuZHNXaXRoKFwiKlwiKSwgXCJZb3UgcmVuZGVyZWQgZGVzY2VuZGFudCA8Um91dGVzPiAob3IgY2FsbGVkIGB1c2VSb3V0ZXMoKWApIGF0IFwiICsgKFwiXFxcIlwiICsgcGFyZW50UGF0aG5hbWUgKyBcIlxcXCIgKHVuZGVyIDxSb3V0ZSBwYXRoPVxcXCJcIiArIHBhcmVudFBhdGggKyBcIlxcXCI+KSBidXQgdGhlIFwiKSArIFwicGFyZW50IHJvdXRlIHBhdGggaGFzIG5vIHRyYWlsaW5nIFxcXCIqXFxcIi4gVGhpcyBtZWFucyBpZiB5b3UgbmF2aWdhdGUgXCIgKyBcImRlZXBlciwgdGhlIHBhcmVudCB3b24ndCBtYXRjaCBhbnltb3JlIGFuZCB0aGVyZWZvcmUgdGhlIGNoaWxkIFwiICsgXCJyb3V0ZXMgd2lsbCBuZXZlciByZW5kZXIuXFxuXFxuXCIgKyAoXCJQbGVhc2UgY2hhbmdlIHRoZSBwYXJlbnQgPFJvdXRlIHBhdGg9XFxcIlwiICsgcGFyZW50UGF0aCArIFwiXFxcIj4gdG8gPFJvdXRlIFwiKSArIChcInBhdGg9XFxcIlwiICsgKHBhcmVudFBhdGggPT09IFwiL1wiID8gXCIqXCIgOiBwYXJlbnRQYXRoICsgXCIvKlwiKSArIFwiXFxcIj4uXCIpKTtcbiAgfVxuICBsZXQgbG9jYXRpb25Gcm9tQ29udGV4dCA9IHVzZUxvY2F0aW9uKCk7XG4gIGxldCBsb2NhdGlvbjtcbiAgaWYgKGxvY2F0aW9uQXJnKSB7XG4gICAgdmFyIF9wYXJzZWRMb2NhdGlvbkFyZyRwYTtcbiAgICBsZXQgcGFyc2VkTG9jYXRpb25BcmcgPSB0eXBlb2YgbG9jYXRpb25BcmcgPT09IFwic3RyaW5nXCIgPyBwYXJzZVBhdGgobG9jYXRpb25BcmcpIDogbG9jYXRpb25Bcmc7XG4gICAgIShwYXJlbnRQYXRobmFtZUJhc2UgPT09IFwiL1wiIHx8ICgoX3BhcnNlZExvY2F0aW9uQXJnJHBhID0gcGFyc2VkTG9jYXRpb25BcmcucGF0aG5hbWUpID09IG51bGwgPyB2b2lkIDAgOiBfcGFyc2VkTG9jYXRpb25BcmckcGEuc3RhcnRzV2l0aChwYXJlbnRQYXRobmFtZUJhc2UpKSkgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCBcIldoZW4gb3ZlcnJpZGluZyB0aGUgbG9jYXRpb24gdXNpbmcgYDxSb3V0ZXMgbG9jYXRpb24+YCBvciBgdXNlUm91dGVzKHJvdXRlcywgbG9jYXRpb24pYCwgXCIgKyBcInRoZSBsb2NhdGlvbiBwYXRobmFtZSBtdXN0IGJlZ2luIHdpdGggdGhlIHBvcnRpb24gb2YgdGhlIFVSTCBwYXRobmFtZSB0aGF0IHdhcyBcIiArIChcIm1hdGNoZWQgYnkgYWxsIHBhcmVudCByb3V0ZXMuIFRoZSBjdXJyZW50IHBhdGhuYW1lIGJhc2UgaXMgXFxcIlwiICsgcGFyZW50UGF0aG5hbWVCYXNlICsgXCJcXFwiIFwiKSArIChcImJ1dCBwYXRobmFtZSBcXFwiXCIgKyBwYXJzZWRMb2NhdGlvbkFyZy5wYXRobmFtZSArIFwiXFxcIiB3YXMgZ2l2ZW4gaW4gdGhlIGBsb2NhdGlvbmAgcHJvcC5cIikpIDogVU5TQUZFX2ludmFyaWFudChmYWxzZSkgOiB2b2lkIDA7XG4gICAgbG9jYXRpb24gPSBwYXJzZWRMb2NhdGlvbkFyZztcbiAgfSBlbHNlIHtcbiAgICBsb2NhdGlvbiA9IGxvY2F0aW9uRnJvbUNvbnRleHQ7XG4gIH1cbiAgbGV0IHBhdGhuYW1lID0gbG9jYXRpb24ucGF0aG5hbWUgfHwgXCIvXCI7XG4gIGxldCByZW1haW5pbmdQYXRobmFtZSA9IHBhdGhuYW1lO1xuICBpZiAocGFyZW50UGF0aG5hbWVCYXNlICE9PSBcIi9cIikge1xuICAgIC8vIERldGVybWluZSB0aGUgcmVtYWluaW5nIHBhdGhuYW1lIGJ5IHJlbW92aW5nIHRoZSAjIG9mIFVSTCBzZWdtZW50cyB0aGVcbiAgICAvLyBwYXJlbnRQYXRobmFtZUJhc2UgaGFzLCBpbnN0ZWFkIG9mIHJlbW92aW5nIGJhc2VkIG9uIGNoYXJhY3RlciBjb3VudC5cbiAgICAvLyBUaGlzIGlzIGJlY2F1c2Ugd2UgY2FuJ3QgZ3VhcmFudGVlIHRoYXQgaW5jb21pbmcvb3V0Z29pbmcgZW5jb2RpbmdzL1xuICAgIC8vIGRlY29kaW5ncyB3aWxsIG1hdGNoIGV4YWN0bHkuXG4gICAgLy8gV2UgZGVjb2RlIHBhdGhzIGJlZm9yZSBtYXRjaGluZyBvbiBhIHBlci1zZWdtZW50IGJhc2lzIHdpdGhcbiAgICAvLyBkZWNvZGVVUklDb21wb25lbnQoKSwgYnV0IHdlIHJlLWVuY29kZSBwYXRobmFtZXMgdmlhIGBuZXcgVVJMKClgIHNvIHRoZXlcbiAgICAvLyBtYXRjaCB3aGF0IGB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWVgIHdvdWxkIHJlZmxlY3QuICBUaG9zZSBkb24ndCAxMDAlXG4gICAgLy8gYWxpZ24gd2hlbiBpdCBjb21lcyB0byBlbmNvZGVkIFVSSSBjaGFyYWN0ZXJzIHN1Y2ggYXMgJSBhbmQgJi5cbiAgICAvL1xuICAgIC8vIFNvIHdlIG1heSBlbmQgdXAgd2l0aDpcbiAgICAvLyAgIHBhdGhuYW1lOiAgICAgICAgICAgXCIvZGVzY2VuZGFudC9hJTI1Yi9tYXRjaFwiXG4gICAgLy8gICBwYXJlbnRQYXRobmFtZUJhc2U6IFwiL2Rlc2NlbmRhbnQvYSViXCJcbiAgICAvL1xuICAgIC8vIEFuZCB0aGUgZGlyZWN0IHN1YnN0cmluZyByZW1vdmFsIGFwcHJvYWNoIHdvbid0IHdvcmsgOi9cbiAgICBsZXQgcGFyZW50U2VnbWVudHMgPSBwYXJlbnRQYXRobmFtZUJhc2UucmVwbGFjZSgvXlxcLy8sIFwiXCIpLnNwbGl0KFwiL1wiKTtcbiAgICBsZXQgc2VnbWVudHMgPSBwYXRobmFtZS5yZXBsYWNlKC9eXFwvLywgXCJcIikuc3BsaXQoXCIvXCIpO1xuICAgIHJlbWFpbmluZ1BhdGhuYW1lID0gXCIvXCIgKyBzZWdtZW50cy5zbGljZShwYXJlbnRTZWdtZW50cy5sZW5ndGgpLmpvaW4oXCIvXCIpO1xuICB9XG4gIGxldCBtYXRjaGVzID0gbWF0Y2hSb3V0ZXMocm91dGVzLCB7XG4gICAgcGF0aG5hbWU6IHJlbWFpbmluZ1BhdGhuYW1lXG4gIH0pO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcocGFyZW50Um91dGUgfHwgbWF0Y2hlcyAhPSBudWxsLCBcIk5vIHJvdXRlcyBtYXRjaGVkIGxvY2F0aW9uIFxcXCJcIiArIGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoICsgbG9jYXRpb24uaGFzaCArIFwiXFxcIiBcIikgOiB2b2lkIDA7XG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcobWF0Y2hlcyA9PSBudWxsIHx8IG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXS5yb3V0ZS5lbGVtZW50ICE9PSB1bmRlZmluZWQgfHwgbWF0Y2hlc1ttYXRjaGVzLmxlbmd0aCAtIDFdLnJvdXRlLkNvbXBvbmVudCAhPT0gdW5kZWZpbmVkIHx8IG1hdGNoZXNbbWF0Y2hlcy5sZW5ndGggLSAxXS5yb3V0ZS5sYXp5ICE9PSB1bmRlZmluZWQsIFwiTWF0Y2hlZCBsZWFmIHJvdXRlIGF0IGxvY2F0aW9uIFxcXCJcIiArIGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoICsgbG9jYXRpb24uaGFzaCArIFwiXFxcIiBcIiArIFwiZG9lcyBub3QgaGF2ZSBhbiBlbGVtZW50IG9yIENvbXBvbmVudC4gVGhpcyBtZWFucyBpdCB3aWxsIHJlbmRlciBhbiA8T3V0bGV0IC8+IHdpdGggYSBcIiArIFwibnVsbCB2YWx1ZSBieSBkZWZhdWx0IHJlc3VsdGluZyBpbiBhbiBcXFwiZW1wdHlcXFwiIHBhZ2UuXCIpIDogdm9pZCAwO1xuICB9XG4gIGxldCByZW5kZXJlZE1hdGNoZXMgPSBfcmVuZGVyTWF0Y2hlcyhtYXRjaGVzICYmIG1hdGNoZXMubWFwKG1hdGNoID0+IE9iamVjdC5hc3NpZ24oe30sIG1hdGNoLCB7XG4gICAgcGFyYW1zOiBPYmplY3QuYXNzaWduKHt9LCBwYXJlbnRQYXJhbXMsIG1hdGNoLnBhcmFtcyksXG4gICAgcGF0aG5hbWU6IGpvaW5QYXRocyhbcGFyZW50UGF0aG5hbWVCYXNlLFxuICAgIC8vIFJlLWVuY29kZSBwYXRobmFtZXMgdGhhdCB3ZXJlIGRlY29kZWQgaW5zaWRlIG1hdGNoUm91dGVzXG4gICAgbmF2aWdhdG9yLmVuY29kZUxvY2F0aW9uID8gbmF2aWdhdG9yLmVuY29kZUxvY2F0aW9uKG1hdGNoLnBhdGhuYW1lKS5wYXRobmFtZSA6IG1hdGNoLnBhdGhuYW1lXSksXG4gICAgcGF0aG5hbWVCYXNlOiBtYXRjaC5wYXRobmFtZUJhc2UgPT09IFwiL1wiID8gcGFyZW50UGF0aG5hbWVCYXNlIDogam9pblBhdGhzKFtwYXJlbnRQYXRobmFtZUJhc2UsXG4gICAgLy8gUmUtZW5jb2RlIHBhdGhuYW1lcyB0aGF0IHdlcmUgZGVjb2RlZCBpbnNpZGUgbWF0Y2hSb3V0ZXNcbiAgICBuYXZpZ2F0b3IuZW5jb2RlTG9jYXRpb24gPyBuYXZpZ2F0b3IuZW5jb2RlTG9jYXRpb24obWF0Y2gucGF0aG5hbWVCYXNlKS5wYXRobmFtZSA6IG1hdGNoLnBhdGhuYW1lQmFzZV0pXG4gIH0pKSwgcGFyZW50TWF0Y2hlcywgZGF0YVJvdXRlclN0YXRlLCBmdXR1cmUpO1xuXG4gIC8vIFdoZW4gYSB1c2VyIHBhc3NlcyBpbiBhIGBsb2NhdGlvbkFyZ2AsIHRoZSBhc3NvY2lhdGVkIHJvdXRlcyBuZWVkIHRvXG4gIC8vIGJlIHdyYXBwZWQgaW4gYSBuZXcgYExvY2F0aW9uQ29udGV4dC5Qcm92aWRlcmAgaW4gb3JkZXIgZm9yIGB1c2VMb2NhdGlvbmBcbiAgLy8gdG8gdXNlIHRoZSBzY29wZWQgbG9jYXRpb24gaW5zdGVhZCBvZiB0aGUgZ2xvYmFsIGxvY2F0aW9uLlxuICBpZiAobG9jYXRpb25BcmcgJiYgcmVuZGVyZWRNYXRjaGVzKSB7XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KExvY2F0aW9uQ29udGV4dC5Qcm92aWRlciwge1xuICAgICAgdmFsdWU6IHtcbiAgICAgICAgbG9jYXRpb246IF9leHRlbmRzKHtcbiAgICAgICAgICBwYXRobmFtZTogXCIvXCIsXG4gICAgICAgICAgc2VhcmNoOiBcIlwiLFxuICAgICAgICAgIGhhc2g6IFwiXCIsXG4gICAgICAgICAgc3RhdGU6IG51bGwsXG4gICAgICAgICAga2V5OiBcImRlZmF1bHRcIlxuICAgICAgICB9LCBsb2NhdGlvbiksXG4gICAgICAgIG5hdmlnYXRpb25UeXBlOiBBY3Rpb24uUG9wXG4gICAgICB9XG4gICAgfSwgcmVuZGVyZWRNYXRjaGVzKTtcbiAgfVxuICByZXR1cm4gcmVuZGVyZWRNYXRjaGVzO1xufVxuZnVuY3Rpb24gRGVmYXVsdEVycm9yQ29tcG9uZW50KCkge1xuICBsZXQgZXJyb3IgPSB1c2VSb3V0ZUVycm9yKCk7XG4gIGxldCBtZXNzYWdlID0gaXNSb3V0ZUVycm9yUmVzcG9uc2UoZXJyb3IpID8gZXJyb3Iuc3RhdHVzICsgXCIgXCIgKyBlcnJvci5zdGF0dXNUZXh0IDogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBKU09OLnN0cmluZ2lmeShlcnJvcik7XG4gIGxldCBzdGFjayA9IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5zdGFjayA6IG51bGw7XG4gIGxldCBsaWdodGdyZXkgPSBcInJnYmEoMjAwLDIwMCwyMDAsIDAuNSlcIjtcbiAgbGV0IHByZVN0eWxlcyA9IHtcbiAgICBwYWRkaW5nOiBcIjAuNXJlbVwiLFxuICAgIGJhY2tncm91bmRDb2xvcjogbGlnaHRncmV5XG4gIH07XG4gIGxldCBjb2RlU3R5bGVzID0ge1xuICAgIHBhZGRpbmc6IFwiMnB4IDRweFwiLFxuICAgIGJhY2tncm91bmRDb2xvcjogbGlnaHRncmV5XG4gIH07XG4gIGxldCBkZXZJbmZvID0gbnVsbDtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBoYW5kbGVkIGJ5IFJlYWN0IFJvdXRlciBkZWZhdWx0IEVycm9yQm91bmRhcnk6XCIsIGVycm9yKTtcbiAgICBkZXZJbmZvID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwicFwiLCBudWxsLCBcIlxcdUQ4M0RcXHVEQ0JGIEhleSBkZXZlbG9wZXIgXFx1RDgzRFxcdURDNEJcIiksIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwicFwiLCBudWxsLCBcIllvdSBjYW4gcHJvdmlkZSBhIHdheSBiZXR0ZXIgVVggdGhhbiB0aGlzIHdoZW4geW91ciBhcHAgdGhyb3dzIGVycm9ycyBieSBwcm92aWRpbmcgeW91ciBvd24gXCIsIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiY29kZVwiLCB7XG4gICAgICBzdHlsZTogY29kZVN0eWxlc1xuICAgIH0sIFwiRXJyb3JCb3VuZGFyeVwiKSwgXCIgb3JcIiwgXCIgXCIsIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiY29kZVwiLCB7XG4gICAgICBzdHlsZTogY29kZVN0eWxlc1xuICAgIH0sIFwiZXJyb3JFbGVtZW50XCIpLCBcIiBwcm9wIG9uIHlvdXIgcm91dGUuXCIpKTtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFwiaDJcIiwgbnVsbCwgXCJVbmV4cGVjdGVkIEFwcGxpY2F0aW9uIEVycm9yIVwiKSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJoM1wiLCB7XG4gICAgc3R5bGU6IHtcbiAgICAgIGZvbnRTdHlsZTogXCJpdGFsaWNcIlxuICAgIH1cbiAgfSwgbWVzc2FnZSksIHN0YWNrID8gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoXCJwcmVcIiwge1xuICAgIHN0eWxlOiBwcmVTdHlsZXNcbiAgfSwgc3RhY2spIDogbnVsbCwgZGV2SW5mbyk7XG59XG5jb25zdCBkZWZhdWx0RXJyb3JFbGVtZW50ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoRGVmYXVsdEVycm9yQ29tcG9uZW50LCBudWxsKTtcbmNsYXNzIFJlbmRlckVycm9yQm91bmRhcnkgZXh0ZW5kcyBSZWFjdC5Db21wb25lbnQge1xuICBjb25zdHJ1Y3Rvcihwcm9wcykge1xuICAgIHN1cGVyKHByb3BzKTtcbiAgICB0aGlzLnN0YXRlID0ge1xuICAgICAgbG9jYXRpb246IHByb3BzLmxvY2F0aW9uLFxuICAgICAgcmV2YWxpZGF0aW9uOiBwcm9wcy5yZXZhbGlkYXRpb24sXG4gICAgICBlcnJvcjogcHJvcHMuZXJyb3JcbiAgICB9O1xuICB9XG4gIHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoZXJyb3IpIHtcbiAgICByZXR1cm4ge1xuICAgICAgZXJyb3I6IGVycm9yXG4gICAgfTtcbiAgfVxuICBzdGF0aWMgZ2V0RGVyaXZlZFN0YXRlRnJvbVByb3BzKHByb3BzLCBzdGF0ZSkge1xuICAgIC8vIFdoZW4gd2UgZ2V0IGludG8gYW4gZXJyb3Igc3RhdGUsIHRoZSB1c2VyIHdpbGwgbGlrZWx5IGNsaWNrIFwiYmFja1wiIHRvIHRoZVxuICAgIC8vIHByZXZpb3VzIHBhZ2UgdGhhdCBkaWRuJ3QgaGF2ZSBhbiBlcnJvci4gQmVjYXVzZSB0aGlzIHdyYXBzIHRoZSBlbnRpcmVcbiAgICAvLyBhcHBsaWNhdGlvbiwgdGhhdCB3aWxsIGhhdmUgbm8gZWZmZWN0LS10aGUgZXJyb3IgcGFnZSBjb250aW51ZXMgdG8gZGlzcGxheS5cbiAgICAvLyBUaGlzIGdpdmVzIHVzIGEgbWVjaGFuaXNtIHRvIHJlY292ZXIgZnJvbSB0aGUgZXJyb3Igd2hlbiB0aGUgbG9jYXRpb24gY2hhbmdlcy5cbiAgICAvL1xuICAgIC8vIFdoZXRoZXIgd2UncmUgaW4gYW4gZXJyb3Igc3RhdGUgb3Igbm90LCB3ZSB1cGRhdGUgdGhlIGxvY2F0aW9uIGluIHN0YXRlXG4gICAgLy8gc28gdGhhdCB3aGVuIHdlIGFyZSBpbiBhbiBlcnJvciBzdGF0ZSwgaXQgZ2V0cyByZXNldCB3aGVuIGEgbmV3IGxvY2F0aW9uXG4gICAgLy8gY29tZXMgaW4gYW5kIHRoZSB1c2VyIHJlY292ZXJzIGZyb20gdGhlIGVycm9yLlxuICAgIGlmIChzdGF0ZS5sb2NhdGlvbiAhPT0gcHJvcHMubG9jYXRpb24gfHwgc3RhdGUucmV2YWxpZGF0aW9uICE9PSBcImlkbGVcIiAmJiBwcm9wcy5yZXZhbGlkYXRpb24gPT09IFwiaWRsZVwiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBlcnJvcjogcHJvcHMuZXJyb3IsXG4gICAgICAgIGxvY2F0aW9uOiBwcm9wcy5sb2NhdGlvbixcbiAgICAgICAgcmV2YWxpZGF0aW9uOiBwcm9wcy5yZXZhbGlkYXRpb25cbiAgICAgIH07XG4gICAgfVxuXG4gICAgLy8gSWYgd2UncmUgbm90IGNoYW5naW5nIGxvY2F0aW9ucywgcHJlc2VydmUgdGhlIGxvY2F0aW9uIGJ1dCBzdGlsbCBzdXJmYWNlXG4gICAgLy8gYW55IG5ldyBlcnJvcnMgdGhhdCBtYXkgY29tZSB0aHJvdWdoLiBXZSByZXRhaW4gdGhlIGV4aXN0aW5nIGVycm9yLCB3ZSBkb1xuICAgIC8vIHRoaXMgYmVjYXVzZSB0aGUgZXJyb3IgcHJvdmlkZWQgZnJvbSB0aGUgYXBwIHN0YXRlIG1heSBiZSBjbGVhcmVkIHdpdGhvdXRcbiAgICAvLyB0aGUgbG9jYXRpb24gY2hhbmdpbmcuXG4gICAgcmV0dXJuIHtcbiAgICAgIGVycm9yOiBwcm9wcy5lcnJvciAhPT0gdW5kZWZpbmVkID8gcHJvcHMuZXJyb3IgOiBzdGF0ZS5lcnJvcixcbiAgICAgIGxvY2F0aW9uOiBzdGF0ZS5sb2NhdGlvbixcbiAgICAgIHJldmFsaWRhdGlvbjogcHJvcHMucmV2YWxpZGF0aW9uIHx8IHN0YXRlLnJldmFsaWRhdGlvblxuICAgIH07XG4gIH1cbiAgY29tcG9uZW50RGlkQ2F0Y2goZXJyb3IsIGVycm9ySW5mbykge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJSZWFjdCBSb3V0ZXIgY2F1Z2h0IHRoZSBmb2xsb3dpbmcgZXJyb3IgZHVyaW5nIHJlbmRlclwiLCBlcnJvciwgZXJyb3JJbmZvKTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuc3RhdGUuZXJyb3IgIT09IHVuZGVmaW5lZCA/IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJvdXRlQ29udGV4dC5Qcm92aWRlciwge1xuICAgICAgdmFsdWU6IHRoaXMucHJvcHMucm91dGVDb250ZXh0XG4gICAgfSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGVFcnJvckNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICAgIHZhbHVlOiB0aGlzLnN0YXRlLmVycm9yLFxuICAgICAgY2hpbGRyZW46IHRoaXMucHJvcHMuY29tcG9uZW50XG4gICAgfSkpIDogdGhpcy5wcm9wcy5jaGlsZHJlbjtcbiAgfVxufVxuZnVuY3Rpb24gUmVuZGVyZWRSb3V0ZShfcmVmKSB7XG4gIGxldCB7XG4gICAgcm91dGVDb250ZXh0LFxuICAgIG1hdGNoLFxuICAgIGNoaWxkcmVuXG4gIH0gPSBfcmVmO1xuICBsZXQgZGF0YVJvdXRlckNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KERhdGFSb3V0ZXJDb250ZXh0KTtcblxuICAvLyBUcmFjayBob3cgZGVlcCB3ZSBnb3QgaW4gb3VyIHJlbmRlciBwYXNzIHRvIGVtdWxhdGUgU1NSIGNvbXBvbmVudERpZENhdGNoXG4gIC8vIGluIGEgRGF0YVN0YXRpY1JvdXRlclxuICBpZiAoZGF0YVJvdXRlckNvbnRleHQgJiYgZGF0YVJvdXRlckNvbnRleHQuc3RhdGljICYmIGRhdGFSb3V0ZXJDb250ZXh0LnN0YXRpY0NvbnRleHQgJiYgKG1hdGNoLnJvdXRlLmVycm9yRWxlbWVudCB8fCBtYXRjaC5yb3V0ZS5FcnJvckJvdW5kYXJ5KSkge1xuICAgIGRhdGFSb3V0ZXJDb250ZXh0LnN0YXRpY0NvbnRleHQuX2RlZXBlc3RSZW5kZXJlZEJvdW5kYXJ5SWQgPSBtYXRjaC5yb3V0ZS5pZDtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGVDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHJvdXRlQ29udGV4dFxuICB9LCBjaGlsZHJlbik7XG59XG5mdW5jdGlvbiBfcmVuZGVyTWF0Y2hlcyhtYXRjaGVzLCBwYXJlbnRNYXRjaGVzLCBkYXRhUm91dGVyU3RhdGUsIGZ1dHVyZSkge1xuICB2YXIgX2RhdGFSb3V0ZXJTdGF0ZTtcbiAgaWYgKHBhcmVudE1hdGNoZXMgPT09IHZvaWQgMCkge1xuICAgIHBhcmVudE1hdGNoZXMgPSBbXTtcbiAgfVxuICBpZiAoZGF0YVJvdXRlclN0YXRlID09PSB2b2lkIDApIHtcbiAgICBkYXRhUm91dGVyU3RhdGUgPSBudWxsO1xuICB9XG4gIGlmIChmdXR1cmUgPT09IHZvaWQgMCkge1xuICAgIGZ1dHVyZSA9IG51bGw7XG4gIH1cbiAgaWYgKG1hdGNoZXMgPT0gbnVsbCkge1xuICAgIHZhciBfZnV0dXJlO1xuICAgIGlmICghZGF0YVJvdXRlclN0YXRlKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKGRhdGFSb3V0ZXJTdGF0ZS5lcnJvcnMpIHtcbiAgICAgIC8vIERvbid0IGJhaWwgaWYgd2UgaGF2ZSBkYXRhIHJvdXRlciBlcnJvcnMgc28gd2UgY2FuIHJlbmRlciB0aGVtIGluIHRoZVxuICAgICAgLy8gYm91bmRhcnkuICBVc2UgdGhlIHByZS1tYXRjaGVkIChvciBzaGltbWVkKSBtYXRjaGVzXG4gICAgICBtYXRjaGVzID0gZGF0YVJvdXRlclN0YXRlLm1hdGNoZXM7XG4gICAgfSBlbHNlIGlmICgoX2Z1dHVyZSA9IGZ1dHVyZSkgIT0gbnVsbCAmJiBfZnV0dXJlLnY3X3BhcnRpYWxIeWRyYXRpb24gJiYgcGFyZW50TWF0Y2hlcy5sZW5ndGggPT09IDAgJiYgIWRhdGFSb3V0ZXJTdGF0ZS5pbml0aWFsaXplZCAmJiBkYXRhUm91dGVyU3RhdGUubWF0Y2hlcy5sZW5ndGggPiAwKSB7XG4gICAgICAvLyBEb24ndCBiYWlsIGlmIHdlJ3JlIGluaXRpYWxpemluZyB3aXRoIHBhcnRpYWwgaHlkcmF0aW9uIGFuZCB3ZSBoYXZlXG4gICAgICAvLyByb3V0ZXIgbWF0Y2hlcy4gIFRoYXQgbWVhbnMgd2UncmUgYWN0aXZlbHkgcnVubmluZyBgcGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb25gXG4gICAgICAvLyBzbyB3ZSBzaG91bGQgcmVuZGVyIGRvd24gdGhlIHBhcnRpYWwgbWF0Y2hlcyB0byB0aGUgYXBwcm9wcmlhdGVcbiAgICAgIC8vIGBIeWRyYXRlRmFsbGJhY2tgLiAgV2Ugb25seSBkbyB0aGlzIGlmIGBwYXJlbnRNYXRjaGVzYCBpcyBlbXB0eSBzbyBpdFxuICAgICAgLy8gb25seSBpbXBhY3RzIHRoZSByb290IG1hdGNoZXMgZm9yIGBSb3V0ZXJQcm92aWRlcmAgYW5kIG5vIGRlc2NlbmRhbnRcbiAgICAgIC8vIGA8Um91dGVzPmBcbiAgICAgIG1hdGNoZXMgPSBkYXRhUm91dGVyU3RhdGUubWF0Y2hlcztcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9XG4gIGxldCByZW5kZXJlZE1hdGNoZXMgPSBtYXRjaGVzO1xuXG4gIC8vIElmIHdlIGhhdmUgZGF0YSBlcnJvcnMsIHRyaW0gbWF0Y2hlcyB0byB0aGUgaGlnaGVzdCBlcnJvciBib3VuZGFyeVxuICBsZXQgZXJyb3JzID0gKF9kYXRhUm91dGVyU3RhdGUgPSBkYXRhUm91dGVyU3RhdGUpID09IG51bGwgPyB2b2lkIDAgOiBfZGF0YVJvdXRlclN0YXRlLmVycm9ycztcbiAgaWYgKGVycm9ycyAhPSBudWxsKSB7XG4gICAgbGV0IGVycm9ySW5kZXggPSByZW5kZXJlZE1hdGNoZXMuZmluZEluZGV4KG0gPT4gbS5yb3V0ZS5pZCAmJiAoZXJyb3JzID09IG51bGwgPyB2b2lkIDAgOiBlcnJvcnNbbS5yb3V0ZS5pZF0pICE9PSB1bmRlZmluZWQpO1xuICAgICEoZXJyb3JJbmRleCA+PSAwKSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIFwiQ291bGQgbm90IGZpbmQgYSBtYXRjaGluZyByb3V0ZSBmb3IgZXJyb3JzIG9uIHJvdXRlIElEczogXCIgKyBPYmplY3Qua2V5cyhlcnJvcnMpLmpvaW4oXCIsXCIpKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICAgIHJlbmRlcmVkTWF0Y2hlcyA9IHJlbmRlcmVkTWF0Y2hlcy5zbGljZSgwLCBNYXRoLm1pbihyZW5kZXJlZE1hdGNoZXMubGVuZ3RoLCBlcnJvckluZGV4ICsgMSkpO1xuICB9XG5cbiAgLy8gSWYgd2UncmUgaW4gYSBwYXJ0aWFsIGh5ZHJhdGlvbiBtb2RlLCBkZXRlY3QgaWYgd2UgbmVlZCB0byByZW5kZXIgZG93biB0b1xuICAvLyBhIGdpdmVuIEh5ZHJhdGVGYWxsYmFjayB3aGlsZSB3ZSBsb2FkIHRoZSByZXN0IG9mIHRoZSBoeWRyYXRpb24gZGF0YVxuICBsZXQgcmVuZGVyRmFsbGJhY2sgPSBmYWxzZTtcbiAgbGV0IGZhbGxiYWNrSW5kZXggPSAtMTtcbiAgaWYgKGRhdGFSb3V0ZXJTdGF0ZSAmJiBmdXR1cmUgJiYgZnV0dXJlLnY3X3BhcnRpYWxIeWRyYXRpb24pIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlbmRlcmVkTWF0Y2hlcy5sZW5ndGg7IGkrKykge1xuICAgICAgbGV0IG1hdGNoID0gcmVuZGVyZWRNYXRjaGVzW2ldO1xuICAgICAgLy8gVHJhY2sgdGhlIGRlZXBlc3QgZmFsbGJhY2sgdXAgdW50aWwgdGhlIGZpcnN0IHJvdXRlIHdpdGhvdXQgZGF0YVxuICAgICAgaWYgKG1hdGNoLnJvdXRlLkh5ZHJhdGVGYWxsYmFjayB8fCBtYXRjaC5yb3V0ZS5oeWRyYXRlRmFsbGJhY2tFbGVtZW50KSB7XG4gICAgICAgIGZhbGxiYWNrSW5kZXggPSBpO1xuICAgICAgfVxuICAgICAgaWYgKG1hdGNoLnJvdXRlLmlkKSB7XG4gICAgICAgIGxldCB7XG4gICAgICAgICAgbG9hZGVyRGF0YSxcbiAgICAgICAgICBlcnJvcnNcbiAgICAgICAgfSA9IGRhdGFSb3V0ZXJTdGF0ZTtcbiAgICAgICAgbGV0IG5lZWRzVG9SdW5Mb2FkZXIgPSBtYXRjaC5yb3V0ZS5sb2FkZXIgJiYgbG9hZGVyRGF0YVttYXRjaC5yb3V0ZS5pZF0gPT09IHVuZGVmaW5lZCAmJiAoIWVycm9ycyB8fCBlcnJvcnNbbWF0Y2gucm91dGUuaWRdID09PSB1bmRlZmluZWQpO1xuICAgICAgICBpZiAobWF0Y2gucm91dGUubGF6eSB8fCBuZWVkc1RvUnVuTG9hZGVyKSB7XG4gICAgICAgICAgLy8gV2UgZm91bmQgdGhlIGZpcnN0IHJvdXRlIHRoYXQncyBub3QgcmVhZHkgdG8gcmVuZGVyICh3YWl0aW5nIG9uXG4gICAgICAgICAgLy8gbGF6eSwgb3IgaGFzIGEgbG9hZGVyIHRoYXQgaGFzbid0IHJ1biB5ZXQpLiAgRmxhZyB0aGF0IHdlIG5lZWQgdG9cbiAgICAgICAgICAvLyByZW5kZXIgYSBmYWxsYmFjayBhbmQgcmVuZGVyIHVwIHVudGlsIHRoZSBhcHByb3ByaWF0ZSBmYWxsYmFja1xuICAgICAgICAgIHJlbmRlckZhbGxiYWNrID0gdHJ1ZTtcbiAgICAgICAgICBpZiAoZmFsbGJhY2tJbmRleCA+PSAwKSB7XG4gICAgICAgICAgICByZW5kZXJlZE1hdGNoZXMgPSByZW5kZXJlZE1hdGNoZXMuc2xpY2UoMCwgZmFsbGJhY2tJbmRleCArIDEpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZW5kZXJlZE1hdGNoZXMgPSBbcmVuZGVyZWRNYXRjaGVzWzBdXTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlbmRlcmVkTWF0Y2hlcy5yZWR1Y2VSaWdodCgob3V0bGV0LCBtYXRjaCwgaW5kZXgpID0+IHtcbiAgICAvLyBPbmx5IGRhdGEgcm91dGVycyBoYW5kbGUgZXJyb3JzL2ZhbGxiYWNrc1xuICAgIGxldCBlcnJvcjtcbiAgICBsZXQgc2hvdWxkUmVuZGVySHlkcmF0ZUZhbGxiYWNrID0gZmFsc2U7XG4gICAgbGV0IGVycm9yRWxlbWVudCA9IG51bGw7XG4gICAgbGV0IGh5ZHJhdGVGYWxsYmFja0VsZW1lbnQgPSBudWxsO1xuICAgIGlmIChkYXRhUm91dGVyU3RhdGUpIHtcbiAgICAgIGVycm9yID0gZXJyb3JzICYmIG1hdGNoLnJvdXRlLmlkID8gZXJyb3JzW21hdGNoLnJvdXRlLmlkXSA6IHVuZGVmaW5lZDtcbiAgICAgIGVycm9yRWxlbWVudCA9IG1hdGNoLnJvdXRlLmVycm9yRWxlbWVudCB8fCBkZWZhdWx0RXJyb3JFbGVtZW50O1xuICAgICAgaWYgKHJlbmRlckZhbGxiYWNrKSB7XG4gICAgICAgIGlmIChmYWxsYmFja0luZGV4IDwgMCAmJiBpbmRleCA9PT0gMCkge1xuICAgICAgICAgIHdhcm5pbmdPbmNlKFwicm91dGUtZmFsbGJhY2tcIiwgZmFsc2UsIFwiTm8gYEh5ZHJhdGVGYWxsYmFja2AgZWxlbWVudCBwcm92aWRlZCB0byByZW5kZXIgZHVyaW5nIGluaXRpYWwgaHlkcmF0aW9uXCIpO1xuICAgICAgICAgIHNob3VsZFJlbmRlckh5ZHJhdGVGYWxsYmFjayA9IHRydWU7XG4gICAgICAgICAgaHlkcmF0ZUZhbGxiYWNrRWxlbWVudCA9IG51bGw7XG4gICAgICAgIH0gZWxzZSBpZiAoZmFsbGJhY2tJbmRleCA9PT0gaW5kZXgpIHtcbiAgICAgICAgICBzaG91bGRSZW5kZXJIeWRyYXRlRmFsbGJhY2sgPSB0cnVlO1xuICAgICAgICAgIGh5ZHJhdGVGYWxsYmFja0VsZW1lbnQgPSBtYXRjaC5yb3V0ZS5oeWRyYXRlRmFsbGJhY2tFbGVtZW50IHx8IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgbGV0IG1hdGNoZXMgPSBwYXJlbnRNYXRjaGVzLmNvbmNhdChyZW5kZXJlZE1hdGNoZXMuc2xpY2UoMCwgaW5kZXggKyAxKSk7XG4gICAgbGV0IGdldENoaWxkcmVuID0gKCkgPT4ge1xuICAgICAgbGV0IGNoaWxkcmVuO1xuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIGNoaWxkcmVuID0gZXJyb3JFbGVtZW50O1xuICAgICAgfSBlbHNlIGlmIChzaG91bGRSZW5kZXJIeWRyYXRlRmFsbGJhY2spIHtcbiAgICAgICAgY2hpbGRyZW4gPSBoeWRyYXRlRmFsbGJhY2tFbGVtZW50O1xuICAgICAgfSBlbHNlIGlmIChtYXRjaC5yb3V0ZS5Db21wb25lbnQpIHtcbiAgICAgICAgLy8gTm90ZTogVGhpcyBpcyBhIGRlLW9wdGltaXplZCBwYXRoIHNpbmNlIFJlYWN0IHdvbid0IHJlLXVzZSB0aGVcbiAgICAgICAgLy8gUmVhY3RFbGVtZW50IHNpbmNlIGl0J3MgaWRlbnRpdHkgY2hhbmdlcyB3aXRoIGVhY2ggbmV3XG4gICAgICAgIC8vIFJlYWN0LmNyZWF0ZUVsZW1lbnQgY2FsbC4gIFdlIGtlZXAgdGhpcyBzbyBmb2xrcyBjYW4gdXNlXG4gICAgICAgIC8vIGA8Um91dGUgQ29tcG9uZW50PXsuLi59PmAgaW4gYDxSb3V0ZXM+YCBidXQgZ2VuZXJhbGx5IGBDb21wb25lbnRgXG4gICAgICAgIC8vIHVzYWdlIGlzIG9ubHkgYWR2aXNlZCBpbiBgUm91dGVyUHJvdmlkZXJgIHdoZW4gd2UgY2FuIGNvbnZlcnQgaXQgdG9cbiAgICAgICAgLy8gYGVsZW1lbnRgIGFoZWFkIG9mIHRpbWUuXG4gICAgICAgIGNoaWxkcmVuID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQobWF0Y2gucm91dGUuQ29tcG9uZW50LCBudWxsKTtcbiAgICAgIH0gZWxzZSBpZiAobWF0Y2gucm91dGUuZWxlbWVudCkge1xuICAgICAgICBjaGlsZHJlbiA9IG1hdGNoLnJvdXRlLmVsZW1lbnQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjaGlsZHJlbiA9IG91dGxldDtcbiAgICAgIH1cbiAgICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChSZW5kZXJlZFJvdXRlLCB7XG4gICAgICAgIG1hdGNoOiBtYXRjaCxcbiAgICAgICAgcm91dGVDb250ZXh0OiB7XG4gICAgICAgICAgb3V0bGV0LFxuICAgICAgICAgIG1hdGNoZXMsXG4gICAgICAgICAgaXNEYXRhUm91dGU6IGRhdGFSb3V0ZXJTdGF0ZSAhPSBudWxsXG4gICAgICAgIH0sXG4gICAgICAgIGNoaWxkcmVuOiBjaGlsZHJlblxuICAgICAgfSk7XG4gICAgfTtcbiAgICAvLyBPbmx5IHdyYXAgaW4gYW4gZXJyb3IgYm91bmRhcnkgd2l0aGluIGRhdGEgcm91dGVyIHVzYWdlcyB3aGVuIHdlIGhhdmUgYW5cbiAgICAvLyBFcnJvckJvdW5kYXJ5L2Vycm9yRWxlbWVudCBvbiB0aGlzIHJvdXRlLiAgT3RoZXJ3aXNlIGxldCBpdCBidWJibGUgdXAgdG9cbiAgICAvLyBhbiBhbmNlc3RvciBFcnJvckJvdW5kYXJ5L2Vycm9yRWxlbWVudFxuICAgIHJldHVybiBkYXRhUm91dGVyU3RhdGUgJiYgKG1hdGNoLnJvdXRlLkVycm9yQm91bmRhcnkgfHwgbWF0Y2gucm91dGUuZXJyb3JFbGVtZW50IHx8IGluZGV4ID09PSAwKSA/IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJlbmRlckVycm9yQm91bmRhcnksIHtcbiAgICAgIGxvY2F0aW9uOiBkYXRhUm91dGVyU3RhdGUubG9jYXRpb24sXG4gICAgICByZXZhbGlkYXRpb246IGRhdGFSb3V0ZXJTdGF0ZS5yZXZhbGlkYXRpb24sXG4gICAgICBjb21wb25lbnQ6IGVycm9yRWxlbWVudCxcbiAgICAgIGVycm9yOiBlcnJvcixcbiAgICAgIGNoaWxkcmVuOiBnZXRDaGlsZHJlbigpLFxuICAgICAgcm91dGVDb250ZXh0OiB7XG4gICAgICAgIG91dGxldDogbnVsbCxcbiAgICAgICAgbWF0Y2hlcyxcbiAgICAgICAgaXNEYXRhUm91dGU6IHRydWVcbiAgICAgIH1cbiAgICB9KSA6IGdldENoaWxkcmVuKCk7XG4gIH0sIG51bGwpO1xufVxudmFyIERhdGFSb3V0ZXJIb29rID0gLyojX19QVVJFX18qL2Z1bmN0aW9uIChEYXRhUm91dGVySG9vaykge1xuICBEYXRhUm91dGVySG9va1tcIlVzZUJsb2NrZXJcIl0gPSBcInVzZUJsb2NrZXJcIjtcbiAgRGF0YVJvdXRlckhvb2tbXCJVc2VSZXZhbGlkYXRvclwiXSA9IFwidXNlUmV2YWxpZGF0b3JcIjtcbiAgRGF0YVJvdXRlckhvb2tbXCJVc2VOYXZpZ2F0ZVN0YWJsZVwiXSA9IFwidXNlTmF2aWdhdGVcIjtcbiAgcmV0dXJuIERhdGFSb3V0ZXJIb29rO1xufShEYXRhUm91dGVySG9vayB8fCB7fSk7XG52YXIgRGF0YVJvdXRlclN0YXRlSG9vayA9IC8qI19fUFVSRV9fKi9mdW5jdGlvbiAoRGF0YVJvdXRlclN0YXRlSG9vaykge1xuICBEYXRhUm91dGVyU3RhdGVIb29rW1wiVXNlQmxvY2tlclwiXSA9IFwidXNlQmxvY2tlclwiO1xuICBEYXRhUm91dGVyU3RhdGVIb29rW1wiVXNlTG9hZGVyRGF0YVwiXSA9IFwidXNlTG9hZGVyRGF0YVwiO1xuICBEYXRhUm91dGVyU3RhdGVIb29rW1wiVXNlQWN0aW9uRGF0YVwiXSA9IFwidXNlQWN0aW9uRGF0YVwiO1xuICBEYXRhUm91dGVyU3RhdGVIb29rW1wiVXNlUm91dGVFcnJvclwiXSA9IFwidXNlUm91dGVFcnJvclwiO1xuICBEYXRhUm91dGVyU3RhdGVIb29rW1wiVXNlTmF2aWdhdGlvblwiXSA9IFwidXNlTmF2aWdhdGlvblwiO1xuICBEYXRhUm91dGVyU3RhdGVIb29rW1wiVXNlUm91dGVMb2FkZXJEYXRhXCJdID0gXCJ1c2VSb3V0ZUxvYWRlckRhdGFcIjtcbiAgRGF0YVJvdXRlclN0YXRlSG9va1tcIlVzZU1hdGNoZXNcIl0gPSBcInVzZU1hdGNoZXNcIjtcbiAgRGF0YVJvdXRlclN0YXRlSG9va1tcIlVzZVJldmFsaWRhdG9yXCJdID0gXCJ1c2VSZXZhbGlkYXRvclwiO1xuICBEYXRhUm91dGVyU3RhdGVIb29rW1wiVXNlTmF2aWdhdGVTdGFibGVcIl0gPSBcInVzZU5hdmlnYXRlXCI7XG4gIERhdGFSb3V0ZXJTdGF0ZUhvb2tbXCJVc2VSb3V0ZUlkXCJdID0gXCJ1c2VSb3V0ZUlkXCI7XG4gIHJldHVybiBEYXRhUm91dGVyU3RhdGVIb29rO1xufShEYXRhUm91dGVyU3RhdGVIb29rIHx8IHt9KTtcbmZ1bmN0aW9uIGdldERhdGFSb3V0ZXJDb25zb2xlRXJyb3IoaG9va05hbWUpIHtcbiAgcmV0dXJuIGhvb2tOYW1lICsgXCIgbXVzdCBiZSB1c2VkIHdpdGhpbiBhIGRhdGEgcm91dGVyLiAgU2VlIGh0dHBzOi8vcmVhY3Ryb3V0ZXIuY29tL3Y2L3JvdXRlcnMvcGlja2luZy1hLXJvdXRlci5cIjtcbn1cbmZ1bmN0aW9uIHVzZURhdGFSb3V0ZXJDb250ZXh0KGhvb2tOYW1lKSB7XG4gIGxldCBjdHggPSBSZWFjdC51c2VDb250ZXh0KERhdGFSb3V0ZXJDb250ZXh0KTtcbiAgIWN0eCA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIGdldERhdGFSb3V0ZXJDb25zb2xlRXJyb3IoaG9va05hbWUpKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICByZXR1cm4gY3R4O1xufVxuZnVuY3Rpb24gdXNlRGF0YVJvdXRlclN0YXRlKGhvb2tOYW1lKSB7XG4gIGxldCBzdGF0ZSA9IFJlYWN0LnVzZUNvbnRleHQoRGF0YVJvdXRlclN0YXRlQ29udGV4dCk7XG4gICFzdGF0ZSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIGdldERhdGFSb3V0ZXJDb25zb2xlRXJyb3IoaG9va05hbWUpKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICByZXR1cm4gc3RhdGU7XG59XG5mdW5jdGlvbiB1c2VSb3V0ZUNvbnRleHQoaG9va05hbWUpIHtcbiAgbGV0IHJvdXRlID0gUmVhY3QudXNlQ29udGV4dChSb3V0ZUNvbnRleHQpO1xuICAhcm91dGUgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCBnZXREYXRhUm91dGVyQ29uc29sZUVycm9yKGhvb2tOYW1lKSkgOiBVTlNBRkVfaW52YXJpYW50KGZhbHNlKSA6IHZvaWQgMDtcbiAgcmV0dXJuIHJvdXRlO1xufVxuXG4vLyBJbnRlcm5hbCB2ZXJzaW9uIHdpdGggaG9va05hbWUtYXdhcmUgZGVidWdnaW5nXG5mdW5jdGlvbiB1c2VDdXJyZW50Um91dGVJZChob29rTmFtZSkge1xuICBsZXQgcm91dGUgPSB1c2VSb3V0ZUNvbnRleHQoaG9va05hbWUpO1xuICBsZXQgdGhpc1JvdXRlID0gcm91dGUubWF0Y2hlc1tyb3V0ZS5tYXRjaGVzLmxlbmd0aCAtIDFdO1xuICAhdGhpc1JvdXRlLnJvdXRlLmlkID8gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX2ludmFyaWFudChmYWxzZSwgaG9va05hbWUgKyBcIiBjYW4gb25seSBiZSB1c2VkIG9uIHJvdXRlcyB0aGF0IGNvbnRhaW4gYSB1bmlxdWUgXFxcImlkXFxcIlwiKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICByZXR1cm4gdGhpc1JvdXRlLnJvdXRlLmlkO1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIElEIGZvciB0aGUgbmVhcmVzdCBjb250ZXh0dWFsIHJvdXRlXG4gKi9cbmZ1bmN0aW9uIHVzZVJvdXRlSWQoKSB7XG4gIHJldHVybiB1c2VDdXJyZW50Um91dGVJZChEYXRhUm91dGVyU3RhdGVIb29rLlVzZVJvdXRlSWQpO1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGN1cnJlbnQgbmF2aWdhdGlvbiwgZGVmYXVsdGluZyB0byBhbiBcImlkbGVcIiBuYXZpZ2F0aW9uIHdoZW5cbiAqIG5vIG5hdmlnYXRpb24gaXMgaW4gcHJvZ3Jlc3NcbiAqL1xuZnVuY3Rpb24gdXNlTmF2aWdhdGlvbigpIHtcbiAgbGV0IHN0YXRlID0gdXNlRGF0YVJvdXRlclN0YXRlKERhdGFSb3V0ZXJTdGF0ZUhvb2suVXNlTmF2aWdhdGlvbik7XG4gIHJldHVybiBzdGF0ZS5uYXZpZ2F0aW9uO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSByZXZhbGlkYXRlIGZ1bmN0aW9uIGZvciBtYW51YWxseSB0cmlnZ2VyaW5nIHJldmFsaWRhdGlvbiwgYXMgd2VsbFxuICogYXMgdGhlIGN1cnJlbnQgc3RhdGUgb2YgYW55IG1hbnVhbCByZXZhbGlkYXRpb25zXG4gKi9cbmZ1bmN0aW9uIHVzZVJldmFsaWRhdG9yKCkge1xuICBsZXQgZGF0YVJvdXRlckNvbnRleHQgPSB1c2VEYXRhUm91dGVyQ29udGV4dChEYXRhUm91dGVySG9vay5Vc2VSZXZhbGlkYXRvcik7XG4gIGxldCBzdGF0ZSA9IHVzZURhdGFSb3V0ZXJTdGF0ZShEYXRhUm91dGVyU3RhdGVIb29rLlVzZVJldmFsaWRhdG9yKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICByZXZhbGlkYXRlOiBkYXRhUm91dGVyQ29udGV4dC5yb3V0ZXIucmV2YWxpZGF0ZSxcbiAgICBzdGF0ZTogc3RhdGUucmV2YWxpZGF0aW9uXG4gIH0pLCBbZGF0YVJvdXRlckNvbnRleHQucm91dGVyLnJldmFsaWRhdGUsIHN0YXRlLnJldmFsaWRhdGlvbl0pO1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGFjdGl2ZSByb3V0ZSBtYXRjaGVzLCB1c2VmdWwgZm9yIGFjY2Vzc2luZyBsb2FkZXJEYXRhIGZvclxuICogcGFyZW50L2NoaWxkIHJvdXRlcyBvciB0aGUgcm91dGUgXCJoYW5kbGVcIiBwcm9wZXJ0eVxuICovXG5mdW5jdGlvbiB1c2VNYXRjaGVzKCkge1xuICBsZXQge1xuICAgIG1hdGNoZXMsXG4gICAgbG9hZGVyRGF0YVxuICB9ID0gdXNlRGF0YVJvdXRlclN0YXRlKERhdGFSb3V0ZXJTdGF0ZUhvb2suVXNlTWF0Y2hlcyk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IG1hdGNoZXMubWFwKG0gPT4gVU5TQUZFX2NvbnZlcnRSb3V0ZU1hdGNoVG9VaU1hdGNoKG0sIGxvYWRlckRhdGEpKSwgW21hdGNoZXMsIGxvYWRlckRhdGFdKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBsb2FkZXIgZGF0YSBmb3IgdGhlIG5lYXJlc3QgYW5jZXN0b3IgUm91dGUgbG9hZGVyXG4gKi9cbmZ1bmN0aW9uIHVzZUxvYWRlckRhdGEoKSB7XG4gIGxldCBzdGF0ZSA9IHVzZURhdGFSb3V0ZXJTdGF0ZShEYXRhUm91dGVyU3RhdGVIb29rLlVzZUxvYWRlckRhdGEpO1xuICBsZXQgcm91dGVJZCA9IHVzZUN1cnJlbnRSb3V0ZUlkKERhdGFSb3V0ZXJTdGF0ZUhvb2suVXNlTG9hZGVyRGF0YSk7XG4gIGlmIChzdGF0ZS5lcnJvcnMgJiYgc3RhdGUuZXJyb3JzW3JvdXRlSWRdICE9IG51bGwpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiWW91IGNhbm5vdCBgdXNlTG9hZGVyRGF0YWAgaW4gYW4gZXJyb3JFbGVtZW50IChyb3V0ZUlkOiBcIiArIHJvdXRlSWQgKyBcIilcIik7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gc3RhdGUubG9hZGVyRGF0YVtyb3V0ZUlkXTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBsb2FkZXJEYXRhIGZvciB0aGUgZ2l2ZW4gcm91dGVJZFxuICovXG5mdW5jdGlvbiB1c2VSb3V0ZUxvYWRlckRhdGEocm91dGVJZCkge1xuICBsZXQgc3RhdGUgPSB1c2VEYXRhUm91dGVyU3RhdGUoRGF0YVJvdXRlclN0YXRlSG9vay5Vc2VSb3V0ZUxvYWRlckRhdGEpO1xuICByZXR1cm4gc3RhdGUubG9hZGVyRGF0YVtyb3V0ZUlkXTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBhY3Rpb24gZGF0YSBmb3IgdGhlIG5lYXJlc3QgYW5jZXN0b3IgUm91dGUgYWN0aW9uXG4gKi9cbmZ1bmN0aW9uIHVzZUFjdGlvbkRhdGEoKSB7XG4gIGxldCBzdGF0ZSA9IHVzZURhdGFSb3V0ZXJTdGF0ZShEYXRhUm91dGVyU3RhdGVIb29rLlVzZUFjdGlvbkRhdGEpO1xuICBsZXQgcm91dGVJZCA9IHVzZUN1cnJlbnRSb3V0ZUlkKERhdGFSb3V0ZXJTdGF0ZUhvb2suVXNlTG9hZGVyRGF0YSk7XG4gIHJldHVybiBzdGF0ZS5hY3Rpb25EYXRhID8gc3RhdGUuYWN0aW9uRGF0YVtyb3V0ZUlkXSA6IHVuZGVmaW5lZDtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBuZWFyZXN0IGFuY2VzdG9yIFJvdXRlIGVycm9yLCB3aGljaCBjb3VsZCBiZSBhIGxvYWRlci9hY3Rpb25cbiAqIGVycm9yIG9yIGEgcmVuZGVyIGVycm9yLiAgVGhpcyBpcyBpbnRlbmRlZCB0byBiZSBjYWxsZWQgZnJvbSB5b3VyXG4gKiBFcnJvckJvdW5kYXJ5L2Vycm9yRWxlbWVudCB0byBkaXNwbGF5IGEgcHJvcGVyIGVycm9yIG1lc3NhZ2UuXG4gKi9cbmZ1bmN0aW9uIHVzZVJvdXRlRXJyb3IoKSB7XG4gIHZhciBfc3RhdGUkZXJyb3JzO1xuICBsZXQgZXJyb3IgPSBSZWFjdC51c2VDb250ZXh0KFJvdXRlRXJyb3JDb250ZXh0KTtcbiAgbGV0IHN0YXRlID0gdXNlRGF0YVJvdXRlclN0YXRlKERhdGFSb3V0ZXJTdGF0ZUhvb2suVXNlUm91dGVFcnJvcik7XG4gIGxldCByb3V0ZUlkID0gdXNlQ3VycmVudFJvdXRlSWQoRGF0YVJvdXRlclN0YXRlSG9vay5Vc2VSb3V0ZUVycm9yKTtcblxuICAvLyBJZiB0aGlzIHdhcyBhIHJlbmRlciBlcnJvciwgd2UgcHV0IGl0IGluIGEgUm91dGVFcnJvciBjb250ZXh0IGluc2lkZVxuICAvLyBvZiBSZW5kZXJFcnJvckJvdW5kYXJ5XG4gIGlmIChlcnJvciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIGVycm9yO1xuICB9XG5cbiAgLy8gT3RoZXJ3aXNlIGxvb2sgZm9yIGVycm9ycyBmcm9tIG91ciBkYXRhIHJvdXRlciBzdGF0ZVxuICByZXR1cm4gKF9zdGF0ZSRlcnJvcnMgPSBzdGF0ZS5lcnJvcnMpID09IG51bGwgPyB2b2lkIDAgOiBfc3RhdGUkZXJyb3JzW3JvdXRlSWRdO1xufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGhhcHB5LXBhdGggZGF0YSBmcm9tIHRoZSBuZWFyZXN0IGFuY2VzdG9yIGA8QXdhaXQgLz5gIHZhbHVlXG4gKi9cbmZ1bmN0aW9uIHVzZUFzeW5jVmFsdWUoKSB7XG4gIGxldCB2YWx1ZSA9IFJlYWN0LnVzZUNvbnRleHQoQXdhaXRDb250ZXh0KTtcbiAgcmV0dXJuIHZhbHVlID09IG51bGwgPyB2b2lkIDAgOiB2YWx1ZS5fZGF0YTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBlcnJvciBmcm9tIHRoZSBuZWFyZXN0IGFuY2VzdG9yIGA8QXdhaXQgLz5gIHZhbHVlXG4gKi9cbmZ1bmN0aW9uIHVzZUFzeW5jRXJyb3IoKSB7XG4gIGxldCB2YWx1ZSA9IFJlYWN0LnVzZUNvbnRleHQoQXdhaXRDb250ZXh0KTtcbiAgcmV0dXJuIHZhbHVlID09IG51bGwgPyB2b2lkIDAgOiB2YWx1ZS5fZXJyb3I7XG59XG5sZXQgYmxvY2tlcklkID0gMDtcblxuLyoqXG4gKiBBbGxvdyB0aGUgYXBwbGljYXRpb24gdG8gYmxvY2sgbmF2aWdhdGlvbnMgd2l0aGluIHRoZSBTUEEgYW5kIHByZXNlbnQgdGhlXG4gKiB1c2VyIGEgY29uZmlybWF0aW9uIGRpYWxvZyB0byBjb25maXJtIHRoZSBuYXZpZ2F0aW9uLiAgTW9zdGx5IHVzZWQgdG8gYXZvaWRcbiAqIHVzaW5nIGhhbGYtZmlsbGVkIGZvcm0gZGF0YS4gIFRoaXMgZG9lcyBub3QgaGFuZGxlIGhhcmQtcmVsb2FkcyBvclxuICogY3Jvc3Mtb3JpZ2luIG5hdmlnYXRpb25zLlxuICovXG5mdW5jdGlvbiB1c2VCbG9ja2VyKHNob3VsZEJsb2NrKSB7XG4gIGxldCB7XG4gICAgcm91dGVyLFxuICAgIGJhc2VuYW1lXG4gIH0gPSB1c2VEYXRhUm91dGVyQ29udGV4dChEYXRhUm91dGVySG9vay5Vc2VCbG9ja2VyKTtcbiAgbGV0IHN0YXRlID0gdXNlRGF0YVJvdXRlclN0YXRlKERhdGFSb3V0ZXJTdGF0ZUhvb2suVXNlQmxvY2tlcik7XG4gIGxldCBbYmxvY2tlcktleSwgc2V0QmxvY2tlcktleV0gPSBSZWFjdC51c2VTdGF0ZShcIlwiKTtcbiAgbGV0IGJsb2NrZXJGdW5jdGlvbiA9IFJlYWN0LnVzZUNhbGxiYWNrKGFyZyA9PiB7XG4gICAgaWYgKHR5cGVvZiBzaG91bGRCbG9jayAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICByZXR1cm4gISFzaG91bGRCbG9jaztcbiAgICB9XG4gICAgaWYgKGJhc2VuYW1lID09PSBcIi9cIikge1xuICAgICAgcmV0dXJuIHNob3VsZEJsb2NrKGFyZyk7XG4gICAgfVxuXG4gICAgLy8gSWYgdGhleSBwcm92aWRlZCB1cyBhIGZ1bmN0aW9uIGFuZCB3ZSd2ZSBnb3QgYW4gYWN0aXZlIGJhc2VuYW1lLCBzdHJpcFxuICAgIC8vIGl0IGZyb20gdGhlIGxvY2F0aW9ucyB3ZSBleHBvc2UgdG8gdGhlIHVzZXIgdG8gbWF0Y2ggdGhlIGJlaGF2aW9yIG9mXG4gICAgLy8gdXNlTG9jYXRpb25cbiAgICBsZXQge1xuICAgICAgY3VycmVudExvY2F0aW9uLFxuICAgICAgbmV4dExvY2F0aW9uLFxuICAgICAgaGlzdG9yeUFjdGlvblxuICAgIH0gPSBhcmc7XG4gICAgcmV0dXJuIHNob3VsZEJsb2NrKHtcbiAgICAgIGN1cnJlbnRMb2NhdGlvbjogX2V4dGVuZHMoe30sIGN1cnJlbnRMb2NhdGlvbiwge1xuICAgICAgICBwYXRobmFtZTogc3RyaXBCYXNlbmFtZShjdXJyZW50TG9jYXRpb24ucGF0aG5hbWUsIGJhc2VuYW1lKSB8fCBjdXJyZW50TG9jYXRpb24ucGF0aG5hbWVcbiAgICAgIH0pLFxuICAgICAgbmV4dExvY2F0aW9uOiBfZXh0ZW5kcyh7fSwgbmV4dExvY2F0aW9uLCB7XG4gICAgICAgIHBhdGhuYW1lOiBzdHJpcEJhc2VuYW1lKG5leHRMb2NhdGlvbi5wYXRobmFtZSwgYmFzZW5hbWUpIHx8IG5leHRMb2NhdGlvbi5wYXRobmFtZVxuICAgICAgfSksXG4gICAgICBoaXN0b3J5QWN0aW9uXG4gICAgfSk7XG4gIH0sIFtiYXNlbmFtZSwgc2hvdWxkQmxvY2tdKTtcblxuICAvLyBUaGlzIGVmZmVjdCBpcyBpbiBjaGFyZ2Ugb2YgYmxvY2tlciBrZXkgYXNzaWdubWVudCBhbmQgZGVsZXRpb24gKHdoaWNoIGlzXG4gIC8vIHRpZ2h0bHkgY291cGxlZCB0byB0aGUga2V5KVxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBrZXkgPSBTdHJpbmcoKytibG9ja2VySWQpO1xuICAgIHNldEJsb2NrZXJLZXkoa2V5KTtcbiAgICByZXR1cm4gKCkgPT4gcm91dGVyLmRlbGV0ZUJsb2NrZXIoa2V5KTtcbiAgfSwgW3JvdXRlcl0pO1xuXG4gIC8vIFRoaXMgZWZmZWN0IGhhbmRsZXMgYXNzaWduaW5nIHRoZSBibG9ja2VyRnVuY3Rpb24uICBUaGlzIGlzIHRvIGhhbmRsZVxuICAvLyB1bnN0YWJsZSBibG9ja2VyIGZ1bmN0aW9uIGlkZW50aXRpZXMsIGFuZCBoYXBwZW5zIG9ubHkgYWZ0ZXIgdGhlIHByaW9yXG4gIC8vIGVmZmVjdCBzbyB3ZSBkb24ndCBnZXQgYW4gb3JwaGFuZWQgYmxvY2tlckZ1bmN0aW9uIGluIHRoZSByb3V0ZXIgd2l0aCBhXG4gIC8vIGtleSBvZiBcIlwiLiAgVW50aWwgdGhlbiB3ZSBqdXN0IGhhdmUgdGhlIElETEVfQkxPQ0tFUi5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYmxvY2tlcktleSAhPT0gXCJcIikge1xuICAgICAgcm91dGVyLmdldEJsb2NrZXIoYmxvY2tlcktleSwgYmxvY2tlckZ1bmN0aW9uKTtcbiAgICB9XG4gIH0sIFtyb3V0ZXIsIGJsb2NrZXJLZXksIGJsb2NrZXJGdW5jdGlvbl0pO1xuXG4gIC8vIFByZWZlciB0aGUgYmxvY2tlciBmcm9tIGBzdGF0ZWAgbm90IGByb3V0ZXIuc3RhdGVgIHNpbmNlIERhdGFSb3V0ZXJDb250ZXh0XG4gIC8vIGlzIG1lbW9pemVkIHNvIHRoaXMgZW5zdXJlcyB3ZSB1cGRhdGUgb24gYmxvY2tlciBzdGF0ZSB1cGRhdGVzXG4gIHJldHVybiBibG9ja2VyS2V5ICYmIHN0YXRlLmJsb2NrZXJzLmhhcyhibG9ja2VyS2V5KSA/IHN0YXRlLmJsb2NrZXJzLmdldChibG9ja2VyS2V5KSA6IElETEVfQkxPQ0tFUjtcbn1cblxuLyoqXG4gKiBTdGFibGUgdmVyc2lvbiBvZiB1c2VOYXZpZ2F0ZSB0aGF0IGlzIHVzZWQgd2hlbiB3ZSBhcmUgaW4gdGhlIGNvbnRleHQgb2ZcbiAqIGEgUm91dGVyUHJvdmlkZXIuXG4gKi9cbmZ1bmN0aW9uIHVzZU5hdmlnYXRlU3RhYmxlKCkge1xuICBsZXQge1xuICAgIHJvdXRlclxuICB9ID0gdXNlRGF0YVJvdXRlckNvbnRleHQoRGF0YVJvdXRlckhvb2suVXNlTmF2aWdhdGVTdGFibGUpO1xuICBsZXQgaWQgPSB1c2VDdXJyZW50Um91dGVJZChEYXRhUm91dGVyU3RhdGVIb29rLlVzZU5hdmlnYXRlU3RhYmxlKTtcbiAgbGV0IGFjdGl2ZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGFjdGl2ZVJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgfSk7XG4gIGxldCBuYXZpZ2F0ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKGZ1bmN0aW9uICh0bywgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICB9XG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcoYWN0aXZlUmVmLmN1cnJlbnQsIG5hdmlnYXRlRWZmZWN0V2FybmluZykgOiB2b2lkIDA7XG5cbiAgICAvLyBTaG9ydCBjaXJjdWl0IGhlcmUgc2luY2UgaWYgdGhpcyBoYXBwZW5zIG9uIGZpcnN0IHJlbmRlciB0aGUgbmF2aWdhdGVcbiAgICAvLyBpcyB1c2VsZXNzIGJlY2F1c2Ugd2UgaGF2ZW4ndCB3aXJlZCB1cCBvdXIgcm91dGVyIHN1YnNjcmliZXIgeWV0XG4gICAgaWYgKCFhY3RpdmVSZWYuY3VycmVudCkgcmV0dXJuO1xuICAgIGlmICh0eXBlb2YgdG8gPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHJvdXRlci5uYXZpZ2F0ZSh0byk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJvdXRlci5uYXZpZ2F0ZSh0bywgX2V4dGVuZHMoe1xuICAgICAgICBmcm9tUm91dGVJZDogaWRcbiAgICAgIH0sIG9wdGlvbnMpKTtcbiAgICB9XG4gIH0sIFtyb3V0ZXIsIGlkXSk7XG4gIHJldHVybiBuYXZpZ2F0ZTtcbn1cbmNvbnN0IGFscmVhZHlXYXJuZWQkMSA9IHt9O1xuZnVuY3Rpb24gd2FybmluZ09uY2Uoa2V5LCBjb25kLCBtZXNzYWdlKSB7XG4gIGlmICghY29uZCAmJiAhYWxyZWFkeVdhcm5lZCQxW2tleV0pIHtcbiAgICBhbHJlYWR5V2FybmVkJDFba2V5XSA9IHRydWU7XG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcoZmFsc2UsIG1lc3NhZ2UpIDogdm9pZCAwO1xuICB9XG59XG5cbmNvbnN0IGFscmVhZHlXYXJuZWQgPSB7fTtcbmZ1bmN0aW9uIHdhcm5PbmNlKGtleSwgbWVzc2FnZSkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFhbHJlYWR5V2FybmVkW21lc3NhZ2VdKSB7XG4gICAgYWxyZWFkeVdhcm5lZFttZXNzYWdlXSA9IHRydWU7XG4gICAgY29uc29sZS53YXJuKG1lc3NhZ2UpO1xuICB9XG59XG5jb25zdCBsb2dEZXByZWNhdGlvbiA9IChmbGFnLCBtc2csIGxpbmspID0+IHdhcm5PbmNlKGZsYWcsIFwiXFx1MjZBMFxcdUZFMEYgUmVhY3QgUm91dGVyIEZ1dHVyZSBGbGFnIFdhcm5pbmc6IFwiICsgbXNnICsgXCIuIFwiICsgKFwiWW91IGNhbiB1c2UgdGhlIGBcIiArIGZsYWcgKyBcImAgZnV0dXJlIGZsYWcgdG8gb3B0LWluIGVhcmx5LiBcIikgKyAoXCJGb3IgbW9yZSBpbmZvcm1hdGlvbiwgc2VlIFwiICsgbGluayArIFwiLlwiKSk7XG5mdW5jdGlvbiBsb2dWNkRlcHJlY2F0aW9uV2FybmluZ3MocmVuZGVyRnV0dXJlLCByb3V0ZXJGdXR1cmUpIHtcbiAgaWYgKChyZW5kZXJGdXR1cmUgPT0gbnVsbCA/IHZvaWQgMCA6IHJlbmRlckZ1dHVyZS52N19zdGFydFRyYW5zaXRpb24pID09PSB1bmRlZmluZWQpIHtcbiAgICBsb2dEZXByZWNhdGlvbihcInY3X3N0YXJ0VHJhbnNpdGlvblwiLCBcIlJlYWN0IFJvdXRlciB3aWxsIGJlZ2luIHdyYXBwaW5nIHN0YXRlIHVwZGF0ZXMgaW4gYFJlYWN0LnN0YXJ0VHJhbnNpdGlvbmAgaW4gdjdcIiwgXCJodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91cGdyYWRpbmcvZnV0dXJlI3Y3X3N0YXJ0dHJhbnNpdGlvblwiKTtcbiAgfVxuICBpZiAoKHJlbmRlckZ1dHVyZSA9PSBudWxsID8gdm9pZCAwIDogcmVuZGVyRnV0dXJlLnY3X3JlbGF0aXZlU3BsYXRQYXRoKSA9PT0gdW5kZWZpbmVkICYmICghcm91dGVyRnV0dXJlIHx8IHJvdXRlckZ1dHVyZS52N19yZWxhdGl2ZVNwbGF0UGF0aCA9PT0gdW5kZWZpbmVkKSkge1xuICAgIGxvZ0RlcHJlY2F0aW9uKFwidjdfcmVsYXRpdmVTcGxhdFBhdGhcIiwgXCJSZWxhdGl2ZSByb3V0ZSByZXNvbHV0aW9uIHdpdGhpbiBTcGxhdCByb3V0ZXMgaXMgY2hhbmdpbmcgaW4gdjdcIiwgXCJodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91cGdyYWRpbmcvZnV0dXJlI3Y3X3JlbGF0aXZlc3BsYXRwYXRoXCIpO1xuICB9XG4gIGlmIChyb3V0ZXJGdXR1cmUpIHtcbiAgICBpZiAocm91dGVyRnV0dXJlLnY3X2ZldGNoZXJQZXJzaXN0ID09PSB1bmRlZmluZWQpIHtcbiAgICAgIGxvZ0RlcHJlY2F0aW9uKFwidjdfZmV0Y2hlclBlcnNpc3RcIiwgXCJUaGUgcGVyc2lzdGVuY2UgYmVoYXZpb3Igb2YgZmV0Y2hlcnMgaXMgY2hhbmdpbmcgaW4gdjdcIiwgXCJodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91cGdyYWRpbmcvZnV0dXJlI3Y3X2ZldGNoZXJwZXJzaXN0XCIpO1xuICAgIH1cbiAgICBpZiAocm91dGVyRnV0dXJlLnY3X25vcm1hbGl6ZUZvcm1NZXRob2QgPT09IHVuZGVmaW5lZCkge1xuICAgICAgbG9nRGVwcmVjYXRpb24oXCJ2N19ub3JtYWxpemVGb3JtTWV0aG9kXCIsIFwiQ2FzaW5nIG9mIGBmb3JtTWV0aG9kYCBmaWVsZHMgaXMgYmVpbmcgbm9ybWFsaXplZCB0byB1cHBlcmNhc2UgaW4gdjdcIiwgXCJodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91cGdyYWRpbmcvZnV0dXJlI3Y3X25vcm1hbGl6ZWZvcm1tZXRob2RcIik7XG4gICAgfVxuICAgIGlmIChyb3V0ZXJGdXR1cmUudjdfcGFydGlhbEh5ZHJhdGlvbiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBsb2dEZXByZWNhdGlvbihcInY3X3BhcnRpYWxIeWRyYXRpb25cIiwgXCJgUm91dGVyUHJvdmlkZXJgIGh5ZHJhdGlvbiBiZWhhdmlvciBpcyBjaGFuZ2luZyBpbiB2N1wiLCBcImh0dHBzOi8vcmVhY3Ryb3V0ZXIuY29tL3Y2L3VwZ3JhZGluZy9mdXR1cmUjdjdfcGFydGlhbGh5ZHJhdGlvblwiKTtcbiAgICB9XG4gICAgaWYgKHJvdXRlckZ1dHVyZS52N19za2lwQWN0aW9uRXJyb3JSZXZhbGlkYXRpb24gPT09IHVuZGVmaW5lZCkge1xuICAgICAgbG9nRGVwcmVjYXRpb24oXCJ2N19za2lwQWN0aW9uRXJyb3JSZXZhbGlkYXRpb25cIiwgXCJUaGUgcmV2YWxpZGF0aW9uIGJlaGF2aW9yIGFmdGVyIDR4eC81eHggYGFjdGlvbmAgcmVzcG9uc2VzIGlzIGNoYW5naW5nIGluIHY3XCIsIFwiaHR0cHM6Ly9yZWFjdHJvdXRlci5jb20vdjYvdXBncmFkaW5nL2Z1dHVyZSN2N19za2lwYWN0aW9uZXJyb3JyZXZhbGlkYXRpb25cIik7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICBXZWJwYWNrICsgUmVhY3QgMTcgZmFpbHMgdG8gY29tcGlsZSBvbiBhbnkgb2YgdGhlIGZvbGxvd2luZyBiZWNhdXNlIHdlYnBhY2tcbiAgY29tcGxhaW5zIHRoYXQgYHN0YXJ0VHJhbnNpdGlvbmAgZG9lc24ndCBleGlzdCBpbiBgUmVhY3RgOlxuICAqIGltcG9ydCB7IHN0YXJ0VHJhbnNpdGlvbiB9IGZyb20gXCJyZWFjdFwiXG4gICogaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBmcm9tIFwicmVhY3RcIjtcbiAgICBcInN0YXJ0VHJhbnNpdGlvblwiIGluIFJlYWN0ID8gUmVhY3Quc3RhcnRUcmFuc2l0aW9uKCgpID0+IHNldFN0YXRlKCkpIDogc2V0U3RhdGUoKVxuICAqIGltcG9ydCAqIGFzIFJlYWN0IGZyb20gZnJvbSBcInJlYWN0XCI7XG4gICAgXCJzdGFydFRyYW5zaXRpb25cIiBpbiBSZWFjdCA/IFJlYWN0W1wic3RhcnRUcmFuc2l0aW9uXCJdKCgpID0+IHNldFN0YXRlKCkpIDogc2V0U3RhdGUoKVxuXG4gIE1vdmluZyBpdCB0byBhIGNvbnN0YW50IHN1Y2ggYXMgdGhlIGZvbGxvd2luZyBzb2x2ZXMgdGhlIFdlYnBhY2svUmVhY3QgMTcgaXNzdWU6XG4gICogaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBmcm9tIFwicmVhY3RcIjtcbiAgICBjb25zdCBTVEFSVF9UUkFOU0lUSU9OID0gXCJzdGFydFRyYW5zaXRpb25cIjtcbiAgICBTVEFSVF9UUkFOU0lUSU9OIGluIFJlYWN0ID8gUmVhY3RbU1RBUlRfVFJBTlNJVElPTl0oKCkgPT4gc2V0U3RhdGUoKSkgOiBzZXRTdGF0ZSgpXG5cbiAgSG93ZXZlciwgdGhhdCBpbnRyb2R1Y2VzIHdlYnBhY2svdGVyc2VyIG1pbmlmaWNhdGlvbiBpc3N1ZXMgaW4gcHJvZHVjdGlvbiBidWlsZHNcbiAgaW4gUmVhY3QgMTggd2hlcmUgbWluaWZpY2F0aW9uL29iZnVzY2F0aW9uIGVuZHMgdXAgcmVtb3ZpbmcgdGhlIGNhbGwgb2ZcbiAgUmVhY3Quc3RhcnRUcmFuc2l0aW9uIGVudGlyZWx5IGZyb20gdGhlIGZpcnN0IGhhbGYgb2YgdGhlIHRlcm5hcnkuICBHcmFiYmluZ1xuICB0aGlzIGV4cG9ydGVkIHJlZmVyZW5jZSBvbmNlIHVwIGZyb250IHJlc29sdmVzIHRoYXQgaXNzdWUuXG5cbiAgU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9yZW1peC1ydW4vcmVhY3Qtcm91dGVyL2lzc3Vlcy8xMDU3OVxuKi9cbmNvbnN0IFNUQVJUX1RSQU5TSVRJT04gPSBcInN0YXJ0VHJhbnNpdGlvblwiO1xuY29uc3Qgc3RhcnRUcmFuc2l0aW9uSW1wbCA9IFJlYWN0W1NUQVJUX1RSQU5TSVRJT05dO1xuXG4vKipcbiAqIEdpdmVuIGEgUmVtaXggUm91dGVyIGluc3RhbmNlLCByZW5kZXIgdGhlIGFwcHJvcHJpYXRlIFVJXG4gKi9cbmZ1bmN0aW9uIFJvdXRlclByb3ZpZGVyKF9yZWYpIHtcbiAgbGV0IHtcbiAgICBmYWxsYmFja0VsZW1lbnQsXG4gICAgcm91dGVyLFxuICAgIGZ1dHVyZVxuICB9ID0gX3JlZjtcbiAgbGV0IFtzdGF0ZSwgc2V0U3RhdGVJbXBsXSA9IFJlYWN0LnVzZVN0YXRlKHJvdXRlci5zdGF0ZSk7XG4gIGxldCB7XG4gICAgdjdfc3RhcnRUcmFuc2l0aW9uXG4gIH0gPSBmdXR1cmUgfHwge307XG4gIGxldCBzZXRTdGF0ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKG5ld1N0YXRlID0+IHtcbiAgICBpZiAodjdfc3RhcnRUcmFuc2l0aW9uICYmIHN0YXJ0VHJhbnNpdGlvbkltcGwpIHtcbiAgICAgIHN0YXJ0VHJhbnNpdGlvbkltcGwoKCkgPT4gc2V0U3RhdGVJbXBsKG5ld1N0YXRlKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFN0YXRlSW1wbChuZXdTdGF0ZSk7XG4gICAgfVxuICB9LCBbc2V0U3RhdGVJbXBsLCB2N19zdGFydFRyYW5zaXRpb25dKTtcblxuICAvLyBOZWVkIHRvIHVzZSBhIGxheW91dCBlZmZlY3QgaGVyZSBzbyB3ZSBhcmUgc3Vic2NyaWJlZCBlYXJseSBlbm91Z2ggdG9cbiAgLy8gcGljayB1cCBvbiBhbnkgcmVuZGVyLWRyaXZlbiByZWRpcmVjdHMvbmF2aWdhdGlvbnMgKHVzZUVmZmVjdC88TmF2aWdhdGU+KVxuICBSZWFjdC51c2VMYXlvdXRFZmZlY3QoKCkgPT4gcm91dGVyLnN1YnNjcmliZShzZXRTdGF0ZSksIFtyb3V0ZXIsIHNldFN0YXRlXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcoZmFsbGJhY2tFbGVtZW50ID09IG51bGwgfHwgIXJvdXRlci5mdXR1cmUudjdfcGFydGlhbEh5ZHJhdGlvbiwgXCJgPFJvdXRlclByb3ZpZGVyIGZhbGxiYWNrRWxlbWVudD5gIGlzIGRlcHJlY2F0ZWQgd2hlbiB1c2luZyBcIiArIFwiYHY3X3BhcnRpYWxIeWRyYXRpb25gLCB1c2UgYSBgSHlkcmF0ZUZhbGxiYWNrYCBjb21wb25lbnQgaW5zdGVhZFwiKSA6IHZvaWQgMDtcbiAgICAvLyBPbmx5IGxvZyB0aGlzIG9uY2Ugb24gaW5pdGlhbCBtb3VudFxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW10pO1xuICBsZXQgbmF2aWdhdG9yID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNyZWF0ZUhyZWY6IHJvdXRlci5jcmVhdGVIcmVmLFxuICAgICAgZW5jb2RlTG9jYXRpb246IHJvdXRlci5lbmNvZGVMb2NhdGlvbixcbiAgICAgIGdvOiBuID0+IHJvdXRlci5uYXZpZ2F0ZShuKSxcbiAgICAgIHB1c2g6ICh0bywgc3RhdGUsIG9wdHMpID0+IHJvdXRlci5uYXZpZ2F0ZSh0bywge1xuICAgICAgICBzdGF0ZSxcbiAgICAgICAgcHJldmVudFNjcm9sbFJlc2V0OiBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLnByZXZlbnRTY3JvbGxSZXNldFxuICAgICAgfSksXG4gICAgICByZXBsYWNlOiAodG8sIHN0YXRlLCBvcHRzKSA9PiByb3V0ZXIubmF2aWdhdGUodG8sIHtcbiAgICAgICAgcmVwbGFjZTogdHJ1ZSxcbiAgICAgICAgc3RhdGUsXG4gICAgICAgIHByZXZlbnRTY3JvbGxSZXNldDogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5wcmV2ZW50U2Nyb2xsUmVzZXRcbiAgICAgIH0pXG4gICAgfTtcbiAgfSwgW3JvdXRlcl0pO1xuICBsZXQgYmFzZW5hbWUgPSByb3V0ZXIuYmFzZW5hbWUgfHwgXCIvXCI7XG4gIGxldCBkYXRhUm91dGVyQ29udGV4dCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICByb3V0ZXIsXG4gICAgbmF2aWdhdG9yLFxuICAgIHN0YXRpYzogZmFsc2UsXG4gICAgYmFzZW5hbWVcbiAgfSksIFtyb3V0ZXIsIG5hdmlnYXRvciwgYmFzZW5hbWVdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IGxvZ1Y2RGVwcmVjYXRpb25XYXJuaW5ncyhmdXR1cmUsIHJvdXRlci5mdXR1cmUpLCBbcm91dGVyLCBmdXR1cmVdKTtcblxuICAvLyBUaGUgZnJhZ21lbnQgYW5kIHtudWxsfSBoZXJlIGFyZSBpbXBvcnRhbnQhICBXZSBuZWVkIHRoZW0gdG8ga2VlcCBSZWFjdCAxOCdzXG4gIC8vIHVzZUlkIGhhcHB5IHdoZW4gd2UgYXJlIHNlcnZlci1yZW5kZXJpbmcgc2luY2Ugd2UgbWF5IGhhdmUgYSA8c2NyaXB0PiBoZXJlXG4gIC8vIGNvbnRhaW5pbmcgdGhlIGh5ZHJhdGVkIHNlcnZlci1zaWRlIHN0YXRpY0NvbnRleHQgKGZyb20gU3RhdGljUm91dGVyUHJvdmlkZXIpLlxuICAvLyB1c2VJZCByZWxpZXMgb24gdGhlIGNvbXBvbmVudCB0cmVlIHN0cnVjdHVyZSB0byBnZW5lcmF0ZSBkZXRlcm1pbmlzdGljIGlkJ3NcbiAgLy8gc28gd2UgbmVlZCB0byBlbnN1cmUgaXQgcmVtYWlucyB0aGUgc2FtZSBvbiB0aGUgY2xpZW50IGV2ZW4gdGhvdWdoXG4gIC8vIHdlIGRvbid0IG5lZWQgdGhlIDxzY3JpcHQ+IHRhZ1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KERhdGFSb3V0ZXJDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IGRhdGFSb3V0ZXJDb250ZXh0XG4gIH0sIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KERhdGFSb3V0ZXJTdGF0ZUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogc3RhdGVcbiAgfSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGVyLCB7XG4gICAgYmFzZW5hbWU6IGJhc2VuYW1lLFxuICAgIGxvY2F0aW9uOiBzdGF0ZS5sb2NhdGlvbixcbiAgICBuYXZpZ2F0aW9uVHlwZTogc3RhdGUuaGlzdG9yeUFjdGlvbixcbiAgICBuYXZpZ2F0b3I6IG5hdmlnYXRvcixcbiAgICBmdXR1cmU6IHtcbiAgICAgIHY3X3JlbGF0aXZlU3BsYXRQYXRoOiByb3V0ZXIuZnV0dXJlLnY3X3JlbGF0aXZlU3BsYXRQYXRoXG4gICAgfVxuICB9LCBzdGF0ZS5pbml0aWFsaXplZCB8fCByb3V0ZXIuZnV0dXJlLnY3X3BhcnRpYWxIeWRyYXRpb24gPyAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChEYXRhUm91dGVzLCB7XG4gICAgcm91dGVzOiByb3V0ZXIucm91dGVzLFxuICAgIGZ1dHVyZTogcm91dGVyLmZ1dHVyZSxcbiAgICBzdGF0ZTogc3RhdGVcbiAgfSkgOiBmYWxsYmFja0VsZW1lbnQpKSksIG51bGwpO1xufVxuZnVuY3Rpb24gRGF0YVJvdXRlcyhfcmVmMikge1xuICBsZXQge1xuICAgIHJvdXRlcyxcbiAgICBmdXR1cmUsXG4gICAgc3RhdGVcbiAgfSA9IF9yZWYyO1xuICByZXR1cm4gdXNlUm91dGVzSW1wbChyb3V0ZXMsIHVuZGVmaW5lZCwgc3RhdGUsIGZ1dHVyZSk7XG59XG4vKipcbiAqIEEgYDxSb3V0ZXI+YCB0aGF0IHN0b3JlcyBhbGwgZW50cmllcyBpbiBtZW1vcnkuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9yb3V0ZXItY29tcG9uZW50cy9tZW1vcnktcm91dGVyXG4gKi9cbmZ1bmN0aW9uIE1lbW9yeVJvdXRlcihfcmVmMykge1xuICBsZXQge1xuICAgIGJhc2VuYW1lLFxuICAgIGNoaWxkcmVuLFxuICAgIGluaXRpYWxFbnRyaWVzLFxuICAgIGluaXRpYWxJbmRleCxcbiAgICBmdXR1cmVcbiAgfSA9IF9yZWYzO1xuICBsZXQgaGlzdG9yeVJlZiA9IFJlYWN0LnVzZVJlZigpO1xuICBpZiAoaGlzdG9yeVJlZi5jdXJyZW50ID09IG51bGwpIHtcbiAgICBoaXN0b3J5UmVmLmN1cnJlbnQgPSBjcmVhdGVNZW1vcnlIaXN0b3J5KHtcbiAgICAgIGluaXRpYWxFbnRyaWVzLFxuICAgICAgaW5pdGlhbEluZGV4LFxuICAgICAgdjVDb21wYXQ6IHRydWVcbiAgICB9KTtcbiAgfVxuICBsZXQgaGlzdG9yeSA9IGhpc3RvcnlSZWYuY3VycmVudDtcbiAgbGV0IFtzdGF0ZSwgc2V0U3RhdGVJbXBsXSA9IFJlYWN0LnVzZVN0YXRlKHtcbiAgICBhY3Rpb246IGhpc3RvcnkuYWN0aW9uLFxuICAgIGxvY2F0aW9uOiBoaXN0b3J5LmxvY2F0aW9uXG4gIH0pO1xuICBsZXQge1xuICAgIHY3X3N0YXJ0VHJhbnNpdGlvblxuICB9ID0gZnV0dXJlIHx8IHt9O1xuICBsZXQgc2V0U3RhdGUgPSBSZWFjdC51c2VDYWxsYmFjayhuZXdTdGF0ZSA9PiB7XG4gICAgdjdfc3RhcnRUcmFuc2l0aW9uICYmIHN0YXJ0VHJhbnNpdGlvbkltcGwgPyBzdGFydFRyYW5zaXRpb25JbXBsKCgpID0+IHNldFN0YXRlSW1wbChuZXdTdGF0ZSkpIDogc2V0U3RhdGVJbXBsKG5ld1N0YXRlKTtcbiAgfSwgW3NldFN0YXRlSW1wbCwgdjdfc3RhcnRUcmFuc2l0aW9uXSk7XG4gIFJlYWN0LnVzZUxheW91dEVmZmVjdCgoKSA9PiBoaXN0b3J5Lmxpc3RlbihzZXRTdGF0ZSksIFtoaXN0b3J5LCBzZXRTdGF0ZV0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gbG9nVjZEZXByZWNhdGlvbldhcm5pbmdzKGZ1dHVyZSksIFtmdXR1cmVdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJvdXRlciwge1xuICAgIGJhc2VuYW1lOiBiYXNlbmFtZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW4sXG4gICAgbG9jYXRpb246IHN0YXRlLmxvY2F0aW9uLFxuICAgIG5hdmlnYXRpb25UeXBlOiBzdGF0ZS5hY3Rpb24sXG4gICAgbmF2aWdhdG9yOiBoaXN0b3J5LFxuICAgIGZ1dHVyZTogZnV0dXJlXG4gIH0pO1xufVxuLyoqXG4gKiBDaGFuZ2VzIHRoZSBjdXJyZW50IGxvY2F0aW9uLlxuICpcbiAqIE5vdGU6IFRoaXMgQVBJIGlzIG1vc3RseSB1c2VmdWwgaW4gUmVhY3QuQ29tcG9uZW50IHN1YmNsYXNzZXMgdGhhdCBhcmUgbm90XG4gKiBhYmxlIHRvIHVzZSBob29rcy4gSW4gZnVuY3Rpb25hbCBjb21wb25lbnRzLCB3ZSByZWNvbW1lbmQgeW91IHVzZSB0aGVcbiAqIGB1c2VOYXZpZ2F0ZWAgaG9vayBpbnN0ZWFkLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9yZWFjdHJvdXRlci5jb20vdjYvY29tcG9uZW50cy9uYXZpZ2F0ZVxuICovXG5mdW5jdGlvbiBOYXZpZ2F0ZShfcmVmNCkge1xuICBsZXQge1xuICAgIHRvLFxuICAgIHJlcGxhY2UsXG4gICAgc3RhdGUsXG4gICAgcmVsYXRpdmVcbiAgfSA9IF9yZWY0O1xuICAhdXNlSW5Sb3V0ZXJDb250ZXh0KCkgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCAvLyBUT0RPOiBUaGlzIGVycm9yIGlzIHByb2JhYmx5IGJlY2F1c2UgdGhleSBzb21laG93IGhhdmUgMiB2ZXJzaW9ucyBvZlxuICAvLyB0aGUgcm91dGVyIGxvYWRlZC4gV2UgY2FuIGhlbHAgdGhlbSB1bmRlcnN0YW5kIGhvdyB0byBhdm9pZCB0aGF0LlxuICBcIjxOYXZpZ2F0ZT4gbWF5IGJlIHVzZWQgb25seSBpbiB0aGUgY29udGV4dCBvZiBhIDxSb3V0ZXI+IGNvbXBvbmVudC5cIikgOiBVTlNBRkVfaW52YXJpYW50KGZhbHNlKSA6IHZvaWQgMDtcbiAgbGV0IHtcbiAgICBmdXR1cmUsXG4gICAgc3RhdGljOiBpc1N0YXRpY1xuICB9ID0gUmVhY3QudXNlQ29udGV4dChOYXZpZ2F0aW9uQ29udGV4dCk7XG4gIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV93YXJuaW5nKCFpc1N0YXRpYywgXCI8TmF2aWdhdGU+IG11c3Qgbm90IGJlIHVzZWQgb24gdGhlIGluaXRpYWwgcmVuZGVyIGluIGEgPFN0YXRpY1JvdXRlcj4uIFwiICsgXCJUaGlzIGlzIGEgbm8tb3AsIGJ1dCB5b3Ugc2hvdWxkIG1vZGlmeSB5b3VyIGNvZGUgc28gdGhlIDxOYXZpZ2F0ZT4gaXMgXCIgKyBcIm9ubHkgZXZlciByZW5kZXJlZCBpbiByZXNwb25zZSB0byBzb21lIHVzZXIgaW50ZXJhY3Rpb24gb3Igc3RhdGUgY2hhbmdlLlwiKSA6IHZvaWQgMDtcbiAgbGV0IHtcbiAgICBtYXRjaGVzXG4gIH0gPSBSZWFjdC51c2VDb250ZXh0KFJvdXRlQ29udGV4dCk7XG4gIGxldCB7XG4gICAgcGF0aG5hbWU6IGxvY2F0aW9uUGF0aG5hbWVcbiAgfSA9IHVzZUxvY2F0aW9uKCk7XG4gIGxldCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG5cbiAgLy8gUmVzb2x2ZSB0aGUgcGF0aCBvdXRzaWRlIG9mIHRoZSBlZmZlY3Qgc28gdGhhdCB3aGVuIGVmZmVjdHMgcnVuIHR3aWNlIGluXG4gIC8vIFN0cmljdE1vZGUgdGhleSBuYXZpZ2F0ZSB0byB0aGUgc2FtZSBwbGFjZVxuICBsZXQgcGF0aCA9IHJlc29sdmVUbyh0bywgVU5TQUZFX2dldFJlc29sdmVUb01hdGNoZXMobWF0Y2hlcywgZnV0dXJlLnY3X3JlbGF0aXZlU3BsYXRQYXRoKSwgbG9jYXRpb25QYXRobmFtZSwgcmVsYXRpdmUgPT09IFwicGF0aFwiKTtcbiAgbGV0IGpzb25QYXRoID0gSlNPTi5zdHJpbmdpZnkocGF0aCk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiBuYXZpZ2F0ZShKU09OLnBhcnNlKGpzb25QYXRoKSwge1xuICAgIHJlcGxhY2UsXG4gICAgc3RhdGUsXG4gICAgcmVsYXRpdmVcbiAgfSksIFtuYXZpZ2F0ZSwganNvblBhdGgsIHJlbGF0aXZlLCByZXBsYWNlLCBzdGF0ZV0pO1xuICByZXR1cm4gbnVsbDtcbn1cbi8qKlxuICogUmVuZGVycyB0aGUgY2hpbGQgcm91dGUncyBlbGVtZW50LCBpZiB0aGVyZSBpcyBvbmUuXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9jb21wb25lbnRzL291dGxldFxuICovXG5mdW5jdGlvbiBPdXRsZXQocHJvcHMpIHtcbiAgcmV0dXJuIHVzZU91dGxldChwcm9wcy5jb250ZXh0KTtcbn1cbi8qKlxuICogRGVjbGFyZXMgYW4gZWxlbWVudCB0aGF0IHNob3VsZCBiZSByZW5kZXJlZCBhdCBhIGNlcnRhaW4gVVJMIHBhdGguXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni9jb21wb25lbnRzL3JvdXRlXG4gKi9cbmZ1bmN0aW9uIFJvdXRlKF9wcm9wcykge1xuICBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCBcIkEgPFJvdXRlPiBpcyBvbmx5IGV2ZXIgdG8gYmUgdXNlZCBhcyB0aGUgY2hpbGQgb2YgPFJvdXRlcz4gZWxlbWVudCwgXCIgKyBcIm5ldmVyIHJlbmRlcmVkIGRpcmVjdGx5LiBQbGVhc2Ugd3JhcCB5b3VyIDxSb3V0ZT4gaW4gYSA8Um91dGVzPi5cIikgOiBVTlNBRkVfaW52YXJpYW50KGZhbHNlKSA7XG59XG4vKipcbiAqIFByb3ZpZGVzIGxvY2F0aW9uIGNvbnRleHQgZm9yIHRoZSByZXN0IG9mIHRoZSBhcHAuXG4gKlxuICogTm90ZTogWW91IHVzdWFsbHkgd29uJ3QgcmVuZGVyIGEgYDxSb3V0ZXI+YCBkaXJlY3RseS4gSW5zdGVhZCwgeW91J2xsIHJlbmRlciBhXG4gKiByb3V0ZXIgdGhhdCBpcyBtb3JlIHNwZWNpZmljIHRvIHlvdXIgZW52aXJvbm1lbnQgc3VjaCBhcyBhIGA8QnJvd3NlclJvdXRlcj5gXG4gKiBpbiB3ZWIgYnJvd3NlcnMgb3IgYSBgPFN0YXRpY1JvdXRlcj5gIGZvciBzZXJ2ZXIgcmVuZGVyaW5nLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9yZWFjdHJvdXRlci5jb20vdjYvcm91dGVyLWNvbXBvbmVudHMvcm91dGVyXG4gKi9cbmZ1bmN0aW9uIFJvdXRlcihfcmVmNSkge1xuICBsZXQge1xuICAgIGJhc2VuYW1lOiBiYXNlbmFtZVByb3AgPSBcIi9cIixcbiAgICBjaGlsZHJlbiA9IG51bGwsXG4gICAgbG9jYXRpb246IGxvY2F0aW9uUHJvcCxcbiAgICBuYXZpZ2F0aW9uVHlwZSA9IEFjdGlvbi5Qb3AsXG4gICAgbmF2aWdhdG9yLFxuICAgIHN0YXRpYzogc3RhdGljUHJvcCA9IGZhbHNlLFxuICAgIGZ1dHVyZVxuICB9ID0gX3JlZjU7XG4gICEhdXNlSW5Sb3V0ZXJDb250ZXh0KCkgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCBcIllvdSBjYW5ub3QgcmVuZGVyIGEgPFJvdXRlcj4gaW5zaWRlIGFub3RoZXIgPFJvdXRlcj4uXCIgKyBcIiBZb3Ugc2hvdWxkIG5ldmVyIGhhdmUgbW9yZSB0aGFuIG9uZSBpbiB5b3VyIGFwcC5cIikgOiBVTlNBRkVfaW52YXJpYW50KGZhbHNlKSA6IHZvaWQgMDtcblxuICAvLyBQcmVzZXJ2ZSB0cmFpbGluZyBzbGFzaGVzIG9uIGJhc2VuYW1lLCBzbyB3ZSBjYW4gbGV0IHRoZSB1c2VyIGNvbnRyb2xcbiAgLy8gdGhlIGVuZm9yY2VtZW50IG9mIHRyYWlsaW5nIHNsYXNoZXMgdGhyb3VnaG91dCB0aGUgYXBwXG4gIGxldCBiYXNlbmFtZSA9IGJhc2VuYW1lUHJvcC5yZXBsYWNlKC9eXFwvKi8sIFwiL1wiKTtcbiAgbGV0IG5hdmlnYXRpb25Db250ZXh0ID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIGJhc2VuYW1lLFxuICAgIG5hdmlnYXRvcixcbiAgICBzdGF0aWM6IHN0YXRpY1Byb3AsXG4gICAgZnV0dXJlOiBfZXh0ZW5kcyh7XG4gICAgICB2N19yZWxhdGl2ZVNwbGF0UGF0aDogZmFsc2VcbiAgICB9LCBmdXR1cmUpXG4gIH0pLCBbYmFzZW5hbWUsIGZ1dHVyZSwgbmF2aWdhdG9yLCBzdGF0aWNQcm9wXSk7XG4gIGlmICh0eXBlb2YgbG9jYXRpb25Qcm9wID09PSBcInN0cmluZ1wiKSB7XG4gICAgbG9jYXRpb25Qcm9wID0gcGFyc2VQYXRoKGxvY2F0aW9uUHJvcCk7XG4gIH1cbiAgbGV0IHtcbiAgICBwYXRobmFtZSA9IFwiL1wiLFxuICAgIHNlYXJjaCA9IFwiXCIsXG4gICAgaGFzaCA9IFwiXCIsXG4gICAgc3RhdGUgPSBudWxsLFxuICAgIGtleSA9IFwiZGVmYXVsdFwiXG4gIH0gPSBsb2NhdGlvblByb3A7XG4gIGxldCBsb2NhdGlvbkNvbnRleHQgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBsZXQgdHJhaWxpbmdQYXRobmFtZSA9IHN0cmlwQmFzZW5hbWUocGF0aG5hbWUsIGJhc2VuYW1lKTtcbiAgICBpZiAodHJhaWxpbmdQYXRobmFtZSA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgIHBhdGhuYW1lOiB0cmFpbGluZ1BhdGhuYW1lLFxuICAgICAgICBzZWFyY2gsXG4gICAgICAgIGhhc2gsXG4gICAgICAgIHN0YXRlLFxuICAgICAgICBrZXlcbiAgICAgIH0sXG4gICAgICBuYXZpZ2F0aW9uVHlwZVxuICAgIH07XG4gIH0sIFtiYXNlbmFtZSwgcGF0aG5hbWUsIHNlYXJjaCwgaGFzaCwgc3RhdGUsIGtleSwgbmF2aWdhdGlvblR5cGVdKTtcbiAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcobG9jYXRpb25Db250ZXh0ICE9IG51bGwsIFwiPFJvdXRlciBiYXNlbmFtZT1cXFwiXCIgKyBiYXNlbmFtZSArIFwiXFxcIj4gaXMgbm90IGFibGUgdG8gbWF0Y2ggdGhlIFVSTCBcIiArIChcIlxcXCJcIiArIHBhdGhuYW1lICsgc2VhcmNoICsgaGFzaCArIFwiXFxcIiBiZWNhdXNlIGl0IGRvZXMgbm90IHN0YXJ0IHdpdGggdGhlIFwiKSArIFwiYmFzZW5hbWUsIHNvIHRoZSA8Um91dGVyPiB3b24ndCByZW5kZXIgYW55dGhpbmcuXCIpIDogdm9pZCAwO1xuICBpZiAobG9jYXRpb25Db250ZXh0ID09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTmF2aWdhdGlvbkNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogbmF2aWdhdGlvbkNvbnRleHRcbiAgfSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoTG9jYXRpb25Db250ZXh0LlByb3ZpZGVyLCB7XG4gICAgY2hpbGRyZW46IGNoaWxkcmVuLFxuICAgIHZhbHVlOiBsb2NhdGlvbkNvbnRleHRcbiAgfSkpO1xufVxuLyoqXG4gKiBBIGNvbnRhaW5lciBmb3IgYSBuZXN0ZWQgdHJlZSBvZiBgPFJvdXRlPmAgZWxlbWVudHMgdGhhdCByZW5kZXJzIHRoZSBicmFuY2hcbiAqIHRoYXQgYmVzdCBtYXRjaGVzIHRoZSBjdXJyZW50IGxvY2F0aW9uLlxuICpcbiAqIEBzZWUgaHR0cHM6Ly9yZWFjdHJvdXRlci5jb20vdjYvY29tcG9uZW50cy9yb3V0ZXNcbiAqL1xuZnVuY3Rpb24gUm91dGVzKF9yZWY2KSB7XG4gIGxldCB7XG4gICAgY2hpbGRyZW4sXG4gICAgbG9jYXRpb25cbiAgfSA9IF9yZWY2O1xuICByZXR1cm4gdXNlUm91dGVzKGNyZWF0ZVJvdXRlc0Zyb21DaGlsZHJlbihjaGlsZHJlbiksIGxvY2F0aW9uKTtcbn1cbi8qKlxuICogQ29tcG9uZW50IHRvIHVzZSBmb3IgcmVuZGVyaW5nIGxhemlseSBsb2FkZWQgZGF0YSBmcm9tIHJldHVybmluZyBkZWZlcigpXG4gKiBpbiBhIGxvYWRlciBmdW5jdGlvblxuICovXG5mdW5jdGlvbiBBd2FpdChfcmVmNykge1xuICBsZXQge1xuICAgIGNoaWxkcmVuLFxuICAgIGVycm9yRWxlbWVudCxcbiAgICByZXNvbHZlXG4gIH0gPSBfcmVmNztcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEF3YWl0RXJyb3JCb3VuZGFyeSwge1xuICAgIHJlc29sdmU6IHJlc29sdmUsXG4gICAgZXJyb3JFbGVtZW50OiBlcnJvckVsZW1lbnRcbiAgfSwgLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVzb2x2ZUF3YWl0LCBudWxsLCBjaGlsZHJlbikpO1xufVxudmFyIEF3YWl0UmVuZGVyU3RhdHVzID0gLyojX19QVVJFX18qL2Z1bmN0aW9uIChBd2FpdFJlbmRlclN0YXR1cykge1xuICBBd2FpdFJlbmRlclN0YXR1c1tBd2FpdFJlbmRlclN0YXR1c1tcInBlbmRpbmdcIl0gPSAwXSA9IFwicGVuZGluZ1wiO1xuICBBd2FpdFJlbmRlclN0YXR1c1tBd2FpdFJlbmRlclN0YXR1c1tcInN1Y2Nlc3NcIl0gPSAxXSA9IFwic3VjY2Vzc1wiO1xuICBBd2FpdFJlbmRlclN0YXR1c1tBd2FpdFJlbmRlclN0YXR1c1tcImVycm9yXCJdID0gMl0gPSBcImVycm9yXCI7XG4gIHJldHVybiBBd2FpdFJlbmRlclN0YXR1cztcbn0oQXdhaXRSZW5kZXJTdGF0dXMgfHwge30pO1xuY29uc3QgbmV2ZXJTZXR0bGVkUHJvbWlzZSA9IG5ldyBQcm9taXNlKCgpID0+IHt9KTtcbmNsYXNzIEF3YWl0RXJyb3JCb3VuZGFyeSBleHRlbmRzIFJlYWN0LkNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKHByb3BzKSB7XG4gICAgc3VwZXIocHJvcHMpO1xuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBlcnJvcjogbnVsbFxuICAgIH07XG4gIH1cbiAgc3RhdGljIGdldERlcml2ZWRTdGF0ZUZyb21FcnJvcihlcnJvcikge1xuICAgIHJldHVybiB7XG4gICAgICBlcnJvclxuICAgIH07XG4gIH1cbiAgY29tcG9uZW50RGlkQ2F0Y2goZXJyb3IsIGVycm9ySW5mbykge1xuICAgIGNvbnNvbGUuZXJyb3IoXCI8QXdhaXQ+IGNhdWdodCB0aGUgZm9sbG93aW5nIGVycm9yIGR1cmluZyByZW5kZXJcIiwgZXJyb3IsIGVycm9ySW5mbyk7XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIGxldCB7XG4gICAgICBjaGlsZHJlbixcbiAgICAgIGVycm9yRWxlbWVudCxcbiAgICAgIHJlc29sdmVcbiAgICB9ID0gdGhpcy5wcm9wcztcbiAgICBsZXQgcHJvbWlzZSA9IG51bGw7XG4gICAgbGV0IHN0YXR1cyA9IEF3YWl0UmVuZGVyU3RhdHVzLnBlbmRpbmc7XG4gICAgaWYgKCEocmVzb2x2ZSBpbnN0YW5jZW9mIFByb21pc2UpKSB7XG4gICAgICAvLyBEaWRuJ3QgZ2V0IGEgcHJvbWlzZSAtIHByb3ZpZGUgYXMgYSByZXNvbHZlZCBwcm9taXNlXG4gICAgICBzdGF0dXMgPSBBd2FpdFJlbmRlclN0YXR1cy5zdWNjZXNzO1xuICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHByb21pc2UsIFwiX3RyYWNrZWRcIiwge1xuICAgICAgICBnZXQ6ICgpID0+IHRydWVcbiAgICAgIH0pO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHByb21pc2UsIFwiX2RhdGFcIiwge1xuICAgICAgICBnZXQ6ICgpID0+IHJlc29sdmVcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAodGhpcy5zdGF0ZS5lcnJvcikge1xuICAgICAgLy8gQ2F1Z2h0IGEgcmVuZGVyIGVycm9yLCBwcm92aWRlIGl0IGFzIGEgcmVqZWN0ZWQgcHJvbWlzZVxuICAgICAgc3RhdHVzID0gQXdhaXRSZW5kZXJTdGF0dXMuZXJyb3I7XG4gICAgICBsZXQgcmVuZGVyRXJyb3IgPSB0aGlzLnN0YXRlLmVycm9yO1xuICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVqZWN0KCkuY2F0Y2goKCkgPT4ge30pOyAvLyBBdm9pZCB1bmhhbmRsZWQgcmVqZWN0aW9uIHdhcm5pbmdzXG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocHJvbWlzZSwgXCJfdHJhY2tlZFwiLCB7XG4gICAgICAgIGdldDogKCkgPT4gdHJ1ZVxuICAgICAgfSk7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocHJvbWlzZSwgXCJfZXJyb3JcIiwge1xuICAgICAgICBnZXQ6ICgpID0+IHJlbmRlckVycm9yXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHJlc29sdmUuX3RyYWNrZWQpIHtcbiAgICAgIC8vIEFscmVhZHkgdHJhY2tlZCBwcm9taXNlIC0gY2hlY2sgY29udGVudHNcbiAgICAgIHByb21pc2UgPSByZXNvbHZlO1xuICAgICAgc3RhdHVzID0gXCJfZXJyb3JcIiBpbiBwcm9taXNlID8gQXdhaXRSZW5kZXJTdGF0dXMuZXJyb3IgOiBcIl9kYXRhXCIgaW4gcHJvbWlzZSA/IEF3YWl0UmVuZGVyU3RhdHVzLnN1Y2Nlc3MgOiBBd2FpdFJlbmRlclN0YXR1cy5wZW5kaW5nO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBSYXcgKHVudHJhY2tlZCkgcHJvbWlzZSAtIHRyYWNrIGl0XG4gICAgICBzdGF0dXMgPSBBd2FpdFJlbmRlclN0YXR1cy5wZW5kaW5nO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlc29sdmUsIFwiX3RyYWNrZWRcIiwge1xuICAgICAgICBnZXQ6ICgpID0+IHRydWVcbiAgICAgIH0pO1xuICAgICAgcHJvbWlzZSA9IHJlc29sdmUudGhlbihkYXRhID0+IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXNvbHZlLCBcIl9kYXRhXCIsIHtcbiAgICAgICAgZ2V0OiAoKSA9PiBkYXRhXG4gICAgICB9KSwgZXJyb3IgPT4gT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlc29sdmUsIFwiX2Vycm9yXCIsIHtcbiAgICAgICAgZ2V0OiAoKSA9PiBlcnJvclxuICAgICAgfSkpO1xuICAgIH1cbiAgICBpZiAoc3RhdHVzID09PSBBd2FpdFJlbmRlclN0YXR1cy5lcnJvciAmJiBwcm9taXNlLl9lcnJvciBpbnN0YW5jZW9mIEFib3J0ZWREZWZlcnJlZEVycm9yKSB7XG4gICAgICAvLyBGcmVlemUgdGhlIFVJIGJ5IHRocm93aW5nIGEgbmV2ZXIgcmVzb2x2ZWQgcHJvbWlzZVxuICAgICAgdGhyb3cgbmV2ZXJTZXR0bGVkUHJvbWlzZTtcbiAgICB9XG4gICAgaWYgKHN0YXR1cyA9PT0gQXdhaXRSZW5kZXJTdGF0dXMuZXJyb3IgJiYgIWVycm9yRWxlbWVudCkge1xuICAgICAgLy8gTm8gZXJyb3JFbGVtZW50LCB0aHJvdyB0byB0aGUgbmVhcmVzdCByb3V0ZS1sZXZlbCBlcnJvciBib3VuZGFyeVxuICAgICAgdGhyb3cgcHJvbWlzZS5fZXJyb3I7XG4gICAgfVxuICAgIGlmIChzdGF0dXMgPT09IEF3YWl0UmVuZGVyU3RhdHVzLmVycm9yKSB7XG4gICAgICAvLyBSZW5kZXIgdmlhIG91ciBlcnJvckVsZW1lbnRcbiAgICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChBd2FpdENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICAgICAgdmFsdWU6IHByb21pc2UsXG4gICAgICAgIGNoaWxkcmVuOiBlcnJvckVsZW1lbnRcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoc3RhdHVzID09PSBBd2FpdFJlbmRlclN0YXR1cy5zdWNjZXNzKSB7XG4gICAgICAvLyBSZW5kZXIgY2hpbGRyZW4gd2l0aCByZXNvbHZlZCB2YWx1ZVxuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KEF3YWl0Q29udGV4dC5Qcm92aWRlciwge1xuICAgICAgICB2YWx1ZTogcHJvbWlzZSxcbiAgICAgICAgY2hpbGRyZW46IGNoaWxkcmVuXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBUaHJvdyB0byB0aGUgc3VzcGVuc2UgYm91bmRhcnlcbiAgICB0aHJvdyBwcm9taXNlO1xuICB9XG59XG5cbi8qKlxuICogQHByaXZhdGVcbiAqIEluZGlyZWN0aW9uIHRvIGxldmVyYWdlIHVzZUFzeW5jVmFsdWUgZm9yIGEgcmVuZGVyLXByb3AgQVBJIG9uIGA8QXdhaXQ+YFxuICovXG5mdW5jdGlvbiBSZXNvbHZlQXdhaXQoX3JlZjgpIHtcbiAgbGV0IHtcbiAgICBjaGlsZHJlblxuICB9ID0gX3JlZjg7XG4gIGxldCBkYXRhID0gdXNlQXN5bmNWYWx1ZSgpO1xuICBsZXQgdG9SZW5kZXIgPSB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKGRhdGEpIDogY2hpbGRyZW47XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwgbnVsbCwgdG9SZW5kZXIpO1xufVxuXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vLyBVVElMU1xuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4vKipcbiAqIENyZWF0ZXMgYSByb3V0ZSBjb25maWcgZnJvbSBhIFJlYWN0IFwiY2hpbGRyZW5cIiBvYmplY3QsIHdoaWNoIGlzIHVzdWFsbHlcbiAqIGVpdGhlciBhIGA8Um91dGU+YCBlbGVtZW50IG9yIGFuIGFycmF5IG9mIHRoZW0uIFVzZWQgaW50ZXJuYWxseSBieVxuICogYDxSb3V0ZXM+YCB0byBjcmVhdGUgYSByb3V0ZSBjb25maWcgZnJvbSBpdHMgY2hpbGRyZW4uXG4gKlxuICogQHNlZSBodHRwczovL3JlYWN0cm91dGVyLmNvbS92Ni91dGlscy9jcmVhdGUtcm91dGVzLWZyb20tY2hpbGRyZW5cbiAqL1xuZnVuY3Rpb24gY3JlYXRlUm91dGVzRnJvbUNoaWxkcmVuKGNoaWxkcmVuLCBwYXJlbnRQYXRoKSB7XG4gIGlmIChwYXJlbnRQYXRoID09PSB2b2lkIDApIHtcbiAgICBwYXJlbnRQYXRoID0gW107XG4gIH1cbiAgbGV0IHJvdXRlcyA9IFtdO1xuICBSZWFjdC5DaGlsZHJlbi5mb3JFYWNoKGNoaWxkcmVuLCAoZWxlbWVudCwgaW5kZXgpID0+IHtcbiAgICBpZiAoISAvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQoZWxlbWVudCkpIHtcbiAgICAgIC8vIElnbm9yZSBub24tZWxlbWVudHMuIFRoaXMgYWxsb3dzIHBlb3BsZSB0byBtb3JlIGVhc2lseSBpbmxpbmVcbiAgICAgIC8vIGNvbmRpdGlvbmFscyBpbiB0aGVpciByb3V0ZSBjb25maWcuXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCB0cmVlUGF0aCA9IFsuLi5wYXJlbnRQYXRoLCBpbmRleF07XG4gICAgaWYgKGVsZW1lbnQudHlwZSA9PT0gUmVhY3QuRnJhZ21lbnQpIHtcbiAgICAgIC8vIFRyYW5zcGFyZW50bHkgc3VwcG9ydCBSZWFjdC5GcmFnbWVudCBhbmQgaXRzIGNoaWxkcmVuLlxuICAgICAgcm91dGVzLnB1c2guYXBwbHkocm91dGVzLCBjcmVhdGVSb3V0ZXNGcm9tQ2hpbGRyZW4oZWxlbWVudC5wcm9wcy5jaGlsZHJlbiwgdHJlZVBhdGgpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgIShlbGVtZW50LnR5cGUgPT09IFJvdXRlKSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIFwiW1wiICsgKHR5cGVvZiBlbGVtZW50LnR5cGUgPT09IFwic3RyaW5nXCIgPyBlbGVtZW50LnR5cGUgOiBlbGVtZW50LnR5cGUubmFtZSkgKyBcIl0gaXMgbm90IGEgPFJvdXRlPiBjb21wb25lbnQuIEFsbCBjb21wb25lbnQgY2hpbGRyZW4gb2YgPFJvdXRlcz4gbXVzdCBiZSBhIDxSb3V0ZT4gb3IgPFJlYWN0LkZyYWdtZW50PlwiKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICAgICEoIWVsZW1lbnQucHJvcHMuaW5kZXggfHwgIWVsZW1lbnQucHJvcHMuY2hpbGRyZW4pID8gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX2ludmFyaWFudChmYWxzZSwgXCJBbiBpbmRleCByb3V0ZSBjYW5ub3QgaGF2ZSBjaGlsZCByb3V0ZXMuXCIpIDogVU5TQUZFX2ludmFyaWFudChmYWxzZSkgOiB2b2lkIDA7XG4gICAgbGV0IHJvdXRlID0ge1xuICAgICAgaWQ6IGVsZW1lbnQucHJvcHMuaWQgfHwgdHJlZVBhdGguam9pbihcIi1cIiksXG4gICAgICBjYXNlU2Vuc2l0aXZlOiBlbGVtZW50LnByb3BzLmNhc2VTZW5zaXRpdmUsXG4gICAgICBlbGVtZW50OiBlbGVtZW50LnByb3BzLmVsZW1lbnQsXG4gICAgICBDb21wb25lbnQ6IGVsZW1lbnQucHJvcHMuQ29tcG9uZW50LFxuICAgICAgaW5kZXg6IGVsZW1lbnQucHJvcHMuaW5kZXgsXG4gICAgICBwYXRoOiBlbGVtZW50LnByb3BzLnBhdGgsXG4gICAgICBsb2FkZXI6IGVsZW1lbnQucHJvcHMubG9hZGVyLFxuICAgICAgYWN0aW9uOiBlbGVtZW50LnByb3BzLmFjdGlvbixcbiAgICAgIGVycm9yRWxlbWVudDogZWxlbWVudC5wcm9wcy5lcnJvckVsZW1lbnQsXG4gICAgICBFcnJvckJvdW5kYXJ5OiBlbGVtZW50LnByb3BzLkVycm9yQm91bmRhcnksXG4gICAgICBoYXNFcnJvckJvdW5kYXJ5OiBlbGVtZW50LnByb3BzLkVycm9yQm91bmRhcnkgIT0gbnVsbCB8fCBlbGVtZW50LnByb3BzLmVycm9yRWxlbWVudCAhPSBudWxsLFxuICAgICAgc2hvdWxkUmV2YWxpZGF0ZTogZWxlbWVudC5wcm9wcy5zaG91bGRSZXZhbGlkYXRlLFxuICAgICAgaGFuZGxlOiBlbGVtZW50LnByb3BzLmhhbmRsZSxcbiAgICAgIGxhenk6IGVsZW1lbnQucHJvcHMubGF6eVxuICAgIH07XG4gICAgaWYgKGVsZW1lbnQucHJvcHMuY2hpbGRyZW4pIHtcbiAgICAgIHJvdXRlLmNoaWxkcmVuID0gY3JlYXRlUm91dGVzRnJvbUNoaWxkcmVuKGVsZW1lbnQucHJvcHMuY2hpbGRyZW4sIHRyZWVQYXRoKTtcbiAgICB9XG4gICAgcm91dGVzLnB1c2gocm91dGUpO1xuICB9KTtcbiAgcmV0dXJuIHJvdXRlcztcbn1cblxuLyoqXG4gKiBSZW5kZXJzIHRoZSByZXN1bHQgb2YgYG1hdGNoUm91dGVzKClgIGludG8gYSBSZWFjdCBlbGVtZW50LlxuICovXG5mdW5jdGlvbiByZW5kZXJNYXRjaGVzKG1hdGNoZXMpIHtcbiAgcmV0dXJuIF9yZW5kZXJNYXRjaGVzKG1hdGNoZXMpO1xufVxuXG5mdW5jdGlvbiBtYXBSb3V0ZVByb3BlcnRpZXMocm91dGUpIHtcbiAgbGV0IHVwZGF0ZXMgPSB7XG4gICAgLy8gTm90ZTogdGhpcyBjaGVjayBhbHNvIG9jY3VycyBpbiBjcmVhdGVSb3V0ZXNGcm9tQ2hpbGRyZW4gc28gdXBkYXRlXG4gICAgLy8gdGhlcmUgaWYgeW91IGNoYW5nZSB0aGlzIC0tIHBsZWFzZSBhbmQgdGhhbmsgeW91IVxuICAgIGhhc0Vycm9yQm91bmRhcnk6IHJvdXRlLkVycm9yQm91bmRhcnkgIT0gbnVsbCB8fCByb3V0ZS5lcnJvckVsZW1lbnQgIT0gbnVsbFxuICB9O1xuICBpZiAocm91dGUuQ29tcG9uZW50KSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgaWYgKHJvdXRlLmVsZW1lbnQpIHtcbiAgICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcoZmFsc2UsIFwiWW91IHNob3VsZCBub3QgaW5jbHVkZSBib3RoIGBDb21wb25lbnRgIGFuZCBgZWxlbWVudGAgb24geW91ciByb3V0ZSAtIFwiICsgXCJgQ29tcG9uZW50YCB3aWxsIGJlIHVzZWQuXCIpIDogdm9pZCAwO1xuICAgICAgfVxuICAgIH1cbiAgICBPYmplY3QuYXNzaWduKHVwZGF0ZXMsIHtcbiAgICAgIGVsZW1lbnQ6IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KHJvdXRlLkNvbXBvbmVudCksXG4gICAgICBDb21wb25lbnQ6IHVuZGVmaW5lZFxuICAgIH0pO1xuICB9XG4gIGlmIChyb3V0ZS5IeWRyYXRlRmFsbGJhY2spIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBpZiAocm91dGUuaHlkcmF0ZUZhbGxiYWNrRWxlbWVudCkge1xuICAgICAgICBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfd2FybmluZyhmYWxzZSwgXCJZb3Ugc2hvdWxkIG5vdCBpbmNsdWRlIGJvdGggYEh5ZHJhdGVGYWxsYmFja2AgYW5kIGBoeWRyYXRlRmFsbGJhY2tFbGVtZW50YCBvbiB5b3VyIHJvdXRlIC0gXCIgKyBcImBIeWRyYXRlRmFsbGJhY2tgIHdpbGwgYmUgdXNlZC5cIikgOiB2b2lkIDA7XG4gICAgICB9XG4gICAgfVxuICAgIE9iamVjdC5hc3NpZ24odXBkYXRlcywge1xuICAgICAgaHlkcmF0ZUZhbGxiYWNrRWxlbWVudDogLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQocm91dGUuSHlkcmF0ZUZhbGxiYWNrKSxcbiAgICAgIEh5ZHJhdGVGYWxsYmFjazogdW5kZWZpbmVkXG4gICAgfSk7XG4gIH1cbiAgaWYgKHJvdXRlLkVycm9yQm91bmRhcnkpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBpZiAocm91dGUuZXJyb3JFbGVtZW50KSB7XG4gICAgICAgIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV93YXJuaW5nKGZhbHNlLCBcIllvdSBzaG91bGQgbm90IGluY2x1ZGUgYm90aCBgRXJyb3JCb3VuZGFyeWAgYW5kIGBlcnJvckVsZW1lbnRgIG9uIHlvdXIgcm91dGUgLSBcIiArIFwiYEVycm9yQm91bmRhcnlgIHdpbGwgYmUgdXNlZC5cIikgOiB2b2lkIDA7XG4gICAgICB9XG4gICAgfVxuICAgIE9iamVjdC5hc3NpZ24odXBkYXRlcywge1xuICAgICAgZXJyb3JFbGVtZW50OiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChyb3V0ZS5FcnJvckJvdW5kYXJ5KSxcbiAgICAgIEVycm9yQm91bmRhcnk6IHVuZGVmaW5lZFxuICAgIH0pO1xuICB9XG4gIHJldHVybiB1cGRhdGVzO1xufVxuZnVuY3Rpb24gY3JlYXRlTWVtb3J5Um91dGVyKHJvdXRlcywgb3B0cykge1xuICByZXR1cm4gY3JlYXRlUm91dGVyKHtcbiAgICBiYXNlbmFtZTogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5iYXNlbmFtZSxcbiAgICBmdXR1cmU6IF9leHRlbmRzKHt9LCBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLmZ1dHVyZSwge1xuICAgICAgdjdfcHJlcGVuZEJhc2VuYW1lOiB0cnVlXG4gICAgfSksXG4gICAgaGlzdG9yeTogY3JlYXRlTWVtb3J5SGlzdG9yeSh7XG4gICAgICBpbml0aWFsRW50cmllczogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5pbml0aWFsRW50cmllcyxcbiAgICAgIGluaXRpYWxJbmRleDogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5pbml0aWFsSW5kZXhcbiAgICB9KSxcbiAgICBoeWRyYXRpb25EYXRhOiBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLmh5ZHJhdGlvbkRhdGEsXG4gICAgcm91dGVzLFxuICAgIG1hcFJvdXRlUHJvcGVydGllcyxcbiAgICBkYXRhU3RyYXRlZ3k6IG9wdHMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdHMuZGF0YVN0cmF0ZWd5LFxuICAgIHBhdGNoUm91dGVzT25OYXZpZ2F0aW9uOiBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLnBhdGNoUm91dGVzT25OYXZpZ2F0aW9uXG4gIH0pLmluaXRpYWxpemUoKTtcbn1cblxuZXhwb3J0IHsgQXdhaXQsIE1lbW9yeVJvdXRlciwgTmF2aWdhdGUsIE91dGxldCwgUm91dGUsIFJvdXRlciwgUm91dGVyUHJvdmlkZXIsIFJvdXRlcywgRGF0YVJvdXRlckNvbnRleHQgYXMgVU5TQUZFX0RhdGFSb3V0ZXJDb250ZXh0LCBEYXRhUm91dGVyU3RhdGVDb250ZXh0IGFzIFVOU0FGRV9EYXRhUm91dGVyU3RhdGVDb250ZXh0LCBMb2NhdGlvbkNvbnRleHQgYXMgVU5TQUZFX0xvY2F0aW9uQ29udGV4dCwgTmF2aWdhdGlvbkNvbnRleHQgYXMgVU5TQUZFX05hdmlnYXRpb25Db250ZXh0LCBSb3V0ZUNvbnRleHQgYXMgVU5TQUZFX1JvdXRlQ29udGV4dCwgbG9nVjZEZXByZWNhdGlvbldhcm5pbmdzIGFzIFVOU0FGRV9sb2dWNkRlcHJlY2F0aW9uV2FybmluZ3MsIG1hcFJvdXRlUHJvcGVydGllcyBhcyBVTlNBRkVfbWFwUm91dGVQcm9wZXJ0aWVzLCB1c2VSb3V0ZUlkIGFzIFVOU0FGRV91c2VSb3V0ZUlkLCB1c2VSb3V0ZXNJbXBsIGFzIFVOU0FGRV91c2VSb3V0ZXNJbXBsLCBjcmVhdGVNZW1vcnlSb3V0ZXIsIGNyZWF0ZVJvdXRlc0Zyb21DaGlsZHJlbiwgY3JlYXRlUm91dGVzRnJvbUNoaWxkcmVuIGFzIGNyZWF0ZVJvdXRlc0Zyb21FbGVtZW50cywgcmVuZGVyTWF0Y2hlcywgdXNlQWN0aW9uRGF0YSwgdXNlQXN5bmNFcnJvciwgdXNlQXN5bmNWYWx1ZSwgdXNlQmxvY2tlciwgdXNlSHJlZiwgdXNlSW5Sb3V0ZXJDb250ZXh0LCB1c2VMb2FkZXJEYXRhLCB1c2VMb2NhdGlvbiwgdXNlTWF0Y2gsIHVzZU1hdGNoZXMsIHVzZU5hdmlnYXRlLCB1c2VOYXZpZ2F0aW9uLCB1c2VOYXZpZ2F0aW9uVHlwZSwgdXNlT3V0bGV0LCB1c2VPdXRsZXRDb250ZXh0LCB1c2VQYXJhbXMsIHVzZVJlc29sdmVkUGF0aCwgdXNlUmV2YWxpZGF0b3IsIHVzZVJvdXRlRXJyb3IsIHVzZVJvdXRlTG9hZGVyRGF0YSwgdXNlUm91dGVzIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXBcbiIsIi8qKlxuICogUmVhY3QgUm91dGVyIERPTSB2Ni4zMC40XG4gKlxuICogQ29weXJpZ2h0IChjKSBSZW1peCBTb2Z0d2FyZSBJbmMuXG4gKlxuICogVGhpcyBzb3VyY2UgY29kZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UgZm91bmQgaW4gdGhlXG4gKiBMSUNFTlNFLm1kIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKlxuICogQGxpY2Vuc2UgTUlUXG4gKi9cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCAqIGFzIFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBVTlNBRkVfbWFwUm91dGVQcm9wZXJ0aWVzLCBVTlNBRkVfbG9nVjZEZXByZWNhdGlvbldhcm5pbmdzLCBVTlNBRkVfRGF0YVJvdXRlckNvbnRleHQsIFVOU0FGRV9EYXRhUm91dGVyU3RhdGVDb250ZXh0LCBSb3V0ZXIsIFVOU0FGRV91c2VSb3V0ZXNJbXBsLCBVTlNBRkVfTmF2aWdhdGlvbkNvbnRleHQsIHVzZUhyZWYsIHVzZVJlc29sdmVkUGF0aCwgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCBjcmVhdGVQYXRoLCBVTlNBRkVfdXNlUm91dGVJZCwgVU5TQUZFX1JvdXRlQ29udGV4dCwgdXNlTWF0Y2hlcywgdXNlTmF2aWdhdGlvbiwgdXNlQmxvY2tlciB9IGZyb20gJ3JlYWN0LXJvdXRlcic7XG5leHBvcnQgeyBBYm9ydGVkRGVmZXJyZWRFcnJvciwgQXdhaXQsIE1lbW9yeVJvdXRlciwgTmF2aWdhdGUsIE5hdmlnYXRpb25UeXBlLCBPdXRsZXQsIFJvdXRlLCBSb3V0ZXIsIFJvdXRlcywgVU5TQUZFX0RhdGFSb3V0ZXJDb250ZXh0LCBVTlNBRkVfRGF0YVJvdXRlclN0YXRlQ29udGV4dCwgVU5TQUZFX0xvY2F0aW9uQ29udGV4dCwgVU5TQUZFX05hdmlnYXRpb25Db250ZXh0LCBVTlNBRkVfUm91dGVDb250ZXh0LCBVTlNBRkVfdXNlUm91dGVJZCwgY3JlYXRlTWVtb3J5Um91dGVyLCBjcmVhdGVQYXRoLCBjcmVhdGVSb3V0ZXNGcm9tQ2hpbGRyZW4sIGNyZWF0ZVJvdXRlc0Zyb21FbGVtZW50cywgZGVmZXIsIGdlbmVyYXRlUGF0aCwgaXNSb3V0ZUVycm9yUmVzcG9uc2UsIGpzb24sIG1hdGNoUGF0aCwgbWF0Y2hSb3V0ZXMsIHBhcnNlUGF0aCwgcmVkaXJlY3QsIHJlZGlyZWN0RG9jdW1lbnQsIHJlbmRlck1hdGNoZXMsIHJlcGxhY2UsIHJlc29sdmVQYXRoLCB1c2VBY3Rpb25EYXRhLCB1c2VBc3luY0Vycm9yLCB1c2VBc3luY1ZhbHVlLCB1c2VCbG9ja2VyLCB1c2VIcmVmLCB1c2VJblJvdXRlckNvbnRleHQsIHVzZUxvYWRlckRhdGEsIHVzZUxvY2F0aW9uLCB1c2VNYXRjaCwgdXNlTWF0Y2hlcywgdXNlTmF2aWdhdGUsIHVzZU5hdmlnYXRpb24sIHVzZU5hdmlnYXRpb25UeXBlLCB1c2VPdXRsZXQsIHVzZU91dGxldENvbnRleHQsIHVzZVBhcmFtcywgdXNlUmVzb2x2ZWRQYXRoLCB1c2VSZXZhbGlkYXRvciwgdXNlUm91dGVFcnJvciwgdXNlUm91dGVMb2FkZXJEYXRhLCB1c2VSb3V0ZXMgfSBmcm9tICdyZWFjdC1yb3V0ZXInO1xuaW1wb3J0IHsgc3RyaXBCYXNlbmFtZSwgVU5TQUZFX3dhcm5pbmcsIGNyZWF0ZVJvdXRlciwgY3JlYXRlQnJvd3Nlckhpc3RvcnksIGNyZWF0ZUhhc2hIaXN0b3J5LCBVTlNBRkVfRXJyb3JSZXNwb25zZUltcGwsIFVOU0FGRV9pbnZhcmlhbnQsIGpvaW5QYXRocywgSURMRV9GRVRDSEVSLCBtYXRjaFBhdGggfSBmcm9tICdAcmVtaXgtcnVuL3JvdXRlcic7XG5leHBvcnQgeyBVTlNBRkVfRXJyb3JSZXNwb25zZUltcGwgfSBmcm9tICdAcmVtaXgtcnVuL3JvdXRlcic7XG5cbmZ1bmN0aW9uIF9leHRlbmRzKCkge1xuICByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikge1xuICAgIGZvciAodmFyIGUgPSAxOyBlIDwgYXJndW1lbnRzLmxlbmd0aDsgZSsrKSB7XG4gICAgICB2YXIgdCA9IGFyZ3VtZW50c1tlXTtcbiAgICAgIGZvciAodmFyIHIgaW4gdCkgKHt9KS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHQsIHIpICYmIChuW3JdID0gdFtyXSk7XG4gICAgfVxuICAgIHJldHVybiBuO1xuICB9LCBfZXh0ZW5kcy5hcHBseShudWxsLCBhcmd1bWVudHMpO1xufVxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UociwgZSkge1xuICBpZiAobnVsbCA9PSByKSByZXR1cm4ge307XG4gIHZhciB0ID0ge307XG4gIGZvciAodmFyIG4gaW4gcikgaWYgKHt9Lmhhc093blByb3BlcnR5LmNhbGwociwgbikpIHtcbiAgICBpZiAoLTEgIT09IGUuaW5kZXhPZihuKSkgY29udGludWU7XG4gICAgdFtuXSA9IHJbbl07XG4gIH1cbiAgcmV0dXJuIHQ7XG59XG5cbmNvbnN0IGRlZmF1bHRNZXRob2QgPSBcImdldFwiO1xuY29uc3QgZGVmYXVsdEVuY1R5cGUgPSBcImFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFwiO1xuZnVuY3Rpb24gaXNIdG1sRWxlbWVudChvYmplY3QpIHtcbiAgcmV0dXJuIG9iamVjdCAhPSBudWxsICYmIHR5cGVvZiBvYmplY3QudGFnTmFtZSA9PT0gXCJzdHJpbmdcIjtcbn1cbmZ1bmN0aW9uIGlzQnV0dG9uRWxlbWVudChvYmplY3QpIHtcbiAgcmV0dXJuIGlzSHRtbEVsZW1lbnQob2JqZWN0KSAmJiBvYmplY3QudGFnTmFtZS50b0xvd2VyQ2FzZSgpID09PSBcImJ1dHRvblwiO1xufVxuZnVuY3Rpb24gaXNGb3JtRWxlbWVudChvYmplY3QpIHtcbiAgcmV0dXJuIGlzSHRtbEVsZW1lbnQob2JqZWN0KSAmJiBvYmplY3QudGFnTmFtZS50b0xvd2VyQ2FzZSgpID09PSBcImZvcm1cIjtcbn1cbmZ1bmN0aW9uIGlzSW5wdXRFbGVtZW50KG9iamVjdCkge1xuICByZXR1cm4gaXNIdG1sRWxlbWVudChvYmplY3QpICYmIG9iamVjdC50YWdOYW1lLnRvTG93ZXJDYXNlKCkgPT09IFwiaW5wdXRcIjtcbn1cbmZ1bmN0aW9uIGlzTW9kaWZpZWRFdmVudChldmVudCkge1xuICByZXR1cm4gISEoZXZlbnQubWV0YUtleSB8fCBldmVudC5hbHRLZXkgfHwgZXZlbnQuY3RybEtleSB8fCBldmVudC5zaGlmdEtleSk7XG59XG5mdW5jdGlvbiBzaG91bGRQcm9jZXNzTGlua0NsaWNrKGV2ZW50LCB0YXJnZXQpIHtcbiAgcmV0dXJuIGV2ZW50LmJ1dHRvbiA9PT0gMCAmJiAoXG4gIC8vIElnbm9yZSBldmVyeXRoaW5nIGJ1dCBsZWZ0IGNsaWNrc1xuICAhdGFyZ2V0IHx8IHRhcmdldCA9PT0gXCJfc2VsZlwiKSAmJlxuICAvLyBMZXQgYnJvd3NlciBoYW5kbGUgXCJ0YXJnZXQ9X2JsYW5rXCIgZXRjLlxuICAhaXNNb2RpZmllZEV2ZW50KGV2ZW50KSAvLyBJZ25vcmUgY2xpY2tzIHdpdGggbW9kaWZpZXIga2V5c1xuO1xufVxuLyoqXG4gKiBDcmVhdGVzIGEgVVJMU2VhcmNoUGFyYW1zIG9iamVjdCB1c2luZyB0aGUgZ2l2ZW4gaW5pdGlhbGl6ZXIuXG4gKlxuICogVGhpcyBpcyBpZGVudGljYWwgdG8gYG5ldyBVUkxTZWFyY2hQYXJhbXMoaW5pdClgIGV4Y2VwdCBpdCBhbHNvXG4gKiBzdXBwb3J0cyBhcnJheXMgYXMgdmFsdWVzIGluIHRoZSBvYmplY3QgZm9ybSBvZiB0aGUgaW5pdGlhbGl6ZXJcbiAqIGluc3RlYWQgb2YganVzdCBzdHJpbmdzLiBUaGlzIGlzIGNvbnZlbmllbnQgd2hlbiB5b3UgbmVlZCBtdWx0aXBsZVxuICogdmFsdWVzIGZvciBhIGdpdmVuIGtleSwgYnV0IGRvbid0IHdhbnQgdG8gdXNlIGFuIGFycmF5IGluaXRpYWxpemVyLlxuICpcbiAqIEZvciBleGFtcGxlLCBpbnN0ZWFkIG9mOlxuICpcbiAqICAgbGV0IHNlYXJjaFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoW1xuICogICAgIFsnc29ydCcsICduYW1lJ10sXG4gKiAgICAgWydzb3J0JywgJ3ByaWNlJ11cbiAqICAgXSk7XG4gKlxuICogeW91IGNhbiBkbzpcbiAqXG4gKiAgIGxldCBzZWFyY2hQYXJhbXMgPSBjcmVhdGVTZWFyY2hQYXJhbXMoe1xuICogICAgIHNvcnQ6IFsnbmFtZScsICdwcmljZSddXG4gKiAgIH0pO1xuICovXG5mdW5jdGlvbiBjcmVhdGVTZWFyY2hQYXJhbXMoaW5pdCkge1xuICBpZiAoaW5pdCA9PT0gdm9pZCAwKSB7XG4gICAgaW5pdCA9IFwiXCI7XG4gIH1cbiAgcmV0dXJuIG5ldyBVUkxTZWFyY2hQYXJhbXModHlwZW9mIGluaXQgPT09IFwic3RyaW5nXCIgfHwgQXJyYXkuaXNBcnJheShpbml0KSB8fCBpbml0IGluc3RhbmNlb2YgVVJMU2VhcmNoUGFyYW1zID8gaW5pdCA6IE9iamVjdC5rZXlzKGluaXQpLnJlZHVjZSgobWVtbywga2V5KSA9PiB7XG4gICAgbGV0IHZhbHVlID0gaW5pdFtrZXldO1xuICAgIHJldHVybiBtZW1vLmNvbmNhdChBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLm1hcCh2ID0+IFtrZXksIHZdKSA6IFtba2V5LCB2YWx1ZV1dKTtcbiAgfSwgW10pKTtcbn1cbmZ1bmN0aW9uIGdldFNlYXJjaFBhcmFtc0ZvckxvY2F0aW9uKGxvY2F0aW9uU2VhcmNoLCBkZWZhdWx0U2VhcmNoUGFyYW1zKSB7XG4gIGxldCBzZWFyY2hQYXJhbXMgPSBjcmVhdGVTZWFyY2hQYXJhbXMobG9jYXRpb25TZWFyY2gpO1xuICBpZiAoZGVmYXVsdFNlYXJjaFBhcmFtcykge1xuICAgIC8vIFVzZSBgZGVmYXVsdFNlYXJjaFBhcmFtcy5mb3JFYWNoKC4uLilgIGhlcmUgaW5zdGVhZCBvZiBpdGVyYXRpbmcgb2ZcbiAgICAvLyBgZGVmYXVsdFNlYXJjaFBhcmFtcy5rZXlzKClgIHRvIHdvcmstYXJvdW5kIGEgYnVnIGluIEZpcmVmb3ggcmVsYXRlZCB0b1xuICAgIC8vIHdlYiBleHRlbnNpb25zLiBSZWxldmFudCBCdWd6aWxsYSB0aWNrZXRzOlxuICAgIC8vIGh0dHBzOi8vYnVnemlsbGEubW96aWxsYS5vcmcvc2hvd19idWcuY2dpP2lkPTE0MTQ2MDJcbiAgICAvLyBodHRwczovL2J1Z3ppbGxhLm1vemlsbGEub3JnL3Nob3dfYnVnLmNnaT9pZD0xMDIzOTg0XG4gICAgZGVmYXVsdFNlYXJjaFBhcmFtcy5mb3JFYWNoKChfLCBrZXkpID0+IHtcbiAgICAgIGlmICghc2VhcmNoUGFyYW1zLmhhcyhrZXkpKSB7XG4gICAgICAgIGRlZmF1bHRTZWFyY2hQYXJhbXMuZ2V0QWxsKGtleSkuZm9yRWFjaCh2YWx1ZSA9PiB7XG4gICAgICAgICAgc2VhcmNoUGFyYW1zLmFwcGVuZChrZXksIHZhbHVlKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHNlYXJjaFBhcmFtcztcbn1cbi8vIE9uZS10aW1lIGNoZWNrIGZvciBzdWJtaXR0ZXIgc3VwcG9ydFxubGV0IF9mb3JtRGF0YVN1cHBvcnRzU3VibWl0dGVyID0gbnVsbDtcbmZ1bmN0aW9uIGlzRm9ybURhdGFTdWJtaXR0ZXJTdXBwb3J0ZWQoKSB7XG4gIGlmIChfZm9ybURhdGFTdXBwb3J0c1N1Ym1pdHRlciA9PT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBuZXcgRm9ybURhdGEoZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImZvcm1cIiksXG4gICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIGlmIEZvcm1EYXRhIHN1cHBvcnRzIHRoZSBzdWJtaXR0ZXIgcGFyYW1ldGVyLCB0aGlzIHdpbGwgdGhyb3dcbiAgICAgIDApO1xuICAgICAgX2Zvcm1EYXRhU3VwcG9ydHNTdWJtaXR0ZXIgPSBmYWxzZTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBfZm9ybURhdGFTdXBwb3J0c1N1Ym1pdHRlciA9IHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBfZm9ybURhdGFTdXBwb3J0c1N1Ym1pdHRlcjtcbn1cbmNvbnN0IHN1cHBvcnRlZEZvcm1FbmNUeXBlcyA9IG5ldyBTZXQoW1wiYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkXCIsIFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiLCBcInRleHQvcGxhaW5cIl0pO1xuZnVuY3Rpb24gZ2V0Rm9ybUVuY1R5cGUoZW5jVHlwZSkge1xuICBpZiAoZW5jVHlwZSAhPSBudWxsICYmICFzdXBwb3J0ZWRGb3JtRW5jVHlwZXMuaGFzKGVuY1R5cGUpKSB7XG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcoZmFsc2UsIFwiXFxcIlwiICsgZW5jVHlwZSArIFwiXFxcIiBpcyBub3QgYSB2YWxpZCBgZW5jVHlwZWAgZm9yIGA8Rm9ybT5gL2A8ZmV0Y2hlci5Gb3JtPmAgXCIgKyAoXCJhbmQgd2lsbCBkZWZhdWx0IHRvIFxcXCJcIiArIGRlZmF1bHRFbmNUeXBlICsgXCJcXFwiXCIpKSA6IHZvaWQgMDtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gZW5jVHlwZTtcbn1cbmZ1bmN0aW9uIGdldEZvcm1TdWJtaXNzaW9uSW5mbyh0YXJnZXQsIGJhc2VuYW1lKSB7XG4gIGxldCBtZXRob2Q7XG4gIGxldCBhY3Rpb247XG4gIGxldCBlbmNUeXBlO1xuICBsZXQgZm9ybURhdGE7XG4gIGxldCBib2R5O1xuICBpZiAoaXNGb3JtRWxlbWVudCh0YXJnZXQpKSB7XG4gICAgLy8gV2hlbiBncmFiYmluZyB0aGUgYWN0aW9uIGZyb20gdGhlIGVsZW1lbnQsIGl0IHdpbGwgaGF2ZSBoYWQgdGhlIGJhc2VuYW1lXG4gICAgLy8gcHJlZml4ZWQgdG8gZW5zdXJlIG5vbi1KUyBzY2VuYXJpb3Mgd29yaywgc28gc3RyaXAgaXQgc2luY2Ugd2UnbGxcbiAgICAvLyByZS1wcmVmaXggaW4gdGhlIHJvdXRlclxuICAgIGxldCBhdHRyID0gdGFyZ2V0LmdldEF0dHJpYnV0ZShcImFjdGlvblwiKTtcbiAgICBhY3Rpb24gPSBhdHRyID8gc3RyaXBCYXNlbmFtZShhdHRyLCBiYXNlbmFtZSkgOiBudWxsO1xuICAgIG1ldGhvZCA9IHRhcmdldC5nZXRBdHRyaWJ1dGUoXCJtZXRob2RcIikgfHwgZGVmYXVsdE1ldGhvZDtcbiAgICBlbmNUeXBlID0gZ2V0Rm9ybUVuY1R5cGUodGFyZ2V0LmdldEF0dHJpYnV0ZShcImVuY3R5cGVcIikpIHx8IGRlZmF1bHRFbmNUeXBlO1xuICAgIGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKHRhcmdldCk7XG4gIH0gZWxzZSBpZiAoaXNCdXR0b25FbGVtZW50KHRhcmdldCkgfHwgaXNJbnB1dEVsZW1lbnQodGFyZ2V0KSAmJiAodGFyZ2V0LnR5cGUgPT09IFwic3VibWl0XCIgfHwgdGFyZ2V0LnR5cGUgPT09IFwiaW1hZ2VcIikpIHtcbiAgICBsZXQgZm9ybSA9IHRhcmdldC5mb3JtO1xuICAgIGlmIChmb3JtID09IG51bGwpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNhbm5vdCBzdWJtaXQgYSA8YnV0dG9uPiBvciA8aW5wdXQgdHlwZT1cXFwic3VibWl0XFxcIj4gd2l0aG91dCBhIDxmb3JtPlwiKTtcbiAgICB9XG4gICAgLy8gPGJ1dHRvbj4vPGlucHV0IHR5cGU9XCJzdWJtaXRcIj4gbWF5IG92ZXJyaWRlIGF0dHJpYnV0ZXMgb2YgPGZvcm0+XG4gICAgLy8gV2hlbiBncmFiYmluZyB0aGUgYWN0aW9uIGZyb20gdGhlIGVsZW1lbnQsIGl0IHdpbGwgaGF2ZSBoYWQgdGhlIGJhc2VuYW1lXG4gICAgLy8gcHJlZml4ZWQgdG8gZW5zdXJlIG5vbi1KUyBzY2VuYXJpb3Mgd29yaywgc28gc3RyaXAgaXQgc2luY2Ugd2UnbGxcbiAgICAvLyByZS1wcmVmaXggaW4gdGhlIHJvdXRlclxuICAgIGxldCBhdHRyID0gdGFyZ2V0LmdldEF0dHJpYnV0ZShcImZvcm1hY3Rpb25cIikgfHwgZm9ybS5nZXRBdHRyaWJ1dGUoXCJhY3Rpb25cIik7XG4gICAgYWN0aW9uID0gYXR0ciA/IHN0cmlwQmFzZW5hbWUoYXR0ciwgYmFzZW5hbWUpIDogbnVsbDtcbiAgICBtZXRob2QgPSB0YXJnZXQuZ2V0QXR0cmlidXRlKFwiZm9ybW1ldGhvZFwiKSB8fCBmb3JtLmdldEF0dHJpYnV0ZShcIm1ldGhvZFwiKSB8fCBkZWZhdWx0TWV0aG9kO1xuICAgIGVuY1R5cGUgPSBnZXRGb3JtRW5jVHlwZSh0YXJnZXQuZ2V0QXR0cmlidXRlKFwiZm9ybWVuY3R5cGVcIikpIHx8IGdldEZvcm1FbmNUeXBlKGZvcm0uZ2V0QXR0cmlidXRlKFwiZW5jdHlwZVwiKSkgfHwgZGVmYXVsdEVuY1R5cGU7XG4gICAgLy8gQnVpbGQgYSBGb3JtRGF0YSBvYmplY3QgcG9wdWxhdGVkIGZyb20gYSBmb3JtIGFuZCBzdWJtaXR0ZXJcbiAgICBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YShmb3JtLCB0YXJnZXQpO1xuICAgIC8vIElmIHRoaXMgYnJvd3NlciBkb2Vzbid0IHN1cHBvcnQgdGhlIGBGb3JtRGF0YShlbCwgc3VibWl0dGVyKWAgZm9ybWF0LFxuICAgIC8vIHRoZW4gdGFjayBvbiB0aGUgc3VibWl0dGVyIHZhbHVlIGF0IHRoZSBlbmQuICBUaGlzIGlzIGEgbGlnaHR3ZWlnaHRcbiAgICAvLyBzb2x1dGlvbiB0aGF0IGlzIG5vdCAxMDAlIHNwZWMgY29tcGxpYW50LiAgRm9yIGNvbXBsZXRlIHN1cHBvcnQgaW4gb2xkZXJcbiAgICAvLyBicm93c2VycywgY29uc2lkZXIgdXNpbmcgdGhlIGBmb3JtZGF0YS1zdWJtaXR0ZXItcG9seWZpbGxgIHBhY2thZ2VcbiAgICBpZiAoIWlzRm9ybURhdGFTdWJtaXR0ZXJTdXBwb3J0ZWQoKSkge1xuICAgICAgbGV0IHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdHlwZSxcbiAgICAgICAgdmFsdWVcbiAgICAgIH0gPSB0YXJnZXQ7XG4gICAgICBpZiAodHlwZSA9PT0gXCJpbWFnZVwiKSB7XG4gICAgICAgIGxldCBwcmVmaXggPSBuYW1lID8gbmFtZSArIFwiLlwiIDogXCJcIjtcbiAgICAgICAgZm9ybURhdGEuYXBwZW5kKHByZWZpeCArIFwieFwiLCBcIjBcIik7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZChwcmVmaXggKyBcInlcIiwgXCIwXCIpO1xuICAgICAgfSBlbHNlIGlmIChuYW1lKSB7XG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZChuYW1lLCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2UgaWYgKGlzSHRtbEVsZW1lbnQodGFyZ2V0KSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkNhbm5vdCBzdWJtaXQgZWxlbWVudCB0aGF0IGlzIG5vdCA8Zm9ybT4sIDxidXR0b24+LCBvciBcIiArIFwiPGlucHV0IHR5cGU9XFxcInN1Ym1pdHxpbWFnZVxcXCI+XCIpO1xuICB9IGVsc2Uge1xuICAgIG1ldGhvZCA9IGRlZmF1bHRNZXRob2Q7XG4gICAgYWN0aW9uID0gbnVsbDtcbiAgICBlbmNUeXBlID0gZGVmYXVsdEVuY1R5cGU7XG4gICAgYm9keSA9IHRhcmdldDtcbiAgfVxuICAvLyBTZW5kIGJvZHkgZm9yIDxGb3JtIGVuY1R5cGU9XCJ0ZXh0L3BsYWluXCIgc28gd2UgZW5jb2RlIGl0IGludG8gdGV4dFxuICBpZiAoZm9ybURhdGEgJiYgZW5jVHlwZSA9PT0gXCJ0ZXh0L3BsYWluXCIpIHtcbiAgICBib2R5ID0gZm9ybURhdGE7XG4gICAgZm9ybURhdGEgPSB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBhY3Rpb24sXG4gICAgbWV0aG9kOiBtZXRob2QudG9Mb3dlckNhc2UoKSxcbiAgICBlbmNUeXBlLFxuICAgIGZvcm1EYXRhLFxuICAgIGJvZHlcbiAgfTtcbn1cblxuY29uc3QgX2V4Y2x1ZGVkID0gW1wib25DbGlja1wiLCBcInJlbGF0aXZlXCIsIFwicmVsb2FkRG9jdW1lbnRcIiwgXCJyZXBsYWNlXCIsIFwic3RhdGVcIiwgXCJ0YXJnZXRcIiwgXCJ0b1wiLCBcInByZXZlbnRTY3JvbGxSZXNldFwiLCBcInZpZXdUcmFuc2l0aW9uXCJdLFxuICBfZXhjbHVkZWQyID0gW1wiYXJpYS1jdXJyZW50XCIsIFwiY2FzZVNlbnNpdGl2ZVwiLCBcImNsYXNzTmFtZVwiLCBcImVuZFwiLCBcInN0eWxlXCIsIFwidG9cIiwgXCJ2aWV3VHJhbnNpdGlvblwiLCBcImNoaWxkcmVuXCJdLFxuICBfZXhjbHVkZWQzID0gW1wiZmV0Y2hlcktleVwiLCBcIm5hdmlnYXRlXCIsIFwicmVsb2FkRG9jdW1lbnRcIiwgXCJyZXBsYWNlXCIsIFwic3RhdGVcIiwgXCJtZXRob2RcIiwgXCJhY3Rpb25cIiwgXCJvblN1Ym1pdFwiLCBcInJlbGF0aXZlXCIsIFwicHJldmVudFNjcm9sbFJlc2V0XCIsIFwidmlld1RyYW5zaXRpb25cIl07XG4vLyBIRVkgWU9VISBET04nVCBUT1VDSCBUSElTIFZBUklBQkxFIVxuLy9cbi8vIEl0IGlzIHJlcGxhY2VkIHdpdGggdGhlIHByb3BlciB2ZXJzaW9uIGF0IGJ1aWxkIHRpbWUgdmlhIGEgYmFiZWwgcGx1Z2luIGluXG4vLyB0aGUgcm9sbHVwIGNvbmZpZy5cbi8vXG4vLyBFeHBvcnQgYSBnbG9iYWwgcHJvcGVydHkgb250byB0aGUgd2luZG93IGZvciBSZWFjdCBSb3V0ZXIgZGV0ZWN0aW9uIGJ5IHRoZVxuLy8gQ29yZSBXZWIgVml0YWxzIFRlY2hub2xvZ3kgUmVwb3J0LiAgVGhpcyB3YXkgdGhleSBjYW4gY29uZmlndXJlIHRoZSBgd2FwcGFseXplcmBcbi8vIHRvIGRldGVjdCBhbmQgcHJvcGVybHkgY2xhc3NpZnkgbGl2ZSB3ZWJzaXRlcyBhcyBiZWluZyBidWlsdCB3aXRoIFJlYWN0IFJvdXRlcjpcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9IVFRQQXJjaGl2ZS93YXBwYWx5emVyL2Jsb2IvbWFpbi9zcmMvdGVjaG5vbG9naWVzL3IuanNvblxuY29uc3QgUkVBQ1RfUk9VVEVSX1ZFUlNJT04gPSBcIjZcIjtcbnRyeSB7XG4gIHdpbmRvdy5fX3JlYWN0Um91dGVyVmVyc2lvbiA9IFJFQUNUX1JPVVRFUl9WRVJTSU9OO1xufSBjYXRjaCAoZSkge1xuICAvLyBuby1vcFxufVxuZnVuY3Rpb24gY3JlYXRlQnJvd3NlclJvdXRlcihyb3V0ZXMsIG9wdHMpIHtcbiAgcmV0dXJuIGNyZWF0ZVJvdXRlcih7XG4gICAgYmFzZW5hbWU6IG9wdHMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdHMuYmFzZW5hbWUsXG4gICAgZnV0dXJlOiBfZXh0ZW5kcyh7fSwgb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5mdXR1cmUsIHtcbiAgICAgIHY3X3ByZXBlbmRCYXNlbmFtZTogdHJ1ZVxuICAgIH0pLFxuICAgIGhpc3Rvcnk6IGNyZWF0ZUJyb3dzZXJIaXN0b3J5KHtcbiAgICAgIHdpbmRvdzogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy53aW5kb3dcbiAgICB9KSxcbiAgICBoeWRyYXRpb25EYXRhOiAob3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5oeWRyYXRpb25EYXRhKSB8fCBwYXJzZUh5ZHJhdGlvbkRhdGEoKSxcbiAgICByb3V0ZXMsXG4gICAgbWFwUm91dGVQcm9wZXJ0aWVzOiBVTlNBRkVfbWFwUm91dGVQcm9wZXJ0aWVzLFxuICAgIGRhdGFTdHJhdGVneTogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5kYXRhU3RyYXRlZ3ksXG4gICAgcGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb246IG9wdHMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdHMucGF0Y2hSb3V0ZXNPbk5hdmlnYXRpb24sXG4gICAgd2luZG93OiBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLndpbmRvd1xuICB9KS5pbml0aWFsaXplKCk7XG59XG5mdW5jdGlvbiBjcmVhdGVIYXNoUm91dGVyKHJvdXRlcywgb3B0cykge1xuICByZXR1cm4gY3JlYXRlUm91dGVyKHtcbiAgICBiYXNlbmFtZTogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5iYXNlbmFtZSxcbiAgICBmdXR1cmU6IF9leHRlbmRzKHt9LCBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLmZ1dHVyZSwge1xuICAgICAgdjdfcHJlcGVuZEJhc2VuYW1lOiB0cnVlXG4gICAgfSksXG4gICAgaGlzdG9yeTogY3JlYXRlSGFzaEhpc3Rvcnkoe1xuICAgICAgd2luZG93OiBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLndpbmRvd1xuICAgIH0pLFxuICAgIGh5ZHJhdGlvbkRhdGE6IChvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLmh5ZHJhdGlvbkRhdGEpIHx8IHBhcnNlSHlkcmF0aW9uRGF0YSgpLFxuICAgIHJvdXRlcyxcbiAgICBtYXBSb3V0ZVByb3BlcnRpZXM6IFVOU0FGRV9tYXBSb3V0ZVByb3BlcnRpZXMsXG4gICAgZGF0YVN0cmF0ZWd5OiBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLmRhdGFTdHJhdGVneSxcbiAgICBwYXRjaFJvdXRlc09uTmF2aWdhdGlvbjogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5wYXRjaFJvdXRlc09uTmF2aWdhdGlvbixcbiAgICB3aW5kb3c6IG9wdHMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdHMud2luZG93XG4gIH0pLmluaXRpYWxpemUoKTtcbn1cbmZ1bmN0aW9uIHBhcnNlSHlkcmF0aW9uRGF0YSgpIHtcbiAgdmFyIF93aW5kb3c7XG4gIGxldCBzdGF0ZSA9IChfd2luZG93ID0gd2luZG93KSA9PSBudWxsID8gdm9pZCAwIDogX3dpbmRvdy5fX3N0YXRpY1JvdXRlckh5ZHJhdGlvbkRhdGE7XG4gIGlmIChzdGF0ZSAmJiBzdGF0ZS5lcnJvcnMpIHtcbiAgICBzdGF0ZSA9IF9leHRlbmRzKHt9LCBzdGF0ZSwge1xuICAgICAgZXJyb3JzOiBkZXNlcmlhbGl6ZUVycm9ycyhzdGF0ZS5lcnJvcnMpXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHN0YXRlO1xufVxuZnVuY3Rpb24gZGVzZXJpYWxpemVFcnJvcnMoZXJyb3JzKSB7XG4gIGlmICghZXJyb3JzKSByZXR1cm4gbnVsbDtcbiAgbGV0IGVudHJpZXMgPSBPYmplY3QuZW50cmllcyhlcnJvcnMpO1xuICBsZXQgc2VyaWFsaXplZCA9IHt9O1xuICBmb3IgKGxldCBba2V5LCB2YWxdIG9mIGVudHJpZXMpIHtcbiAgICAvLyBIZXkgeW91ISAgSWYgeW91IGNoYW5nZSB0aGlzLCBwbGVhc2UgY2hhbmdlIHRoZSBjb3JyZXNwb25kaW5nIGxvZ2ljIGluXG4gICAgLy8gc2VyaWFsaXplRXJyb3JzIGluIHJlYWN0LXJvdXRlci1kb20vc2VydmVyLnRzeCA6KVxuICAgIGlmICh2YWwgJiYgdmFsLl9fdHlwZSA9PT0gXCJSb3V0ZUVycm9yUmVzcG9uc2VcIikge1xuICAgICAgc2VyaWFsaXplZFtrZXldID0gbmV3IFVOU0FGRV9FcnJvclJlc3BvbnNlSW1wbCh2YWwuc3RhdHVzLCB2YWwuc3RhdHVzVGV4dCwgdmFsLmRhdGEsIHZhbC5pbnRlcm5hbCA9PT0gdHJ1ZSk7XG4gICAgfSBlbHNlIGlmICh2YWwgJiYgdmFsLl9fdHlwZSA9PT0gXCJFcnJvclwiKSB7XG4gICAgICAvLyBBdHRlbXB0IHRvIHJlY29uc3RydWN0IHRoZSByaWdodCB0eXBlIG9mIEVycm9yIChpLmUuLCBSZWZlcmVuY2VFcnJvcilcbiAgICAgIGlmICh2YWwuX19zdWJUeXBlKSB7XG4gICAgICAgIGxldCBFcnJvckNvbnN0cnVjdG9yID0gd2luZG93W3ZhbC5fX3N1YlR5cGVdO1xuICAgICAgICBpZiAodHlwZW9mIEVycm9yQ29uc3RydWN0b3IgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yXG4gICAgICAgICAgICBsZXQgZXJyb3IgPSBuZXcgRXJyb3JDb25zdHJ1Y3Rvcih2YWwubWVzc2FnZSk7XG4gICAgICAgICAgICAvLyBXaXBlIGF3YXkgdGhlIGNsaWVudC1zaWRlIHN0YWNrIHRyYWNlLiAgTm90aGluZyB0byBmaWxsIGl0IGluIHdpdGhcbiAgICAgICAgICAgIC8vIGJlY2F1c2Ugd2UgZG9uJ3Qgc2VyaWFsaXplIFNTUiBzdGFjayB0cmFjZXMgZm9yIHNlY3VyaXR5IHJlYXNvbnNcbiAgICAgICAgICAgIGVycm9yLnN0YWNrID0gXCJcIjtcbiAgICAgICAgICAgIHNlcmlhbGl6ZWRba2V5XSA9IGVycm9yO1xuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIC8vIG5vLW9wIC0gZmFsbCB0aHJvdWdoIGFuZCBjcmVhdGUgYSBub3JtYWwgRXJyb3JcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChzZXJpYWxpemVkW2tleV0gPT0gbnVsbCkge1xuICAgICAgICBsZXQgZXJyb3IgPSBuZXcgRXJyb3IodmFsLm1lc3NhZ2UpO1xuICAgICAgICAvLyBXaXBlIGF3YXkgdGhlIGNsaWVudC1zaWRlIHN0YWNrIHRyYWNlLiAgTm90aGluZyB0byBmaWxsIGl0IGluIHdpdGhcbiAgICAgICAgLy8gYmVjYXVzZSB3ZSBkb24ndCBzZXJpYWxpemUgU1NSIHN0YWNrIHRyYWNlcyBmb3Igc2VjdXJpdHkgcmVhc29uc1xuICAgICAgICBlcnJvci5zdGFjayA9IFwiXCI7XG4gICAgICAgIHNlcmlhbGl6ZWRba2V5XSA9IGVycm9yO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzZXJpYWxpemVkW2tleV0gPSB2YWw7XG4gICAgfVxuICB9XG4gIHJldHVybiBzZXJpYWxpemVkO1xufVxuY29uc3QgVmlld1RyYW5zaXRpb25Db250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQoe1xuICBpc1RyYW5zaXRpb25pbmc6IGZhbHNlXG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgVmlld1RyYW5zaXRpb25Db250ZXh0LmRpc3BsYXlOYW1lID0gXCJWaWV3VHJhbnNpdGlvblwiO1xufVxuY29uc3QgRmV0Y2hlcnNDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobmV3IE1hcCgpKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgRmV0Y2hlcnNDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJGZXRjaGVyc1wiO1xufVxuLy8jZW5kcmVnaW9uXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuLy8jcmVnaW9uIENvbXBvbmVudHNcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4vKipcbiAgV2VicGFjayArIFJlYWN0IDE3IGZhaWxzIHRvIGNvbXBpbGUgb24gYW55IG9mIHRoZSBmb2xsb3dpbmcgYmVjYXVzZSB3ZWJwYWNrXG4gIGNvbXBsYWlucyB0aGF0IGBzdGFydFRyYW5zaXRpb25gIGRvZXNuJ3QgZXhpc3QgaW4gYFJlYWN0YDpcbiAgKiBpbXBvcnQgeyBzdGFydFRyYW5zaXRpb24gfSBmcm9tIFwicmVhY3RcIlxuICAqIGltcG9ydCAqIGFzIFJlYWN0IGZyb20gZnJvbSBcInJlYWN0XCI7XG4gICAgXCJzdGFydFRyYW5zaXRpb25cIiBpbiBSZWFjdCA/IFJlYWN0LnN0YXJ0VHJhbnNpdGlvbigoKSA9PiBzZXRTdGF0ZSgpKSA6IHNldFN0YXRlKClcbiAgKiBpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIGZyb20gXCJyZWFjdFwiO1xuICAgIFwic3RhcnRUcmFuc2l0aW9uXCIgaW4gUmVhY3QgPyBSZWFjdFtcInN0YXJ0VHJhbnNpdGlvblwiXSgoKSA9PiBzZXRTdGF0ZSgpKSA6IHNldFN0YXRlKClcblxuICBNb3ZpbmcgaXQgdG8gYSBjb25zdGFudCBzdWNoIGFzIHRoZSBmb2xsb3dpbmcgc29sdmVzIHRoZSBXZWJwYWNrL1JlYWN0IDE3IGlzc3VlOlxuICAqIGltcG9ydCAqIGFzIFJlYWN0IGZyb20gZnJvbSBcInJlYWN0XCI7XG4gICAgY29uc3QgU1RBUlRfVFJBTlNJVElPTiA9IFwic3RhcnRUcmFuc2l0aW9uXCI7XG4gICAgU1RBUlRfVFJBTlNJVElPTiBpbiBSZWFjdCA/IFJlYWN0W1NUQVJUX1RSQU5TSVRJT05dKCgpID0+IHNldFN0YXRlKCkpIDogc2V0U3RhdGUoKVxuXG4gIEhvd2V2ZXIsIHRoYXQgaW50cm9kdWNlcyB3ZWJwYWNrL3RlcnNlciBtaW5pZmljYXRpb24gaXNzdWVzIGluIHByb2R1Y3Rpb24gYnVpbGRzXG4gIGluIFJlYWN0IDE4IHdoZXJlIG1pbmlmaWNhdGlvbi9vYmZ1c2NhdGlvbiBlbmRzIHVwIHJlbW92aW5nIHRoZSBjYWxsIG9mXG4gIFJlYWN0LnN0YXJ0VHJhbnNpdGlvbiBlbnRpcmVseSBmcm9tIHRoZSBmaXJzdCBoYWxmIG9mIHRoZSB0ZXJuYXJ5LiAgR3JhYmJpbmdcbiAgdGhpcyBleHBvcnRlZCByZWZlcmVuY2Ugb25jZSB1cCBmcm9udCByZXNvbHZlcyB0aGF0IGlzc3VlLlxuXG4gIFNlZSBodHRwczovL2dpdGh1Yi5jb20vcmVtaXgtcnVuL3JlYWN0LXJvdXRlci9pc3N1ZXMvMTA1NzlcbiovXG5jb25zdCBTVEFSVF9UUkFOU0lUSU9OID0gXCJzdGFydFRyYW5zaXRpb25cIjtcbmNvbnN0IHN0YXJ0VHJhbnNpdGlvbkltcGwgPSBSZWFjdFtTVEFSVF9UUkFOU0lUSU9OXTtcbmNvbnN0IEZMVVNIX1NZTkMgPSBcImZsdXNoU3luY1wiO1xuY29uc3QgZmx1c2hTeW5jSW1wbCA9IFJlYWN0RE9NW0ZMVVNIX1NZTkNdO1xuY29uc3QgVVNFX0lEID0gXCJ1c2VJZFwiO1xuY29uc3QgdXNlSWRJbXBsID0gUmVhY3RbVVNFX0lEXTtcbmZ1bmN0aW9uIHN0YXJ0VHJhbnNpdGlvblNhZmUoY2IpIHtcbiAgaWYgKHN0YXJ0VHJhbnNpdGlvbkltcGwpIHtcbiAgICBzdGFydFRyYW5zaXRpb25JbXBsKGNiKTtcbiAgfSBlbHNlIHtcbiAgICBjYigpO1xuICB9XG59XG5mdW5jdGlvbiBmbHVzaFN5bmNTYWZlKGNiKSB7XG4gIGlmIChmbHVzaFN5bmNJbXBsKSB7XG4gICAgZmx1c2hTeW5jSW1wbChjYik7XG4gIH0gZWxzZSB7XG4gICAgY2IoKTtcbiAgfVxufVxuY2xhc3MgRGVmZXJyZWQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuICAgIHRoaXMucHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMucmVzb2x2ZSA9IHZhbHVlID0+IHtcbiAgICAgICAgaWYgKHRoaXMuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuICAgICAgICAgIHRoaXMuc3RhdHVzID0gXCJyZXNvbHZlZFwiO1xuICAgICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgdGhpcy5yZWplY3QgPSByZWFzb24gPT4ge1xuICAgICAgICBpZiAodGhpcy5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB7XG4gICAgICAgICAgdGhpcy5zdGF0dXMgPSBcInJlamVjdGVkXCI7XG4gICAgICAgICAgcmVqZWN0KHJlYXNvbik7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfSk7XG4gIH1cbn1cbi8qKlxuICogR2l2ZW4gYSBSZW1peCBSb3V0ZXIgaW5zdGFuY2UsIHJlbmRlciB0aGUgYXBwcm9wcmlhdGUgVUlcbiAqL1xuZnVuY3Rpb24gUm91dGVyUHJvdmlkZXIoX3JlZikge1xuICBsZXQge1xuICAgIGZhbGxiYWNrRWxlbWVudCxcbiAgICByb3V0ZXIsXG4gICAgZnV0dXJlXG4gIH0gPSBfcmVmO1xuICBsZXQgW3N0YXRlLCBzZXRTdGF0ZUltcGxdID0gUmVhY3QudXNlU3RhdGUocm91dGVyLnN0YXRlKTtcbiAgbGV0IFtwZW5kaW5nU3RhdGUsIHNldFBlbmRpbmdTdGF0ZV0gPSBSZWFjdC51c2VTdGF0ZSgpO1xuICBsZXQgW3Z0Q29udGV4dCwgc2V0VnRDb250ZXh0XSA9IFJlYWN0LnVzZVN0YXRlKHtcbiAgICBpc1RyYW5zaXRpb25pbmc6IGZhbHNlXG4gIH0pO1xuICBsZXQgW3JlbmRlckRmZCwgc2V0UmVuZGVyRGZkXSA9IFJlYWN0LnVzZVN0YXRlKCk7XG4gIGxldCBbdHJhbnNpdGlvbiwgc2V0VHJhbnNpdGlvbl0gPSBSZWFjdC51c2VTdGF0ZSgpO1xuICBsZXQgW2ludGVycnVwdGlvbiwgc2V0SW50ZXJydXB0aW9uXSA9IFJlYWN0LnVzZVN0YXRlKCk7XG4gIGxldCBmZXRjaGVyRGF0YSA9IFJlYWN0LnVzZVJlZihuZXcgTWFwKCkpO1xuICBsZXQge1xuICAgIHY3X3N0YXJ0VHJhbnNpdGlvblxuICB9ID0gZnV0dXJlIHx8IHt9O1xuICBsZXQgb3B0SW5TdGFydFRyYW5zaXRpb24gPSBSZWFjdC51c2VDYWxsYmFjayhjYiA9PiB7XG4gICAgaWYgKHY3X3N0YXJ0VHJhbnNpdGlvbikge1xuICAgICAgc3RhcnRUcmFuc2l0aW9uU2FmZShjYik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNiKCk7XG4gICAgfVxuICB9LCBbdjdfc3RhcnRUcmFuc2l0aW9uXSk7XG4gIGxldCBzZXRTdGF0ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKChuZXdTdGF0ZSwgX3JlZjIpID0+IHtcbiAgICBsZXQge1xuICAgICAgZGVsZXRlZEZldGNoZXJzLFxuICAgICAgZmx1c2hTeW5jOiBmbHVzaFN5bmMsXG4gICAgICB2aWV3VHJhbnNpdGlvbk9wdHM6IHZpZXdUcmFuc2l0aW9uT3B0c1xuICAgIH0gPSBfcmVmMjtcbiAgICBuZXdTdGF0ZS5mZXRjaGVycy5mb3JFYWNoKChmZXRjaGVyLCBrZXkpID0+IHtcbiAgICAgIGlmIChmZXRjaGVyLmRhdGEgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICBmZXRjaGVyRGF0YS5jdXJyZW50LnNldChrZXksIGZldGNoZXIuZGF0YSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgZGVsZXRlZEZldGNoZXJzLmZvckVhY2goa2V5ID0+IGZldGNoZXJEYXRhLmN1cnJlbnQuZGVsZXRlKGtleSkpO1xuICAgIGxldCBpc1ZpZXdUcmFuc2l0aW9uVW5hdmFpbGFibGUgPSByb3V0ZXIud2luZG93ID09IG51bGwgfHwgcm91dGVyLndpbmRvdy5kb2N1bWVudCA9PSBudWxsIHx8IHR5cGVvZiByb3V0ZXIud2luZG93LmRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24gIT09IFwiZnVuY3Rpb25cIjtcbiAgICAvLyBJZiB0aGlzIGlzbid0IGEgdmlldyB0cmFuc2l0aW9uIG9yIGl0J3Mgbm90IGF2YWlsYWJsZSBpbiB0aGlzIGJyb3dzZXIsXG4gICAgLy8ganVzdCB1cGRhdGUgYW5kIGJlIGRvbmUgd2l0aCBpdFxuICAgIGlmICghdmlld1RyYW5zaXRpb25PcHRzIHx8IGlzVmlld1RyYW5zaXRpb25VbmF2YWlsYWJsZSkge1xuICAgICAgaWYgKGZsdXNoU3luYykge1xuICAgICAgICBmbHVzaFN5bmNTYWZlKCgpID0+IHNldFN0YXRlSW1wbChuZXdTdGF0ZSkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgb3B0SW5TdGFydFRyYW5zaXRpb24oKCkgPT4gc2V0U3RhdGVJbXBsKG5ld1N0YXRlKSk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIGZsdXNoU3luYyArIHN0YXJ0Vmlld1RyYW5zaXRpb25cbiAgICBpZiAoZmx1c2hTeW5jKSB7XG4gICAgICAvLyBGbHVzaCB0aHJvdWdoIHRoZSBjb250ZXh0IHRvIG1hcmsgRE9NIGVsZW1lbnRzIGFzIHRyYW5zaXRpb249aW5nXG4gICAgICBmbHVzaFN5bmNTYWZlKCgpID0+IHtcbiAgICAgICAgLy8gQ2FuY2VsIGFueSBwZW5kaW5nIHRyYW5zaXRpb25zXG4gICAgICAgIGlmICh0cmFuc2l0aW9uKSB7XG4gICAgICAgICAgcmVuZGVyRGZkICYmIHJlbmRlckRmZC5yZXNvbHZlKCk7XG4gICAgICAgICAgdHJhbnNpdGlvbi5za2lwVHJhbnNpdGlvbigpO1xuICAgICAgICB9XG4gICAgICAgIHNldFZ0Q29udGV4dCh7XG4gICAgICAgICAgaXNUcmFuc2l0aW9uaW5nOiB0cnVlLFxuICAgICAgICAgIGZsdXNoU3luYzogdHJ1ZSxcbiAgICAgICAgICBjdXJyZW50TG9jYXRpb246IHZpZXdUcmFuc2l0aW9uT3B0cy5jdXJyZW50TG9jYXRpb24sXG4gICAgICAgICAgbmV4dExvY2F0aW9uOiB2aWV3VHJhbnNpdGlvbk9wdHMubmV4dExvY2F0aW9uXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgICAvLyBVcGRhdGUgdGhlIERPTVxuICAgICAgbGV0IHQgPSByb3V0ZXIud2luZG93LmRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24oKCkgPT4ge1xuICAgICAgICBmbHVzaFN5bmNTYWZlKCgpID0+IHNldFN0YXRlSW1wbChuZXdTdGF0ZSkpO1xuICAgICAgfSk7XG4gICAgICAvLyBDbGVhbiB1cCBhZnRlciB0aGUgYW5pbWF0aW9uIGNvbXBsZXRlc1xuICAgICAgdC5maW5pc2hlZC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgZmx1c2hTeW5jU2FmZSgoKSA9PiB7XG4gICAgICAgICAgc2V0UmVuZGVyRGZkKHVuZGVmaW5lZCk7XG4gICAgICAgICAgc2V0VHJhbnNpdGlvbih1bmRlZmluZWQpO1xuICAgICAgICAgIHNldFBlbmRpbmdTdGF0ZSh1bmRlZmluZWQpO1xuICAgICAgICAgIHNldFZ0Q29udGV4dCh7XG4gICAgICAgICAgICBpc1RyYW5zaXRpb25pbmc6IGZhbHNlXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgICBmbHVzaFN5bmNTYWZlKCgpID0+IHNldFRyYW5zaXRpb24odCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBzdGFydFRyYW5zaXRpb24gKyBzdGFydFZpZXdUcmFuc2l0aW9uXG4gICAgaWYgKHRyYW5zaXRpb24pIHtcbiAgICAgIC8vIEludGVycnVwdGluZyBhbiBpbi1wcm9ncmVzcyB0cmFuc2l0aW9uLCBjYW5jZWwgYW5kIGxldCBldmVyeXRoaW5nIGZsdXNoXG4gICAgICAvLyBvdXQsIGFuZCB0aGVuIGtpY2sgb2ZmIGEgbmV3IHRyYW5zaXRpb24gZnJvbSB0aGUgaW50ZXJydXB0aW9uIHN0YXRlXG4gICAgICByZW5kZXJEZmQgJiYgcmVuZGVyRGZkLnJlc29sdmUoKTtcbiAgICAgIHRyYW5zaXRpb24uc2tpcFRyYW5zaXRpb24oKTtcbiAgICAgIHNldEludGVycnVwdGlvbih7XG4gICAgICAgIHN0YXRlOiBuZXdTdGF0ZSxcbiAgICAgICAgY3VycmVudExvY2F0aW9uOiB2aWV3VHJhbnNpdGlvbk9wdHMuY3VycmVudExvY2F0aW9uLFxuICAgICAgICBuZXh0TG9jYXRpb246IHZpZXdUcmFuc2l0aW9uT3B0cy5uZXh0TG9jYXRpb25cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBDb21wbGV0ZWQgbmF2aWdhdGlvbiB1cGRhdGUgd2l0aCBvcHRlZC1pbiB2aWV3IHRyYW5zaXRpb25zLCBsZXQgJ2VyIHJpcFxuICAgICAgc2V0UGVuZGluZ1N0YXRlKG5ld1N0YXRlKTtcbiAgICAgIHNldFZ0Q29udGV4dCh7XG4gICAgICAgIGlzVHJhbnNpdGlvbmluZzogdHJ1ZSxcbiAgICAgICAgZmx1c2hTeW5jOiBmYWxzZSxcbiAgICAgICAgY3VycmVudExvY2F0aW9uOiB2aWV3VHJhbnNpdGlvbk9wdHMuY3VycmVudExvY2F0aW9uLFxuICAgICAgICBuZXh0TG9jYXRpb246IHZpZXdUcmFuc2l0aW9uT3B0cy5uZXh0TG9jYXRpb25cbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW3JvdXRlci53aW5kb3csIHRyYW5zaXRpb24sIHJlbmRlckRmZCwgZmV0Y2hlckRhdGEsIG9wdEluU3RhcnRUcmFuc2l0aW9uXSk7XG4gIC8vIE5lZWQgdG8gdXNlIGEgbGF5b3V0IGVmZmVjdCBoZXJlIHNvIHdlIGFyZSBzdWJzY3JpYmVkIGVhcmx5IGVub3VnaCB0b1xuICAvLyBwaWNrIHVwIG9uIGFueSByZW5kZXItZHJpdmVuIHJlZGlyZWN0cy9uYXZpZ2F0aW9ucyAodXNlRWZmZWN0LzxOYXZpZ2F0ZT4pXG4gIFJlYWN0LnVzZUxheW91dEVmZmVjdCgoKSA9PiByb3V0ZXIuc3Vic2NyaWJlKHNldFN0YXRlKSwgW3JvdXRlciwgc2V0U3RhdGVdKTtcbiAgLy8gV2hlbiB3ZSBzdGFydCBhIHZpZXcgdHJhbnNpdGlvbiwgY3JlYXRlIGEgRGVmZXJyZWQgd2UgY2FuIHVzZSBmb3IgdGhlXG4gIC8vIGV2ZW50dWFsIFwiY29tcGxldGVkXCIgcmVuZGVyXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHZ0Q29udGV4dC5pc1RyYW5zaXRpb25pbmcgJiYgIXZ0Q29udGV4dC5mbHVzaFN5bmMpIHtcbiAgICAgIHNldFJlbmRlckRmZChuZXcgRGVmZXJyZWQoKSk7XG4gICAgfVxuICB9LCBbdnRDb250ZXh0XSk7XG4gIC8vIE9uY2UgdGhlIGRlZmVycmVkIGlzIGNyZWF0ZWQsIGtpY2sgb2ZmIHN0YXJ0Vmlld1RyYW5zaXRpb24oKSB0byB1cGRhdGUgdGhlXG4gIC8vIERPTSBhbmQgdGhlbiB3YWl0IG9uIHRoZSBEZWZlcnJlZCB0byByZXNvbHZlIChpbmRpY2F0aW5nIHRoZSBET00gdXBkYXRlIGhhc1xuICAvLyBoYXBwZW5lZClcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocmVuZGVyRGZkICYmIHBlbmRpbmdTdGF0ZSAmJiByb3V0ZXIud2luZG93KSB7XG4gICAgICBsZXQgbmV3U3RhdGUgPSBwZW5kaW5nU3RhdGU7XG4gICAgICBsZXQgcmVuZGVyUHJvbWlzZSA9IHJlbmRlckRmZC5wcm9taXNlO1xuICAgICAgbGV0IHRyYW5zaXRpb24gPSByb3V0ZXIud2luZG93LmRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24oYXN5bmMgKCkgPT4ge1xuICAgICAgICBvcHRJblN0YXJ0VHJhbnNpdGlvbigoKSA9PiBzZXRTdGF0ZUltcGwobmV3U3RhdGUpKTtcbiAgICAgICAgYXdhaXQgcmVuZGVyUHJvbWlzZTtcbiAgICAgIH0pO1xuICAgICAgdHJhbnNpdGlvbi5maW5pc2hlZC5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgc2V0UmVuZGVyRGZkKHVuZGVmaW5lZCk7XG4gICAgICAgIHNldFRyYW5zaXRpb24odW5kZWZpbmVkKTtcbiAgICAgICAgc2V0UGVuZGluZ1N0YXRlKHVuZGVmaW5lZCk7XG4gICAgICAgIHNldFZ0Q29udGV4dCh7XG4gICAgICAgICAgaXNUcmFuc2l0aW9uaW5nOiBmYWxzZVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgICAgc2V0VHJhbnNpdGlvbih0cmFuc2l0aW9uKTtcbiAgICB9XG4gIH0sIFtvcHRJblN0YXJ0VHJhbnNpdGlvbiwgcGVuZGluZ1N0YXRlLCByZW5kZXJEZmQsIHJvdXRlci53aW5kb3ddKTtcbiAgLy8gV2hlbiB0aGUgbmV3IGxvY2F0aW9uIGZpbmFsbHkgcmVuZGVycyBhbmQgaXMgY29tbWl0dGVkIHRvIHRoZSBET00sIHRoaXNcbiAgLy8gZWZmZWN0IHdpbGwgcnVuIHRvIHJlc29sdmUgdGhlIHRyYW5zaXRpb25cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAocmVuZGVyRGZkICYmIHBlbmRpbmdTdGF0ZSAmJiBzdGF0ZS5sb2NhdGlvbi5rZXkgPT09IHBlbmRpbmdTdGF0ZS5sb2NhdGlvbi5rZXkpIHtcbiAgICAgIHJlbmRlckRmZC5yZXNvbHZlKCk7XG4gICAgfVxuICB9LCBbcmVuZGVyRGZkLCB0cmFuc2l0aW9uLCBzdGF0ZS5sb2NhdGlvbiwgcGVuZGluZ1N0YXRlXSk7XG4gIC8vIElmIHdlIGdldCBpbnRlcnJ1cHRlZCB3aXRoIGEgbmV3IG5hdmlnYXRpb24gZHVyaW5nIGEgdHJhbnNpdGlvbiwgd2Ugc2tpcFxuICAvLyB0aGUgYWN0aXZlIHRyYW5zaXRpb24sIGxldCBpdCBjbGVhbnVwLCB0aGVuIGtpY2sgaXQgb2ZmIGFnYWluIGhlcmVcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXZ0Q29udGV4dC5pc1RyYW5zaXRpb25pbmcgJiYgaW50ZXJydXB0aW9uKSB7XG4gICAgICBzZXRQZW5kaW5nU3RhdGUoaW50ZXJydXB0aW9uLnN0YXRlKTtcbiAgICAgIHNldFZ0Q29udGV4dCh7XG4gICAgICAgIGlzVHJhbnNpdGlvbmluZzogdHJ1ZSxcbiAgICAgICAgZmx1c2hTeW5jOiBmYWxzZSxcbiAgICAgICAgY3VycmVudExvY2F0aW9uOiBpbnRlcnJ1cHRpb24uY3VycmVudExvY2F0aW9uLFxuICAgICAgICBuZXh0TG9jYXRpb246IGludGVycnVwdGlvbi5uZXh0TG9jYXRpb25cbiAgICAgIH0pO1xuICAgICAgc2V0SW50ZXJydXB0aW9uKHVuZGVmaW5lZCk7XG4gICAgfVxuICB9LCBbdnRDb250ZXh0LmlzVHJhbnNpdGlvbmluZywgaW50ZXJydXB0aW9uXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcoZmFsbGJhY2tFbGVtZW50ID09IG51bGwgfHwgIXJvdXRlci5mdXR1cmUudjdfcGFydGlhbEh5ZHJhdGlvbiwgXCJgPFJvdXRlclByb3ZpZGVyIGZhbGxiYWNrRWxlbWVudD5gIGlzIGRlcHJlY2F0ZWQgd2hlbiB1c2luZyBcIiArIFwiYHY3X3BhcnRpYWxIeWRyYXRpb25gLCB1c2UgYSBgSHlkcmF0ZUZhbGxiYWNrYCBjb21wb25lbnQgaW5zdGVhZFwiKSA6IHZvaWQgMDtcbiAgICAvLyBPbmx5IGxvZyB0aGlzIG9uY2Ugb24gaW5pdGlhbCBtb3VudFxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW10pO1xuICBsZXQgbmF2aWdhdG9yID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNyZWF0ZUhyZWY6IHJvdXRlci5jcmVhdGVIcmVmLFxuICAgICAgZW5jb2RlTG9jYXRpb246IHJvdXRlci5lbmNvZGVMb2NhdGlvbixcbiAgICAgIGdvOiBuID0+IHJvdXRlci5uYXZpZ2F0ZShuKSxcbiAgICAgIHB1c2g6ICh0bywgc3RhdGUsIG9wdHMpID0+IHJvdXRlci5uYXZpZ2F0ZSh0bywge1xuICAgICAgICBzdGF0ZSxcbiAgICAgICAgcHJldmVudFNjcm9sbFJlc2V0OiBvcHRzID09IG51bGwgPyB2b2lkIDAgOiBvcHRzLnByZXZlbnRTY3JvbGxSZXNldFxuICAgICAgfSksXG4gICAgICByZXBsYWNlOiAodG8sIHN0YXRlLCBvcHRzKSA9PiByb3V0ZXIubmF2aWdhdGUodG8sIHtcbiAgICAgICAgcmVwbGFjZTogdHJ1ZSxcbiAgICAgICAgc3RhdGUsXG4gICAgICAgIHByZXZlbnRTY3JvbGxSZXNldDogb3B0cyA9PSBudWxsID8gdm9pZCAwIDogb3B0cy5wcmV2ZW50U2Nyb2xsUmVzZXRcbiAgICAgIH0pXG4gICAgfTtcbiAgfSwgW3JvdXRlcl0pO1xuICBsZXQgYmFzZW5hbWUgPSByb3V0ZXIuYmFzZW5hbWUgfHwgXCIvXCI7XG4gIGxldCBkYXRhUm91dGVyQ29udGV4dCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICByb3V0ZXIsXG4gICAgbmF2aWdhdG9yLFxuICAgIHN0YXRpYzogZmFsc2UsXG4gICAgYmFzZW5hbWVcbiAgfSksIFtyb3V0ZXIsIG5hdmlnYXRvciwgYmFzZW5hbWVdKTtcbiAgbGV0IHJvdXRlckZ1dHVyZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICB2N19yZWxhdGl2ZVNwbGF0UGF0aDogcm91dGVyLmZ1dHVyZS52N19yZWxhdGl2ZVNwbGF0UGF0aFxuICB9KSwgW3JvdXRlci5mdXR1cmUudjdfcmVsYXRpdmVTcGxhdFBhdGhdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IFVOU0FGRV9sb2dWNkRlcHJlY2F0aW9uV2FybmluZ3MoZnV0dXJlLCByb3V0ZXIuZnV0dXJlKSwgW2Z1dHVyZSwgcm91dGVyLmZ1dHVyZV0pO1xuICAvLyBUaGUgZnJhZ21lbnQgYW5kIHtudWxsfSBoZXJlIGFyZSBpbXBvcnRhbnQhICBXZSBuZWVkIHRoZW0gdG8ga2VlcCBSZWFjdCAxOCdzXG4gIC8vIHVzZUlkIGhhcHB5IHdoZW4gd2UgYXJlIHNlcnZlci1yZW5kZXJpbmcgc2luY2Ugd2UgbWF5IGhhdmUgYSA8c2NyaXB0PiBoZXJlXG4gIC8vIGNvbnRhaW5pbmcgdGhlIGh5ZHJhdGVkIHNlcnZlci1zaWRlIHN0YXRpY0NvbnRleHQgKGZyb20gU3RhdGljUm91dGVyUHJvdmlkZXIpLlxuICAvLyB1c2VJZCByZWxpZXMgb24gdGhlIGNvbXBvbmVudCB0cmVlIHN0cnVjdHVyZSB0byBnZW5lcmF0ZSBkZXRlcm1pbmlzdGljIGlkJ3NcbiAgLy8gc28gd2UgbmVlZCB0byBlbnN1cmUgaXQgcmVtYWlucyB0aGUgc2FtZSBvbiB0aGUgY2xpZW50IGV2ZW4gdGhvdWdoXG4gIC8vIHdlIGRvbid0IG5lZWQgdGhlIDxzY3JpcHQ+IHRhZ1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFVOU0FGRV9EYXRhUm91dGVyQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBkYXRhUm91dGVyQ29udGV4dFxuICB9LCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChVTlNBRkVfRGF0YVJvdXRlclN0YXRlQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBzdGF0ZVxuICB9LCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGZXRjaGVyc0NvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogZmV0Y2hlckRhdGEuY3VycmVudFxuICB9LCAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChWaWV3VHJhbnNpdGlvbkNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogdnRDb250ZXh0XG4gIH0sIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJvdXRlciwge1xuICAgIGJhc2VuYW1lOiBiYXNlbmFtZSxcbiAgICBsb2NhdGlvbjogc3RhdGUubG9jYXRpb24sXG4gICAgbmF2aWdhdGlvblR5cGU6IHN0YXRlLmhpc3RvcnlBY3Rpb24sXG4gICAgbmF2aWdhdG9yOiBuYXZpZ2F0b3IsXG4gICAgZnV0dXJlOiByb3V0ZXJGdXR1cmVcbiAgfSwgc3RhdGUuaW5pdGlhbGl6ZWQgfHwgcm91dGVyLmZ1dHVyZS52N19wYXJ0aWFsSHlkcmF0aW9uID8gKC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KE1lbW9pemVkRGF0YVJvdXRlcywge1xuICAgIHJvdXRlczogcm91dGVyLnJvdXRlcyxcbiAgICBmdXR1cmU6IHJvdXRlci5mdXR1cmUsXG4gICAgc3RhdGU6IHN0YXRlXG4gIH0pKSA6IGZhbGxiYWNrRWxlbWVudCkpKSkpLCBudWxsKTtcbn1cbi8vIE1lbW9pemUgdG8gYXZvaWQgcmUtcmVuZGVycyB3aGVuIHVwZGF0aW5nIGBWaWV3VHJhbnNpdGlvbkNvbnRleHRgXG5jb25zdCBNZW1vaXplZERhdGFSb3V0ZXMgPSAvKiNfX1BVUkVfXyovUmVhY3QubWVtbyhEYXRhUm91dGVzKTtcbmZ1bmN0aW9uIERhdGFSb3V0ZXMoX3JlZjMpIHtcbiAgbGV0IHtcbiAgICByb3V0ZXMsXG4gICAgZnV0dXJlLFxuICAgIHN0YXRlXG4gIH0gPSBfcmVmMztcbiAgcmV0dXJuIFVOU0FGRV91c2VSb3V0ZXNJbXBsKHJvdXRlcywgdW5kZWZpbmVkLCBzdGF0ZSwgZnV0dXJlKTtcbn1cbi8qKlxuICogQSBgPFJvdXRlcj5gIGZvciB1c2UgaW4gd2ViIGJyb3dzZXJzLiBQcm92aWRlcyB0aGUgY2xlYW5lc3QgVVJMcy5cbiAqL1xuZnVuY3Rpb24gQnJvd3NlclJvdXRlcihfcmVmNCkge1xuICBsZXQge1xuICAgIGJhc2VuYW1lLFxuICAgIGNoaWxkcmVuLFxuICAgIGZ1dHVyZSxcbiAgICB3aW5kb3dcbiAgfSA9IF9yZWY0O1xuICBsZXQgaGlzdG9yeVJlZiA9IFJlYWN0LnVzZVJlZigpO1xuICBpZiAoaGlzdG9yeVJlZi5jdXJyZW50ID09IG51bGwpIHtcbiAgICBoaXN0b3J5UmVmLmN1cnJlbnQgPSBjcmVhdGVCcm93c2VySGlzdG9yeSh7XG4gICAgICB3aW5kb3csXG4gICAgICB2NUNvbXBhdDogdHJ1ZVxuICAgIH0pO1xuICB9XG4gIGxldCBoaXN0b3J5ID0gaGlzdG9yeVJlZi5jdXJyZW50O1xuICBsZXQgW3N0YXRlLCBzZXRTdGF0ZUltcGxdID0gUmVhY3QudXNlU3RhdGUoe1xuICAgIGFjdGlvbjogaGlzdG9yeS5hY3Rpb24sXG4gICAgbG9jYXRpb246IGhpc3RvcnkubG9jYXRpb25cbiAgfSk7XG4gIGxldCB7XG4gICAgdjdfc3RhcnRUcmFuc2l0aW9uXG4gIH0gPSBmdXR1cmUgfHwge307XG4gIGxldCBzZXRTdGF0ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKG5ld1N0YXRlID0+IHtcbiAgICB2N19zdGFydFRyYW5zaXRpb24gJiYgc3RhcnRUcmFuc2l0aW9uSW1wbCA/IHN0YXJ0VHJhbnNpdGlvbkltcGwoKCkgPT4gc2V0U3RhdGVJbXBsKG5ld1N0YXRlKSkgOiBzZXRTdGF0ZUltcGwobmV3U3RhdGUpO1xuICB9LCBbc2V0U3RhdGVJbXBsLCB2N19zdGFydFRyYW5zaXRpb25dKTtcbiAgUmVhY3QudXNlTGF5b3V0RWZmZWN0KCgpID0+IGhpc3RvcnkubGlzdGVuKHNldFN0YXRlKSwgW2hpc3RvcnksIHNldFN0YXRlXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiBVTlNBRkVfbG9nVjZEZXByZWNhdGlvbldhcm5pbmdzKGZ1dHVyZSksIFtmdXR1cmVdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJvdXRlciwge1xuICAgIGJhc2VuYW1lOiBiYXNlbmFtZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW4sXG4gICAgbG9jYXRpb246IHN0YXRlLmxvY2F0aW9uLFxuICAgIG5hdmlnYXRpb25UeXBlOiBzdGF0ZS5hY3Rpb24sXG4gICAgbmF2aWdhdG9yOiBoaXN0b3J5LFxuICAgIGZ1dHVyZTogZnV0dXJlXG4gIH0pO1xufVxuLyoqXG4gKiBBIGA8Um91dGVyPmAgZm9yIHVzZSBpbiB3ZWIgYnJvd3NlcnMuIFN0b3JlcyB0aGUgbG9jYXRpb24gaW4gdGhlIGhhc2hcbiAqIHBvcnRpb24gb2YgdGhlIFVSTCBzbyBpdCBpcyBub3Qgc2VudCB0byB0aGUgc2VydmVyLlxuICovXG5mdW5jdGlvbiBIYXNoUm91dGVyKF9yZWY1KSB7XG4gIGxldCB7XG4gICAgYmFzZW5hbWUsXG4gICAgY2hpbGRyZW4sXG4gICAgZnV0dXJlLFxuICAgIHdpbmRvd1xuICB9ID0gX3JlZjU7XG4gIGxldCBoaXN0b3J5UmVmID0gUmVhY3QudXNlUmVmKCk7XG4gIGlmIChoaXN0b3J5UmVmLmN1cnJlbnQgPT0gbnVsbCkge1xuICAgIGhpc3RvcnlSZWYuY3VycmVudCA9IGNyZWF0ZUhhc2hIaXN0b3J5KHtcbiAgICAgIHdpbmRvdyxcbiAgICAgIHY1Q29tcGF0OiB0cnVlXG4gICAgfSk7XG4gIH1cbiAgbGV0IGhpc3RvcnkgPSBoaXN0b3J5UmVmLmN1cnJlbnQ7XG4gIGxldCBbc3RhdGUsIHNldFN0YXRlSW1wbF0gPSBSZWFjdC51c2VTdGF0ZSh7XG4gICAgYWN0aW9uOiBoaXN0b3J5LmFjdGlvbixcbiAgICBsb2NhdGlvbjogaGlzdG9yeS5sb2NhdGlvblxuICB9KTtcbiAgbGV0IHtcbiAgICB2N19zdGFydFRyYW5zaXRpb25cbiAgfSA9IGZ1dHVyZSB8fCB7fTtcbiAgbGV0IHNldFN0YXRlID0gUmVhY3QudXNlQ2FsbGJhY2sobmV3U3RhdGUgPT4ge1xuICAgIHY3X3N0YXJ0VHJhbnNpdGlvbiAmJiBzdGFydFRyYW5zaXRpb25JbXBsID8gc3RhcnRUcmFuc2l0aW9uSW1wbCgoKSA9PiBzZXRTdGF0ZUltcGwobmV3U3RhdGUpKSA6IHNldFN0YXRlSW1wbChuZXdTdGF0ZSk7XG4gIH0sIFtzZXRTdGF0ZUltcGwsIHY3X3N0YXJ0VHJhbnNpdGlvbl0pO1xuICBSZWFjdC51c2VMYXlvdXRFZmZlY3QoKCkgPT4gaGlzdG9yeS5saXN0ZW4oc2V0U3RhdGUpLCBbaGlzdG9yeSwgc2V0U3RhdGVdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IFVOU0FGRV9sb2dWNkRlcHJlY2F0aW9uV2FybmluZ3MoZnV0dXJlKSwgW2Z1dHVyZV0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUVsZW1lbnQoUm91dGVyLCB7XG4gICAgYmFzZW5hbWU6IGJhc2VuYW1lLFxuICAgIGNoaWxkcmVuOiBjaGlsZHJlbixcbiAgICBsb2NhdGlvbjogc3RhdGUubG9jYXRpb24sXG4gICAgbmF2aWdhdGlvblR5cGU6IHN0YXRlLmFjdGlvbixcbiAgICBuYXZpZ2F0b3I6IGhpc3RvcnksXG4gICAgZnV0dXJlOiBmdXR1cmVcbiAgfSk7XG59XG4vKipcbiAqIEEgYDxSb3V0ZXI+YCB0aGF0IGFjY2VwdHMgYSBwcmUtaW5zdGFudGlhdGVkIGhpc3Rvcnkgb2JqZWN0LiBJdCdzIGltcG9ydGFudFxuICogdG8gbm90ZSB0aGF0IHVzaW5nIHlvdXIgb3duIGhpc3Rvcnkgb2JqZWN0IGlzIGhpZ2hseSBkaXNjb3VyYWdlZCBhbmQgbWF5IGFkZFxuICogdHdvIHZlcnNpb25zIG9mIHRoZSBoaXN0b3J5IGxpYnJhcnkgdG8geW91ciBidW5kbGVzIHVubGVzcyB5b3UgdXNlIHRoZSBzYW1lXG4gKiB2ZXJzaW9uIG9mIHRoZSBoaXN0b3J5IGxpYnJhcnkgdGhhdCBSZWFjdCBSb3V0ZXIgdXNlcyBpbnRlcm5hbGx5LlxuICovXG5mdW5jdGlvbiBIaXN0b3J5Um91dGVyKF9yZWY2KSB7XG4gIGxldCB7XG4gICAgYmFzZW5hbWUsXG4gICAgY2hpbGRyZW4sXG4gICAgZnV0dXJlLFxuICAgIGhpc3RvcnlcbiAgfSA9IF9yZWY2O1xuICBsZXQgW3N0YXRlLCBzZXRTdGF0ZUltcGxdID0gUmVhY3QudXNlU3RhdGUoe1xuICAgIGFjdGlvbjogaGlzdG9yeS5hY3Rpb24sXG4gICAgbG9jYXRpb246IGhpc3RvcnkubG9jYXRpb25cbiAgfSk7XG4gIGxldCB7XG4gICAgdjdfc3RhcnRUcmFuc2l0aW9uXG4gIH0gPSBmdXR1cmUgfHwge307XG4gIGxldCBzZXRTdGF0ZSA9IFJlYWN0LnVzZUNhbGxiYWNrKG5ld1N0YXRlID0+IHtcbiAgICB2N19zdGFydFRyYW5zaXRpb24gJiYgc3RhcnRUcmFuc2l0aW9uSW1wbCA/IHN0YXJ0VHJhbnNpdGlvbkltcGwoKCkgPT4gc2V0U3RhdGVJbXBsKG5ld1N0YXRlKSkgOiBzZXRTdGF0ZUltcGwobmV3U3RhdGUpO1xuICB9LCBbc2V0U3RhdGVJbXBsLCB2N19zdGFydFRyYW5zaXRpb25dKTtcbiAgUmVhY3QudXNlTGF5b3V0RWZmZWN0KCgpID0+IGhpc3RvcnkubGlzdGVuKHNldFN0YXRlKSwgW2hpc3RvcnksIHNldFN0YXRlXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiBVTlNBRkVfbG9nVjZEZXByZWNhdGlvbldhcm5pbmdzKGZ1dHVyZSksIFtmdXR1cmVdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVFbGVtZW50KFJvdXRlciwge1xuICAgIGJhc2VuYW1lOiBiYXNlbmFtZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW4sXG4gICAgbG9jYXRpb246IHN0YXRlLmxvY2F0aW9uLFxuICAgIG5hdmlnYXRpb25UeXBlOiBzdGF0ZS5hY3Rpb24sXG4gICAgbmF2aWdhdG9yOiBoaXN0b3J5LFxuICAgIGZ1dHVyZTogZnV0dXJlXG4gIH0pO1xufVxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBIaXN0b3J5Um91dGVyLmRpc3BsYXlOYW1lID0gXCJ1bnN0YWJsZV9IaXN0b3J5Um91dGVyXCI7XG59XG5jb25zdCBpc0Jyb3dzZXIgPSB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiB3aW5kb3cuZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgdHlwZW9mIHdpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50ICE9PSBcInVuZGVmaW5lZFwiO1xuY29uc3QgQUJTT0xVVEVfVVJMX1JFR0VYID0gL14oPzpbYS16XVthLXowLTkrLi1dKjp8XFwvXFwvKS9pO1xuLyoqXG4gKiBUaGUgcHVibGljIEFQSSBmb3IgcmVuZGVyaW5nIGEgaGlzdG9yeS1hd2FyZSBgPGE+YC5cbiAqL1xuY29uc3QgTGluayA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIExpbmtXaXRoUmVmKF9yZWY3LCByZWYpIHtcbiAgbGV0IHtcbiAgICAgIG9uQ2xpY2ssXG4gICAgICByZWxhdGl2ZSxcbiAgICAgIHJlbG9hZERvY3VtZW50LFxuICAgICAgcmVwbGFjZSxcbiAgICAgIHN0YXRlLFxuICAgICAgdGFyZ2V0LFxuICAgICAgdG8sXG4gICAgICBwcmV2ZW50U2Nyb2xsUmVzZXQsXG4gICAgICB2aWV3VHJhbnNpdGlvblxuICAgIH0gPSBfcmVmNyxcbiAgICByZXN0ID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoX3JlZjcsIF9leGNsdWRlZCk7XG4gIGxldCB7XG4gICAgYmFzZW5hbWVcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoVU5TQUZFX05hdmlnYXRpb25Db250ZXh0KTtcbiAgLy8gUmVuZGVyZWQgaW50byA8YSBocmVmPiBmb3IgYWJzb2x1dGUgVVJMc1xuICBsZXQgYWJzb2x1dGVIcmVmO1xuICBsZXQgaXNFeHRlcm5hbCA9IGZhbHNlO1xuICBpZiAodHlwZW9mIHRvID09PSBcInN0cmluZ1wiICYmIEFCU09MVVRFX1VSTF9SRUdFWC50ZXN0KHRvKSkge1xuICAgIC8vIFJlbmRlciB0aGUgYWJzb2x1dGUgaHJlZiBzZXJ2ZXItIGFuZCBjbGllbnQtc2lkZVxuICAgIGFic29sdXRlSHJlZiA9IHRvO1xuICAgIC8vIE9ubHkgY2hlY2sgZm9yIGV4dGVybmFsIG9yaWdpbnMgY2xpZW50LXNpZGVcbiAgICBpZiAoaXNCcm93c2VyKSB7XG4gICAgICB0cnkge1xuICAgICAgICBsZXQgY3VycmVudFVybCA9IG5ldyBVUkwod2luZG93LmxvY2F0aW9uLmhyZWYpO1xuICAgICAgICBsZXQgdGFyZ2V0VXJsID0gdG8uc3RhcnRzV2l0aChcIi8vXCIpID8gbmV3IFVSTChjdXJyZW50VXJsLnByb3RvY29sICsgdG8pIDogbmV3IFVSTCh0byk7XG4gICAgICAgIGxldCBwYXRoID0gc3RyaXBCYXNlbmFtZSh0YXJnZXRVcmwucGF0aG5hbWUsIGJhc2VuYW1lKTtcbiAgICAgICAgaWYgKHRhcmdldFVybC5vcmlnaW4gPT09IGN1cnJlbnRVcmwub3JpZ2luICYmIHBhdGggIT0gbnVsbCkge1xuICAgICAgICAgIC8vIFN0cmlwIHRoZSBwcm90b2NvbC9vcmlnaW4vYmFzZW5hbWUgZm9yIHNhbWUtb3JpZ2luIGFic29sdXRlIFVSTHNcbiAgICAgICAgICB0byA9IHBhdGggKyB0YXJnZXRVcmwuc2VhcmNoICsgdGFyZ2V0VXJsLmhhc2g7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaXNFeHRlcm5hbCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gV2UgY2FuJ3QgZG8gZXh0ZXJuYWwgVVJMIGRldGVjdGlvbiB3aXRob3V0IGEgdmFsaWQgVVJMXG4gICAgICAgIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV93YXJuaW5nKGZhbHNlLCBcIjxMaW5rIHRvPVxcXCJcIiArIHRvICsgXCJcXFwiPiBjb250YWlucyBhbiBpbnZhbGlkIFVSTCB3aGljaCB3aWxsIHByb2JhYmx5IGJyZWFrIFwiICsgXCJ3aGVuIGNsaWNrZWQgLSBwbGVhc2UgdXBkYXRlIHRvIGEgdmFsaWQgVVJMIHBhdGguXCIpIDogdm9pZCAwO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAvLyBSZW5kZXJlZCBpbnRvIDxhIGhyZWY+IGZvciByZWxhdGl2ZSBVUkxzXG4gIGxldCBocmVmID0gdXNlSHJlZih0bywge1xuICAgIHJlbGF0aXZlXG4gIH0pO1xuICBsZXQgaW50ZXJuYWxPbkNsaWNrID0gdXNlTGlua0NsaWNrSGFuZGxlcih0bywge1xuICAgIHJlcGxhY2UsXG4gICAgc3RhdGUsXG4gICAgdGFyZ2V0LFxuICAgIHByZXZlbnRTY3JvbGxSZXNldCxcbiAgICByZWxhdGl2ZSxcbiAgICB2aWV3VHJhbnNpdGlvblxuICB9KTtcbiAgZnVuY3Rpb24gaGFuZGxlQ2xpY2soZXZlbnQpIHtcbiAgICBpZiAob25DbGljaykgb25DbGljayhldmVudCk7XG4gICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICBpbnRlcm5hbE9uQ2xpY2soZXZlbnQpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gKFxuICAgIC8qI19fUFVSRV9fKi9cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUganN4LWExMXkvYW5jaG9yLWhhcy1jb250ZW50XG4gICAgUmVhY3QuY3JlYXRlRWxlbWVudChcImFcIiwgX2V4dGVuZHMoe30sIHJlc3QsIHtcbiAgICAgIGhyZWY6IGFic29sdXRlSHJlZiB8fCBocmVmLFxuICAgICAgb25DbGljazogaXNFeHRlcm5hbCB8fCByZWxvYWREb2N1bWVudCA/IG9uQ2xpY2sgOiBoYW5kbGVDbGljayxcbiAgICAgIHJlZjogcmVmLFxuICAgICAgdGFyZ2V0OiB0YXJnZXRcbiAgICB9KSlcbiAgKTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBMaW5rLmRpc3BsYXlOYW1lID0gXCJMaW5rXCI7XG59XG4vKipcbiAqIEEgYDxMaW5rPmAgd3JhcHBlciB0aGF0IGtub3dzIGlmIGl0J3MgXCJhY3RpdmVcIiBvciBub3QuXG4gKi9cbmNvbnN0IE5hdkxpbmsgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBOYXZMaW5rV2l0aFJlZihfcmVmOCwgcmVmKSB7XG4gIGxldCB7XG4gICAgICBcImFyaWEtY3VycmVudFwiOiBhcmlhQ3VycmVudFByb3AgPSBcInBhZ2VcIixcbiAgICAgIGNhc2VTZW5zaXRpdmUgPSBmYWxzZSxcbiAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lUHJvcCA9IFwiXCIsXG4gICAgICBlbmQgPSBmYWxzZSxcbiAgICAgIHN0eWxlOiBzdHlsZVByb3AsXG4gICAgICB0byxcbiAgICAgIHZpZXdUcmFuc2l0aW9uLFxuICAgICAgY2hpbGRyZW5cbiAgICB9ID0gX3JlZjgsXG4gICAgcmVzdCA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKF9yZWY4LCBfZXhjbHVkZWQyKTtcbiAgbGV0IHBhdGggPSB1c2VSZXNvbHZlZFBhdGgodG8sIHtcbiAgICByZWxhdGl2ZTogcmVzdC5yZWxhdGl2ZVxuICB9KTtcbiAgbGV0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgbGV0IHJvdXRlclN0YXRlID0gUmVhY3QudXNlQ29udGV4dChVTlNBRkVfRGF0YVJvdXRlclN0YXRlQ29udGV4dCk7XG4gIGxldCB7XG4gICAgbmF2aWdhdG9yLFxuICAgIGJhc2VuYW1lXG4gIH0gPSBSZWFjdC51c2VDb250ZXh0KFVOU0FGRV9OYXZpZ2F0aW9uQ29udGV4dCk7XG4gIGxldCBpc1RyYW5zaXRpb25pbmcgPSByb3V0ZXJTdGF0ZSAhPSBudWxsICYmXG4gIC8vIENvbmRpdGlvbmFsIHVzYWdlIGlzIE9LIGhlcmUgYmVjYXVzZSB0aGUgdXNhZ2Ugb2YgYSBkYXRhIHJvdXRlciBpcyBzdGF0aWNcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gIHVzZVZpZXdUcmFuc2l0aW9uU3RhdGUocGF0aCkgJiYgdmlld1RyYW5zaXRpb24gPT09IHRydWU7XG4gIGxldCB0b1BhdGhuYW1lID0gbmF2aWdhdG9yLmVuY29kZUxvY2F0aW9uID8gbmF2aWdhdG9yLmVuY29kZUxvY2F0aW9uKHBhdGgpLnBhdGhuYW1lIDogcGF0aC5wYXRobmFtZTtcbiAgbGV0IGxvY2F0aW9uUGF0aG5hbWUgPSBsb2NhdGlvbi5wYXRobmFtZTtcbiAgbGV0IG5leHRMb2NhdGlvblBhdGhuYW1lID0gcm91dGVyU3RhdGUgJiYgcm91dGVyU3RhdGUubmF2aWdhdGlvbiAmJiByb3V0ZXJTdGF0ZS5uYXZpZ2F0aW9uLmxvY2F0aW9uID8gcm91dGVyU3RhdGUubmF2aWdhdGlvbi5sb2NhdGlvbi5wYXRobmFtZSA6IG51bGw7XG4gIGlmICghY2FzZVNlbnNpdGl2ZSkge1xuICAgIGxvY2F0aW9uUGF0aG5hbWUgPSBsb2NhdGlvblBhdGhuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgbmV4dExvY2F0aW9uUGF0aG5hbWUgPSBuZXh0TG9jYXRpb25QYXRobmFtZSA/IG5leHRMb2NhdGlvblBhdGhuYW1lLnRvTG93ZXJDYXNlKCkgOiBudWxsO1xuICAgIHRvUGF0aG5hbWUgPSB0b1BhdGhuYW1lLnRvTG93ZXJDYXNlKCk7XG4gIH1cbiAgaWYgKG5leHRMb2NhdGlvblBhdGhuYW1lICYmIGJhc2VuYW1lKSB7XG4gICAgbmV4dExvY2F0aW9uUGF0aG5hbWUgPSBzdHJpcEJhc2VuYW1lKG5leHRMb2NhdGlvblBhdGhuYW1lLCBiYXNlbmFtZSkgfHwgbmV4dExvY2F0aW9uUGF0aG5hbWU7XG4gIH1cbiAgLy8gSWYgdGhlIGB0b2AgaGFzIGEgdHJhaWxpbmcgc2xhc2gsIGxvb2sgYXQgdGhhdCBleGFjdCBzcG90LiAgT3RoZXJ3aXNlLFxuICAvLyB3ZSdyZSBsb29raW5nIGZvciBhIHNsYXNoIF9hZnRlcl8gd2hhdCdzIGluIGB0b2AuICBGb3IgZXhhbXBsZTpcbiAgLy9cbiAgLy8gPE5hdkxpbmsgdG89XCIvdXNlcnNcIj4gYW5kIDxOYXZMaW5rIHRvPVwiL3VzZXJzL1wiPlxuICAvLyBib3RoIHdhbnQgdG8gbG9vayBmb3IgYSAvIGF0IGluZGV4IDYgdG8gbWF0Y2ggVVJMIGAvdXNlcnMvbWF0dGBcbiAgY29uc3QgZW5kU2xhc2hQb3NpdGlvbiA9IHRvUGF0aG5hbWUgIT09IFwiL1wiICYmIHRvUGF0aG5hbWUuZW5kc1dpdGgoXCIvXCIpID8gdG9QYXRobmFtZS5sZW5ndGggLSAxIDogdG9QYXRobmFtZS5sZW5ndGg7XG4gIGxldCBpc0FjdGl2ZSA9IGxvY2F0aW9uUGF0aG5hbWUgPT09IHRvUGF0aG5hbWUgfHwgIWVuZCAmJiBsb2NhdGlvblBhdGhuYW1lLnN0YXJ0c1dpdGgodG9QYXRobmFtZSkgJiYgbG9jYXRpb25QYXRobmFtZS5jaGFyQXQoZW5kU2xhc2hQb3NpdGlvbikgPT09IFwiL1wiO1xuICBsZXQgaXNQZW5kaW5nID0gbmV4dExvY2F0aW9uUGF0aG5hbWUgIT0gbnVsbCAmJiAobmV4dExvY2F0aW9uUGF0aG5hbWUgPT09IHRvUGF0aG5hbWUgfHwgIWVuZCAmJiBuZXh0TG9jYXRpb25QYXRobmFtZS5zdGFydHNXaXRoKHRvUGF0aG5hbWUpICYmIG5leHRMb2NhdGlvblBhdGhuYW1lLmNoYXJBdCh0b1BhdGhuYW1lLmxlbmd0aCkgPT09IFwiL1wiKTtcbiAgbGV0IHJlbmRlclByb3BzID0ge1xuICAgIGlzQWN0aXZlLFxuICAgIGlzUGVuZGluZyxcbiAgICBpc1RyYW5zaXRpb25pbmdcbiAgfTtcbiAgbGV0IGFyaWFDdXJyZW50ID0gaXNBY3RpdmUgPyBhcmlhQ3VycmVudFByb3AgOiB1bmRlZmluZWQ7XG4gIGxldCBjbGFzc05hbWU7XG4gIGlmICh0eXBlb2YgY2xhc3NOYW1lUHJvcCA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgY2xhc3NOYW1lID0gY2xhc3NOYW1lUHJvcChyZW5kZXJQcm9wcyk7XG4gIH0gZWxzZSB7XG4gICAgLy8gSWYgdGhlIGNsYXNzTmFtZSBwcm9wIGlzIG5vdCBhIGZ1bmN0aW9uLCB3ZSB1c2UgYSBkZWZhdWx0IGBhY3RpdmVgXG4gICAgLy8gY2xhc3MgZm9yIDxOYXZMaW5rIC8+cyB0aGF0IGFyZSBhY3RpdmUuIEluIHY1IGBhY3RpdmVgIHdhcyB0aGUgZGVmYXVsdFxuICAgIC8vIHZhbHVlIGZvciBgYWN0aXZlQ2xhc3NOYW1lYCwgYnV0IHdlIGFyZSByZW1vdmluZyB0aGF0IEFQSSBhbmQgY2FuIHN0aWxsXG4gICAgLy8gdXNlIHRoZSBvbGQgZGVmYXVsdCBiZWhhdmlvciBmb3IgYSBjbGVhbmVyIHVwZ3JhZGUgcGF0aCBhbmQga2VlcCB0aGVcbiAgICAvLyBzaW1wbGUgc3R5bGluZyBydWxlcyB3b3JraW5nIGFzIHRoZXkgY3VycmVudGx5IGRvLlxuICAgIGNsYXNzTmFtZSA9IFtjbGFzc05hbWVQcm9wLCBpc0FjdGl2ZSA/IFwiYWN0aXZlXCIgOiBudWxsLCBpc1BlbmRpbmcgPyBcInBlbmRpbmdcIiA6IG51bGwsIGlzVHJhbnNpdGlvbmluZyA/IFwidHJhbnNpdGlvbmluZ1wiIDogbnVsbF0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oXCIgXCIpO1xuICB9XG4gIGxldCBzdHlsZSA9IHR5cGVvZiBzdHlsZVByb3AgPT09IFwiZnVuY3Rpb25cIiA/IHN0eWxlUHJvcChyZW5kZXJQcm9wcykgOiBzdHlsZVByb3A7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChMaW5rLCBfZXh0ZW5kcyh7fSwgcmVzdCwge1xuICAgIFwiYXJpYS1jdXJyZW50XCI6IGFyaWFDdXJyZW50LFxuICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lLFxuICAgIHJlZjogcmVmLFxuICAgIHN0eWxlOiBzdHlsZSxcbiAgICB0bzogdG8sXG4gICAgdmlld1RyYW5zaXRpb246IHZpZXdUcmFuc2l0aW9uXG4gIH0pLCB0eXBlb2YgY2hpbGRyZW4gPT09IFwiZnVuY3Rpb25cIiA/IGNoaWxkcmVuKHJlbmRlclByb3BzKSA6IGNoaWxkcmVuKTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBOYXZMaW5rLmRpc3BsYXlOYW1lID0gXCJOYXZMaW5rXCI7XG59XG4vKipcbiAqIEEgYEByZW1peC1ydW4vcm91dGVyYC1hd2FyZSBgPGZvcm0+YC4gSXQgYmVoYXZlcyBsaWtlIGEgbm9ybWFsIGZvcm0gZXhjZXB0XG4gKiB0aGF0IHRoZSBpbnRlcmFjdGlvbiB3aXRoIHRoZSBzZXJ2ZXIgaXMgd2l0aCBgZmV0Y2hgIGluc3RlYWQgb2YgbmV3IGRvY3VtZW50XG4gKiByZXF1ZXN0cywgYWxsb3dpbmcgY29tcG9uZW50cyB0byBhZGQgbmljZXIgVVggdG8gdGhlIHBhZ2UgYXMgdGhlIGZvcm0gaXNcbiAqIHN1Ym1pdHRlZCBhbmQgcmV0dXJucyB3aXRoIGRhdGEuXG4gKi9cbmNvbnN0IEZvcm0gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZigoX3JlZjksIGZvcndhcmRlZFJlZikgPT4ge1xuICBsZXQge1xuICAgICAgZmV0Y2hlcktleSxcbiAgICAgIG5hdmlnYXRlLFxuICAgICAgcmVsb2FkRG9jdW1lbnQsXG4gICAgICByZXBsYWNlLFxuICAgICAgc3RhdGUsXG4gICAgICBtZXRob2QgPSBkZWZhdWx0TWV0aG9kLFxuICAgICAgYWN0aW9uLFxuICAgICAgb25TdWJtaXQsXG4gICAgICByZWxhdGl2ZSxcbiAgICAgIHByZXZlbnRTY3JvbGxSZXNldCxcbiAgICAgIHZpZXdUcmFuc2l0aW9uXG4gICAgfSA9IF9yZWY5LFxuICAgIHByb3BzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UoX3JlZjksIF9leGNsdWRlZDMpO1xuICBsZXQgc3VibWl0ID0gdXNlU3VibWl0KCk7XG4gIGxldCBmb3JtQWN0aW9uID0gdXNlRm9ybUFjdGlvbihhY3Rpb24sIHtcbiAgICByZWxhdGl2ZVxuICB9KTtcbiAgbGV0IGZvcm1NZXRob2QgPSBtZXRob2QudG9Mb3dlckNhc2UoKSA9PT0gXCJnZXRcIiA/IFwiZ2V0XCIgOiBcInBvc3RcIjtcbiAgbGV0IHN1Ym1pdEhhbmRsZXIgPSBldmVudCA9PiB7XG4gICAgb25TdWJtaXQgJiYgb25TdWJtaXQoZXZlbnQpO1xuICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkKSByZXR1cm47XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBsZXQgc3VibWl0dGVyID0gZXZlbnQubmF0aXZlRXZlbnQuc3VibWl0dGVyO1xuICAgIGxldCBzdWJtaXRNZXRob2QgPSAoc3VibWl0dGVyID09IG51bGwgPyB2b2lkIDAgOiBzdWJtaXR0ZXIuZ2V0QXR0cmlidXRlKFwiZm9ybW1ldGhvZFwiKSkgfHwgbWV0aG9kO1xuICAgIHN1Ym1pdChzdWJtaXR0ZXIgfHwgZXZlbnQuY3VycmVudFRhcmdldCwge1xuICAgICAgZmV0Y2hlcktleSxcbiAgICAgIG1ldGhvZDogc3VibWl0TWV0aG9kLFxuICAgICAgbmF2aWdhdGUsXG4gICAgICByZXBsYWNlLFxuICAgICAgc3RhdGUsXG4gICAgICByZWxhdGl2ZSxcbiAgICAgIHByZXZlbnRTY3JvbGxSZXNldCxcbiAgICAgIHZpZXdUcmFuc2l0aW9uXG4gICAgfSk7XG4gIH07XG4gIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChcImZvcm1cIiwgX2V4dGVuZHMoe1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIG1ldGhvZDogZm9ybU1ldGhvZCxcbiAgICBhY3Rpb246IGZvcm1BY3Rpb24sXG4gICAgb25TdWJtaXQ6IHJlbG9hZERvY3VtZW50ID8gb25TdWJtaXQgOiBzdWJtaXRIYW5kbGVyXG4gIH0sIHByb3BzKSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgRm9ybS5kaXNwbGF5TmFtZSA9IFwiRm9ybVwiO1xufVxuLyoqXG4gKiBUaGlzIGNvbXBvbmVudCB3aWxsIGVtdWxhdGUgdGhlIGJyb3dzZXIncyBzY3JvbGwgcmVzdG9yYXRpb24gb24gbG9jYXRpb25cbiAqIGNoYW5nZXMuXG4gKi9cbmZ1bmN0aW9uIFNjcm9sbFJlc3RvcmF0aW9uKF9yZWYwKSB7XG4gIGxldCB7XG4gICAgZ2V0S2V5LFxuICAgIHN0b3JhZ2VLZXlcbiAgfSA9IF9yZWYwO1xuICB1c2VTY3JvbGxSZXN0b3JhdGlvbih7XG4gICAgZ2V0S2V5LFxuICAgIHN0b3JhZ2VLZXlcbiAgfSk7XG4gIHJldHVybiBudWxsO1xufVxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICBTY3JvbGxSZXN0b3JhdGlvbi5kaXNwbGF5TmFtZSA9IFwiU2Nyb2xsUmVzdG9yYXRpb25cIjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vI3JlZ2lvbiBIb29rc1xuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbnZhciBEYXRhUm91dGVySG9vaztcbihmdW5jdGlvbiAoRGF0YVJvdXRlckhvb2spIHtcbiAgRGF0YVJvdXRlckhvb2tbXCJVc2VTY3JvbGxSZXN0b3JhdGlvblwiXSA9IFwidXNlU2Nyb2xsUmVzdG9yYXRpb25cIjtcbiAgRGF0YVJvdXRlckhvb2tbXCJVc2VTdWJtaXRcIl0gPSBcInVzZVN1Ym1pdFwiO1xuICBEYXRhUm91dGVySG9va1tcIlVzZVN1Ym1pdEZldGNoZXJcIl0gPSBcInVzZVN1Ym1pdEZldGNoZXJcIjtcbiAgRGF0YVJvdXRlckhvb2tbXCJVc2VGZXRjaGVyXCJdID0gXCJ1c2VGZXRjaGVyXCI7XG4gIERhdGFSb3V0ZXJIb29rW1widXNlVmlld1RyYW5zaXRpb25TdGF0ZVwiXSA9IFwidXNlVmlld1RyYW5zaXRpb25TdGF0ZVwiO1xufSkoRGF0YVJvdXRlckhvb2sgfHwgKERhdGFSb3V0ZXJIb29rID0ge30pKTtcbnZhciBEYXRhUm91dGVyU3RhdGVIb29rO1xuKGZ1bmN0aW9uIChEYXRhUm91dGVyU3RhdGVIb29rKSB7XG4gIERhdGFSb3V0ZXJTdGF0ZUhvb2tbXCJVc2VGZXRjaGVyXCJdID0gXCJ1c2VGZXRjaGVyXCI7XG4gIERhdGFSb3V0ZXJTdGF0ZUhvb2tbXCJVc2VGZXRjaGVyc1wiXSA9IFwidXNlRmV0Y2hlcnNcIjtcbiAgRGF0YVJvdXRlclN0YXRlSG9va1tcIlVzZVNjcm9sbFJlc3RvcmF0aW9uXCJdID0gXCJ1c2VTY3JvbGxSZXN0b3JhdGlvblwiO1xufSkoRGF0YVJvdXRlclN0YXRlSG9vayB8fCAoRGF0YVJvdXRlclN0YXRlSG9vayA9IHt9KSk7XG4vLyBJbnRlcm5hbCBob29rc1xuZnVuY3Rpb24gZ2V0RGF0YVJvdXRlckNvbnNvbGVFcnJvcihob29rTmFtZSkge1xuICByZXR1cm4gaG9va05hbWUgKyBcIiBtdXN0IGJlIHVzZWQgd2l0aGluIGEgZGF0YSByb3V0ZXIuICBTZWUgaHR0cHM6Ly9yZWFjdHJvdXRlci5jb20vdjYvcm91dGVycy9waWNraW5nLWEtcm91dGVyLlwiO1xufVxuZnVuY3Rpb24gdXNlRGF0YVJvdXRlckNvbnRleHQoaG9va05hbWUpIHtcbiAgbGV0IGN0eCA9IFJlYWN0LnVzZUNvbnRleHQoVU5TQUZFX0RhdGFSb3V0ZXJDb250ZXh0KTtcbiAgIWN0eCA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIGdldERhdGFSb3V0ZXJDb25zb2xlRXJyb3IoaG9va05hbWUpKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICByZXR1cm4gY3R4O1xufVxuZnVuY3Rpb24gdXNlRGF0YVJvdXRlclN0YXRlKGhvb2tOYW1lKSB7XG4gIGxldCBzdGF0ZSA9IFJlYWN0LnVzZUNvbnRleHQoVU5TQUZFX0RhdGFSb3V0ZXJTdGF0ZUNvbnRleHQpO1xuICAhc3RhdGUgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCBnZXREYXRhUm91dGVyQ29uc29sZUVycm9yKGhvb2tOYW1lKSkgOiBVTlNBRkVfaW52YXJpYW50KGZhbHNlKSA6IHZvaWQgMDtcbiAgcmV0dXJuIHN0YXRlO1xufVxuLy8gRXh0ZXJuYWwgaG9va3Ncbi8qKlxuICogSGFuZGxlcyB0aGUgY2xpY2sgYmVoYXZpb3IgZm9yIHJvdXRlciBgPExpbms+YCBjb21wb25lbnRzLiBUaGlzIGlzIHVzZWZ1bCBpZlxuICogeW91IG5lZWQgdG8gY3JlYXRlIGN1c3RvbSBgPExpbms+YCBjb21wb25lbnRzIHdpdGggdGhlIHNhbWUgY2xpY2sgYmVoYXZpb3Igd2VcbiAqIHVzZSBpbiBvdXIgZXhwb3J0ZWQgYDxMaW5rPmAuXG4gKi9cbmZ1bmN0aW9uIHVzZUxpbmtDbGlja0hhbmRsZXIodG8sIF90ZW1wKSB7XG4gIGxldCB7XG4gICAgdGFyZ2V0LFxuICAgIHJlcGxhY2U6IHJlcGxhY2VQcm9wLFxuICAgIHN0YXRlLFxuICAgIHByZXZlbnRTY3JvbGxSZXNldCxcbiAgICByZWxhdGl2ZSxcbiAgICB2aWV3VHJhbnNpdGlvblxuICB9ID0gX3RlbXAgPT09IHZvaWQgMCA/IHt9IDogX3RlbXA7XG4gIGxldCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGxldCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XG4gIGxldCBwYXRoID0gdXNlUmVzb2x2ZWRQYXRoKHRvLCB7XG4gICAgcmVsYXRpdmVcbiAgfSk7XG4gIHJldHVybiBSZWFjdC51c2VDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKHNob3VsZFByb2Nlc3NMaW5rQ2xpY2soZXZlbnQsIHRhcmdldCkpIHtcbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAvLyBJZiB0aGUgVVJMIGhhc24ndCBjaGFuZ2VkLCBhIHJlZ3VsYXIgPGE+IHdpbGwgZG8gYSByZXBsYWNlIGluc3RlYWQgb2ZcbiAgICAgIC8vIGEgcHVzaCwgc28gZG8gdGhlIHNhbWUgaGVyZSB1bmxlc3MgdGhlIHJlcGxhY2UgcHJvcCBpcyBleHBsaWNpdGx5IHNldFxuICAgICAgbGV0IHJlcGxhY2UgPSByZXBsYWNlUHJvcCAhPT0gdW5kZWZpbmVkID8gcmVwbGFjZVByb3AgOiBjcmVhdGVQYXRoKGxvY2F0aW9uKSA9PT0gY3JlYXRlUGF0aChwYXRoKTtcbiAgICAgIG5hdmlnYXRlKHRvLCB7XG4gICAgICAgIHJlcGxhY2UsXG4gICAgICAgIHN0YXRlLFxuICAgICAgICBwcmV2ZW50U2Nyb2xsUmVzZXQsXG4gICAgICAgIHJlbGF0aXZlLFxuICAgICAgICB2aWV3VHJhbnNpdGlvblxuICAgICAgfSk7XG4gICAgfVxuICB9LCBbbG9jYXRpb24sIG5hdmlnYXRlLCBwYXRoLCByZXBsYWNlUHJvcCwgc3RhdGUsIHRhcmdldCwgdG8sIHByZXZlbnRTY3JvbGxSZXNldCwgcmVsYXRpdmUsIHZpZXdUcmFuc2l0aW9uXSk7XG59XG4vKipcbiAqIEEgY29udmVuaWVudCB3cmFwcGVyIGZvciByZWFkaW5nIGFuZCB3cml0aW5nIHNlYXJjaCBwYXJhbWV0ZXJzIHZpYSB0aGVcbiAqIFVSTFNlYXJjaFBhcmFtcyBpbnRlcmZhY2UuXG4gKi9cbmZ1bmN0aW9uIHVzZVNlYXJjaFBhcmFtcyhkZWZhdWx0SW5pdCkge1xuICBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfd2FybmluZyh0eXBlb2YgVVJMU2VhcmNoUGFyYW1zICE9PSBcInVuZGVmaW5lZFwiLCBcIllvdSBjYW5ub3QgdXNlIHRoZSBgdXNlU2VhcmNoUGFyYW1zYCBob29rIGluIGEgYnJvd3NlciB0aGF0IGRvZXMgbm90IFwiICsgXCJzdXBwb3J0IHRoZSBVUkxTZWFyY2hQYXJhbXMgQVBJLiBJZiB5b3UgbmVlZCB0byBzdXBwb3J0IEludGVybmV0IFwiICsgXCJFeHBsb3JlciAxMSwgd2UgcmVjb21tZW5kIHlvdSBsb2FkIGEgcG9seWZpbGwgc3VjaCBhcyBcIiArIFwiaHR0cHM6Ly9naXRodWIuY29tL3VuZ2FwL3VybC1zZWFyY2gtcGFyYW1zLlwiKSA6IHZvaWQgMDtcbiAgbGV0IGRlZmF1bHRTZWFyY2hQYXJhbXNSZWYgPSBSZWFjdC51c2VSZWYoY3JlYXRlU2VhcmNoUGFyYW1zKGRlZmF1bHRJbml0KSk7XG4gIGxldCBoYXNTZXRTZWFyY2hQYXJhbXNSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBsZXQgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xuICBsZXQgc2VhcmNoUGFyYW1zID0gUmVhY3QudXNlTWVtbygoKSA9PlxuICAvLyBPbmx5IG1lcmdlIGluIHRoZSBkZWZhdWx0cyBpZiB3ZSBoYXZlbid0IHlldCBjYWxsZWQgc2V0U2VhcmNoUGFyYW1zLlxuICAvLyBPbmNlIHdlIGNhbGwgdGhhdCB3ZSB3YW50IHRob3NlIHRvIHRha2UgcHJlY2VkZW5jZSwgb3RoZXJ3aXNlIHlvdSBjYW4ndFxuICAvLyByZW1vdmUgYSBwYXJhbSB3aXRoIHNldFNlYXJjaFBhcmFtcyh7fSkgaWYgaXQgaGFzIGFuIGluaXRpYWwgdmFsdWVcbiAgZ2V0U2VhcmNoUGFyYW1zRm9yTG9jYXRpb24obG9jYXRpb24uc2VhcmNoLCBoYXNTZXRTZWFyY2hQYXJhbXNSZWYuY3VycmVudCA/IG51bGwgOiBkZWZhdWx0U2VhcmNoUGFyYW1zUmVmLmN1cnJlbnQpLCBbbG9jYXRpb24uc2VhcmNoXSk7XG4gIGxldCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XG4gIGxldCBzZXRTZWFyY2hQYXJhbXMgPSBSZWFjdC51c2VDYWxsYmFjaygobmV4dEluaXQsIG5hdmlnYXRlT3B0aW9ucykgPT4ge1xuICAgIGNvbnN0IG5ld1NlYXJjaFBhcmFtcyA9IGNyZWF0ZVNlYXJjaFBhcmFtcyh0eXBlb2YgbmV4dEluaXQgPT09IFwiZnVuY3Rpb25cIiA/IG5leHRJbml0KHNlYXJjaFBhcmFtcykgOiBuZXh0SW5pdCk7XG4gICAgaGFzU2V0U2VhcmNoUGFyYW1zUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIG5hdmlnYXRlKFwiP1wiICsgbmV3U2VhcmNoUGFyYW1zLCBuYXZpZ2F0ZU9wdGlvbnMpO1xuICB9LCBbbmF2aWdhdGUsIHNlYXJjaFBhcmFtc10pO1xuICByZXR1cm4gW3NlYXJjaFBhcmFtcywgc2V0U2VhcmNoUGFyYW1zXTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlQ2xpZW50U2lkZVN1Ym1pc3Npb24oKSB7XG4gIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJZb3UgYXJlIGNhbGxpbmcgc3VibWl0IGR1cmluZyB0aGUgc2VydmVyIHJlbmRlci4gXCIgKyBcIlRyeSBjYWxsaW5nIHN1Ym1pdCB3aXRoaW4gYSBgdXNlRWZmZWN0YCBvciBjYWxsYmFjayBpbnN0ZWFkLlwiKTtcbiAgfVxufVxubGV0IGZldGNoZXJJZCA9IDA7XG5sZXQgZ2V0VW5pcXVlRmV0Y2hlcklkID0gKCkgPT4gXCJfX1wiICsgU3RyaW5nKCsrZmV0Y2hlcklkKSArIFwiX19cIjtcbi8qKlxuICogUmV0dXJucyBhIGZ1bmN0aW9uIHRoYXQgbWF5IGJlIHVzZWQgdG8gcHJvZ3JhbW1hdGljYWxseSBzdWJtaXQgYSBmb3JtIChvclxuICogc29tZSBhcmJpdHJhcnkgZGF0YSkgdG8gdGhlIHNlcnZlci5cbiAqL1xuZnVuY3Rpb24gdXNlU3VibWl0KCkge1xuICBsZXQge1xuICAgIHJvdXRlclxuICB9ID0gdXNlRGF0YVJvdXRlckNvbnRleHQoRGF0YVJvdXRlckhvb2suVXNlU3VibWl0KTtcbiAgbGV0IHtcbiAgICBiYXNlbmFtZVxuICB9ID0gUmVhY3QudXNlQ29udGV4dChVTlNBRkVfTmF2aWdhdGlvbkNvbnRleHQpO1xuICBsZXQgY3VycmVudFJvdXRlSWQgPSBVTlNBRkVfdXNlUm91dGVJZCgpO1xuICByZXR1cm4gUmVhY3QudXNlQ2FsbGJhY2soZnVuY3Rpb24gKHRhcmdldCwgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICB9XG4gICAgdmFsaWRhdGVDbGllbnRTaWRlU3VibWlzc2lvbigpO1xuICAgIGxldCB7XG4gICAgICBhY3Rpb24sXG4gICAgICBtZXRob2QsXG4gICAgICBlbmNUeXBlLFxuICAgICAgZm9ybURhdGEsXG4gICAgICBib2R5XG4gICAgfSA9IGdldEZvcm1TdWJtaXNzaW9uSW5mbyh0YXJnZXQsIGJhc2VuYW1lKTtcbiAgICBpZiAob3B0aW9ucy5uYXZpZ2F0ZSA9PT0gZmFsc2UpIHtcbiAgICAgIGxldCBrZXkgPSBvcHRpb25zLmZldGNoZXJLZXkgfHwgZ2V0VW5pcXVlRmV0Y2hlcklkKCk7XG4gICAgICByb3V0ZXIuZmV0Y2goa2V5LCBjdXJyZW50Um91dGVJZCwgb3B0aW9ucy5hY3Rpb24gfHwgYWN0aW9uLCB7XG4gICAgICAgIHByZXZlbnRTY3JvbGxSZXNldDogb3B0aW9ucy5wcmV2ZW50U2Nyb2xsUmVzZXQsXG4gICAgICAgIGZvcm1EYXRhLFxuICAgICAgICBib2R5LFxuICAgICAgICBmb3JtTWV0aG9kOiBvcHRpb25zLm1ldGhvZCB8fCBtZXRob2QsXG4gICAgICAgIGZvcm1FbmNUeXBlOiBvcHRpb25zLmVuY1R5cGUgfHwgZW5jVHlwZSxcbiAgICAgICAgZmx1c2hTeW5jOiBvcHRpb25zLmZsdXNoU3luY1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJvdXRlci5uYXZpZ2F0ZShvcHRpb25zLmFjdGlvbiB8fCBhY3Rpb24sIHtcbiAgICAgICAgcHJldmVudFNjcm9sbFJlc2V0OiBvcHRpb25zLnByZXZlbnRTY3JvbGxSZXNldCxcbiAgICAgICAgZm9ybURhdGEsXG4gICAgICAgIGJvZHksXG4gICAgICAgIGZvcm1NZXRob2Q6IG9wdGlvbnMubWV0aG9kIHx8IG1ldGhvZCxcbiAgICAgICAgZm9ybUVuY1R5cGU6IG9wdGlvbnMuZW5jVHlwZSB8fCBlbmNUeXBlLFxuICAgICAgICByZXBsYWNlOiBvcHRpb25zLnJlcGxhY2UsXG4gICAgICAgIHN0YXRlOiBvcHRpb25zLnN0YXRlLFxuICAgICAgICBmcm9tUm91dGVJZDogY3VycmVudFJvdXRlSWQsXG4gICAgICAgIGZsdXNoU3luYzogb3B0aW9ucy5mbHVzaFN5bmMsXG4gICAgICAgIHZpZXdUcmFuc2l0aW9uOiBvcHRpb25zLnZpZXdUcmFuc2l0aW9uXG4gICAgICB9KTtcbiAgICB9XG4gIH0sIFtyb3V0ZXIsIGJhc2VuYW1lLCBjdXJyZW50Um91dGVJZF0pO1xufVxuLy8gdjc6IEV2ZW50dWFsbHkgd2Ugc2hvdWxkIGRlcHJlY2F0ZSB0aGlzIGVudGlyZWx5IGluIGZhdm9yIG9mIHVzaW5nIHRoZVxuLy8gcm91dGVyIG1ldGhvZCBkaXJlY3RseT9cbmZ1bmN0aW9uIHVzZUZvcm1BY3Rpb24oYWN0aW9uLCBfdGVtcDIpIHtcbiAgbGV0IHtcbiAgICByZWxhdGl2ZVxuICB9ID0gX3RlbXAyID09PSB2b2lkIDAgPyB7fSA6IF90ZW1wMjtcbiAgbGV0IHtcbiAgICBiYXNlbmFtZVxuICB9ID0gUmVhY3QudXNlQ29udGV4dChVTlNBRkVfTmF2aWdhdGlvbkNvbnRleHQpO1xuICBsZXQgcm91dGVDb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChVTlNBRkVfUm91dGVDb250ZXh0KTtcbiAgIXJvdXRlQ29udGV4dCA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIFwidXNlRm9ybUFjdGlvbiBtdXN0IGJlIHVzZWQgaW5zaWRlIGEgUm91dGVDb250ZXh0XCIpIDogVU5TQUZFX2ludmFyaWFudChmYWxzZSkgOiB2b2lkIDA7XG4gIGxldCBbbWF0Y2hdID0gcm91dGVDb250ZXh0Lm1hdGNoZXMuc2xpY2UoLTEpO1xuICAvLyBTaGFsbG93IGNsb25lIHBhdGggc28gd2UgY2FuIG1vZGlmeSBpdCBiZWxvdywgb3RoZXJ3aXNlIHdlIG1vZGlmeSB0aGVcbiAgLy8gb2JqZWN0IHJlZmVyZW5jZWQgYnkgdXNlTWVtbyBpbnNpZGUgdXNlUmVzb2x2ZWRQYXRoXG4gIGxldCBwYXRoID0gX2V4dGVuZHMoe30sIHVzZVJlc29sdmVkUGF0aChhY3Rpb24gPyBhY3Rpb24gOiBcIi5cIiwge1xuICAgIHJlbGF0aXZlXG4gIH0pKTtcbiAgLy8gSWYgbm8gYWN0aW9uIHdhcyBzcGVjaWZpZWQsIGJyb3dzZXJzIHdpbGwgcGVyc2lzdCBjdXJyZW50IHNlYXJjaCBwYXJhbXNcbiAgLy8gd2hlbiBkZXRlcm1pbmluZyB0aGUgcGF0aCwgc28gbWF0Y2ggdGhhdCBiZWhhdmlvclxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vcmVtaXgtcnVuL3JlbWl4L2lzc3Vlcy85MjdcbiAgbGV0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgaWYgKGFjdGlvbiA9PSBudWxsKSB7XG4gICAgLy8gU2FmZSB0byB3cml0ZSB0byB0aGlzIGRpcmVjdGx5IGhlcmUgc2luY2UgaWYgYWN0aW9uIHdhcyB1bmRlZmluZWQsIHdlXG4gICAgLy8gd291bGQgaGF2ZSBjYWxsZWQgdXNlUmVzb2x2ZWRQYXRoKFwiLlwiKSB3aGljaCB3aWxsIG5ldmVyIGluY2x1ZGUgYSBzZWFyY2hcbiAgICBwYXRoLnNlYXJjaCA9IGxvY2F0aW9uLnNlYXJjaDtcbiAgICAvLyBXaGVuIGdyYWJiaW5nIHNlYXJjaCBwYXJhbXMgZnJvbSB0aGUgVVJMLCByZW1vdmUgYW55IGluY2x1ZGVkID9pbmRleCBwYXJhbVxuICAgIC8vIHNpbmNlIGl0IG1pZ2h0IG5vdCBhcHBseSB0byBvdXIgY29udGV4dHVhbCByb3V0ZS4gIFdlIGFkZCBpdCBiYWNrIGJhc2VkXG4gICAgLy8gb24gbWF0Y2gucm91dGUuaW5kZXggYmVsb3dcbiAgICBsZXQgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhwYXRoLnNlYXJjaCk7XG4gICAgbGV0IGluZGV4VmFsdWVzID0gcGFyYW1zLmdldEFsbChcImluZGV4XCIpO1xuICAgIGxldCBoYXNOYWtlZEluZGV4UGFyYW0gPSBpbmRleFZhbHVlcy5zb21lKHYgPT4gdiA9PT0gXCJcIik7XG4gICAgaWYgKGhhc05ha2VkSW5kZXhQYXJhbSkge1xuICAgICAgcGFyYW1zLmRlbGV0ZShcImluZGV4XCIpO1xuICAgICAgaW5kZXhWYWx1ZXMuZmlsdGVyKHYgPT4gdikuZm9yRWFjaCh2ID0+IHBhcmFtcy5hcHBlbmQoXCJpbmRleFwiLCB2KSk7XG4gICAgICBsZXQgcXMgPSBwYXJhbXMudG9TdHJpbmcoKTtcbiAgICAgIHBhdGguc2VhcmNoID0gcXMgPyBcIj9cIiArIHFzIDogXCJcIjtcbiAgICB9XG4gIH1cbiAgaWYgKCghYWN0aW9uIHx8IGFjdGlvbiA9PT0gXCIuXCIpICYmIG1hdGNoLnJvdXRlLmluZGV4KSB7XG4gICAgcGF0aC5zZWFyY2ggPSBwYXRoLnNlYXJjaCA/IHBhdGguc2VhcmNoLnJlcGxhY2UoL15cXD8vLCBcIj9pbmRleCZcIikgOiBcIj9pbmRleFwiO1xuICB9XG4gIC8vIElmIHdlJ3JlIG9wZXJhdGluZyB3aXRoaW4gYSBiYXNlbmFtZSwgcHJlcGVuZCBpdCB0byB0aGUgcGF0aG5hbWUgcHJpb3JcbiAgLy8gdG8gY3JlYXRpbmcgdGhlIGZvcm0gYWN0aW9uLiAgSWYgdGhpcyBpcyBhIHJvb3QgbmF2aWdhdGlvbiwgdGhlbiBqdXN0IHVzZVxuICAvLyB0aGUgcmF3IGJhc2VuYW1lIHdoaWNoIGFsbG93cyB0aGUgYmFzZW5hbWUgdG8gaGF2ZSBmdWxsIGNvbnRyb2wgb3ZlciB0aGVcbiAgLy8gcHJlc2VuY2Ugb2YgYSB0cmFpbGluZyBzbGFzaCBvbiByb290IGFjdGlvbnNcbiAgaWYgKGJhc2VuYW1lICE9PSBcIi9cIikge1xuICAgIHBhdGgucGF0aG5hbWUgPSBwYXRoLnBhdGhuYW1lID09PSBcIi9cIiA/IGJhc2VuYW1lIDogam9pblBhdGhzKFtiYXNlbmFtZSwgcGF0aC5wYXRobmFtZV0pO1xuICB9XG4gIHJldHVybiBjcmVhdGVQYXRoKHBhdGgpO1xufVxuLy8gVE9ETzogKHY3KSBDaGFuZ2UgdGhlIHVzZUZldGNoZXIgZ2VuZXJpYyBkZWZhdWx0IGZyb20gYGFueWAgdG8gYHVua25vd25gXG4vKipcbiAqIEludGVyYWN0cyB3aXRoIHJvdXRlIGxvYWRlcnMgYW5kIGFjdGlvbnMgd2l0aG91dCBjYXVzaW5nIGEgbmF2aWdhdGlvbi4gR3JlYXRcbiAqIGZvciBhbnkgaW50ZXJhY3Rpb24gdGhhdCBzdGF5cyBvbiB0aGUgc2FtZSBwYWdlLlxuICovXG5mdW5jdGlvbiB1c2VGZXRjaGVyKF90ZW1wMykge1xuICB2YXIgX3JvdXRlJG1hdGNoZXM7XG4gIGxldCB7XG4gICAga2V5XG4gIH0gPSBfdGVtcDMgPT09IHZvaWQgMCA/IHt9IDogX3RlbXAzO1xuICBsZXQge1xuICAgIHJvdXRlclxuICB9ID0gdXNlRGF0YVJvdXRlckNvbnRleHQoRGF0YVJvdXRlckhvb2suVXNlRmV0Y2hlcik7XG4gIGxldCBzdGF0ZSA9IHVzZURhdGFSb3V0ZXJTdGF0ZShEYXRhUm91dGVyU3RhdGVIb29rLlVzZUZldGNoZXIpO1xuICBsZXQgZmV0Y2hlckRhdGEgPSBSZWFjdC51c2VDb250ZXh0KEZldGNoZXJzQ29udGV4dCk7XG4gIGxldCByb3V0ZSA9IFJlYWN0LnVzZUNvbnRleHQoVU5TQUZFX1JvdXRlQ29udGV4dCk7XG4gIGxldCByb3V0ZUlkID0gKF9yb3V0ZSRtYXRjaGVzID0gcm91dGUubWF0Y2hlc1tyb3V0ZS5tYXRjaGVzLmxlbmd0aCAtIDFdKSA9PSBudWxsID8gdm9pZCAwIDogX3JvdXRlJG1hdGNoZXMucm91dGUuaWQ7XG4gICFmZXRjaGVyRGF0YSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIFwidXNlRmV0Y2hlciBtdXN0IGJlIHVzZWQgaW5zaWRlIGEgRmV0Y2hlcnNDb250ZXh0XCIpIDogVU5TQUZFX2ludmFyaWFudChmYWxzZSkgOiB2b2lkIDA7XG4gICFyb3V0ZSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIFwidXNlRmV0Y2hlciBtdXN0IGJlIHVzZWQgaW5zaWRlIGEgUm91dGVDb250ZXh0XCIpIDogVU5TQUZFX2ludmFyaWFudChmYWxzZSkgOiB2b2lkIDA7XG4gICEocm91dGVJZCAhPSBudWxsKSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIFwidXNlRmV0Y2hlciBjYW4gb25seSBiZSB1c2VkIG9uIHJvdXRlcyB0aGF0IGNvbnRhaW4gYSB1bmlxdWUgXFxcImlkXFxcIlwiKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICAvLyBGZXRjaGVyIGtleSBoYW5kbGluZ1xuICAvLyBPSyB0byBjYWxsIGNvbmRpdGlvbmFsbHkgdG8gZmVhdHVyZSBkZXRlY3QgYHVzZUlkYFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3NcbiAgbGV0IGRlZmF1bHRLZXkgPSB1c2VJZEltcGwgPyB1c2VJZEltcGwoKSA6IFwiXCI7XG4gIGxldCBbZmV0Y2hlcktleSwgc2V0RmV0Y2hlcktleV0gPSBSZWFjdC51c2VTdGF0ZShrZXkgfHwgZGVmYXVsdEtleSk7XG4gIGlmIChrZXkgJiYga2V5ICE9PSBmZXRjaGVyS2V5KSB7XG4gICAgc2V0RmV0Y2hlcktleShrZXkpO1xuICB9IGVsc2UgaWYgKCFmZXRjaGVyS2V5KSB7XG4gICAgLy8gV2Ugd2lsbCBvbmx5IGZhbGwgdGhyb3VnaCBoZXJlIHdoZW4gYHVzZUlkYCBpcyBub3QgYXZhaWxhYmxlXG4gICAgc2V0RmV0Y2hlcktleShnZXRVbmlxdWVGZXRjaGVySWQoKSk7XG4gIH1cbiAgLy8gUmVnaXN0cmF0aW9uL2NsZWFudXBcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICByb3V0ZXIuZ2V0RmV0Y2hlcihmZXRjaGVyS2V5KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgLy8gVGVsbCB0aGUgcm91dGVyIHdlJ3ZlIHVubW91bnRlZCAtIGlmIHY3X2ZldGNoZXJQZXJzaXN0IGlzIGVuYWJsZWQgdGhpc1xuICAgICAgLy8gd2lsbCBub3QgZGVsZXRlIGltbWVkaWF0ZWx5IGJ1dCBpbnN0ZWFkIHF1ZXVlIHVwIGEgZGVsZXRlIGFmdGVyIHRoZVxuICAgICAgLy8gZmV0Y2hlciByZXR1cm5zIHRvIGFuIGBpZGxlYCBzdGF0ZVxuICAgICAgcm91dGVyLmRlbGV0ZUZldGNoZXIoZmV0Y2hlcktleSk7XG4gICAgfTtcbiAgfSwgW3JvdXRlciwgZmV0Y2hlcktleV0pO1xuICAvLyBGZXRjaGVyIGFkZGl0aW9uc1xuICBsZXQgbG9hZCA9IFJlYWN0LnVzZUNhbGxiYWNrKChocmVmLCBvcHRzKSA9PiB7XG4gICAgIXJvdXRlSWQgPyBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBVTlNBRkVfaW52YXJpYW50KGZhbHNlLCBcIk5vIHJvdXRlSWQgYXZhaWxhYmxlIGZvciBmZXRjaGVyLmxvYWQoKVwiKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICAgIHJvdXRlci5mZXRjaChmZXRjaGVyS2V5LCByb3V0ZUlkLCBocmVmLCBvcHRzKTtcbiAgfSwgW2ZldGNoZXJLZXksIHJvdXRlSWQsIHJvdXRlcl0pO1xuICBsZXQgc3VibWl0SW1wbCA9IHVzZVN1Ym1pdCgpO1xuICBsZXQgc3VibWl0ID0gUmVhY3QudXNlQ2FsbGJhY2soKHRhcmdldCwgb3B0cykgPT4ge1xuICAgIHN1Ym1pdEltcGwodGFyZ2V0LCBfZXh0ZW5kcyh7fSwgb3B0cywge1xuICAgICAgbmF2aWdhdGU6IGZhbHNlLFxuICAgICAgZmV0Y2hlcktleVxuICAgIH0pKTtcbiAgfSwgW2ZldGNoZXJLZXksIHN1Ym1pdEltcGxdKTtcbiAgbGV0IEZldGNoZXJGb3JtID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgbGV0IEZldGNoZXJGb3JtID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcbiAgICAgIHJldHVybiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlRWxlbWVudChGb3JtLCBfZXh0ZW5kcyh7fSwgcHJvcHMsIHtcbiAgICAgICAgbmF2aWdhdGU6IGZhbHNlLFxuICAgICAgICBmZXRjaGVyS2V5OiBmZXRjaGVyS2V5LFxuICAgICAgICByZWY6IHJlZlxuICAgICAgfSkpO1xuICAgIH0pO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIEZldGNoZXJGb3JtLmRpc3BsYXlOYW1lID0gXCJmZXRjaGVyLkZvcm1cIjtcbiAgICB9XG4gICAgcmV0dXJuIEZldGNoZXJGb3JtO1xuICB9LCBbZmV0Y2hlcktleV0pO1xuICAvLyBFeHBvc2VkIEZldGNoZXJXaXRoQ29tcG9uZW50c1xuICBsZXQgZmV0Y2hlciA9IHN0YXRlLmZldGNoZXJzLmdldChmZXRjaGVyS2V5KSB8fCBJRExFX0ZFVENIRVI7XG4gIGxldCBkYXRhID0gZmV0Y2hlckRhdGEuZ2V0KGZldGNoZXJLZXkpO1xuICBsZXQgZmV0Y2hlcldpdGhDb21wb25lbnRzID0gUmVhY3QudXNlTWVtbygoKSA9PiBfZXh0ZW5kcyh7XG4gICAgRm9ybTogRmV0Y2hlckZvcm0sXG4gICAgc3VibWl0LFxuICAgIGxvYWRcbiAgfSwgZmV0Y2hlciwge1xuICAgIGRhdGFcbiAgfSksIFtGZXRjaGVyRm9ybSwgc3VibWl0LCBsb2FkLCBmZXRjaGVyLCBkYXRhXSk7XG4gIHJldHVybiBmZXRjaGVyV2l0aENvbXBvbmVudHM7XG59XG4vKipcbiAqIFByb3ZpZGVzIGFsbCBmZXRjaGVycyBjdXJyZW50bHkgb24gdGhlIHBhZ2UuIFVzZWZ1bCBmb3IgbGF5b3V0cyBhbmQgcGFyZW50XG4gKiByb3V0ZXMgdGhhdCBuZWVkIHRvIHByb3ZpZGUgcGVuZGluZy9vcHRpbWlzdGljIFVJIHJlZ2FyZGluZyB0aGUgZmV0Y2guXG4gKi9cbmZ1bmN0aW9uIHVzZUZldGNoZXJzKCkge1xuICBsZXQgc3RhdGUgPSB1c2VEYXRhUm91dGVyU3RhdGUoRGF0YVJvdXRlclN0YXRlSG9vay5Vc2VGZXRjaGVycyk7XG4gIHJldHVybiBBcnJheS5mcm9tKHN0YXRlLmZldGNoZXJzLmVudHJpZXMoKSkubWFwKF9yZWYxID0+IHtcbiAgICBsZXQgW2tleSwgZmV0Y2hlcl0gPSBfcmVmMTtcbiAgICByZXR1cm4gX2V4dGVuZHMoe30sIGZldGNoZXIsIHtcbiAgICAgIGtleVxuICAgIH0pO1xuICB9KTtcbn1cbmNvbnN0IFNDUk9MTF9SRVNUT1JBVElPTl9TVE9SQUdFX0tFWSA9IFwicmVhY3Qtcm91dGVyLXNjcm9sbC1wb3NpdGlvbnNcIjtcbmxldCBzYXZlZFNjcm9sbFBvc2l0aW9ucyA9IHt9O1xuLyoqXG4gKiBXaGVuIHJlbmRlcmVkIGluc2lkZSBhIFJvdXRlclByb3ZpZGVyLCB3aWxsIHJlc3RvcmUgc2Nyb2xsIHBvc2l0aW9ucyBvbiBuYXZpZ2F0aW9uc1xuICovXG5mdW5jdGlvbiB1c2VTY3JvbGxSZXN0b3JhdGlvbihfdGVtcDQpIHtcbiAgbGV0IHtcbiAgICBnZXRLZXksXG4gICAgc3RvcmFnZUtleVxuICB9ID0gX3RlbXA0ID09PSB2b2lkIDAgPyB7fSA6IF90ZW1wNDtcbiAgbGV0IHtcbiAgICByb3V0ZXJcbiAgfSA9IHVzZURhdGFSb3V0ZXJDb250ZXh0KERhdGFSb3V0ZXJIb29rLlVzZVNjcm9sbFJlc3RvcmF0aW9uKTtcbiAgbGV0IHtcbiAgICByZXN0b3JlU2Nyb2xsUG9zaXRpb24sXG4gICAgcHJldmVudFNjcm9sbFJlc2V0XG4gIH0gPSB1c2VEYXRhUm91dGVyU3RhdGUoRGF0YVJvdXRlclN0YXRlSG9vay5Vc2VTY3JvbGxSZXN0b3JhdGlvbik7XG4gIGxldCB7XG4gICAgYmFzZW5hbWVcbiAgfSA9IFJlYWN0LnVzZUNvbnRleHQoVU5TQUZFX05hdmlnYXRpb25Db250ZXh0KTtcbiAgbGV0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgbGV0IG1hdGNoZXMgPSB1c2VNYXRjaGVzKCk7XG4gIGxldCBuYXZpZ2F0aW9uID0gdXNlTmF2aWdhdGlvbigpO1xuICAvLyBUcmlnZ2VyIG1hbnVhbCBzY3JvbGwgcmVzdG9yYXRpb24gd2hpbGUgd2UncmUgYWN0aXZlXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgd2luZG93Lmhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSBcIm1hbnVhbFwiO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cuaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwiYXV0b1wiO1xuICAgIH07XG4gIH0sIFtdKTtcbiAgLy8gU2F2ZSBwb3NpdGlvbnMgb24gcGFnZWhpZGVcbiAgdXNlUGFnZUhpZGUoUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmIChuYXZpZ2F0aW9uLnN0YXRlID09PSBcImlkbGVcIikge1xuICAgICAgbGV0IGtleSA9IChnZXRLZXkgPyBnZXRLZXkobG9jYXRpb24sIG1hdGNoZXMpIDogbnVsbCkgfHwgbG9jYXRpb24ua2V5O1xuICAgICAgc2F2ZWRTY3JvbGxQb3NpdGlvbnNba2V5XSA9IHdpbmRvdy5zY3JvbGxZO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShzdG9yYWdlS2V5IHx8IFNDUk9MTF9SRVNUT1JBVElPTl9TVE9SQUdFX0tFWSwgSlNPTi5zdHJpbmdpZnkoc2F2ZWRTY3JvbGxQb3NpdGlvbnMpKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gVU5TQUZFX3dhcm5pbmcoZmFsc2UsIFwiRmFpbGVkIHRvIHNhdmUgc2Nyb2xsIHBvc2l0aW9ucyBpbiBzZXNzaW9uU3RvcmFnZSwgPFNjcm9sbFJlc3RvcmF0aW9uIC8+IHdpbGwgbm90IHdvcmsgcHJvcGVybHkgKFwiICsgZXJyb3IgKyBcIikuXCIpIDogdm9pZCAwO1xuICAgIH1cbiAgICB3aW5kb3cuaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwiYXV0b1wiO1xuICB9LCBbc3RvcmFnZUtleSwgZ2V0S2V5LCBuYXZpZ2F0aW9uLnN0YXRlLCBsb2NhdGlvbiwgbWF0Y2hlc10pKTtcbiAgLy8gUmVhZCBpbiBhbnkgc2F2ZWQgc2Nyb2xsIGxvY2F0aW9uc1xuICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgUmVhY3QudXNlTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGxldCBzZXNzaW9uUG9zaXRpb25zID0gc2Vzc2lvblN0b3JhZ2UuZ2V0SXRlbShzdG9yYWdlS2V5IHx8IFNDUk9MTF9SRVNUT1JBVElPTl9TVE9SQUdFX0tFWSk7XG4gICAgICAgIGlmIChzZXNzaW9uUG9zaXRpb25zKSB7XG4gICAgICAgICAgc2F2ZWRTY3JvbGxQb3NpdGlvbnMgPSBKU09OLnBhcnNlKHNlc3Npb25Qb3NpdGlvbnMpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIG5vLW9wLCB1c2UgZGVmYXVsdCBlbXB0eSBvYmplY3RcbiAgICAgIH1cbiAgICB9LCBbc3RvcmFnZUtleV0pO1xuICAgIC8vIEVuYWJsZSBzY3JvbGwgcmVzdG9yYXRpb24gaW4gdGhlIHJvdXRlclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICAgIFJlYWN0LnVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICBsZXQgZ2V0S2V5V2l0aG91dEJhc2VuYW1lID0gZ2V0S2V5ICYmIGJhc2VuYW1lICE9PSBcIi9cIiA/IChsb2NhdGlvbiwgbWF0Y2hlcykgPT4gZ2V0S2V5KC8vIFN0cmlwIHRoZSBiYXNlbmFtZSB0byBtYXRjaCB1c2VMb2NhdGlvbigpXG4gICAgICBfZXh0ZW5kcyh7fSwgbG9jYXRpb24sIHtcbiAgICAgICAgcGF0aG5hbWU6IHN0cmlwQmFzZW5hbWUobG9jYXRpb24ucGF0aG5hbWUsIGJhc2VuYW1lKSB8fCBsb2NhdGlvbi5wYXRobmFtZVxuICAgICAgfSksIG1hdGNoZXMpIDogZ2V0S2V5O1xuICAgICAgbGV0IGRpc2FibGVTY3JvbGxSZXN0b3JhdGlvbiA9IHJvdXRlciA9PSBudWxsID8gdm9pZCAwIDogcm91dGVyLmVuYWJsZVNjcm9sbFJlc3RvcmF0aW9uKHNhdmVkU2Nyb2xsUG9zaXRpb25zLCAoKSA9PiB3aW5kb3cuc2Nyb2xsWSwgZ2V0S2V5V2l0aG91dEJhc2VuYW1lKTtcbiAgICAgIHJldHVybiAoKSA9PiBkaXNhYmxlU2Nyb2xsUmVzdG9yYXRpb24gJiYgZGlzYWJsZVNjcm9sbFJlc3RvcmF0aW9uKCk7XG4gICAgfSwgW3JvdXRlciwgYmFzZW5hbWUsIGdldEtleV0pO1xuICAgIC8vIFJlc3RvcmUgc2Nyb2xsaW5nIHdoZW4gc3RhdGUucmVzdG9yZVNjcm9sbFBvc2l0aW9uIGNoYW5nZXNcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3NcbiAgICBSZWFjdC51c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgLy8gRXhwbGljaXQgZmFsc2UgbWVhbnMgZG9uJ3QgZG8gYW55dGhpbmcgKHVzZWQgZm9yIHN1Ym1pc3Npb25zKVxuICAgICAgaWYgKHJlc3RvcmVTY3JvbGxQb3NpdGlvbiA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gYmVlbiBoZXJlIGJlZm9yZSwgc2Nyb2xsIHRvIGl0XG4gICAgICBpZiAodHlwZW9mIHJlc3RvcmVTY3JvbGxQb3NpdGlvbiA9PT0gXCJudW1iZXJcIikge1xuICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgcmVzdG9yZVNjcm9sbFBvc2l0aW9uKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gdHJ5IHRvIHNjcm9sbCB0byB0aGUgaGFzaFxuICAgICAgaWYgKGxvY2F0aW9uLmhhc2gpIHtcbiAgICAgICAgbGV0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoZGVjb2RlVVJJQ29tcG9uZW50KGxvY2F0aW9uLmhhc2guc2xpY2UoMSkpKTtcbiAgICAgICAgaWYgKGVsKSB7XG4gICAgICAgICAgZWwuc2Nyb2xsSW50b1ZpZXcoKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8vIERvbid0IHJlc2V0IGlmIHRoaXMgbmF2aWdhdGlvbiBvcHRlZCBvdXRcbiAgICAgIGlmIChwcmV2ZW50U2Nyb2xsUmVzZXQgPT09IHRydWUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gb3RoZXJ3aXNlIGdvIHRvIHRoZSB0b3Agb24gbmV3IGxvY2F0aW9uc1xuICAgICAgd2luZG93LnNjcm9sbFRvKDAsIDApO1xuICAgIH0sIFtsb2NhdGlvbiwgcmVzdG9yZVNjcm9sbFBvc2l0aW9uLCBwcmV2ZW50U2Nyb2xsUmVzZXRdKTtcbiAgfVxufVxuLyoqXG4gKiBTZXR1cCBhIGNhbGxiYWNrIHRvIGJlIGZpcmVkIG9uIHRoZSB3aW5kb3cncyBgYmVmb3JldW5sb2FkYCBldmVudC4gVGhpcyBpc1xuICogdXNlZnVsIGZvciBzYXZpbmcgc29tZSBkYXRhIHRvIGB3aW5kb3cubG9jYWxTdG9yYWdlYCBqdXN0IGJlZm9yZSB0aGUgcGFnZVxuICogcmVmcmVzaGVzLlxuICpcbiAqIE5vdGU6IFRoZSBgY2FsbGJhY2tgIGFyZ3VtZW50IHNob3VsZCBiZSBhIGZ1bmN0aW9uIGNyZWF0ZWQgd2l0aFxuICogYFJlYWN0LnVzZUNhbGxiYWNrKClgLlxuICovXG5mdW5jdGlvbiB1c2VCZWZvcmVVbmxvYWQoY2FsbGJhY2ssIG9wdGlvbnMpIHtcbiAgbGV0IHtcbiAgICBjYXB0dXJlXG4gIH0gPSBvcHRpb25zIHx8IHt9O1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxldCBvcHRzID0gY2FwdHVyZSAhPSBudWxsID8ge1xuICAgICAgY2FwdHVyZVxuICAgIH0gOiB1bmRlZmluZWQ7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJiZWZvcmV1bmxvYWRcIiwgY2FsbGJhY2ssIG9wdHMpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImJlZm9yZXVubG9hZFwiLCBjYWxsYmFjaywgb3B0cyk7XG4gICAgfTtcbiAgfSwgW2NhbGxiYWNrLCBjYXB0dXJlXSk7XG59XG4vKipcbiAqIFNldHVwIGEgY2FsbGJhY2sgdG8gYmUgZmlyZWQgb24gdGhlIHdpbmRvdydzIGBwYWdlaGlkZWAgZXZlbnQuIFRoaXMgaXNcbiAqIHVzZWZ1bCBmb3Igc2F2aW5nIHNvbWUgZGF0YSB0byBgd2luZG93LmxvY2FsU3RvcmFnZWAganVzdCBiZWZvcmUgdGhlIHBhZ2VcbiAqIHJlZnJlc2hlcy4gIFRoaXMgZXZlbnQgaXMgYmV0dGVyIHN1cHBvcnRlZCB0aGFuIGJlZm9yZXVubG9hZCBhY3Jvc3MgYnJvd3NlcnMuXG4gKlxuICogTm90ZTogVGhlIGBjYWxsYmFja2AgYXJndW1lbnQgc2hvdWxkIGJlIGEgZnVuY3Rpb24gY3JlYXRlZCB3aXRoXG4gKiBgUmVhY3QudXNlQ2FsbGJhY2soKWAuXG4gKi9cbmZ1bmN0aW9uIHVzZVBhZ2VIaWRlKGNhbGxiYWNrLCBvcHRpb25zKSB7XG4gIGxldCB7XG4gICAgY2FwdHVyZVxuICB9ID0gb3B0aW9ucyB8fCB7fTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgb3B0cyA9IGNhcHR1cmUgIT0gbnVsbCA/IHtcbiAgICAgIGNhcHR1cmVcbiAgICB9IDogdW5kZWZpbmVkO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgY2FsbGJhY2ssIG9wdHMpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIGNhbGxiYWNrLCBvcHRzKTtcbiAgICB9O1xuICB9LCBbY2FsbGJhY2ssIGNhcHR1cmVdKTtcbn1cbi8qKlxuICogV3JhcHBlciBhcm91bmQgdXNlQmxvY2tlciB0byBzaG93IGEgd2luZG93LmNvbmZpcm0gcHJvbXB0IHRvIHVzZXJzIGluc3RlYWRcbiAqIG9mIGJ1aWxkaW5nIGEgY3VzdG9tIFVJIHdpdGggdXNlQmxvY2tlci5cbiAqXG4gKiBXYXJuaW5nOiBUaGlzIGhhcyAqYSBsb3Qgb2Ygcm91Z2ggZWRnZXMqIGFuZCBiZWhhdmVzIHZlcnkgZGlmZmVyZW50bHkgKGFuZFxuICogdmVyeSBpbmNvcnJlY3RseSBpbiBzb21lIGNhc2VzKSBhY3Jvc3MgYnJvd3NlcnMgaWYgdXNlciBjbGljayBhZGRpdGlvblxuICogYmFjay9mb3J3YXJkIG5hdmlnYXRpb25zIHdoaWxlIHRoZSBjb25maXJtIGlzIG9wZW4uICBVc2UgYXQgeW91ciBvd24gcmlzay5cbiAqL1xuZnVuY3Rpb24gdXNlUHJvbXB0KF9yZWYxMCkge1xuICBsZXQge1xuICAgIHdoZW4sXG4gICAgbWVzc2FnZVxuICB9ID0gX3JlZjEwO1xuICBsZXQgYmxvY2tlciA9IHVzZUJsb2NrZXIod2hlbik7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGJsb2NrZXIuc3RhdGUgPT09IFwiYmxvY2tlZFwiKSB7XG4gICAgICBsZXQgcHJvY2VlZCA9IHdpbmRvdy5jb25maXJtKG1lc3NhZ2UpO1xuICAgICAgaWYgKHByb2NlZWQpIHtcbiAgICAgICAgLy8gVGhpcyB0aW1lb3V0IGlzIG5lZWRlZCB0byBhdm9pZCBhIHdlaXJkIFwicmFjZVwiIG9uIFBPUCBuYXZpZ2F0aW9uc1xuICAgICAgICAvLyBiZXR3ZWVuIHRoZSBgd2luZG93Lmhpc3RvcnlgIHJldmVydCBuYXZpZ2F0aW9uIGFuZCB0aGUgcmVzdWx0IG9mXG4gICAgICAgIC8vIGB3aW5kb3cuY29uZmlybWBcbiAgICAgICAgc2V0VGltZW91dChibG9ja2VyLnByb2NlZWQsIDApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYmxvY2tlci5yZXNldCgpO1xuICAgICAgfVxuICAgIH1cbiAgfSwgW2Jsb2NrZXIsIG1lc3NhZ2VdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYmxvY2tlci5zdGF0ZSA9PT0gXCJibG9ja2VkXCIgJiYgIXdoZW4pIHtcbiAgICAgIGJsb2NrZXIucmVzZXQoKTtcbiAgICB9XG4gIH0sIFtibG9ja2VyLCB3aGVuXSk7XG59XG4vKipcbiAqIFJldHVybiBhIGJvb2xlYW4gaW5kaWNhdGluZyBpZiB0aGVyZSBpcyBhbiBhY3RpdmUgdmlldyB0cmFuc2l0aW9uIHRvIHRoZVxuICogZ2l2ZW4gaHJlZi4gIFlvdSBjYW4gdXNlIHRoaXMgdmFsdWUgdG8gcmVuZGVyIENTUyBjbGFzc2VzIG9yIHZpZXdUcmFuc2l0aW9uTmFtZVxuICogc3R5bGVzIG9udG8geW91ciBlbGVtZW50c1xuICpcbiAqIEBwYXJhbSBocmVmIFRoZSBkZXN0aW5hdGlvbiBocmVmXG4gKiBAcGFyYW0gW29wdHMucmVsYXRpdmVdIFJlbGF0aXZlIHJvdXRpbmcgdHlwZSAoXCJyb3V0ZVwiIHwgXCJwYXRoXCIpXG4gKi9cbmZ1bmN0aW9uIHVzZVZpZXdUcmFuc2l0aW9uU3RhdGUodG8sIG9wdHMpIHtcbiAgaWYgKG9wdHMgPT09IHZvaWQgMCkge1xuICAgIG9wdHMgPSB7fTtcbiAgfVxuICBsZXQgdnRDb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChWaWV3VHJhbnNpdGlvbkNvbnRleHQpO1xuICAhKHZ0Q29udGV4dCAhPSBudWxsKSA/IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UsIFwiYHVzZVZpZXdUcmFuc2l0aW9uU3RhdGVgIG11c3QgYmUgdXNlZCB3aXRoaW4gYHJlYWN0LXJvdXRlci1kb21gJ3MgYFJvdXRlclByb3ZpZGVyYC4gIFwiICsgXCJEaWQgeW91IGFjY2lkZW50YWxseSBpbXBvcnQgYFJvdXRlclByb3ZpZGVyYCBmcm9tIGByZWFjdC1yb3V0ZXJgP1wiKSA6IFVOU0FGRV9pbnZhcmlhbnQoZmFsc2UpIDogdm9pZCAwO1xuICBsZXQge1xuICAgIGJhc2VuYW1lXG4gIH0gPSB1c2VEYXRhUm91dGVyQ29udGV4dChEYXRhUm91dGVySG9vay51c2VWaWV3VHJhbnNpdGlvblN0YXRlKTtcbiAgbGV0IHBhdGggPSB1c2VSZXNvbHZlZFBhdGgodG8sIHtcbiAgICByZWxhdGl2ZTogb3B0cy5yZWxhdGl2ZVxuICB9KTtcbiAgaWYgKCF2dENvbnRleHQuaXNUcmFuc2l0aW9uaW5nKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGxldCBjdXJyZW50UGF0aCA9IHN0cmlwQmFzZW5hbWUodnRDb250ZXh0LmN1cnJlbnRMb2NhdGlvbi5wYXRobmFtZSwgYmFzZW5hbWUpIHx8IHZ0Q29udGV4dC5jdXJyZW50TG9jYXRpb24ucGF0aG5hbWU7XG4gIGxldCBuZXh0UGF0aCA9IHN0cmlwQmFzZW5hbWUodnRDb250ZXh0Lm5leHRMb2NhdGlvbi5wYXRobmFtZSwgYmFzZW5hbWUpIHx8IHZ0Q29udGV4dC5uZXh0TG9jYXRpb24ucGF0aG5hbWU7XG4gIC8vIFRyYW5zaXRpb24gaXMgYWN0aXZlIGlmIHdlJ3JlIGdvaW5nIHRvIG9yIGNvbWluZyBmcm9tIHRoZSBpbmRpY2F0ZWRcbiAgLy8gZGVzdGluYXRpb24uICBUaGlzIGVuc3VyZXMgdGhhdCBvdGhlciBQVVNIIG5hdmlnYXRpb25zIHRoYXQgcmV2ZXJzZVxuICAvLyBhbiBpbmRpY2F0ZWQgdHJhbnNpdGlvbiBhcHBseS4gIEkuZS4sIG9uIHRoZSBsaXN0IHZpZXcgeW91IGhhdmU6XG4gIC8vXG4gIC8vICAgPE5hdkxpbmsgdG89XCIvZGV0YWlscy8xXCIgdmlld1RyYW5zaXRpb24+XG4gIC8vXG4gIC8vIElmIHlvdSBjbGljayB0aGUgYnJlYWRjcnVtYiBiYWNrIHRvIHRoZSBsaXN0IHZpZXc6XG4gIC8vXG4gIC8vICAgPE5hdkxpbmsgdG89XCIvbGlzdFwiIHZpZXdUcmFuc2l0aW9uPlxuICAvL1xuICAvLyBXZSBzaG91bGQgYXBwbHkgdGhlIHRyYW5zaXRpb24gYmVjYXVzZSBpdCdzIGluZGljYXRlZCBhcyBhY3RpdmUgZ29pbmdcbiAgLy8gZnJvbSAvbGlzdCAtPiAvZGV0YWlscy8xIGFuZCB0aGVyZWZvcmUgc2hvdWxkIGJlIGFjdGl2ZSBvbiB0aGUgcmV2ZXJzZVxuICAvLyAoZXZlbiB0aG91Z2ggdGhpcyBpc24ndCBzdHJpY3RseSBhIFBPUCByZXZlcnNlKVxuICByZXR1cm4gbWF0Y2hQYXRoKHBhdGgucGF0aG5hbWUsIG5leHRQYXRoKSAhPSBudWxsIHx8IG1hdGNoUGF0aChwYXRoLnBhdGhuYW1lLCBjdXJyZW50UGF0aCkgIT0gbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuXG5leHBvcnQgeyBCcm93c2VyUm91dGVyLCBGb3JtLCBIYXNoUm91dGVyLCBMaW5rLCBOYXZMaW5rLCBSb3V0ZXJQcm92aWRlciwgU2Nyb2xsUmVzdG9yYXRpb24sIEZldGNoZXJzQ29udGV4dCBhcyBVTlNBRkVfRmV0Y2hlcnNDb250ZXh0LCBWaWV3VHJhbnNpdGlvbkNvbnRleHQgYXMgVU5TQUZFX1ZpZXdUcmFuc2l0aW9uQ29udGV4dCwgdXNlU2Nyb2xsUmVzdG9yYXRpb24gYXMgVU5TQUZFX3VzZVNjcm9sbFJlc3RvcmF0aW9uLCBjcmVhdGVCcm93c2VyUm91dGVyLCBjcmVhdGVIYXNoUm91dGVyLCBjcmVhdGVTZWFyY2hQYXJhbXMsIEhpc3RvcnlSb3V0ZXIgYXMgdW5zdGFibGVfSGlzdG9yeVJvdXRlciwgdXNlUHJvbXB0IGFzIHVuc3RhYmxlX3VzZVByb21wdCwgdXNlQmVmb3JlVW5sb2FkLCB1c2VGZXRjaGVyLCB1c2VGZXRjaGVycywgdXNlRm9ybUFjdGlvbiwgdXNlTGlua0NsaWNrSGFuZGxlciwgdXNlU2VhcmNoUGFyYW1zLCB1c2VTdWJtaXQsIHVzZVZpZXdUcmFuc2l0aW9uU3RhdGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBVUEsU0FBU0EsYUFBVztDQUNsQixPQUFPLGFBQVcsT0FBTyxTQUFTLE9BQU8sT0FBTyxLQUFLLElBQUksU0FBVSxHQUFHO0VBQ3BFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztHQUN6QyxJQUFJLElBQUksVUFBVTtHQUNsQixLQUFLLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFBLENBQUcsZUFBZSxLQUFLLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFO0VBQy9EO0VBQ0EsT0FBTztDQUNULEdBQUdBLFdBQVMsTUFBTSxNQUFNLFNBQVM7QUFDbkM7Ozs7QUFRQSxJQUFJO0NBQ0gsU0FBVSxRQUFROzs7Ozs7OztDQVFqQixPQUFPLFNBQVM7Ozs7OztDQU1oQixPQUFPLFVBQVU7Ozs7O0NBS2pCLE9BQU8sYUFBYTtBQUN0QixFQUFBLENBQUcsV0FBVyxTQUFTLENBQUMsRUFBRTtBQUMxQixJQUFNLG9CQUFvQjs7Ozs7QUFLMUIsU0FBUyxvQkFBb0IsU0FBUztDQUNwQyxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixJQUFJLEVBQ0YsaUJBQWlCLENBQUMsR0FBRyxHQUNyQixjQUNBLFdBQVcsVUFDVDtDQUNKLElBQUk7Q0FDSixVQUFVLGVBQWUsS0FBSyxPQUFPLFVBQVUscUJBQXFCLE9BQU8sT0FBTyxVQUFVLFdBQVcsT0FBTyxNQUFNLE9BQU8sVUFBVSxJQUFJLFlBQVksS0FBQSxDQUFTLENBQUM7Q0FDL0osSUFBSSxRQUFRLFdBQVcsZ0JBQWdCLE9BQU8sUUFBUSxTQUFTLElBQUksWUFBWTtDQUMvRSxJQUFJLFNBQVMsT0FBTztDQUNwQixJQUFJLFdBQVc7Q0FDZixTQUFTLFdBQVcsR0FBRztFQUNyQixPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLEdBQUcsUUFBUSxTQUFTLENBQUM7Q0FDcEQ7Q0FDQSxTQUFTLHFCQUFxQjtFQUM1QixPQUFPLFFBQVE7Q0FDakI7Q0FDQSxTQUFTLHFCQUFxQixJQUFJLE9BQU8sS0FBSztFQUM1QyxJQUFJLFVBQVUsS0FBSyxHQUNqQixRQUFRO0VBRVYsSUFBSSxXQUFXLGVBQWUsVUFBVSxtQkFBbUIsQ0FBQyxDQUFDLFdBQVcsS0FBSyxJQUFJLE9BQU8sR0FBRztFQUMzRixRQUFRLFNBQVMsU0FBUyxPQUFPLENBQUMsTUFBTSxLQUFLLDZEQUE2RCxLQUFLLFVBQVUsRUFBRSxDQUFDO0VBQzVILE9BQU87Q0FDVDtDQUNBLFNBQVMsV0FBVyxJQUFJO0VBQ3RCLE9BQU8sT0FBTyxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7Q0FDcEQ7Q0FvRUEsT0FBTztFQWxFTCxJQUFJLFFBQVE7R0FDVixPQUFPO0VBQ1Q7RUFDQSxJQUFJLFNBQVM7R0FDWCxPQUFPO0VBQ1Q7RUFDQSxJQUFJLFdBQVc7R0FDYixPQUFPLG1CQUFtQjtFQUM1QjtFQUNBO0VBQ0EsVUFBVSxJQUFJO0dBQ1osT0FBTyxJQUFJLElBQUksV0FBVyxFQUFFLEdBQUcsa0JBQWtCO0VBQ25EO0VBQ0EsZUFBZSxJQUFJO0dBQ2pCLElBQUksT0FBTyxPQUFPLE9BQU8sV0FBVyxVQUFVLEVBQUUsSUFBSTtHQUNwRCxPQUFPO0lBQ0wsVUFBVSxLQUFLLFlBQVk7SUFDM0IsUUFBUSxLQUFLLFVBQVU7SUFDdkIsTUFBTSxLQUFLLFFBQVE7R0FDckI7RUFDRjtFQUNBLEtBQUssSUFBSSxPQUFPO0dBQ2QsU0FBUyxPQUFPO0dBQ2hCLElBQUksZUFBZSxxQkFBcUIsSUFBSSxLQUFLO0dBQ2pELFNBQVM7R0FDVCxRQUFRLE9BQU8sT0FBTyxRQUFRLFFBQVEsWUFBWTtHQUNsRCxJQUFJLFlBQVksVUFDZCxTQUFTO0lBQ1A7SUFDQSxVQUFVO0lBQ1YsT0FBTztHQUNULENBQUM7RUFFTDtFQUNBLFFBQVEsSUFBSSxPQUFPO0dBQ2pCLFNBQVMsT0FBTztHQUNoQixJQUFJLGVBQWUscUJBQXFCLElBQUksS0FBSztHQUNqRCxRQUFRLFNBQVM7R0FDakIsSUFBSSxZQUFZLFVBQ2QsU0FBUztJQUNQO0lBQ0EsVUFBVTtJQUNWLE9BQU87R0FDVCxDQUFDO0VBRUw7RUFDQSxHQUFHLE9BQU87R0FDUixTQUFTLE9BQU87R0FDaEIsSUFBSSxZQUFZLFdBQVcsUUFBUSxLQUFLO0dBQ3hDLElBQUksZUFBZSxRQUFRO0dBQzNCLFFBQVE7R0FDUixJQUFJLFVBQ0YsU0FBUztJQUNQO0lBQ0EsVUFBVTtJQUNWO0dBQ0YsQ0FBQztFQUVMO0VBQ0EsT0FBTyxJQUFJO0dBQ1QsV0FBVztHQUNYLGFBQWE7SUFDWCxXQUFXO0dBQ2I7RUFDRjtDQUVXO0FBQ2Y7Ozs7Ozs7O0FBUUEsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixTQUFTLHNCQUFzQixRQUFRLGVBQWU7RUFDcEQsSUFBSSxFQUNGLFVBQ0EsUUFDQSxTQUNFLE9BQU87RUFDWCxPQUFPLGVBQWUsSUFBSTtHQUN4QjtHQUNBO0dBQ0E7RUFDRixHQUVBLGNBQWMsU0FBUyxjQUFjLE1BQU0sT0FBTyxNQUFNLGNBQWMsU0FBUyxjQUFjLE1BQU0sT0FBTyxTQUFTO0NBQ3JIO0NBQ0EsU0FBUyxrQkFBa0IsUUFBUSxJQUFJO0VBQ3JDLE9BQU8sT0FBTyxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7Q0FDcEQ7Q0FDQSxPQUFPLG1CQUFtQix1QkFBdUIsbUJBQW1CLE1BQU0sT0FBTztBQUNuRjs7Ozs7Ozs7O0FBU0EsU0FBUyxrQkFBa0IsU0FBUztDQUNsQyxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixTQUFTLG1CQUFtQixRQUFRLGVBQWU7RUFDakQsSUFBSSxFQUNGLFdBQVcsS0FDWCxTQUFTLElBQ1QsT0FBTyxPQUNMLFVBQVUsT0FBTyxTQUFTLEtBQUssT0FBTyxDQUFDLENBQUM7RUFPNUMsSUFBSSxDQUFDLFNBQVMsV0FBVyxHQUFHLEtBQUssQ0FBQyxTQUFTLFdBQVcsR0FBRyxHQUN2RCxXQUFXLE1BQU07RUFFbkIsT0FBTyxlQUFlLElBQUk7R0FDeEI7R0FDQTtHQUNBO0VBQ0YsR0FFQSxjQUFjLFNBQVMsY0FBYyxNQUFNLE9BQU8sTUFBTSxjQUFjLFNBQVMsY0FBYyxNQUFNLE9BQU8sU0FBUztDQUNySDtDQUNBLFNBQVMsZUFBZSxRQUFRLElBQUk7RUFDbEMsSUFBSSxPQUFPLE9BQU8sU0FBUyxjQUFjLE1BQU07RUFDL0MsSUFBSSxPQUFPO0VBQ1gsSUFBSSxRQUFRLEtBQUssYUFBYSxNQUFNLEdBQUc7R0FDckMsSUFBSSxNQUFNLE9BQU8sU0FBUztHQUMxQixJQUFJLFlBQVksSUFBSSxRQUFRLEdBQUc7R0FDL0IsT0FBTyxjQUFjLEtBQUssTUFBTSxJQUFJLE1BQU0sR0FBRyxTQUFTO0VBQ3hEO0VBQ0EsT0FBTyxPQUFPLE9BQU8sT0FBTyxPQUFPLFdBQVcsS0FBSyxXQUFXLEVBQUU7Q0FDbEU7Q0FDQSxTQUFTLHFCQUFxQixVQUFVLElBQUk7RUFDMUMsUUFBUSxTQUFTLFNBQVMsT0FBTyxDQUFDLE1BQU0sS0FBSywrREFBK0QsS0FBSyxVQUFVLEVBQUUsSUFBSSxHQUFHO0NBQ3RJO0NBQ0EsT0FBTyxtQkFBbUIsb0JBQW9CLGdCQUFnQixzQkFBc0IsT0FBTztBQUM3RjtBQUNBLFNBQVMsVUFBVSxPQUFPLFNBQVM7Q0FDakMsSUFBSSxVQUFVLFNBQVMsVUFBVSxRQUFRLE9BQU8sVUFBVSxhQUN4RCxNQUFNLElBQUksTUFBTSxPQUFPO0FBRTNCO0FBQ0EsU0FBUyxRQUFRLE1BQU0sU0FBUztDQUM5QixJQUFJLENBQUMsTUFBTTtFQUVULElBQUksT0FBTyxZQUFZLGFBQWEsUUFBUSxLQUFLLE9BQU87RUFDeEQsSUFBSTtHQU1GLE1BQU0sSUFBSSxNQUFNLE9BQU87RUFFekIsU0FBUyxHQUFHLENBQUM7Q0FDZjtBQUNGO0FBQ0EsU0FBUyxZQUFZO0NBQ25CLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDO0FBQy9DOzs7O0FBSUEsU0FBUyxnQkFBZ0IsVUFBVSxPQUFPO0NBQ3hDLE9BQU87RUFDTCxLQUFLLFNBQVM7RUFDZCxLQUFLLFNBQVM7RUFDZCxLQUFLO0NBQ1A7QUFDRjs7OztBQUlBLFNBQVMsZUFBZSxTQUFTLElBQUksT0FBTyxLQUFLO0NBQy9DLElBQUksVUFBVSxLQUFLLEdBQ2pCLFFBQVE7Q0FjVixPQVplQSxXQUFTO0VBQ3RCLFVBQVUsT0FBTyxZQUFZLFdBQVcsVUFBVSxRQUFRO0VBQzFELFFBQVE7RUFDUixNQUFNO0NBQ1IsR0FBRyxPQUFPLE9BQU8sV0FBVyxVQUFVLEVBQUUsSUFBSSxJQUFJO0VBQzlDO0VBS0EsS0FBSyxNQUFNLEdBQUcsT0FBTyxPQUFPLFVBQVU7Q0FDeEMsQ0FDYztBQUNoQjs7OztBQUlBLFNBQVMsV0FBVyxNQUFNO0NBQ3hCLElBQUksRUFDRixXQUFXLEtBQ1gsU0FBUyxJQUNULE9BQU8sT0FDTDtDQUNKLElBQUksVUFBVSxXQUFXLEtBQUssWUFBWSxPQUFPLE9BQU8sQ0FBQyxNQUFNLE1BQU0sU0FBUyxNQUFNO0NBQ3BGLElBQUksUUFBUSxTQUFTLEtBQUssWUFBWSxLQUFLLE9BQU8sQ0FBQyxNQUFNLE1BQU0sT0FBTyxNQUFNO0NBQzVFLE9BQU87QUFDVDs7OztBQUlBLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLElBQUksYUFBYSxDQUFDO0NBQ2xCLElBQUksTUFBTTtFQUNSLElBQUksWUFBWSxLQUFLLFFBQVEsR0FBRztFQUNoQyxJQUFJLGFBQWEsR0FBRztHQUNsQixXQUFXLE9BQU8sS0FBSyxPQUFPLFNBQVM7R0FDdkMsT0FBTyxLQUFLLE9BQU8sR0FBRyxTQUFTO0VBQ2pDO0VBQ0EsSUFBSSxjQUFjLEtBQUssUUFBUSxHQUFHO0VBQ2xDLElBQUksZUFBZSxHQUFHO0dBQ3BCLFdBQVcsU0FBUyxLQUFLLE9BQU8sV0FBVztHQUMzQyxPQUFPLEtBQUssT0FBTyxHQUFHLFdBQVc7RUFDbkM7RUFDQSxJQUFJLE1BQ0YsV0FBVyxXQUFXO0NBRTFCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsYUFBYSxZQUFZLGtCQUFrQixTQUFTO0NBQzlFLElBQUksWUFBWSxLQUFLLEdBQ25CLFVBQVUsQ0FBQztDQUViLElBQUksRUFDRixTQUFTLFNBQVMsYUFDbEIsV0FBVyxVQUNUO0NBQ0osSUFBSSxnQkFBZ0IsT0FBTztDQUMzQixJQUFJLFNBQVMsT0FBTztDQUNwQixJQUFJLFdBQVc7Q0FDZixJQUFJLFFBQVEsU0FBUztDQUlyQixJQUFJLFNBQVMsTUFBTTtFQUNqQixRQUFRO0VBQ1IsY0FBYyxhQUFhQSxXQUFTLENBQUMsR0FBRyxjQUFjLE9BQU8sRUFDM0QsS0FBSyxNQUNQLENBQUMsR0FBRyxFQUFFO0NBQ1I7Q0FDQSxTQUFTLFdBQVc7RUFJbEIsUUFIWSxjQUFjLFNBQVMsRUFDakMsS0FBSyxLQUNQLEVBQUEsQ0FDYTtDQUNmO0NBQ0EsU0FBUyxZQUFZO0VBQ25CLFNBQVMsT0FBTztFQUNoQixJQUFJLFlBQVksU0FBUztFQUN6QixJQUFJLFFBQVEsYUFBYSxPQUFPLE9BQU8sWUFBWTtFQUNuRCxRQUFRO0VBQ1IsSUFBSSxVQUNGLFNBQVM7R0FDUDtHQUNBLFVBQVUsUUFBUTtHQUNsQjtFQUNGLENBQUM7Q0FFTDtDQUNBLFNBQVMsS0FBSyxJQUFJLE9BQU87RUFDdkIsU0FBUyxPQUFPO0VBQ2hCLElBQUksV0FBVyxlQUFlLFFBQVEsVUFBVSxJQUFJLEtBQUs7RUFDekQsSUFBSSxrQkFBa0IsaUJBQWlCLFVBQVUsRUFBRTtFQUNuRCxRQUFRLFNBQVMsSUFBSTtFQUNyQixJQUFJLGVBQWUsZ0JBQWdCLFVBQVUsS0FBSztFQUNsRCxJQUFJLE1BQU0sUUFBUSxXQUFXLFFBQVE7RUFFckMsSUFBSTtHQUNGLGNBQWMsVUFBVSxjQUFjLElBQUksR0FBRztFQUMvQyxTQUFTLE9BQU87R0FLZCxJQUFJLGlCQUFpQixnQkFBZ0IsTUFBTSxTQUFTLGtCQUNsRCxNQUFNO0dBSVIsT0FBTyxTQUFTLE9BQU8sR0FBRztFQUM1QjtFQUNBLElBQUksWUFBWSxVQUNkLFNBQVM7R0FDUDtHQUNBLFVBQVUsUUFBUTtHQUNsQixPQUFPO0VBQ1QsQ0FBQztDQUVMO0NBQ0EsU0FBUyxRQUFRLElBQUksT0FBTztFQUMxQixTQUFTLE9BQU87RUFDaEIsSUFBSSxXQUFXLGVBQWUsUUFBUSxVQUFVLElBQUksS0FBSztFQUN6RCxJQUFJLGtCQUFrQixpQkFBaUIsVUFBVSxFQUFFO0VBQ25ELFFBQVEsU0FBUztFQUNqQixJQUFJLGVBQWUsZ0JBQWdCLFVBQVUsS0FBSztFQUNsRCxJQUFJLE1BQU0sUUFBUSxXQUFXLFFBQVE7RUFDckMsY0FBYyxhQUFhLGNBQWMsSUFBSSxHQUFHO0VBQ2hELElBQUksWUFBWSxVQUNkLFNBQVM7R0FDUDtHQUNBLFVBQVUsUUFBUTtHQUNsQixPQUFPO0VBQ1QsQ0FBQztDQUVMO0NBQ0EsU0FBUyxVQUFVLElBQUk7RUFJckIsSUFBSSxPQUFPLE9BQU8sU0FBUyxXQUFXLFNBQVMsT0FBTyxTQUFTLFNBQVMsT0FBTyxTQUFTO0VBQ3hGLElBQUksT0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLLFdBQVcsRUFBRTtFQUl0RCxPQUFPLEtBQUssUUFBUSxNQUFNLEtBQUs7RUFDL0IsVUFBVSxNQUFNLHdFQUF3RSxJQUFJO0VBQzVGLE9BQU8sSUFBSSxJQUFJLE1BQU0sSUFBSTtDQUMzQjtDQUNBLElBQUksVUFBVTtFQUNaLElBQUksU0FBUztHQUNYLE9BQU87RUFDVDtFQUNBLElBQUksV0FBVztHQUNiLE9BQU8sWUFBWSxRQUFRLGFBQWE7RUFDMUM7RUFDQSxPQUFPLElBQUk7R0FDVCxJQUFJLFVBQ0YsTUFBTSxJQUFJLE1BQU0sNENBQTRDO0dBRTlELE9BQU8saUJBQWlCLG1CQUFtQixTQUFTO0dBQ3BELFdBQVc7R0FDWCxhQUFhO0lBQ1gsT0FBTyxvQkFBb0IsbUJBQW1CLFNBQVM7SUFDdkQsV0FBVztHQUNiO0VBQ0Y7RUFDQSxXQUFXLElBQUk7R0FDYixPQUFPLFdBQVcsUUFBUSxFQUFFO0VBQzlCO0VBQ0E7RUFDQSxlQUFlLElBQUk7R0FFakIsSUFBSSxNQUFNLFVBQVUsRUFBRTtHQUN0QixPQUFPO0lBQ0wsVUFBVSxJQUFJO0lBQ2QsUUFBUSxJQUFJO0lBQ1osTUFBTSxJQUFJO0dBQ1o7RUFDRjtFQUNBO0VBQ0E7RUFDQSxHQUFHLEdBQUc7R0FDSixPQUFPLGNBQWMsR0FBRyxDQUFDO0VBQzNCO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFHQSxJQUFJO0NBQ0gsU0FBVSxZQUFZO0NBQ3JCLFdBQVcsVUFBVTtDQUNyQixXQUFXLGNBQWM7Q0FDekIsV0FBVyxjQUFjO0NBQ3pCLFdBQVcsV0FBVztBQUN4QixFQUFBLENBQUcsZUFBZSxhQUFhLENBQUMsRUFBRTtBQUNsQyxJQUFNLHFDQUFxQixJQUFJLElBQUk7Q0FBQztDQUFRO0NBQWlCO0NBQVE7Q0FBTTtDQUFTO0FBQVUsQ0FBQztBQUMvRixTQUFTLGFBQWEsT0FBTztDQUMzQixPQUFPLE1BQU0sVUFBVTtBQUN6QjtBQUdBLFNBQVMsMEJBQTBCLFFBQVEsb0JBQW9CLFlBQVksVUFBVTtDQUNuRixJQUFJLGVBQWUsS0FBSyxHQUN0QixhQUFhLENBQUM7Q0FFaEIsSUFBSSxhQUFhLEtBQUssR0FDcEIsV0FBVyxDQUFDO0NBRWQsT0FBTyxPQUFPLEtBQUssT0FBTyxVQUFVO0VBQ2xDLElBQUksV0FBVyxDQUFDLEdBQUcsWUFBWSxPQUFPLEtBQUssQ0FBQztFQUM1QyxJQUFJLEtBQUssT0FBTyxNQUFNLE9BQU8sV0FBVyxNQUFNLEtBQUssU0FBUyxLQUFLLEdBQUc7RUFDcEUsVUFBVSxNQUFNLFVBQVUsUUFBUSxDQUFDLE1BQU0sVUFBVSwyQ0FBMkM7RUFDOUYsVUFBVSxDQUFDLFNBQVMsS0FBSyx3Q0FBd0MsS0FBSyxtRUFBd0U7RUFDOUksSUFBSSxhQUFhLEtBQUssR0FBRztHQUN2QixJQUFJLGFBQWFBLFdBQVMsQ0FBQyxHQUFHLE9BQU8sbUJBQW1CLEtBQUssR0FBRyxFQUM5RCxHQUNGLENBQUM7R0FDRCxTQUFTLE1BQU07R0FDZixPQUFPO0VBQ1QsT0FBTztHQUNMLElBQUksb0JBQW9CQSxXQUFTLENBQUMsR0FBRyxPQUFPLG1CQUFtQixLQUFLLEdBQUc7SUFDckU7SUFDQSxVQUFVLEtBQUE7R0FDWixDQUFDO0dBQ0QsU0FBUyxNQUFNO0dBQ2YsSUFBSSxNQUFNLFVBQ1Isa0JBQWtCLFdBQVcsMEJBQTBCLE1BQU0sVUFBVSxvQkFBb0IsVUFBVSxRQUFRO0dBRS9HLE9BQU87RUFDVDtDQUNGLENBQUM7QUFDSDs7Ozs7O0FBTUEsU0FBUyxZQUFZLFFBQVEsYUFBYSxVQUFVO0NBQ2xELElBQUksYUFBYSxLQUFLLEdBQ3BCLFdBQVc7Q0FFYixPQUFPLGdCQUFnQixRQUFRLGFBQWEsVUFBVSxLQUFLO0FBQzdEO0FBQ0EsU0FBUyxnQkFBZ0IsUUFBUSxhQUFhLFVBQVUsY0FBYztDQUVwRSxJQUFJLFdBQVcsZUFEQSxPQUFPLGdCQUFnQixXQUFXLFVBQVUsV0FBVyxJQUFJLFlBQUEsQ0FDcEMsWUFBWSxLQUFLLFFBQVE7Q0FDL0QsSUFBSSxZQUFZLE1BQ2QsT0FBTztDQUVULElBQUksV0FBVyxjQUFjLE1BQU07Q0FDbkMsa0JBQWtCLFFBQVE7Q0FDMUIsSUFBSSxVQUFVO0NBQ2QsSUFBSSxVQUFVLFdBQVcsUUFBUTtDQUNqQyxLQUFLLElBQUksSUFBSSxHQUFHLFdBQVcsUUFBUSxJQUFJLFNBQVMsUUFBUSxFQUFFLEdBT3hELFVBQVUsaUJBQWlCLFNBQVMsSUFBSSxTQUFTLFlBQVk7Q0FFL0QsT0FBTztBQUNUO0FBQ0EsU0FBUywyQkFBMkIsT0FBTyxZQUFZO0NBQ3JELElBQUksRUFDRixPQUNBLFVBQ0EsV0FDRTtDQUNKLE9BQU87RUFDTCxJQUFJLE1BQU07RUFDVjtFQUNBO0VBQ0EsTUFBTSxXQUFXLE1BQU07RUFDdkIsUUFBUSxNQUFNO0NBQ2hCO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsUUFBUSxVQUFVLGFBQWEsWUFBWTtDQUNoRSxJQUFJLGFBQWEsS0FBSyxHQUNwQixXQUFXLENBQUM7Q0FFZCxJQUFJLGdCQUFnQixLQUFLLEdBQ3ZCLGNBQWMsQ0FBQztDQUVqQixJQUFJLGVBQWUsS0FBSyxHQUN0QixhQUFhO0NBRWYsSUFBSSxnQkFBZ0IsT0FBTyxPQUFPLGlCQUFpQjtFQUNqRCxJQUFJLE9BQU87R0FDVCxjQUFjLGlCQUFpQixLQUFBLElBQVksTUFBTSxRQUFRLEtBQUs7R0FDOUQsZUFBZSxNQUFNLGtCQUFrQjtHQUN2QyxlQUFlO0dBQ2Y7RUFDRjtFQUNBLElBQUksS0FBSyxhQUFhLFdBQVcsR0FBRyxHQUFHO0dBQ3JDLFVBQVUsS0FBSyxhQUFhLFdBQVcsVUFBVSxHQUFHLDJCQUEyQixLQUFLLGVBQWUsMkJBQTJCLE9BQU8sYUFBYSxvREFBb0QsNkRBQTZEO0dBQ25RLEtBQUssZUFBZSxLQUFLLGFBQWEsTUFBTSxXQUFXLE1BQU07RUFDL0Q7RUFDQSxJQUFJLE9BQU8sVUFBVSxDQUFDLFlBQVksS0FBSyxZQUFZLENBQUM7RUFDcEQsSUFBSSxhQUFhLFlBQVksT0FBTyxJQUFJO0VBSXhDLElBQUksTUFBTSxZQUFZLE1BQU0sU0FBUyxTQUFTLEdBQUc7R0FDL0MsVUFHQSxNQUFNLFVBQVUsTUFBTSw2REFBNkQsd0NBQXdDLE9BQU8sTUFBTTtHQUN4SSxjQUFjLE1BQU0sVUFBVSxVQUFVLFlBQVksSUFBSTtFQUMxRDtFQUdBLElBQUksTUFBTSxRQUFRLFFBQVEsQ0FBQyxNQUFNLE9BQy9CO0VBRUYsU0FBUyxLQUFLO0dBQ1o7R0FDQSxPQUFPLGFBQWEsTUFBTSxNQUFNLEtBQUs7R0FDckM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxPQUFPLFNBQVMsT0FBTyxVQUFVO0VBQy9CLElBQUk7RUFFSixJQUFJLE1BQU0sU0FBUyxNQUFNLEdBQUcsY0FBYyxNQUFNLFNBQVMsUUFBUSxZQUFZLFNBQVMsR0FBRyxJQUN2RixhQUFhLE9BQU8sS0FBSztPQUV6QixLQUFLLElBQUksWUFBWSx3QkFBd0IsTUFBTSxJQUFJLEdBQ3JELGFBQWEsT0FBTyxPQUFPLFFBQVE7Q0FHekMsQ0FBQztDQUNELE9BQU87QUFDVDs7Ozs7Ozs7Ozs7Ozs7O0FBZUEsU0FBUyx3QkFBd0IsTUFBTTtDQUNyQyxJQUFJLFdBQVcsS0FBSyxNQUFNLEdBQUc7Q0FDN0IsSUFBSSxTQUFTLFdBQVcsR0FBRyxPQUFPLENBQUM7Q0FDbkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRO0NBRXZCLElBQUksYUFBYSxNQUFNLFNBQVMsR0FBRztDQUVuQyxJQUFJLFdBQVcsTUFBTSxRQUFRLE9BQU8sRUFBRTtDQUN0QyxJQUFJLEtBQUssV0FBVyxHQUdsQixPQUFPLGFBQWEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFFBQVE7Q0FFaEQsSUFBSSxlQUFlLHdCQUF3QixLQUFLLEtBQUssR0FBRyxDQUFDO0NBQ3pELElBQUksU0FBUyxDQUFDO0NBUWQsT0FBTyxLQUFLLEdBQUcsYUFBYSxLQUFJLFlBQVcsWUFBWSxLQUFLLFdBQVcsQ0FBQyxVQUFVLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7Q0FFckcsSUFBSSxZQUNGLE9BQU8sS0FBSyxHQUFHLFlBQVk7Q0FHN0IsT0FBTyxPQUFPLEtBQUksYUFBWSxLQUFLLFdBQVcsR0FBRyxLQUFLLGFBQWEsS0FBSyxNQUFNLFFBQVE7QUFDeEY7QUFDQSxTQUFTLGtCQUFrQixVQUFVO0NBQ25DLFNBQVMsTUFBTSxHQUFHLE1BQU0sRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxRQUN4RCxlQUFlLEVBQUUsV0FBVyxLQUFJLFNBQVEsS0FBSyxhQUFhLEdBQUcsRUFBRSxXQUFXLEtBQUksU0FBUSxLQUFLLGFBQWEsQ0FBQyxDQUFDO0FBQzlHO0FBQ0EsSUFBTSxVQUFVO0FBQ2hCLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sb0JBQW9CO0FBQzFCLElBQU0scUJBQXFCO0FBQzNCLElBQU0sZUFBZTtBQUNyQixJQUFNLFdBQVUsTUFBSyxNQUFNO0FBQzNCLFNBQVMsYUFBYSxNQUFNLE9BQU87Q0FDakMsSUFBSSxXQUFXLEtBQUssTUFBTSxHQUFHO0NBQzdCLElBQUksZUFBZSxTQUFTO0NBQzVCLElBQUksU0FBUyxLQUFLLE9BQU8sR0FDdkIsZ0JBQWdCO0NBRWxCLElBQUksT0FDRixnQkFBZ0I7Q0FFbEIsT0FBTyxTQUFTLFFBQU8sTUFBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLE9BQU8sWUFBWSxTQUFTLFFBQVEsS0FBSyxPQUFPLElBQUksc0JBQXNCLFlBQVksS0FBSyxvQkFBb0IscUJBQXFCLFlBQVk7QUFDbk07QUFDQSxTQUFTLGVBQWUsR0FBRyxHQUFHO0NBRTVCLE9BRGUsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxNQUFNLEVBQUUsRUFBRSxJQU1qRixFQUFFLEVBQUUsU0FBUyxLQUFLLEVBQUUsRUFBRSxTQUFTLEtBRy9CO0FBQ0Y7QUFDQSxTQUFTLGlCQUFpQixRQUFRLFVBQVUsY0FBYztDQUN4RCxJQUFJLGlCQUFpQixLQUFLLEdBQ3hCLGVBQWU7Q0FFakIsSUFBSSxFQUNGLGVBQ0U7Q0FDSixJQUFJLGdCQUFnQixDQUFDO0NBQ3JCLElBQUksa0JBQWtCO0NBQ3RCLElBQUksVUFBVSxDQUFDO0NBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFdBQVcsUUFBUSxFQUFFLEdBQUc7RUFDMUMsSUFBSSxPQUFPLFdBQVc7RUFDdEIsSUFBSSxNQUFNLE1BQU0sV0FBVyxTQUFTO0VBQ3BDLElBQUksb0JBQW9CLG9CQUFvQixNQUFNLFdBQVcsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEtBQUs7RUFDdkcsSUFBSSxRQUFRLFVBQVU7R0FDcEIsTUFBTSxLQUFLO0dBQ1gsZUFBZSxLQUFLO0dBQ3BCO0VBQ0YsR0FBRyxpQkFBaUI7RUFDcEIsSUFBSSxRQUFRLEtBQUs7RUFDakIsSUFBSSxDQUFDLFNBQVMsT0FBTyxnQkFBZ0IsQ0FBQyxXQUFXLFdBQVcsU0FBUyxFQUFFLENBQUMsTUFBTSxPQUM1RSxRQUFRLFVBQVU7R0FDaEIsTUFBTSxLQUFLO0dBQ1gsZUFBZSxLQUFLO0dBQ3BCLEtBQUs7RUFDUCxHQUFHLGlCQUFpQjtFQUV0QixJQUFJLENBQUMsT0FDSCxPQUFPO0VBRVQsT0FBTyxPQUFPLGVBQWUsTUFBTSxNQUFNO0VBQ3pDLFFBQVEsS0FBSztHQUVYLFFBQVE7R0FDUixVQUFVLFVBQVUsQ0FBQyxpQkFBaUIsTUFBTSxRQUFRLENBQUM7R0FDckQsY0FBYyxrQkFBa0IsVUFBVSxDQUFDLGlCQUFpQixNQUFNLFlBQVksQ0FBQyxDQUFDO0dBQ2hGO0VBQ0YsQ0FBQztFQUNELElBQUksTUFBTSxpQkFBaUIsS0FDekIsa0JBQWtCLFVBQVUsQ0FBQyxpQkFBaUIsTUFBTSxZQUFZLENBQUM7Q0FFckU7Q0FDQSxPQUFPO0FBQ1Q7Ozs7OztBQU1BLFNBQVMsYUFBYSxjQUFjLFFBQVE7Q0FDMUMsSUFBSSxXQUFXLEtBQUssR0FDbEIsU0FBUyxDQUFDO0NBRVosSUFBSSxPQUFPO0NBQ1gsSUFBSSxLQUFLLFNBQVMsR0FBRyxLQUFLLFNBQVMsT0FBTyxDQUFDLEtBQUssU0FBUyxJQUFJLEdBQUc7RUFDOUQsUUFBUSxPQUFPLGtCQUFrQixPQUFPLHVDQUF1QyxPQUFPLEtBQUssUUFBUSxPQUFPLElBQUksSUFBSSx3Q0FBd0Msc0VBQXNFLHVDQUF1QyxLQUFLLFFBQVEsT0FBTyxJQUFJLElBQUksTUFBTTtFQUN6UyxPQUFPLEtBQUssUUFBUSxPQUFPLElBQUk7Q0FDakM7Q0FFQSxNQUFNLFNBQVMsS0FBSyxXQUFXLEdBQUcsSUFBSSxNQUFNO0NBQzVDLE1BQU0sYUFBWSxNQUFLLEtBQUssT0FBTyxLQUFLLE9BQU8sTUFBTSxXQUFXLElBQUksT0FBTyxDQUFDO0NBcUI1RSxPQUFPLFNBcEJVLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQyxLQUFLLFNBQVMsT0FBTyxVQUFVO0VBR2hFLElBRnNCLFVBQVUsTUFBTSxTQUFTLEtBRTFCLFlBQVksS0FHL0IsT0FBTyxVQUFVLE9BQU8sSUFBSztFQUUvQixNQUFNLFdBQVcsUUFBUSxNQUFNLGtCQUFrQjtFQUNqRCxJQUFJLFVBQVU7R0FDWixNQUFNLEdBQUcsS0FBSyxZQUFZO0dBQzFCLElBQUksUUFBUSxPQUFPO0dBQ25CLFVBQVUsYUFBYSxPQUFPLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTSxVQUFVO0dBQzdFLE9BQU8sVUFBVSxLQUFLO0VBQ3hCO0VBRUEsT0FBTyxRQUFRLFFBQVEsUUFBUSxFQUFFO0NBQ25DLENBQUMsQ0FBQyxDQUVELFFBQU8sWUFBVyxDQUFDLENBQUMsT0FDRSxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQ25DOzs7Ozs7O0FBT0EsU0FBUyxVQUFVLFNBQVMsVUFBVTtDQUNwQyxJQUFJLE9BQU8sWUFBWSxVQUNyQixVQUFVO0VBQ1IsTUFBTTtFQUNOLGVBQWU7RUFDZixLQUFLO0NBQ1A7Q0FFRixJQUFJLENBQUMsU0FBUyxrQkFBa0IsWUFBWSxRQUFRLE1BQU0sUUFBUSxlQUFlLFFBQVEsR0FBRztDQUM1RixJQUFJLFFBQVEsU0FBUyxNQUFNLE9BQU87Q0FDbEMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixJQUFJLGtCQUFrQixNQUFNO0NBQzVCLElBQUksZUFBZSxnQkFBZ0IsUUFBUSxXQUFXLElBQUk7Q0FDMUQsSUFBSSxnQkFBZ0IsTUFBTSxNQUFNLENBQUM7Q0FvQmpDLE9BQU87RUFDTCxRQXBCVyxlQUFlLFFBQVEsTUFBTSxNQUFNLFVBQVU7R0FDeEQsSUFBSSxFQUNGLFdBQ0EsZUFDRTtHQUdKLElBQUksY0FBYyxLQUFLO0lBQ3JCLElBQUksYUFBYSxjQUFjLFVBQVU7SUFDekMsZUFBZSxnQkFBZ0IsTUFBTSxHQUFHLGdCQUFnQixTQUFTLFdBQVcsTUFBTSxDQUFDLENBQUMsUUFBUSxXQUFXLElBQUk7R0FDN0c7R0FDQSxNQUFNLFFBQVEsY0FBYztHQUM1QixJQUFJLGNBQWMsQ0FBQyxPQUNqQixLQUFLLGFBQWEsS0FBQTtRQUVsQixLQUFLLGNBQWMsU0FBUyxHQUFBLENBQUksUUFBUSxRQUFRLEdBQUc7R0FFckQsT0FBTztFQUNULEdBQUcsQ0FBQyxDQUVHO0VBQ0wsVUFBVTtFQUNWO0VBQ0E7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxZQUFZLE1BQU0sZUFBZSxLQUFLO0NBQzdDLElBQUksa0JBQWtCLEtBQUssR0FDekIsZ0JBQWdCO0NBRWxCLElBQUksUUFBUSxLQUFLLEdBQ2YsTUFBTTtDQUVSLFFBQVEsU0FBUyxPQUFPLENBQUMsS0FBSyxTQUFTLEdBQUcsS0FBSyxLQUFLLFNBQVMsSUFBSSxHQUFHLGtCQUFrQixPQUFPLHVDQUF1QyxPQUFPLEtBQUssUUFBUSxPQUFPLElBQUksSUFBSSx3Q0FBd0Msc0VBQXNFLHVDQUF1QyxLQUFLLFFBQVEsT0FBTyxJQUFJLElBQUksTUFBTTtDQUM5VixJQUFJLFNBQVMsQ0FBQztDQUNkLElBQUksZUFBZSxNQUFNLEtBQUssUUFBUSxXQUFXLEVBQUUsQ0FBQyxDQUNuRCxRQUFRLFFBQVEsR0FBRyxDQUFDLENBQ3BCLFFBQVEsc0JBQXNCLE1BQU0sQ0FBQyxDQUNyQyxRQUFRLHNCQUFzQixHQUFHLFdBQVcsZUFBZTtFQUMxRCxPQUFPLEtBQUs7R0FDVjtHQUNBLFlBQVksY0FBYztFQUM1QixDQUFDO0VBQ0QsT0FBTyxhQUFhLGlCQUFpQjtDQUN2QyxDQUFDO0NBQ0QsSUFBSSxLQUFLLFNBQVMsR0FBRyxHQUFHO0VBQ3RCLE9BQU8sS0FBSyxFQUNWLFdBQVcsSUFDYixDQUFDO0VBQ0QsZ0JBQWdCLFNBQVMsT0FBTyxTQUFTLE9BQU8sVUFDOUM7Q0FDSixPQUFPLElBQUksS0FFVCxnQkFBZ0I7TUFDWCxJQUFJLFNBQVMsTUFBTSxTQUFTLEtBUWpDLGdCQUFnQjtDQUdsQixPQUFPLENBQUMsSUFEVSxPQUFPLGNBQWMsZ0JBQWdCLEtBQUEsSUFBWSxHQUNyRCxHQUFHLE1BQU07QUFDekI7QUFDQSxTQUFTLFdBQVcsT0FBTztDQUN6QixJQUFJO0VBQ0YsT0FBTyxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSSxNQUFLLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxRQUFRLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDeEYsU0FBUyxPQUFPO0VBQ2QsUUFBUSxPQUFPLG9CQUFvQixRQUFRLDhHQUFtSCxlQUFlLFFBQVEsS0FBSztFQUMxTCxPQUFPO0NBQ1Q7QUFDRjs7OztBQUlBLFNBQVMsY0FBYyxVQUFVLFVBQVU7Q0FDekMsSUFBSSxhQUFhLEtBQUssT0FBTztDQUM3QixJQUFJLENBQUMsU0FBUyxZQUFZLENBQUMsQ0FBQyxXQUFXLFNBQVMsWUFBWSxDQUFDLEdBQzNELE9BQU87Q0FJVCxJQUFJLGFBQWEsU0FBUyxTQUFTLEdBQUcsSUFBSSxTQUFTLFNBQVMsSUFBSSxTQUFTO0NBQ3pFLElBQUksV0FBVyxTQUFTLE9BQU8sVUFBVTtDQUN6QyxJQUFJLFlBQVksYUFBYSxLQUUzQixPQUFPO0NBRVQsT0FBTyxTQUFTLE1BQU0sVUFBVSxLQUFLO0FBQ3ZDO0FBQ0EsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxpQkFBZ0IsUUFBTyxxQkFBcUIsS0FBSyxHQUFHOzs7Ozs7QUFNMUQsU0FBUyxZQUFZLElBQUksY0FBYztDQUNyQyxJQUFJLGlCQUFpQixLQUFLLEdBQ3hCLGVBQWU7Q0FFakIsSUFBSSxFQUNGLFVBQVUsWUFDVixTQUFTLElBQ1QsT0FBTyxPQUNMLE9BQU8sT0FBTyxXQUFXLFVBQVUsRUFBRSxJQUFJO0NBQzdDLElBQUk7Q0FDSixJQUFJLFlBQVk7RUFDZCxJQUFJLGNBQWMsVUFBVSxHQUMxQixXQUFXO09BQ047R0FDTCxJQUFJLFdBQVcsU0FBUyxJQUFJLEdBQUc7SUFDN0IsSUFBSSxjQUFjO0lBQ2xCLGFBQWEsb0JBQW9CLFVBQVU7SUFDM0MsUUFBUSxPQUFPLGtFQUFrRSxjQUFjLFNBQVMsV0FBVztHQUNySDtHQUNBLElBQUksV0FBVyxXQUFXLEdBQUcsR0FDM0IsV0FBVyxnQkFBZ0IsV0FBVyxVQUFVLENBQUMsR0FBRyxHQUFHO1FBRXZELFdBQVcsZ0JBQWdCLFlBQVksWUFBWTtFQUV2RDtDQUNGLE9BQ0UsV0FBVztDQUViLE9BQU87RUFDTDtFQUNBLFFBQVEsZ0JBQWdCLE1BQU07RUFDOUIsTUFBTSxjQUFjLElBQUk7Q0FDMUI7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLGNBQWMsY0FBYztDQUNuRCxJQUFJLFdBQVcsYUFBYSxRQUFRLFFBQVEsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHO0NBRXpELGFBRG9DLE1BQU0sR0FDM0IsQ0FBQyxDQUFDLFNBQVEsWUFBVztFQUNsQyxJQUFJLFlBQVksTUFFVjtPQUFBLFNBQVMsU0FBUyxHQUFHLFNBQVMsSUFBSTtFQUFBLE9BQ2pDLElBQUksWUFBWSxLQUNyQixTQUFTLEtBQUssT0FBTztDQUV6QixDQUFDO0NBQ0QsT0FBTyxTQUFTLFNBQVMsSUFBSSxTQUFTLEtBQUssR0FBRyxJQUFJO0FBQ3BEO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTSxPQUFPLE1BQU0sTUFBTTtDQUNwRCxPQUFPLHVCQUF1QixPQUFPLDBDQUEwQyxTQUFTLFFBQVEsY0FBYyxLQUFLLFVBQVUsSUFBSSxJQUFJLHlDQUF5QyxTQUFTLE9BQU8sOERBQThEO0FBQzlQOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF3QkEsU0FBUywyQkFBMkIsU0FBUztDQUMzQyxPQUFPLFFBQVEsUUFBUSxPQUFPLFVBQVUsVUFBVSxLQUFLLE1BQU0sTUFBTSxRQUFRLE1BQU0sTUFBTSxLQUFLLFNBQVMsQ0FBQztBQUN4RztBQUdBLFNBQVMsb0JBQW9CLFNBQVMsc0JBQXNCO0NBQzFELElBQUksY0FBYywyQkFBMkIsT0FBTztDQUlwRCxJQUFJLHNCQUNGLE9BQU8sWUFBWSxLQUFLLE9BQU8sUUFBUSxRQUFRLFlBQVksU0FBUyxJQUFJLE1BQU0sV0FBVyxNQUFNLFlBQVk7Q0FFN0csT0FBTyxZQUFZLEtBQUksVUFBUyxNQUFNLFlBQVk7QUFDcEQ7Ozs7QUFJQSxTQUFTLFVBQVUsT0FBTyxnQkFBZ0Isa0JBQWtCLGdCQUFnQjtDQUMxRSxJQUFJLG1CQUFtQixLQUFLLEdBQzFCLGlCQUFpQjtDQUVuQixJQUFJO0NBQ0osSUFBSSxPQUFPLFVBQVUsVUFDbkIsS0FBSyxVQUFVLEtBQUs7TUFDZjtFQUNMLEtBQUtBLFdBQVMsQ0FBQyxHQUFHLEtBQUs7RUFDdkIsVUFBVSxDQUFDLEdBQUcsWUFBWSxDQUFDLEdBQUcsU0FBUyxTQUFTLEdBQUcsR0FBRyxvQkFBb0IsS0FBSyxZQUFZLFVBQVUsRUFBRSxDQUFDO0VBQ3hHLFVBQVUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxHQUFHLFNBQVMsU0FBUyxHQUFHLEdBQUcsb0JBQW9CLEtBQUssWUFBWSxRQUFRLEVBQUUsQ0FBQztFQUN0RyxVQUFVLENBQUMsR0FBRyxVQUFVLENBQUMsR0FBRyxPQUFPLFNBQVMsR0FBRyxHQUFHLG9CQUFvQixLQUFLLFVBQVUsUUFBUSxFQUFFLENBQUM7Q0FDbEc7Q0FDQSxJQUFJLGNBQWMsVUFBVSxNQUFNLEdBQUcsYUFBYTtDQUNsRCxJQUFJLGFBQWEsY0FBYyxNQUFNLEdBQUc7Q0FDeEMsSUFBSTtDQVVKLElBQUksY0FBYyxNQUNoQixPQUFPO01BQ0Y7RUFDTCxJQUFJLHFCQUFxQixlQUFlLFNBQVM7RUFLakQsSUFBSSxDQUFDLGtCQUFrQixXQUFXLFdBQVcsSUFBSSxHQUFHO0dBQ2xELElBQUksYUFBYSxXQUFXLE1BQU0sR0FBRztHQUNyQyxPQUFPLFdBQVcsT0FBTyxNQUFNO0lBQzdCLFdBQVcsTUFBTTtJQUNqQixzQkFBc0I7R0FDeEI7R0FDQSxHQUFHLFdBQVcsV0FBVyxLQUFLLEdBQUc7RUFDbkM7RUFDQSxPQUFPLHNCQUFzQixJQUFJLGVBQWUsc0JBQXNCO0NBQ3hFO0NBQ0EsSUFBSSxPQUFPLFlBQVksSUFBSSxJQUFJO0NBRS9CLElBQUksMkJBQTJCLGNBQWMsZUFBZSxPQUFPLFdBQVcsU0FBUyxHQUFHO0NBRTFGLElBQUksMkJBQTJCLGVBQWUsZUFBZSxRQUFRLGlCQUFpQixTQUFTLEdBQUc7Q0FDbEcsSUFBSSxDQUFDLEtBQUssU0FBUyxTQUFTLEdBQUcsTUFBTSw0QkFBNEIsMEJBQy9ELEtBQUssWUFBWTtDQUVuQixPQUFPO0FBQ1Q7QUFRQSxJQUFNLHVCQUFzQixTQUFRLEtBQUssUUFBUSxVQUFVLEdBQUc7Ozs7QUFJOUQsSUFBTSxhQUFZLFVBQVMsb0JBQW9CLE1BQU0sS0FBSyxHQUFHLENBQUM7Ozs7QUFJOUQsSUFBTSxxQkFBb0IsYUFBWSxTQUFTLFFBQVEsUUFBUSxFQUFFLENBQUMsQ0FBQyxRQUFRLFFBQVEsR0FBRzs7OztBQUl0RixJQUFNLG1CQUFrQixXQUFVLENBQUMsVUFBVSxXQUFXLE1BQU0sS0FBSyxPQUFPLFdBQVcsR0FBRyxJQUFJLFNBQVMsTUFBTTs7OztBQUkzRyxJQUFNLGlCQUFnQixTQUFRLENBQUMsUUFBUSxTQUFTLE1BQU0sS0FBSyxLQUFLLFdBQVcsR0FBRyxJQUFJLE9BQU8sTUFBTTs7Ozs7Ozs7QUFRL0YsSUFBTSxPQUFPLFNBQVMsS0FBSyxNQUFNLE1BQU07Q0FDckMsSUFBSSxTQUFTLEtBQUssR0FDaEIsT0FBTyxDQUFDO0NBRVYsSUFBSSxlQUFlLE9BQU8sU0FBUyxXQUFXLEVBQzVDLFFBQVEsS0FDVixJQUFJO0NBQ0osSUFBSSxVQUFVLElBQUksUUFBUSxhQUFhLE9BQU87Q0FDOUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxjQUFjLEdBQzdCLFFBQVEsSUFBSSxnQkFBZ0IsaUNBQWlDO0NBRS9ELE9BQU8sSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLEdBQUdBLFdBQVMsQ0FBQyxHQUFHLGNBQWMsRUFDbkUsUUFDRixDQUFDLENBQUM7QUFDSjtBQWlCQSxJQUFNLHVCQUFOLGNBQW1DLE1BQU0sQ0FBQztBQUMxQyxJQUFNLGVBQU4sTUFBbUI7Q0FDakIsWUFBWSxNQUFNLGNBQWM7RUFDOUIsS0FBSyxpQ0FBaUIsSUFBSSxJQUFJO0VBQzlCLEtBQUssOEJBQWMsSUFBSSxJQUFJO0VBQzNCLEtBQUssZUFBZSxDQUFDO0VBQ3JCLFVBQVUsUUFBUSxPQUFPLFNBQVMsWUFBWSxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQUcsb0NBQW9DO0VBR3hHLElBQUk7RUFDSixLQUFLLGVBQWUsSUFBSSxTQUFTLEdBQUcsTUFBTSxTQUFTLENBQUM7RUFDcEQsS0FBSyxhQUFhLElBQUksZ0JBQWdCO0VBQ3RDLElBQUksZ0JBQWdCLE9BQU8sSUFBSSxxQkFBcUIsdUJBQXVCLENBQUM7RUFDNUUsS0FBSyw0QkFBNEIsS0FBSyxXQUFXLE9BQU8sb0JBQW9CLFNBQVMsT0FBTztFQUM1RixLQUFLLFdBQVcsT0FBTyxpQkFBaUIsU0FBUyxPQUFPO0VBQ3hELEtBQUssT0FBTyxPQUFPLFFBQVEsSUFBSSxDQUFDLENBQUMsUUFBUSxLQUFLLFVBQVU7R0FDdEQsSUFBSSxDQUFDLEtBQUssU0FBUztHQUNuQixPQUFPLE9BQU8sT0FBTyxLQUFLLEdBQ3ZCLE1BQU0sS0FBSyxhQUFhLEtBQUssS0FBSyxFQUNyQyxDQUFDO0VBQ0gsR0FBRyxDQUFDLENBQUM7RUFDTCxJQUFJLEtBQUssTUFFUCxLQUFLLG9CQUFvQjtFQUUzQixLQUFLLE9BQU87Q0FDZDtDQUNBLGFBQWEsS0FBSyxPQUFPO0VBQ3ZCLElBQUksRUFBRSxpQkFBaUIsVUFDckIsT0FBTztFQUVULEtBQUssYUFBYSxLQUFLLEdBQUc7RUFDMUIsS0FBSyxlQUFlLElBQUksR0FBRztFQUczQixJQUFJLFVBQVUsUUFBUSxLQUFLLENBQUMsT0FBTyxLQUFLLFlBQVksQ0FBQyxDQUFDLENBQUMsTUFBSyxTQUFRLEtBQUssU0FBUyxTQUFTLEtBQUssS0FBQSxHQUFXLElBQUksSUFBRyxVQUFTLEtBQUssU0FBUyxTQUFTLEtBQUssS0FBSyxDQUFDO0VBRzdKLFFBQVEsWUFBWSxDQUFDLENBQUM7RUFDdEIsT0FBTyxlQUFlLFNBQVMsWUFBWSxFQUN6QyxXQUFXLEtBQ2IsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLFNBQVMsU0FBUyxLQUFLLE9BQU8sTUFBTTtFQUNsQyxJQUFJLEtBQUssV0FBVyxPQUFPLFdBQVcsaUJBQWlCLHNCQUFzQjtHQUMzRSxLQUFLLG9CQUFvQjtHQUN6QixPQUFPLGVBQWUsU0FBUyxVQUFVLEVBQ3ZDLFdBQVcsTUFDYixDQUFDO0dBQ0QsT0FBTyxRQUFRLE9BQU8sS0FBSztFQUM3QjtFQUNBLEtBQUssZUFBZSxPQUFPLEdBQUc7RUFDOUIsSUFBSSxLQUFLLE1BRVAsS0FBSyxvQkFBb0I7RUFJM0IsSUFBSSxVQUFVLEtBQUEsS0FBYSxTQUFTLEtBQUEsR0FBVztHQUM3QyxJQUFJLGlDQUFpQixJQUFJLE1BQU0sNkJBQTZCLE1BQU0sd0ZBQTZGO0dBQy9KLE9BQU8sZUFBZSxTQUFTLFVBQVUsRUFDdkMsV0FBVyxlQUNiLENBQUM7R0FDRCxLQUFLLEtBQUssT0FBTyxHQUFHO0dBQ3BCLE9BQU8sUUFBUSxPQUFPLGNBQWM7RUFDdEM7RUFDQSxJQUFJLFNBQVMsS0FBQSxHQUFXO0dBQ3RCLE9BQU8sZUFBZSxTQUFTLFVBQVUsRUFDdkMsV0FBVyxNQUNiLENBQUM7R0FDRCxLQUFLLEtBQUssT0FBTyxHQUFHO0dBQ3BCLE9BQU8sUUFBUSxPQUFPLEtBQUs7RUFDN0I7RUFDQSxPQUFPLGVBQWUsU0FBUyxTQUFTLEVBQ3RDLFdBQVcsS0FDYixDQUFDO0VBQ0QsS0FBSyxLQUFLLE9BQU8sR0FBRztFQUNwQixPQUFPO0NBQ1Q7Q0FDQSxLQUFLLFNBQVMsWUFBWTtFQUN4QixLQUFLLFlBQVksU0FBUSxlQUFjLFdBQVcsU0FBUyxVQUFVLENBQUM7Q0FDeEU7Q0FDQSxVQUFVLElBQUk7RUFDWixLQUFLLFlBQVksSUFBSSxFQUFFO0VBQ3ZCLGFBQWEsS0FBSyxZQUFZLE9BQU8sRUFBRTtDQUN6QztDQUNBLFNBQVM7RUFDUCxLQUFLLFdBQVcsTUFBTTtFQUN0QixLQUFLLGVBQWUsU0FBUyxHQUFHLE1BQU0sS0FBSyxlQUFlLE9BQU8sQ0FBQyxDQUFDO0VBQ25FLEtBQUssS0FBSyxJQUFJO0NBQ2hCO0NBQ0EsTUFBTSxZQUFZLFFBQVE7RUFDeEIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxDQUFDLEtBQUssTUFBTTtHQUNkLElBQUksZ0JBQWdCLEtBQUssT0FBTztHQUNoQyxPQUFPLGlCQUFpQixTQUFTLE9BQU87R0FDeEMsVUFBVSxNQUFNLElBQUksU0FBUSxZQUFXO0lBQ3JDLEtBQUssV0FBVSxZQUFXO0tBQ3hCLE9BQU8sb0JBQW9CLFNBQVMsT0FBTztLQUMzQyxJQUFJLFdBQVcsS0FBSyxNQUNsQixRQUFRLE9BQU87SUFFbkIsQ0FBQztHQUNILENBQUM7RUFDSDtFQUNBLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTztFQUNULE9BQU8sS0FBSyxlQUFlLFNBQVM7Q0FDdEM7Q0FDQSxJQUFJLGdCQUFnQjtFQUNsQixVQUFVLEtBQUssU0FBUyxRQUFRLEtBQUssTUFBTSwyREFBMkQ7RUFDdEcsT0FBTyxPQUFPLFFBQVEsS0FBSyxJQUFJLENBQUMsQ0FBQyxRQUFRLEtBQUssVUFBVTtHQUN0RCxJQUFJLENBQUMsS0FBSyxTQUFTO0dBQ25CLE9BQU8sT0FBTyxPQUFPLEtBQUssR0FDdkIsTUFBTSxxQkFBcUIsS0FBSyxFQUNuQyxDQUFDO0VBQ0gsR0FBRyxDQUFDLENBQUM7Q0FDUDtDQUNBLElBQUksY0FBYztFQUNoQixPQUFPLE1BQU0sS0FBSyxLQUFLLGNBQWM7Q0FDdkM7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLE9BQU87Q0FDL0IsT0FBTyxpQkFBaUIsV0FBVyxNQUFNLGFBQWE7QUFDeEQ7QUFDQSxTQUFTLHFCQUFxQixPQUFPO0NBQ25DLElBQUksQ0FBQyxpQkFBaUIsS0FBSyxHQUN6QixPQUFPO0NBRVQsSUFBSSxNQUFNLFFBQ1IsTUFBTSxNQUFNO0NBRWQsT0FBTyxNQUFNO0FBQ2Y7Ozs7O0FBS0EsSUFBTSxRQUFRLFNBQVMsTUFBTSxNQUFNLE1BQU07Q0FDdkMsSUFBSSxTQUFTLEtBQUssR0FDaEIsT0FBTyxDQUFDO0NBS1YsT0FBTyxJQUFJLGFBQWEsTUFITCxPQUFPLFNBQVMsV0FBVyxFQUM1QyxRQUFRLEtBQ1YsSUFBSSxJQUNzQztBQUM1Qzs7Ozs7QUFLQSxJQUFNLFdBQVcsU0FBUyxTQUFTLEtBQUssTUFBTTtDQUM1QyxJQUFJLFNBQVMsS0FBSyxHQUNoQixPQUFPO0NBRVQsSUFBSSxlQUFlO0NBQ25CLElBQUksT0FBTyxpQkFBaUIsVUFDMUIsZUFBZSxFQUNiLFFBQVEsYUFDVjtNQUNLLElBQUksT0FBTyxhQUFhLFdBQVcsYUFDeEMsYUFBYSxTQUFTO0NBRXhCLElBQUksVUFBVSxJQUFJLFFBQVEsYUFBYSxPQUFPO0NBQzlDLFFBQVEsSUFBSSxZQUFZLEdBQUc7Q0FDM0IsT0FBTyxJQUFJLFNBQVMsTUFBTUEsV0FBUyxDQUFDLEdBQUcsY0FBYyxFQUNuRCxRQUNGLENBQUMsQ0FBQztBQUNKOzs7Ozs7QUFNQSxJQUFNLG9CQUFvQixLQUFLLFNBQVM7Q0FDdEMsSUFBSSxXQUFXLFNBQVMsS0FBSyxJQUFJO0NBQ2pDLFNBQVMsUUFBUSxJQUFJLDJCQUEyQixNQUFNO0NBQ3RELE9BQU87QUFDVDs7Ozs7OztBQU9BLElBQU0sV0FBVyxLQUFLLFNBQVM7Q0FDN0IsSUFBSSxXQUFXLFNBQVMsS0FBSyxJQUFJO0NBQ2pDLFNBQVMsUUFBUSxJQUFJLG1CQUFtQixNQUFNO0NBQzlDLE9BQU87QUFDVDs7Ozs7Ozs7O0FBU0EsSUFBTSxvQkFBTixNQUF3QjtDQUN0QixZQUFZLFFBQVEsWUFBWSxNQUFNLFVBQVU7RUFDOUMsSUFBSSxhQUFhLEtBQUssR0FDcEIsV0FBVztFQUViLEtBQUssU0FBUztFQUNkLEtBQUssYUFBYSxjQUFjO0VBQ2hDLEtBQUssV0FBVztFQUNoQixJQUFJLGdCQUFnQixPQUFPO0dBQ3pCLEtBQUssT0FBTyxLQUFLLFNBQVM7R0FDMUIsS0FBSyxRQUFRO0VBQ2YsT0FDRSxLQUFLLE9BQU87Q0FFaEI7QUFDRjs7Ozs7QUFLQSxTQUFTLHFCQUFxQixPQUFPO0NBQ25DLE9BQU8sU0FBUyxRQUFRLE9BQU8sTUFBTSxXQUFXLFlBQVksT0FBTyxNQUFNLGVBQWUsWUFBWSxPQUFPLE1BQU0sYUFBYSxhQUFhLFVBQVU7QUFDdko7QUFFQSxJQUFNLDBCQUEwQjtDQUFDO0NBQVE7Q0FBTztDQUFTO0FBQVE7QUFDakUsSUFBTSx1QkFBdUIsSUFBSSxJQUFJLHVCQUF1QjtBQUM1RCxJQUFNLHlCQUF5QixDQUFDLE9BQU8sR0FBRyx1QkFBdUI7QUFDakUsSUFBTSxzQkFBc0IsSUFBSSxJQUFJLHNCQUFzQjtBQUMxRCxJQUFNLHNDQUFzQixJQUFJLElBQUk7Q0FBQztDQUFLO0NBQUs7Q0FBSztDQUFLO0FBQUcsQ0FBQztBQUM3RCxJQUFNLG9EQUFvQyxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQztBQUM1RCxJQUFNLGtCQUFrQjtDQUN0QixPQUFPO0NBQ1AsVUFBVSxLQUFBO0NBQ1YsWUFBWSxLQUFBO0NBQ1osWUFBWSxLQUFBO0NBQ1osYUFBYSxLQUFBO0NBQ2IsVUFBVSxLQUFBO0NBQ1YsTUFBTSxLQUFBO0NBQ04sTUFBTSxLQUFBO0FBQ1I7QUFDQSxJQUFNLGVBQWU7Q0FDbkIsT0FBTztDQUNQLE1BQU0sS0FBQTtDQUNOLFlBQVksS0FBQTtDQUNaLFlBQVksS0FBQTtDQUNaLGFBQWEsS0FBQTtDQUNiLFVBQVUsS0FBQTtDQUNWLE1BQU0sS0FBQTtDQUNOLE1BQU0sS0FBQTtBQUNSO0FBQ0EsSUFBTSxlQUFlO0NBQ25CLE9BQU87Q0FDUCxTQUFTLEtBQUE7Q0FDVCxPQUFPLEtBQUE7Q0FDUCxVQUFVLEtBQUE7QUFDWjtBQUNBLElBQU1DLHVCQUFxQjtBQUMzQixJQUFNLDZCQUE0QixXQUFVLEVBQzFDLGtCQUFrQixRQUFRLE1BQU0sZ0JBQWdCLEVBQ2xEO0FBQ0EsSUFBTSwwQkFBMEI7Ozs7QUFRaEMsU0FBUyxhQUFhLE1BQU07Q0FDMUIsTUFBTSxlQUFlLEtBQUssU0FBUyxLQUFLLFNBQVMsT0FBTyxXQUFXLGNBQWMsU0FBUyxLQUFBO0NBQzFGLE1BQU0sWUFBWSxPQUFPLGlCQUFpQixlQUFlLE9BQU8sYUFBYSxhQUFhLGVBQWUsT0FBTyxhQUFhLFNBQVMsa0JBQWtCO0NBQ3hKLE1BQU0sV0FBVyxDQUFDO0NBQ2xCLFVBQVUsS0FBSyxPQUFPLFNBQVMsR0FBRywyREFBMkQ7Q0FDN0YsSUFBSTtDQUNKLElBQUksS0FBSyxvQkFDUCxxQkFBcUIsS0FBSztNQUNyQixJQUFJLEtBQUsscUJBQXFCO0VBRW5DLElBQUksc0JBQXNCLEtBQUs7RUFDL0Isc0JBQXFCLFdBQVUsRUFDN0Isa0JBQWtCLG9CQUFvQixLQUFLLEVBQzdDO0NBQ0YsT0FDRSxxQkFBcUI7Q0FHdkIsSUFBSSxXQUFXLENBQUM7Q0FFaEIsSUFBSSxhQUFhLDBCQUEwQixLQUFLLFFBQVEsb0JBQW9CLEtBQUEsR0FBVyxRQUFRO0NBQy9GLElBQUk7Q0FDSixJQUFJLFdBQVcsS0FBSyxZQUFZO0NBQ2hDLElBQUksbUJBQW1CLEtBQUssZ0JBQWdCO0NBQzVDLElBQUksOEJBQThCLEtBQUs7Q0FFdkMsSUFBSSxTQUFTRCxXQUFTO0VBQ3BCLG1CQUFtQjtFQUNuQix3QkFBd0I7RUFDeEIscUJBQXFCO0VBQ3JCLG9CQUFvQjtFQUNwQixzQkFBc0I7RUFDdEIsZ0NBQWdDO0NBQ2xDLEdBQUcsS0FBSyxNQUFNO0NBRWQsSUFBSSxrQkFBa0I7Q0FFdEIsSUFBSSw4QkFBYyxJQUFJLElBQUk7Q0FFMUIsSUFBSSx1QkFBdUI7Q0FFM0IsSUFBSSwwQkFBMEI7Q0FFOUIsSUFBSSxvQkFBb0I7Q0FPeEIsSUFBSSx3QkFBd0IsS0FBSyxpQkFBaUI7Q0FDbEQsSUFBSSxpQkFBaUIsWUFBWSxZQUFZLEtBQUssUUFBUSxVQUFVLFFBQVE7Q0FDNUUsSUFBSSxzQkFBc0I7Q0FDMUIsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxrQkFBa0IsUUFBUSxDQUFDLDZCQUE2QjtFQUcxRCxJQUFJLFFBQVEsdUJBQXVCLEtBQUssRUFDdEMsVUFBVSxLQUFLLFFBQVEsU0FBUyxTQUNsQyxDQUFDO0VBQ0QsSUFBSSxFQUNGLFNBQ0EsVUFDRSx1QkFBdUIsVUFBVTtFQUNyQyxpQkFBaUI7RUFDakIsZ0JBQWdCLEdBQ2IsTUFBTSxLQUFLLE1BQ2Q7Q0FDRjtDQU9BLElBQUksa0JBQWtCLENBQUMsS0FBSyxlQUNYO01BQUEsY0FBYyxnQkFBZ0IsWUFBWSxLQUFLLFFBQVEsU0FBUyxRQUNwRSxDQUFDLENBQUMsUUFDWCxpQkFBaUI7Q0FBQTtDQUdyQixJQUFJO0NBQ0osSUFBSSxDQUFDLGdCQUFnQjtFQUNuQixjQUFjO0VBQ2QsaUJBQWlCLENBQUM7RUFJbEIsSUFBSSxPQUFPLHFCQUFxQjtHQUM5QixJQUFJLFdBQVcsY0FBYyxNQUFNLFlBQVksS0FBSyxRQUFRLFNBQVMsUUFBUTtHQUM3RSxJQUFJLFNBQVMsVUFBVSxTQUFTLFNBQVM7SUFDdkMsc0JBQXNCO0lBQ3RCLGlCQUFpQixTQUFTO0dBQzVCO0VBQ0Y7Q0FDRixPQUFPLElBQUksZUFBZSxNQUFLLE1BQUssRUFBRSxNQUFNLElBQUksR0FHOUMsY0FBYztNQUNULElBQUksQ0FBQyxlQUFlLE1BQUssTUFBSyxFQUFFLE1BQU0sTUFBTSxHQUVqRCxjQUFjO01BQ1QsSUFBSSxPQUFPLHFCQUFxQjtFQUlyQyxJQUFJLGFBQWEsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjLGFBQWE7RUFDdEUsSUFBSSxTQUFTLEtBQUssZ0JBQWdCLEtBQUssY0FBYyxTQUFTO0VBRTlELElBQUksUUFBUTtHQUNWLElBQUksTUFBTSxlQUFlLFdBQVUsTUFBSyxPQUFPLEVBQUUsTUFBTSxRQUFRLEtBQUEsQ0FBUztHQUN4RSxjQUFjLGVBQWUsTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTSxNQUFLLENBQUMsMkJBQTJCLEVBQUUsT0FBTyxZQUFZLE1BQU0sQ0FBQztFQUNwSCxPQUNFLGNBQWMsZUFBZSxPQUFNLE1BQUssQ0FBQywyQkFBMkIsRUFBRSxPQUFPLFlBQVksTUFBTSxDQUFDO0NBRXBHLE9BR0UsY0FBYyxLQUFLLGlCQUFpQjtDQUV0QyxJQUFJO0NBQ0osSUFBSSxRQUFRO0VBQ1YsZUFBZSxLQUFLLFFBQVE7RUFDNUIsVUFBVSxLQUFLLFFBQVE7RUFDdkIsU0FBUztFQUNUO0VBQ0EsWUFBWTtFQUVaLHVCQUF1QixLQUFLLGlCQUFpQixPQUFPLFFBQVE7RUFDNUQsb0JBQW9CO0VBQ3BCLGNBQWM7RUFDZCxZQUFZLEtBQUssaUJBQWlCLEtBQUssY0FBYyxjQUFjLENBQUM7RUFDcEUsWUFBWSxLQUFLLGlCQUFpQixLQUFLLGNBQWMsY0FBYztFQUNuRSxRQUFRLEtBQUssaUJBQWlCLEtBQUssY0FBYyxVQUFVO0VBQzNELDBCQUFVLElBQUksSUFBSTtFQUNsQiwwQkFBVSxJQUFJLElBQUk7Q0FDcEI7Q0FHQSxJQUFJLGdCQUFnQixPQUFPO0NBRzNCLElBQUksNEJBQTRCO0NBRWhDLElBQUk7Q0FFSixJQUFJLCtCQUErQjtDQUVuQyxJQUFJLHlDQUF5QixJQUFJLElBQUk7Q0FFckMsSUFBSSw4QkFBOEI7Q0FHbEMsSUFBSSw4QkFBOEI7Q0FLbEMsSUFBSSx5QkFBeUI7Q0FHN0IsSUFBSSwwQkFBMEIsQ0FBQztDQUcvQixJQUFJLHdDQUF3QixJQUFJLElBQUk7Q0FFcEMsSUFBSSxtQ0FBbUIsSUFBSSxJQUFJO0NBRS9CLElBQUkscUJBQXFCO0NBSXpCLElBQUksMEJBQTBCO0NBRTlCLElBQUksaUNBQWlCLElBQUksSUFBSTtDQUU3QixJQUFJLG1DQUFtQixJQUFJLElBQUk7Q0FFL0IsSUFBSSxtQ0FBbUIsSUFBSSxJQUFJO0NBRS9CLElBQUksaUNBQWlCLElBQUksSUFBSTtDQUc3QixJQUFJLGtDQUFrQixJQUFJLElBQUk7Q0FLOUIsSUFBSSxrQ0FBa0IsSUFBSSxJQUFJO0NBRzlCLElBQUksbUNBQW1CLElBQUksSUFBSTtDQUcvQixJQUFJLDhCQUE4QixLQUFBO0NBSWxDLFNBQVMsYUFBYTtFQUdwQixrQkFBa0IsS0FBSyxRQUFRLFFBQU8sU0FBUTtHQUM1QyxJQUFJLEVBQ0YsUUFBUSxlQUNSLFVBQ0EsVUFDRTtHQUdKLElBQUksNkJBQTZCO0lBQy9CLDRCQUE0QjtJQUM1Qiw4QkFBOEIsS0FBQTtJQUM5QjtHQUNGO0dBQ0EsUUFBUSxpQkFBaUIsU0FBUyxLQUFLLFNBQVMsTUFBTSw0WUFBcWE7R0FDM2QsSUFBSSxhQUFhLHNCQUFzQjtJQUNyQyxpQkFBaUIsTUFBTTtJQUN2QixjQUFjO0lBQ2Q7R0FDRixDQUFDO0dBQ0QsSUFBSSxjQUFjLFNBQVMsTUFBTTtJQUUvQixJQUFJLDJCQUEyQixJQUFJLFNBQVEsWUFBVztLQUNwRCw4QkFBOEI7SUFDaEMsQ0FBQztJQUNELEtBQUssUUFBUSxHQUFHLFFBQVEsRUFBRTtJQUUxQixjQUFjLFlBQVk7S0FDeEIsT0FBTztLQUNQO0tBQ0EsVUFBVTtNQUNSLGNBQWMsWUFBWTtPQUN4QixPQUFPO09BQ1AsU0FBUyxLQUFBO09BQ1QsT0FBTyxLQUFBO09BQ1A7TUFDRixDQUFDO01BSUQseUJBQXlCLFdBQVcsS0FBSyxRQUFRLEdBQUcsS0FBSyxDQUFDO0tBQzVEO0tBQ0EsUUFBUTtNQUNOLElBQUksV0FBVyxJQUFJLElBQUksTUFBTSxRQUFRO01BQ3JDLFNBQVMsSUFBSSxZQUFZLFlBQVk7TUFDckMsWUFBWSxFQUNWLFNBQ0YsQ0FBQztLQUNIO0lBQ0YsQ0FBQztJQUNEO0dBQ0Y7R0FDQSxPQUFPLGdCQUFnQixlQUFlLFFBQVE7RUFDaEQsQ0FBQztFQUNELElBQUksV0FBVztHQUdiLDBCQUEwQixjQUFjLHNCQUFzQjtHQUM5RCxJQUFJLGdDQUFnQywwQkFBMEIsY0FBYyxzQkFBc0I7R0FDbEcsYUFBYSxpQkFBaUIsWUFBWSx1QkFBdUI7R0FDakUsb0NBQW9DLGFBQWEsb0JBQW9CLFlBQVksdUJBQXVCO0VBQzFHO0VBTUEsSUFBSSxDQUFDLE1BQU0sYUFDVCxnQkFBZ0IsT0FBTyxLQUFLLE1BQU0sVUFBVSxFQUMxQyxrQkFBa0IsS0FDcEIsQ0FBQztFQUVILE9BQU87Q0FDVDtDQUVBLFNBQVMsVUFBVTtFQUNqQixJQUFJLGlCQUNGLGdCQUFnQjtFQUVsQixJQUFJLDZCQUNGLDRCQUE0QjtFQUU5QixZQUFZLE1BQU07RUFDbEIsK0JBQStCLDRCQUE0QixNQUFNO0VBQ2pFLE1BQU0sU0FBUyxTQUFTLEdBQUcsUUFBUSxjQUFjLEdBQUcsQ0FBQztFQUNyRCxNQUFNLFNBQVMsU0FBUyxHQUFHLFFBQVEsY0FBYyxHQUFHLENBQUM7Q0FDdkQ7Q0FFQSxTQUFTLFVBQVUsSUFBSTtFQUNyQixZQUFZLElBQUksRUFBRTtFQUNsQixhQUFhLFlBQVksT0FBTyxFQUFFO0NBQ3BDO0NBRUEsU0FBUyxZQUFZLFVBQVUsTUFBTTtFQUNuQyxJQUFJLFNBQVMsS0FBSyxHQUNoQixPQUFPLENBQUM7RUFFVixRQUFRQSxXQUFTLENBQUMsR0FBRyxPQUFPLFFBQVE7RUFHcEMsSUFBSSxvQkFBb0IsQ0FBQztFQUN6QixJQUFJLHNCQUFzQixDQUFDO0VBQzNCLElBQUksT0FBTyxtQkFDVCxNQUFNLFNBQVMsU0FBUyxTQUFTLFFBQVE7R0FDdkMsSUFBSSxRQUFRLFVBQVUsUUFBUTtJQUM1QixJQUFJLGdCQUFnQixJQUFJLEdBQUcsR0FFekIsb0JBQW9CLEtBQUssR0FBRztTQUk1QixrQkFBa0IsS0FBSyxHQUFHO0dBRTlCO0VBQ0YsQ0FBQztFQUlILGdCQUFnQixTQUFRLFFBQU87R0FDN0IsSUFBSSxDQUFDLE1BQU0sU0FBUyxJQUFJLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixJQUFJLEdBQUcsR0FDdkQsb0JBQW9CLEtBQUssR0FBRztFQUVoQyxDQUFDO0VBSUQsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxDQUFDLFNBQVEsZUFBYyxXQUFXLE9BQU87R0FDdkQsaUJBQWlCO0dBQ2pCLG9CQUFvQixLQUFLO0dBQ3pCLFdBQVcsS0FBSyxjQUFjO0VBQ2hDLENBQUMsQ0FBQztFQUVGLElBQUksT0FBTyxtQkFBbUI7R0FDNUIsa0JBQWtCLFNBQVEsUUFBTyxNQUFNLFNBQVMsT0FBTyxHQUFHLENBQUM7R0FDM0Qsb0JBQW9CLFNBQVEsUUFBTyxjQUFjLEdBQUcsQ0FBQztFQUN2RCxPQUdFLG9CQUFvQixTQUFRLFFBQU8sZ0JBQWdCLE9BQU8sR0FBRyxDQUFDO0NBRWxFO0NBTUEsU0FBUyxtQkFBbUIsVUFBVSxVQUFVLE9BQU87RUFDckQsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxFQUNGLGNBQ0UsVUFBVSxLQUFLLElBQUksQ0FBQyxJQUFJO0VBTTVCLElBQUksaUJBQWlCLE1BQU0sY0FBYyxRQUFRLE1BQU0sV0FBVyxjQUFjLFFBQVEsaUJBQWlCLE1BQU0sV0FBVyxVQUFVLEtBQUssTUFBTSxXQUFXLFVBQVUsZUFBZSxrQkFBa0IsU0FBUyxVQUFVLE9BQU8sS0FBSyxJQUFJLGdCQUFnQixpQkFBaUI7RUFDelEsSUFBSTtFQUNKLElBQUksU0FBUyxZQUFZO0dBQ3ZCLElBQUksT0FBTyxLQUFLLFNBQVMsVUFBVSxDQUFDLENBQUMsU0FBUyxHQUM1QyxhQUFhLFNBQVM7UUFHdEIsYUFBYTtFQUVqQixPQUFPLElBQUksZ0JBRVQsYUFBYSxNQUFNO09BR25CLGFBQWE7RUFHZixJQUFJLGFBQWEsU0FBUyxhQUFhLGdCQUFnQixNQUFNLFlBQVksU0FBUyxZQUFZLFNBQVMsV0FBVyxDQUFDLEdBQUcsU0FBUyxNQUFNLElBQUksTUFBTTtFQUcvSSxJQUFJLFdBQVcsTUFBTTtFQUNyQixJQUFJLFNBQVMsT0FBTyxHQUFHO0dBQ3JCLFdBQVcsSUFBSSxJQUFJLFFBQVE7R0FDM0IsU0FBUyxTQUFTLEdBQUcsTUFBTSxTQUFTLElBQUksR0FBRyxZQUFZLENBQUM7RUFDMUQ7RUFHQSxJQUFJLHFCQUFxQiw4QkFBOEIsUUFBUSxNQUFNLFdBQVcsY0FBYyxRQUFRLGlCQUFpQixNQUFNLFdBQVcsVUFBVSxPQUFPLG1CQUFtQixTQUFTLFVBQVUsT0FBTyxLQUFLLElBQUksaUJBQWlCLGlCQUFpQjtFQUVqUCxJQUFJLG9CQUFvQjtHQUN0QixhQUFhO0dBQ2IscUJBQXFCLEtBQUE7RUFDdkI7RUFDQSxJQUFJO09BQW9DLElBQUksa0JBQWtCLE9BQU87T0FBWSxJQUFJLGtCQUFrQixPQUFPLE1BQzVHLEtBQUssUUFBUSxLQUFLLFVBQVUsU0FBUyxLQUFLO09BQ3JDLElBQUksa0JBQWtCLE9BQU8sU0FDbEMsS0FBSyxRQUFRLFFBQVEsVUFBVSxTQUFTLEtBQUs7RUFFL0MsSUFBSTtFQUVKLElBQUksa0JBQWtCLE9BQU8sS0FBSztHQUVoQyxJQUFJLGFBQWEsdUJBQXVCLElBQUksTUFBTSxTQUFTLFFBQVE7R0FDbkUsSUFBSSxjQUFjLFdBQVcsSUFBSSxTQUFTLFFBQVEsR0FDaEQscUJBQXFCO0lBQ25CLGlCQUFpQixNQUFNO0lBQ3ZCLGNBQWM7R0FDaEI7UUFDSyxJQUFJLHVCQUF1QixJQUFJLFNBQVMsUUFBUSxHQUdyRCxxQkFBcUI7SUFDbkIsaUJBQWlCO0lBQ2pCLGNBQWMsTUFBTTtHQUN0QjtFQUVKLE9BQU8sSUFBSSw4QkFBOEI7R0FFdkMsSUFBSSxVQUFVLHVCQUF1QixJQUFJLE1BQU0sU0FBUyxRQUFRO0dBQ2hFLElBQUksU0FDRixRQUFRLElBQUksU0FBUyxRQUFRO1FBQ3hCO0lBQ0wsMEJBQVUsSUFBSSxJQUFJLENBQUMsU0FBUyxRQUFRLENBQUM7SUFDckMsdUJBQXVCLElBQUksTUFBTSxTQUFTLFVBQVUsT0FBTztHQUM3RDtHQUNBLHFCQUFxQjtJQUNuQixpQkFBaUIsTUFBTTtJQUN2QixjQUFjO0dBQ2hCO0VBQ0Y7RUFDQSxZQUFZQSxXQUFTLENBQUMsR0FBRyxVQUFVO0dBQ2pDO0dBQ0E7R0FDQSxlQUFlO0dBQ2Y7R0FDQSxhQUFhO0dBQ2IsWUFBWTtHQUNaLGNBQWM7R0FDZCx1QkFBdUIsdUJBQXVCLFVBQVUsU0FBUyxXQUFXLE1BQU0sT0FBTztHQUN6RjtHQUNBO0VBQ0YsQ0FBQyxHQUFHO0dBQ0Y7R0FDQSxXQUFXLGNBQWM7RUFDM0IsQ0FBQztFQUVELGdCQUFnQixPQUFPO0VBQ3ZCLDRCQUE0QjtFQUM1QiwrQkFBK0I7RUFDL0IsOEJBQThCO0VBQzlCLHlCQUF5QjtFQUN6QiwwQkFBMEIsQ0FBQztDQUM3QjtDQUdBLGVBQWUsU0FBUyxJQUFJLE1BQU07RUFDaEMsSUFBSSxPQUFPLE9BQU8sVUFBVTtHQUMxQixLQUFLLFFBQVEsR0FBRyxFQUFFO0dBQ2xCO0VBQ0Y7RUFDQSxJQUFJLGlCQUFpQixZQUFZLE1BQU0sVUFBVSxNQUFNLFNBQVMsVUFBVSxPQUFPLG9CQUFvQixJQUFJLE9BQU8sc0JBQXNCLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxhQUFhLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxRQUFRO0VBQ3JOLElBQUksRUFDRixNQUNBLFlBQ0EsVUFDRSx5QkFBeUIsT0FBTyx3QkFBd0IsT0FBTyxnQkFBZ0IsSUFBSTtFQUN2RixJQUFJLGtCQUFrQixNQUFNO0VBQzVCLElBQUksZUFBZSxlQUFlLE1BQU0sVUFBVSxNQUFNLFFBQVEsS0FBSyxLQUFLO0VBTTFFLGVBQWVBLFdBQVMsQ0FBQyxHQUFHLGNBQWMsS0FBSyxRQUFRLGVBQWUsWUFBWSxDQUFDO0VBQ25GLElBQUksY0FBYyxRQUFRLEtBQUssV0FBVyxPQUFPLEtBQUssVUFBVSxLQUFBO0VBQ2hFLElBQUksZ0JBQWdCLE9BQU87RUFDM0IsSUFBSSxnQkFBZ0IsTUFDbEIsZ0JBQWdCLE9BQU87T0FDbEIsSUFBSSxnQkFBZ0I7T0FBYyxJQUFJLGNBQWMsUUFBUSxpQkFBaUIsV0FBVyxVQUFVLEtBQUssV0FBVyxlQUFlLE1BQU0sU0FBUyxXQUFXLE1BQU0sU0FBUyxRQUsvSyxnQkFBZ0IsT0FBTztFQUV6QixJQUFJLHFCQUFxQixRQUFRLHdCQUF3QixPQUFPLEtBQUssdUJBQXVCLE9BQU8sS0FBQTtFQUNuRyxJQUFJLGFBQWEsUUFBUSxLQUFLLGVBQWU7RUFDN0MsSUFBSSxhQUFhLHNCQUFzQjtHQUNyQztHQUNBO0dBQ0E7RUFDRixDQUFDO0VBQ0QsSUFBSSxZQUFZO0dBRWQsY0FBYyxZQUFZO0lBQ3hCLE9BQU87SUFDUCxVQUFVO0lBQ1YsVUFBVTtLQUNSLGNBQWMsWUFBWTtNQUN4QixPQUFPO01BQ1AsU0FBUyxLQUFBO01BQ1QsT0FBTyxLQUFBO01BQ1AsVUFBVTtLQUNaLENBQUM7S0FFRCxTQUFTLElBQUksSUFBSTtJQUNuQjtJQUNBLFFBQVE7S0FDTixJQUFJLFdBQVcsSUFBSSxJQUFJLE1BQU0sUUFBUTtLQUNyQyxTQUFTLElBQUksWUFBWSxZQUFZO0tBQ3JDLFlBQVksRUFDVixTQUNGLENBQUM7SUFDSDtHQUNGLENBQUM7R0FDRDtFQUNGO0VBQ0EsT0FBTyxNQUFNLGdCQUFnQixlQUFlLGNBQWM7R0FDeEQ7R0FHQSxjQUFjO0dBQ2Q7R0FDQSxTQUFTLFFBQVEsS0FBSztHQUN0QixzQkFBc0IsUUFBUSxLQUFLO0dBQ25DO0VBQ0YsQ0FBQztDQUNIO0NBSUEsU0FBUyxhQUFhO0VBQ3BCLHFCQUFxQjtFQUNyQixZQUFZLEVBQ1YsY0FBYyxVQUNoQixDQUFDO0VBR0QsSUFBSSxNQUFNLFdBQVcsVUFBVSxjQUM3QjtFQUtGLElBQUksTUFBTSxXQUFXLFVBQVUsUUFBUTtHQUNyQyxnQkFBZ0IsTUFBTSxlQUFlLE1BQU0sVUFBVSxFQUNuRCxnQ0FBZ0MsS0FDbEMsQ0FBQztHQUNEO0VBQ0Y7RUFJQSxnQkFBZ0IsaUJBQWlCLE1BQU0sZUFBZSxNQUFNLFdBQVcsVUFBVTtHQUMvRSxvQkFBb0IsTUFBTTtHQUUxQixzQkFBc0IsaUNBQWlDO0VBQ3pELENBQUM7Q0FDSDtDQUlBLGVBQWUsZ0JBQWdCLGVBQWUsVUFBVSxNQUFNO0VBSTVELCtCQUErQiw0QkFBNEIsTUFBTTtFQUNqRSw4QkFBOEI7RUFDOUIsZ0JBQWdCO0VBQ2hCLCtCQUErQixRQUFRLEtBQUssb0NBQW9DO0VBR2hGLG1CQUFtQixNQUFNLFVBQVUsTUFBTSxPQUFPO0VBQ2hELDZCQUE2QixRQUFRLEtBQUssd0JBQXdCO0VBQ2xFLGdDQUFnQyxRQUFRLEtBQUssMEJBQTBCO0VBQ3ZFLElBQUksY0FBYyxzQkFBc0I7RUFDeEMsSUFBSSxvQkFBb0IsUUFBUSxLQUFLO0VBQ3JDLElBQUksVUFBVSxRQUFRLFFBQVEsS0FBSyxvQkFBb0IsTUFBTSxXQUFXLE1BQU0sUUFBUSxTQUFTLEtBQUssQ0FBQyxzQkFFckcsTUFBTSxVQUFVLFlBQVksYUFBYSxVQUFVLFFBQVE7RUFDM0QsSUFBSSxhQUFhLFFBQVEsS0FBSyxlQUFlO0VBTzdDLElBQUksV0FBVyxNQUFNLGVBQWUsQ0FBQywwQkFBMEIsaUJBQWlCLE1BQU0sVUFBVSxRQUFRLEtBQUssRUFBRSxRQUFRLEtBQUssY0FBYyxpQkFBaUIsS0FBSyxXQUFXLFVBQVUsSUFBSTtHQUN2TCxtQkFBbUIsVUFBVSxFQUMzQixRQUNGLEdBQUcsRUFDRCxVQUNGLENBQUM7R0FDRDtFQUNGO0VBQ0EsSUFBSSxXQUFXLGNBQWMsU0FBUyxhQUFhLFNBQVMsUUFBUTtFQUNwRSxJQUFJLFNBQVMsVUFBVSxTQUFTLFNBQzlCLFVBQVUsU0FBUztFQUdyQixJQUFJLENBQUMsU0FBUztHQUNaLElBQUksRUFDRixPQUNBLGlCQUNBLFVBQ0Usc0JBQXNCLFNBQVMsUUFBUTtHQUMzQyxtQkFBbUIsVUFBVTtJQUMzQixTQUFTO0lBQ1QsWUFBWSxDQUFDO0lBQ2IsUUFBUSxHQUNMLE1BQU0sS0FBSyxNQUNkO0dBQ0YsR0FBRyxFQUNELFVBQ0YsQ0FBQztHQUNEO0VBQ0Y7RUFFQSw4QkFBOEIsSUFBSSxnQkFBZ0I7RUFDbEQsSUFBSSxVQUFVLHdCQUF3QixLQUFLLFNBQVMsVUFBVSw0QkFBNEIsUUFBUSxRQUFRLEtBQUssVUFBVTtFQUN6SCxJQUFJO0VBQ0osSUFBSSxRQUFRLEtBQUssY0FLZixzQkFBc0IsQ0FBQyxvQkFBb0IsT0FBTyxDQUFDLENBQUMsTUFBTSxJQUFJO0dBQzVELE1BQU0sV0FBVztHQUNqQixPQUFPLEtBQUs7RUFDZCxDQUFDO09BQ0ksSUFBSSxRQUFRLEtBQUssY0FBYyxpQkFBaUIsS0FBSyxXQUFXLFVBQVUsR0FBRztHQUVsRixJQUFJLGVBQWUsTUFBTSxhQUFhLFNBQVMsVUFBVSxLQUFLLFlBQVksU0FBUyxTQUFTLFFBQVE7SUFDbEcsU0FBUyxLQUFLO0lBQ2Q7R0FDRixDQUFDO0dBQ0QsSUFBSSxhQUFhLGdCQUNmO0dBSUYsSUFBSSxhQUFhLHFCQUFxQjtJQUNwQyxJQUFJLENBQUMsU0FBUyxVQUFVLGFBQWE7SUFDckMsSUFBSSxjQUFjLE1BQU0sS0FBSyxxQkFBcUIsT0FBTyxLQUFLLEtBQUssT0FBTyxNQUFNLFdBQVcsS0FBSztLQUM5Riw4QkFBOEI7S0FDOUIsbUJBQW1CLFVBQVU7TUFDM0IsU0FBUyxhQUFhO01BQ3RCLFlBQVksQ0FBQztNQUNiLFFBQVEsR0FDTCxVQUFVLE9BQU8sTUFDcEI7S0FDRixDQUFDO0tBQ0Q7SUFDRjtHQUNGO0dBQ0EsVUFBVSxhQUFhLFdBQVc7R0FDbEMsc0JBQXNCLGFBQWE7R0FDbkMsb0JBQW9CLHFCQUFxQixVQUFVLEtBQUssVUFBVTtHQUNsRSxZQUFZO0dBRVosU0FBUyxTQUFTO0dBRWxCLFVBQVUsd0JBQXdCLEtBQUssU0FBUyxRQUFRLEtBQUssUUFBUSxNQUFNO0VBQzdFO0VBRUEsSUFBSSxFQUNGLGdCQUNBLFNBQVMsZ0JBQ1QsWUFDQSxXQUNFLE1BQU0sY0FBYyxTQUFTLFVBQVUsU0FBUyxTQUFTLFFBQVEsbUJBQW1CLFFBQVEsS0FBSyxZQUFZLFFBQVEsS0FBSyxtQkFBbUIsUUFBUSxLQUFLLFNBQVMsUUFBUSxLQUFLLHFCQUFxQixNQUFNLFdBQVcsbUJBQW1CO0VBQzdPLElBQUksZ0JBQ0Y7RUFLRiw4QkFBOEI7RUFDOUIsbUJBQW1CLFVBQVVBLFdBQVMsRUFDcEMsU0FBUyxrQkFBa0IsUUFDN0IsR0FBRyx1QkFBdUIsbUJBQW1CLEdBQUc7R0FDOUM7R0FDQTtFQUNGLENBQUMsQ0FBQztDQUNKO0NBR0EsZUFBZSxhQUFhLFNBQVMsVUFBVSxZQUFZLFNBQVMsWUFBWSxNQUFNO0VBQ3BGLElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU8sQ0FBQztFQUVWLHFCQUFxQjtFQUdyQixZQUFZLEVBQ1YsWUFGZSx3QkFBd0IsVUFBVSxVQUV4QyxFQUNYLEdBQUcsRUFDRCxXQUFXLEtBQUssY0FBYyxLQUNoQyxDQUFDO0VBQ0QsSUFBSSxZQUFZO0dBQ2QsSUFBSSxpQkFBaUIsTUFBTSxlQUFlLFNBQVMsU0FBUyxVQUFVLFFBQVEsTUFBTTtHQUNwRixJQUFJLGVBQWUsU0FBUyxXQUMxQixPQUFPLEVBQ0wsZ0JBQWdCLEtBQ2xCO1FBQ0ssSUFBSSxlQUFlLFNBQVMsU0FBUztJQUMxQyxJQUFJLGFBQWEsb0JBQW9CLGVBQWUsY0FBYyxDQUFDLENBQUMsTUFBTTtJQUMxRSxPQUFPO0tBQ0wsU0FBUyxlQUFlO0tBQ3hCLHFCQUFxQixDQUFDLFlBQVk7TUFDaEMsTUFBTSxXQUFXO01BQ2pCLE9BQU8sZUFBZTtLQUN4QixDQUFDO0lBQ0g7R0FDRixPQUFPLElBQUksQ0FBQyxlQUFlLFNBQVM7SUFDbEMsSUFBSSxFQUNGLGlCQUNBLE9BQ0EsVUFDRSxzQkFBc0IsU0FBUyxRQUFRO0lBQzNDLE9BQU87S0FDTCxTQUFTO0tBQ1QscUJBQXFCLENBQUMsTUFBTSxJQUFJO01BQzlCLE1BQU0sV0FBVztNQUNqQjtLQUNGLENBQUM7SUFDSDtHQUNGLE9BQ0UsVUFBVSxlQUFlO0VBRTdCO0VBRUEsSUFBSTtFQUNKLElBQUksY0FBYyxlQUFlLFNBQVMsUUFBUTtFQUNsRCxJQUFJLENBQUMsWUFBWSxNQUFNLFVBQVUsQ0FBQyxZQUFZLE1BQU0sTUFDbEQsU0FBUztHQUNQLE1BQU0sV0FBVztHQUNqQixPQUFPLHVCQUF1QixLQUFLO0lBQ2pDLFFBQVEsUUFBUTtJQUNoQixVQUFVLFNBQVM7SUFDbkIsU0FBUyxZQUFZLE1BQU07R0FDN0IsQ0FBQztFQUNIO09BQ0s7R0FFTCxVQUFTLE1BRFcsaUJBQWlCLFVBQVUsT0FBTyxTQUFTLENBQUMsV0FBVyxHQUFHLFNBQVMsSUFBSSxFQUFBLENBQzFFLFlBQVksTUFBTTtHQUNuQyxJQUFJLFFBQVEsT0FBTyxTQUNqQixPQUFPLEVBQ0wsZ0JBQWdCLEtBQ2xCO0VBRUo7RUFDQSxJQUFJLGlCQUFpQixNQUFNLEdBQUc7R0FDNUIsSUFBSTtHQUNKLElBQUksUUFBUSxLQUFLLFdBQVcsTUFDMUIsVUFBVSxLQUFLO1FBTWYsVUFEZSwwQkFBMEIsT0FBTyxTQUFTLFFBQVEsSUFBSSxVQUFVLEdBQUcsSUFBSSxJQUFJLFFBQVEsR0FBRyxHQUFHLFVBQVUsS0FBSyxPQUN0RyxNQUFNLE1BQU0sU0FBUyxXQUFXLE1BQU0sU0FBUztHQUVsRSxNQUFNLHdCQUF3QixTQUFTLFFBQVEsTUFBTTtJQUNuRDtJQUNBO0dBQ0YsQ0FBQztHQUNELE9BQU8sRUFDTCxnQkFBZ0IsS0FDbEI7RUFDRjtFQUNBLElBQUksaUJBQWlCLE1BQU0sR0FDekIsTUFBTSx1QkFBdUIsS0FBSyxFQUNoQyxNQUFNLGVBQ1IsQ0FBQztFQUVILElBQUksY0FBYyxNQUFNLEdBQUc7R0FHekIsSUFBSSxnQkFBZ0Isb0JBQW9CLFNBQVMsWUFBWSxNQUFNLEVBQUU7R0FNckUsS0FBSyxRQUFRLEtBQUssYUFBYSxNQUM3QixnQkFBZ0IsT0FBTztHQUV6QixPQUFPO0lBQ0w7SUFDQSxxQkFBcUIsQ0FBQyxjQUFjLE1BQU0sSUFBSSxNQUFNO0dBQ3REO0VBQ0Y7RUFDQSxPQUFPO0dBQ0w7R0FDQSxxQkFBcUIsQ0FBQyxZQUFZLE1BQU0sSUFBSSxNQUFNO0VBQ3BEO0NBQ0Y7Q0FHQSxlQUFlLGNBQWMsU0FBUyxVQUFVLFNBQVMsWUFBWSxvQkFBb0IsWUFBWSxtQkFBbUIsU0FBUyxrQkFBa0IsV0FBVyxxQkFBcUI7RUFFakwsSUFBSSxvQkFBb0Isc0JBQXNCLHFCQUFxQixVQUFVLFVBQVU7RUFHdkYsSUFBSSxtQkFBbUIsY0FBYyxxQkFBcUIsNEJBQTRCLGlCQUFpQjtFQU92RyxJQUFJLDhCQUE4QixDQUFDLGdDQUFnQyxDQUFDLE9BQU8sdUJBQXVCLENBQUM7RUFNbkcsSUFBSSxZQUFZO0dBQ2QsSUFBSSw2QkFBNkI7SUFDL0IsSUFBSSxhQUFhLHFCQUFxQixtQkFBbUI7SUFDekQsWUFBWUEsV0FBUyxFQUNuQixZQUFZLGtCQUNkLEdBQUcsZUFBZSxLQUFBLElBQVksRUFDNUIsV0FDRixJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQ1AsVUFDRixDQUFDO0dBQ0g7R0FDQSxJQUFJLGlCQUFpQixNQUFNLGVBQWUsU0FBUyxTQUFTLFVBQVUsUUFBUSxNQUFNO0dBQ3BGLElBQUksZUFBZSxTQUFTLFdBQzFCLE9BQU8sRUFDTCxnQkFBZ0IsS0FDbEI7UUFDSyxJQUFJLGVBQWUsU0FBUyxTQUFTO0lBQzFDLElBQUksYUFBYSxvQkFBb0IsZUFBZSxjQUFjLENBQUMsQ0FBQyxNQUFNO0lBQzFFLE9BQU87S0FDTCxTQUFTLGVBQWU7S0FDeEIsWUFBWSxDQUFDO0tBQ2IsUUFBUSxHQUNMLGFBQWEsZUFBZSxNQUMvQjtJQUNGO0dBQ0YsT0FBTyxJQUFJLENBQUMsZUFBZSxTQUFTO0lBQ2xDLElBQUksRUFDRixPQUNBLGlCQUNBLFVBQ0Usc0JBQXNCLFNBQVMsUUFBUTtJQUMzQyxPQUFPO0tBQ0wsU0FBUztLQUNULFlBQVksQ0FBQztLQUNiLFFBQVEsR0FDTCxNQUFNLEtBQUssTUFDZDtJQUNGO0dBQ0YsT0FDRSxVQUFVLGVBQWU7RUFFN0I7RUFDQSxJQUFJLGNBQWMsc0JBQXNCO0VBQ3hDLElBQUksQ0FBQyxlQUFlLHdCQUF3QixpQkFBaUIsS0FBSyxTQUFTLE9BQU8sU0FBUyxrQkFBa0IsVUFBVSxPQUFPLHVCQUF1QixxQkFBcUIsTUFBTSxPQUFPLGdDQUFnQyx3QkFBd0IseUJBQXlCLHVCQUF1QixpQkFBaUIsa0JBQWtCLGtCQUFrQixhQUFhLFVBQVUsbUJBQW1CO0VBSTlYLHVCQUFzQixZQUFXLEVBQUUsV0FBVyxRQUFRLE1BQUssTUFBSyxFQUFFLE1BQU0sT0FBTyxPQUFPLE1BQU0saUJBQWlCLGNBQWMsTUFBSyxNQUFLLEVBQUUsTUFBTSxPQUFPLE9BQU8sQ0FBQztFQUM1SiwwQkFBMEIsRUFBRTtFQUU1QixJQUFJLGNBQWMsV0FBVyxLQUFLLHFCQUFxQixXQUFXLEdBQUc7R0FDbkUsSUFBSSxrQkFBa0IsdUJBQXVCO0dBQzdDLG1CQUFtQixVQUFVQSxXQUFTO0lBQ3BDO0lBQ0EsWUFBWSxDQUFDO0lBRWIsUUFBUSx1QkFBdUIsY0FBYyxvQkFBb0IsRUFBRSxJQUFJLEdBQ3BFLG9CQUFvQixLQUFLLG9CQUFvQixFQUFFLENBQUMsTUFDbkQsSUFBSTtHQUNOLEdBQUcsdUJBQXVCLG1CQUFtQixHQUFHLGtCQUFrQixFQUNoRSxVQUFVLElBQUksSUFBSSxNQUFNLFFBQVEsRUFDbEMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUNQLFVBQ0YsQ0FBQztHQUNELE9BQU8sRUFDTCxnQkFBZ0IsS0FDbEI7RUFDRjtFQUNBLElBQUksNkJBQTZCO0dBQy9CLElBQUksVUFBVSxDQUFDO0dBQ2YsSUFBSSxDQUFDLFlBQVk7SUFFZixRQUFRLGFBQWE7SUFDckIsSUFBSSxhQUFhLHFCQUFxQixtQkFBbUI7SUFDekQsSUFBSSxlQUFlLEtBQUEsR0FDakIsUUFBUSxhQUFhO0dBRXpCO0dBQ0EsSUFBSSxxQkFBcUIsU0FBUyxHQUNoQyxRQUFRLFdBQVcsK0JBQStCLG9CQUFvQjtHQUV4RSxZQUFZLFNBQVMsRUFDbkIsVUFDRixDQUFDO0VBQ0g7RUFDQSxxQkFBcUIsU0FBUSxPQUFNO0dBQ2pDLGFBQWEsR0FBRyxHQUFHO0dBQ25CLElBQUksR0FBRyxZQUlMLGlCQUFpQixJQUFJLEdBQUcsS0FBSyxHQUFHLFVBQVU7RUFFOUMsQ0FBQztFQUVELElBQUksdUNBQXVDLHFCQUFxQixTQUFRLE1BQUssYUFBYSxFQUFFLEdBQUcsQ0FBQztFQUNoRyxJQUFJLDZCQUNGLDRCQUE0QixPQUFPLGlCQUFpQixTQUFTLDhCQUE4QjtFQUU3RixJQUFJLEVBQ0YsZUFDQSxtQkFDRSxNQUFNLCtCQUErQixPQUFPLFNBQVMsZUFBZSxzQkFBc0IsT0FBTztFQUNyRyxJQUFJLFFBQVEsT0FBTyxTQUNqQixPQUFPLEVBQ0wsZ0JBQWdCLEtBQ2xCO0VBS0YsSUFBSSw2QkFDRiw0QkFBNEIsT0FBTyxvQkFBb0IsU0FBUyw4QkFBOEI7RUFFaEcscUJBQXFCLFNBQVEsT0FBTSxpQkFBaUIsT0FBTyxHQUFHLEdBQUcsQ0FBQztFQUVsRSxJQUFJLFdBQVcsYUFBYSxhQUFhO0VBQ3pDLElBQUksVUFBVTtHQUNaLE1BQU0sd0JBQXdCLFNBQVMsU0FBUyxRQUFRLE1BQU0sRUFDNUQsUUFDRixDQUFDO0dBQ0QsT0FBTyxFQUNMLGdCQUFnQixLQUNsQjtFQUNGO0VBQ0EsV0FBVyxhQUFhLGNBQWM7RUFDdEMsSUFBSSxVQUFVO0dBSVosaUJBQWlCLElBQUksU0FBUyxHQUFHO0dBQ2pDLE1BQU0sd0JBQXdCLFNBQVMsU0FBUyxRQUFRLE1BQU0sRUFDNUQsUUFDRixDQUFDO0dBQ0QsT0FBTyxFQUNMLGdCQUFnQixLQUNsQjtFQUNGO0VBRUEsSUFBSSxFQUNGLFlBQ0EsV0FDRSxrQkFBa0IsT0FBTyxTQUFTLGVBQWUscUJBQXFCLHNCQUFzQixnQkFBZ0IsZUFBZTtFQUUvSCxnQkFBZ0IsU0FBUyxjQUFjLFlBQVk7R0FDakQsYUFBYSxXQUFVLFlBQVc7SUFJaEMsSUFBSSxXQUFXLGFBQWEsTUFDMUIsZ0JBQWdCLE9BQU8sT0FBTztHQUVsQyxDQUFDO0VBQ0gsQ0FBQztFQUVELElBQUksT0FBTyx1QkFBdUIsb0JBQW9CLE1BQU0sUUFDMUQsU0FBU0EsV0FBUyxDQUFDLEdBQUcsTUFBTSxRQUFRLE1BQU07RUFFNUMsSUFBSSxrQkFBa0IsdUJBQXVCO0VBQzdDLElBQUkscUJBQXFCLHFCQUFxQix1QkFBdUI7RUFDckUsSUFBSSx1QkFBdUIsbUJBQW1CLHNCQUFzQixxQkFBcUIsU0FBUztFQUNsRyxPQUFPQSxXQUFTO0dBQ2Q7R0FDQTtHQUNBO0VBQ0YsR0FBRyx1QkFBdUIsRUFDeEIsVUFBVSxJQUFJLElBQUksTUFBTSxRQUFRLEVBQ2xDLElBQUksQ0FBQyxDQUFDO0NBQ1I7Q0FDQSxTQUFTLHFCQUFxQixxQkFBcUI7RUFDakQsSUFBSSx1QkFBdUIsQ0FBQyxjQUFjLG9CQUFvQixFQUFFLEdBSTlELE9BQU8sR0FDSixvQkFBb0IsS0FBSyxvQkFBb0IsRUFBRSxDQUFDLEtBQ25EO09BQ0ssSUFBSSxNQUFNLFlBQVk7R0FDM0IsSUFBSSxPQUFPLEtBQUssTUFBTSxVQUFVLENBQUMsQ0FBQyxXQUFXLEdBQzNDLE9BQU87UUFFUCxPQUFPLE1BQU07RUFFakI7Q0FDRjtDQUNBLFNBQVMsK0JBQStCLHNCQUFzQjtFQUM1RCxxQkFBcUIsU0FBUSxPQUFNO0dBQ2pDLElBQUksVUFBVSxNQUFNLFNBQVMsSUFBSSxHQUFHLEdBQUc7R0FDdkMsSUFBSSxzQkFBc0Isa0JBQWtCLEtBQUEsR0FBVyxVQUFVLFFBQVEsT0FBTyxLQUFBLENBQVM7R0FDekYsTUFBTSxTQUFTLElBQUksR0FBRyxLQUFLLG1CQUFtQjtFQUNoRCxDQUFDO0VBQ0QsT0FBTyxJQUFJLElBQUksTUFBTSxRQUFRO0NBQy9CO0NBRUEsU0FBUyxNQUFNLEtBQUssU0FBUyxNQUFNLE1BQU07RUFDdkMsSUFBSSxVQUNGLE1BQU0sSUFBSSxNQUFNLGtNQUE0TTtFQUU5TixhQUFhLEdBQUc7RUFDaEIsSUFBSSxhQUFhLFFBQVEsS0FBSyxlQUFlO0VBQzdDLElBQUksY0FBYyxzQkFBc0I7RUFDeEMsSUFBSSxpQkFBaUIsWUFBWSxNQUFNLFVBQVUsTUFBTSxTQUFTLFVBQVUsT0FBTyxvQkFBb0IsTUFBTSxPQUFPLHNCQUFzQixTQUFTLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxRQUFRO0VBQ3RMLElBQUksVUFBVSxZQUFZLGFBQWEsZ0JBQWdCLFFBQVE7RUFDL0QsSUFBSSxXQUFXLGNBQWMsU0FBUyxhQUFhLGNBQWM7RUFDakUsSUFBSSxTQUFTLFVBQVUsU0FBUyxTQUM5QixVQUFVLFNBQVM7RUFFckIsSUFBSSxDQUFDLFNBQVM7R0FDWixnQkFBZ0IsS0FBSyxTQUFTLHVCQUF1QixLQUFLLEVBQ3hELFVBQVUsZUFDWixDQUFDLEdBQUcsRUFDRixVQUNGLENBQUM7R0FDRDtFQUNGO0VBQ0EsSUFBSSxFQUNGLE1BQ0EsWUFDQSxVQUNFLHlCQUF5QixPQUFPLHdCQUF3QixNQUFNLGdCQUFnQixJQUFJO0VBQ3RGLElBQUksT0FBTztHQUNULGdCQUFnQixLQUFLLFNBQVMsT0FBTyxFQUNuQyxVQUNGLENBQUM7R0FDRDtFQUNGO0VBQ0EsSUFBSSxRQUFRLGVBQWUsU0FBUyxJQUFJO0VBQ3hDLElBQUksc0JBQXNCLFFBQVEsS0FBSyx3QkFBd0I7RUFDL0QsSUFBSSxjQUFjLGlCQUFpQixXQUFXLFVBQVUsR0FBRztHQUN6RCxvQkFBb0IsS0FBSyxTQUFTLE1BQU0sT0FBTyxTQUFTLFNBQVMsUUFBUSxXQUFXLG9CQUFvQixVQUFVO0dBQ2xIO0VBQ0Y7RUFHQSxpQkFBaUIsSUFBSSxLQUFLO0dBQ3hCO0dBQ0E7RUFDRixDQUFDO0VBQ0Qsb0JBQW9CLEtBQUssU0FBUyxNQUFNLE9BQU8sU0FBUyxTQUFTLFFBQVEsV0FBVyxvQkFBb0IsVUFBVTtDQUNwSDtDQUdBLGVBQWUsb0JBQW9CLEtBQUssU0FBUyxNQUFNLE9BQU8sZ0JBQWdCLFlBQVksV0FBVyxvQkFBb0IsWUFBWTtFQUNuSSxxQkFBcUI7RUFDckIsaUJBQWlCLE9BQU8sR0FBRztFQUMzQixTQUFTLHdCQUF3QixHQUFHO0dBQ2xDLElBQUksQ0FBQyxFQUFFLE1BQU0sVUFBVSxDQUFDLEVBQUUsTUFBTSxNQUFNO0lBTXBDLGdCQUFnQixLQUFLLFNBTFQsdUJBQXVCLEtBQUs7S0FDdEMsUUFBUSxXQUFXO0tBQ25CLFVBQVU7S0FDRDtJQUNYLENBQ2tDLEdBQUcsRUFDbkMsVUFDRixDQUFDO0lBQ0QsT0FBTztHQUNUO0dBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSSxDQUFDLGNBQWMsd0JBQXdCLEtBQUssR0FDOUM7RUFJRixtQkFBbUIsS0FBSyxxQkFBcUIsWUFEdkIsTUFBTSxTQUFTLElBQUksR0FDOEIsQ0FBQyxHQUFHLEVBQ3pFLFVBQ0YsQ0FBQztFQUNELElBQUksa0JBQWtCLElBQUksZ0JBQWdCO0VBQzFDLElBQUksZUFBZSx3QkFBd0IsS0FBSyxTQUFTLE1BQU0sZ0JBQWdCLFFBQVEsVUFBVTtFQUNqRyxJQUFJLFlBQVk7R0FDZCxJQUFJLGlCQUFpQixNQUFNLGVBQWUsZ0JBQWdCLElBQUksSUFBSSxhQUFhLEdBQUcsQ0FBQyxDQUFDLFVBQVUsYUFBYSxRQUFRLEdBQUc7R0FDdEgsSUFBSSxlQUFlLFNBQVMsV0FDMUI7UUFDSyxJQUFJLGVBQWUsU0FBUyxTQUFTO0lBQzFDLGdCQUFnQixLQUFLLFNBQVMsZUFBZSxPQUFPLEVBQ2xELFVBQ0YsQ0FBQztJQUNEO0dBQ0YsT0FBTyxJQUFJLENBQUMsZUFBZSxTQUFTO0lBQ2xDLGdCQUFnQixLQUFLLFNBQVMsdUJBQXVCLEtBQUssRUFDeEQsVUFBVSxLQUNaLENBQUMsR0FBRyxFQUNGLFVBQ0YsQ0FBQztJQUNEO0dBQ0YsT0FBTztJQUNMLGlCQUFpQixlQUFlO0lBQ2hDLFFBQVEsZUFBZSxnQkFBZ0IsSUFBSTtJQUMzQyxJQUFJLHdCQUF3QixLQUFLLEdBQy9CO0dBRUo7RUFDRjtFQUVBLGlCQUFpQixJQUFJLEtBQUssZUFBZTtFQUN6QyxJQUFJLG9CQUFvQjtFQUV4QixJQUFJLGdCQUFlLE1BRE8saUJBQWlCLFVBQVUsT0FBTyxjQUFjLENBQUMsS0FBSyxHQUFHLGdCQUFnQixHQUFHLEVBQUEsQ0FDckUsTUFBTSxNQUFNO0VBQzdDLElBQUksYUFBYSxPQUFPLFNBQVM7R0FHL0IsSUFBSSxpQkFBaUIsSUFBSSxHQUFHLE1BQU0saUJBQ2hDLGlCQUFpQixPQUFPLEdBQUc7R0FFN0I7RUFDRjtFQUlBLElBQUksT0FBTyxxQkFBcUIsZ0JBQWdCLElBQUksR0FBRyxHQUNqRDtPQUFBLGlCQUFpQixZQUFZLEtBQUssY0FBYyxZQUFZLEdBQUc7SUFDakUsbUJBQW1CLEtBQUssZUFBZSxLQUFBLENBQVMsQ0FBQztJQUNqRDtHQUNGO1NBRUs7R0FDTCxJQUFJLGlCQUFpQixZQUFZLEdBQUc7SUFDbEMsaUJBQWlCLE9BQU8sR0FBRztJQUMzQixJQUFJLDBCQUEwQixtQkFBbUI7S0FLL0MsbUJBQW1CLEtBQUssZUFBZSxLQUFBLENBQVMsQ0FBQztLQUNqRDtJQUNGLE9BQU87S0FDTCxpQkFBaUIsSUFBSSxHQUFHO0tBQ3hCLG1CQUFtQixLQUFLLGtCQUFrQixVQUFVLENBQUM7S0FDckQsT0FBTyx3QkFBd0IsY0FBYyxjQUFjLE9BQU87TUFDaEUsbUJBQW1CO01BQ25CO0tBQ0YsQ0FBQztJQUNIO0dBQ0Y7R0FFQSxJQUFJLGNBQWMsWUFBWSxHQUFHO0lBQy9CLGdCQUFnQixLQUFLLFNBQVMsYUFBYSxLQUFLO0lBQ2hEO0dBQ0Y7RUFDRjtFQUNBLElBQUksaUJBQWlCLFlBQVksR0FDL0IsTUFBTSx1QkFBdUIsS0FBSyxFQUNoQyxNQUFNLGVBQ1IsQ0FBQztFQUlILElBQUksZUFBZSxNQUFNLFdBQVcsWUFBWSxNQUFNO0VBQ3RELElBQUksc0JBQXNCLHdCQUF3QixLQUFLLFNBQVMsY0FBYyxnQkFBZ0IsTUFBTTtFQUNwRyxJQUFJLGNBQWMsc0JBQXNCO0VBQ3hDLElBQUksVUFBVSxNQUFNLFdBQVcsVUFBVSxTQUFTLFlBQVksYUFBYSxNQUFNLFdBQVcsVUFBVSxRQUFRLElBQUksTUFBTTtFQUN4SCxVQUFVLFNBQVMsOENBQThDO0VBQ2pFLElBQUksU0FBUyxFQUFFO0VBQ2YsZUFBZSxJQUFJLEtBQUssTUFBTTtFQUM5QixJQUFJLGNBQWMsa0JBQWtCLFlBQVksYUFBYSxJQUFJO0VBQ2pFLE1BQU0sU0FBUyxJQUFJLEtBQUssV0FBVztFQUNuQyxJQUFJLENBQUMsZUFBZSx3QkFBd0IsaUJBQWlCLEtBQUssU0FBUyxPQUFPLFNBQVMsWUFBWSxjQUFjLE9BQU8sT0FBTyxnQ0FBZ0Msd0JBQXdCLHlCQUF5Qix1QkFBdUIsaUJBQWlCLGtCQUFrQixrQkFBa0IsYUFBYSxVQUFVLENBQUMsTUFBTSxNQUFNLElBQUksWUFBWSxDQUFDO0VBSXJWLHFCQUFxQixRQUFPLE9BQU0sR0FBRyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFNBQVEsT0FBTTtHQUM5RCxJQUFJLFdBQVcsR0FBRztHQUNsQixJQUFJLGtCQUFrQixNQUFNLFNBQVMsSUFBSSxRQUFRO0dBQ2pELElBQUksc0JBQXNCLGtCQUFrQixLQUFBLEdBQVcsa0JBQWtCLGdCQUFnQixPQUFPLEtBQUEsQ0FBUztHQUN6RyxNQUFNLFNBQVMsSUFBSSxVQUFVLG1CQUFtQjtHQUNoRCxhQUFhLFFBQVE7R0FDckIsSUFBSSxHQUFHLFlBQ0wsaUJBQWlCLElBQUksVUFBVSxHQUFHLFVBQVU7RUFFaEQsQ0FBQztFQUNELFlBQVksRUFDVixVQUFVLElBQUksSUFBSSxNQUFNLFFBQVEsRUFDbEMsQ0FBQztFQUNELElBQUksdUNBQXVDLHFCQUFxQixTQUFRLE9BQU0sYUFBYSxHQUFHLEdBQUcsQ0FBQztFQUNsRyxnQkFBZ0IsT0FBTyxpQkFBaUIsU0FBUyw4QkFBOEI7RUFDL0UsSUFBSSxFQUNGLGVBQ0EsbUJBQ0UsTUFBTSwrQkFBK0IsT0FBTyxTQUFTLGVBQWUsc0JBQXNCLG1CQUFtQjtFQUNqSCxJQUFJLGdCQUFnQixPQUFPLFNBQ3pCO0VBRUYsZ0JBQWdCLE9BQU8sb0JBQW9CLFNBQVMsOEJBQThCO0VBQ2xGLGVBQWUsT0FBTyxHQUFHO0VBQ3pCLGlCQUFpQixPQUFPLEdBQUc7RUFDM0IscUJBQXFCLFNBQVEsTUFBSyxpQkFBaUIsT0FBTyxFQUFFLEdBQUcsQ0FBQztFQUNoRSxJQUFJLFdBQVcsYUFBYSxhQUFhO0VBQ3pDLElBQUksVUFDRixPQUFPLHdCQUF3QixxQkFBcUIsU0FBUyxRQUFRLE9BQU8sRUFDMUUsbUJBQ0YsQ0FBQztFQUVILFdBQVcsYUFBYSxjQUFjO0VBQ3RDLElBQUksVUFBVTtHQUlaLGlCQUFpQixJQUFJLFNBQVMsR0FBRztHQUNqQyxPQUFPLHdCQUF3QixxQkFBcUIsU0FBUyxRQUFRLE9BQU8sRUFDMUUsbUJBQ0YsQ0FBQztFQUNIO0VBRUEsSUFBSSxFQUNGLFlBQ0EsV0FDRSxrQkFBa0IsT0FBTyxTQUFTLGVBQWUsS0FBQSxHQUFXLHNCQUFzQixnQkFBZ0IsZUFBZTtFQUdySCxJQUFJLE1BQU0sU0FBUyxJQUFJLEdBQUcsR0FBRztHQUMzQixJQUFJLGNBQWMsZUFBZSxhQUFhLElBQUk7R0FDbEQsTUFBTSxTQUFTLElBQUksS0FBSyxXQUFXO0VBQ3JDO0VBQ0EscUJBQXFCLE1BQU07RUFJM0IsSUFBSSxNQUFNLFdBQVcsVUFBVSxhQUFhLFNBQVMseUJBQXlCO0dBQzVFLFVBQVUsZUFBZSx5QkFBeUI7R0FDbEQsK0JBQStCLDRCQUE0QixNQUFNO0dBQ2pFLG1CQUFtQixNQUFNLFdBQVcsVUFBVTtJQUM1QztJQUNBO0lBQ0E7SUFDQSxVQUFVLElBQUksSUFBSSxNQUFNLFFBQVE7R0FDbEMsQ0FBQztFQUNILE9BQU87R0FJTCxZQUFZO0lBQ1Y7SUFDQSxZQUFZLGdCQUFnQixNQUFNLFlBQVksWUFBWSxTQUFTLE1BQU07SUFDekUsVUFBVSxJQUFJLElBQUksTUFBTSxRQUFRO0dBQ2xDLENBQUM7R0FDRCx5QkFBeUI7RUFDM0I7Q0FDRjtDQUVBLGVBQWUsb0JBQW9CLEtBQUssU0FBUyxNQUFNLE9BQU8sU0FBUyxZQUFZLFdBQVcsb0JBQW9CLFlBQVk7RUFDNUgsSUFBSSxrQkFBa0IsTUFBTSxTQUFTLElBQUksR0FBRztFQUM1QyxtQkFBbUIsS0FBSyxrQkFBa0IsWUFBWSxrQkFBa0IsZ0JBQWdCLE9BQU8sS0FBQSxDQUFTLEdBQUcsRUFDekcsVUFDRixDQUFDO0VBQ0QsSUFBSSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDMUMsSUFBSSxlQUFlLHdCQUF3QixLQUFLLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTTtFQUNyRixJQUFJLFlBQVk7R0FDZCxJQUFJLGlCQUFpQixNQUFNLGVBQWUsU0FBUyxJQUFJLElBQUksYUFBYSxHQUFHLENBQUMsQ0FBQyxVQUFVLGFBQWEsUUFBUSxHQUFHO0dBQy9HLElBQUksZUFBZSxTQUFTLFdBQzFCO1FBQ0ssSUFBSSxlQUFlLFNBQVMsU0FBUztJQUMxQyxnQkFBZ0IsS0FBSyxTQUFTLGVBQWUsT0FBTyxFQUNsRCxVQUNGLENBQUM7SUFDRDtHQUNGLE9BQU8sSUFBSSxDQUFDLGVBQWUsU0FBUztJQUNsQyxnQkFBZ0IsS0FBSyxTQUFTLHVCQUF1QixLQUFLLEVBQ3hELFVBQVUsS0FDWixDQUFDLEdBQUcsRUFDRixVQUNGLENBQUM7SUFDRDtHQUNGLE9BQU87SUFDTCxVQUFVLGVBQWU7SUFDekIsUUFBUSxlQUFlLFNBQVMsSUFBSTtHQUN0QztFQUNGO0VBRUEsaUJBQWlCLElBQUksS0FBSyxlQUFlO0VBQ3pDLElBQUksb0JBQW9CO0VBRXhCLElBQUksVUFBUyxNQURPLGlCQUFpQixVQUFVLE9BQU8sY0FBYyxDQUFDLEtBQUssR0FBRyxTQUFTLEdBQUcsRUFBQSxDQUNwRSxNQUFNLE1BQU07RUFLakMsSUFBSSxpQkFBaUIsTUFBTSxHQUN6QixTQUFVLE1BQU0sb0JBQW9CLFFBQVEsYUFBYSxRQUFRLElBQUksS0FBTTtFQUk3RSxJQUFJLGlCQUFpQixJQUFJLEdBQUcsTUFBTSxpQkFDaEMsaUJBQWlCLE9BQU8sR0FBRztFQUU3QixJQUFJLGFBQWEsT0FBTyxTQUN0QjtFQUlGLElBQUksZ0JBQWdCLElBQUksR0FBRyxHQUFHO0dBQzVCLG1CQUFtQixLQUFLLGVBQWUsS0FBQSxDQUFTLENBQUM7R0FDakQ7RUFDRjtFQUVBLElBQUksaUJBQWlCLE1BQU0sR0FBRztHQUM1QixJQUFJLDBCQUEwQixtQkFBbUI7SUFHL0MsbUJBQW1CLEtBQUssZUFBZSxLQUFBLENBQVMsQ0FBQztJQUNqRDtHQUNGLE9BQU87SUFDTCxpQkFBaUIsSUFBSSxHQUFHO0lBQ3hCLE1BQU0sd0JBQXdCLGNBQWMsUUFBUSxPQUFPLEVBQ3pELG1CQUNGLENBQUM7SUFDRDtHQUNGO0VBQ0Y7RUFFQSxJQUFJLGNBQWMsTUFBTSxHQUFHO0dBQ3pCLGdCQUFnQixLQUFLLFNBQVMsT0FBTyxLQUFLO0dBQzFDO0VBQ0Y7RUFDQSxVQUFVLENBQUMsaUJBQWlCLE1BQU0sR0FBRyxpQ0FBaUM7RUFFdEUsbUJBQW1CLEtBQUssZUFBZSxPQUFPLElBQUksQ0FBQztDQUNyRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FvQkEsZUFBZSx3QkFBd0IsU0FBUyxVQUFVLGNBQWMsUUFBUTtFQUM5RSxJQUFJLEVBQ0YsWUFDQSxtQkFDQSxvQkFDQSxZQUNFLFdBQVcsS0FBSyxJQUFJLENBQUMsSUFBSTtFQUM3QixJQUFJLFNBQVMsU0FBUyxRQUFRLElBQUksb0JBQW9CLEdBQ3BELHlCQUF5QjtFQUUzQixJQUFJLFdBQVcsU0FBUyxTQUFTLFFBQVEsSUFBSSxVQUFVO0VBQ3ZELFVBQVUsVUFBVSxxREFBcUQ7RUFDekUsV0FBVywwQkFBMEIsVUFBVSxJQUFJLElBQUksUUFBUSxHQUFHLEdBQUcsVUFBVSxLQUFLLE9BQU87RUFDM0YsSUFBSSxtQkFBbUIsZUFBZSxNQUFNLFVBQVUsVUFBVSxFQUM5RCxhQUFhLEtBQ2YsQ0FBQztFQUNELElBQUksV0FBVztHQUNiLElBQUksbUJBQW1CO0dBQ3ZCLElBQUksU0FBUyxTQUFTLFFBQVEsSUFBSSx5QkFBeUIsR0FFekQsbUJBQW1CO1FBQ2QsSUFBSUMscUJBQW1CLEtBQUssUUFBUSxHQUFHO0lBQzVDLE1BQU0sTUFBTSxLQUFLLFFBQVEsVUFBVSxRQUFRO0lBQzNDLG1CQUVBLElBQUksV0FBVyxhQUFhLFNBQVMsVUFFckMsY0FBYyxJQUFJLFVBQVUsUUFBUSxLQUFLO0dBQzNDO0dBQ0EsSUFBSSxrQkFBa0I7SUFDcEIsSUFBSSxTQUNGLGFBQWEsU0FBUyxRQUFRLFFBQVE7U0FFdEMsYUFBYSxTQUFTLE9BQU8sUUFBUTtJQUV2QztHQUNGO0VBQ0Y7RUFHQSw4QkFBOEI7RUFDOUIsSUFBSSx3QkFBd0IsWUFBWSxRQUFRLFNBQVMsU0FBUyxRQUFRLElBQUksaUJBQWlCLElBQUksT0FBTyxVQUFVLE9BQU87RUFHM0gsSUFBSSxFQUNGLFlBQ0EsWUFDQSxnQkFDRSxNQUFNO0VBQ1YsSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsY0FBYyxjQUFjLGFBQ25FLGFBQWEsNEJBQTRCLE1BQU0sVUFBVTtFQUszRCxJQUFJLG1CQUFtQixjQUFjO0VBQ3JDLElBQUksa0NBQWtDLElBQUksU0FBUyxTQUFTLE1BQU0sS0FBSyxvQkFBb0IsaUJBQWlCLGlCQUFpQixVQUFVLEdBQ3JJLE1BQU0sZ0JBQWdCLHVCQUF1QixrQkFBa0I7R0FDN0QsWUFBWUQsV0FBUyxDQUFDLEdBQUcsa0JBQWtCLEVBQ3pDLFlBQVksU0FDZCxDQUFDO0dBRUQsb0JBQW9CLHNCQUFzQjtHQUMxQyxzQkFBc0IsZUFBZSwrQkFBK0IsS0FBQTtFQUN0RSxDQUFDO09BS0QsTUFBTSxnQkFBZ0IsdUJBQXVCLGtCQUFrQjtHQUM3RCxvQkFGdUIscUJBQXFCLGtCQUFrQixVQUU3QztHQUVqQjtHQUVBLG9CQUFvQixzQkFBc0I7R0FDMUMsc0JBQXNCLGVBQWUsK0JBQStCLEtBQUE7RUFDdEUsQ0FBQztDQUVMO0NBR0EsZUFBZSxpQkFBaUIsTUFBTSxPQUFPLFNBQVMsZUFBZSxTQUFTLFlBQVk7RUFDeEYsSUFBSTtFQUNKLElBQUksY0FBYyxDQUFDO0VBQ25CLElBQUk7R0FDRixVQUFVLE1BQU0scUJBQXFCLGtCQUFrQixNQUFNLE9BQU8sU0FBUyxlQUFlLFNBQVMsWUFBWSxVQUFVLGtCQUFrQjtFQUMvSSxTQUFTLEdBQUc7R0FHVixjQUFjLFNBQVEsTUFBSztJQUN6QixZQUFZLEVBQUUsTUFBTSxNQUFNO0tBQ3hCLE1BQU0sV0FBVztLQUNqQixPQUFPO0lBQ1Q7R0FDRixDQUFDO0dBQ0QsT0FBTztFQUNUO0VBQ0EsS0FBSyxJQUFJLENBQUMsU0FBUyxXQUFXLE9BQU8sUUFBUSxPQUFPLEdBQ2xELElBQUksbUNBQW1DLE1BQU0sR0FBRztHQUM5QyxJQUFJLFdBQVcsT0FBTztHQUN0QixZQUFZLFdBQVc7SUFDckIsTUFBTSxXQUFXO0lBQ2pCLFVBQVUseUNBQXlDLFVBQVUsU0FBUyxTQUFTLFNBQVMsVUFBVSxPQUFPLG9CQUFvQjtHQUMvSDtFQUNGLE9BQ0UsWUFBWSxXQUFXLE1BQU0sc0NBQXNDLE1BQU07RUFHN0UsT0FBTztDQUNUO0NBQ0EsZUFBZSwrQkFBK0IsT0FBTyxTQUFTLGVBQWUsZ0JBQWdCLFNBQVM7RUFDcEcsSUFBSSxpQkFBaUIsTUFBTTtFQUUzQixJQUFJLHVCQUF1QixpQkFBaUIsVUFBVSxPQUFPLFNBQVMsZUFBZSxTQUFTLElBQUk7RUFDbEcsSUFBSSx3QkFBd0IsUUFBUSxJQUFJLGVBQWUsSUFBSSxPQUFNLE1BQUs7R0FDcEUsSUFBSSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsWUFBWTtJQUV4QyxJQUFJLFVBQVMsTUFETyxpQkFBaUIsVUFBVSxPQUFPLHdCQUF3QixLQUFLLFNBQVMsRUFBRSxNQUFNLEVBQUUsV0FBVyxNQUFNLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUEsQ0FDaEksRUFBRSxNQUFNLE1BQU07SUFFbkMsT0FBTyxHQUNKLEVBQUUsTUFBTSxPQUNYO0dBQ0YsT0FDRSxPQUFPLFFBQVEsUUFBUSxHQUNwQixFQUFFLE1BQU07SUFDUCxNQUFNLFdBQVc7SUFDakIsT0FBTyx1QkFBdUIsS0FBSyxFQUNqQyxVQUFVLEVBQUUsS0FDZCxDQUFDO0dBQ0gsRUFDRixDQUFDO0VBRUwsQ0FBQyxDQUFDO0VBQ0YsSUFBSSxnQkFBZ0IsTUFBTTtFQUMxQixJQUFJLGtCQUFrQixNQUFNLHNCQUFBLENBQXVCLFFBQVEsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDL0YsTUFBTSxRQUFRLElBQUksQ0FBQyxpQ0FBaUMsU0FBUyxlQUFlLFFBQVEsUUFBUSxnQkFBZ0IsTUFBTSxVQUFVLEdBQUcsOEJBQThCLFNBQVMsZ0JBQWdCLGNBQWMsQ0FBQyxDQUFDO0VBQ3RNLE9BQU87R0FDTDtHQUNBO0VBQ0Y7Q0FDRjtDQUNBLFNBQVMsdUJBQXVCO0VBRTlCLHlCQUF5QjtFQUd6Qix3QkFBd0IsS0FBSyxHQUFHLHNCQUFzQixDQUFDO0VBRXZELGlCQUFpQixTQUFTLEdBQUcsUUFBUTtHQUNuQyxJQUFJLGlCQUFpQixJQUFJLEdBQUcsR0FDMUIsc0JBQXNCLElBQUksR0FBRztHQUUvQixhQUFhLEdBQUc7RUFDbEIsQ0FBQztDQUNIO0NBQ0EsU0FBUyxtQkFBbUIsS0FBSyxTQUFTLE1BQU07RUFDOUMsSUFBSSxTQUFTLEtBQUssR0FDaEIsT0FBTyxDQUFDO0VBRVYsTUFBTSxTQUFTLElBQUksS0FBSyxPQUFPO0VBQy9CLFlBQVksRUFDVixVQUFVLElBQUksSUFBSSxNQUFNLFFBQVEsRUFDbEMsR0FBRyxFQUNELFlBQVksUUFBUSxLQUFLLGVBQWUsS0FDMUMsQ0FBQztDQUNIO0NBQ0EsU0FBUyxnQkFBZ0IsS0FBSyxTQUFTLE9BQU8sTUFBTTtFQUNsRCxJQUFJLFNBQVMsS0FBSyxHQUNoQixPQUFPLENBQUM7RUFFVixJQUFJLGdCQUFnQixvQkFBb0IsTUFBTSxTQUFTLE9BQU87RUFDOUQsY0FBYyxHQUFHO0VBQ2pCLFlBQVk7R0FDVixRQUFRLEdBQ0wsY0FBYyxNQUFNLEtBQUssTUFDNUI7R0FDQSxVQUFVLElBQUksSUFBSSxNQUFNLFFBQVE7RUFDbEMsR0FBRyxFQUNELFlBQVksUUFBUSxLQUFLLGVBQWUsS0FDMUMsQ0FBQztDQUNIO0NBQ0EsU0FBUyxXQUFXLEtBQUs7RUFDdkIsZUFBZSxJQUFJLE1BQU0sZUFBZSxJQUFJLEdBQUcsS0FBSyxLQUFLLENBQUM7RUFHMUQsSUFBSSxnQkFBZ0IsSUFBSSxHQUFHLEdBQ3pCLGdCQUFnQixPQUFPLEdBQUc7RUFFNUIsT0FBTyxNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQUs7Q0FDcEM7Q0FDQSxTQUFTLGNBQWMsS0FBSztFQUMxQixJQUFJLFVBQVUsTUFBTSxTQUFTLElBQUksR0FBRztFQUlwQyxJQUFJLGlCQUFpQixJQUFJLEdBQUcsS0FBSyxFQUFFLFdBQVcsUUFBUSxVQUFVLGFBQWEsZUFBZSxJQUFJLEdBQUcsSUFDakcsYUFBYSxHQUFHO0VBRWxCLGlCQUFpQixPQUFPLEdBQUc7RUFDM0IsZUFBZSxPQUFPLEdBQUc7RUFDekIsaUJBQWlCLE9BQU8sR0FBRztFQU8zQixJQUFJLE9BQU8sbUJBQ1QsZ0JBQWdCLE9BQU8sR0FBRztFQUU1QixzQkFBc0IsT0FBTyxHQUFHO0VBQ2hDLE1BQU0sU0FBUyxPQUFPLEdBQUc7Q0FDM0I7Q0FDQSxTQUFTLDRCQUE0QixLQUFLO0VBQ3hDLElBQUksU0FBUyxlQUFlLElBQUksR0FBRyxLQUFLLEtBQUs7RUFDN0MsSUFBSSxTQUFTLEdBQUc7R0FDZCxlQUFlLE9BQU8sR0FBRztHQUN6QixnQkFBZ0IsSUFBSSxHQUFHO0dBQ3ZCLElBQUksQ0FBQyxPQUFPLG1CQUNWLGNBQWMsR0FBRztFQUVyQixPQUNFLGVBQWUsSUFBSSxLQUFLLEtBQUs7RUFFL0IsWUFBWSxFQUNWLFVBQVUsSUFBSSxJQUFJLE1BQU0sUUFBUSxFQUNsQyxDQUFDO0NBQ0g7Q0FDQSxTQUFTLGFBQWEsS0FBSztFQUN6QixJQUFJLGFBQWEsaUJBQWlCLElBQUksR0FBRztFQUN6QyxJQUFJLFlBQVk7R0FDZCxXQUFXLE1BQU07R0FDakIsaUJBQWlCLE9BQU8sR0FBRztFQUM3QjtDQUNGO0NBQ0EsU0FBUyxpQkFBaUIsTUFBTTtFQUM5QixLQUFLLElBQUksT0FBTyxNQUFNO0dBRXBCLElBQUksY0FBYyxlQURKLFdBQVcsR0FDYyxDQUFDLENBQUMsSUFBSTtHQUM3QyxNQUFNLFNBQVMsSUFBSSxLQUFLLFdBQVc7RUFDckM7Q0FDRjtDQUNBLFNBQVMseUJBQXlCO0VBQ2hDLElBQUksV0FBVyxDQUFDO0VBQ2hCLElBQUksa0JBQWtCO0VBQ3RCLEtBQUssSUFBSSxPQUFPLGtCQUFrQjtHQUNoQyxJQUFJLFVBQVUsTUFBTSxTQUFTLElBQUksR0FBRztHQUNwQyxVQUFVLFNBQVMsdUJBQXVCLEdBQUc7R0FDN0MsSUFBSSxRQUFRLFVBQVUsV0FBVztJQUMvQixpQkFBaUIsT0FBTyxHQUFHO0lBQzNCLFNBQVMsS0FBSyxHQUFHO0lBQ2pCLGtCQUFrQjtHQUNwQjtFQUNGO0VBQ0EsaUJBQWlCLFFBQVE7RUFDekIsT0FBTztDQUNUO0NBQ0EsU0FBUyxxQkFBcUIsVUFBVTtFQUN0QyxJQUFJLGFBQWEsQ0FBQztFQUNsQixLQUFLLElBQUksQ0FBQyxLQUFLLE9BQU8sZ0JBQ3BCLElBQUksS0FBSyxVQUFVO0dBQ2pCLElBQUksVUFBVSxNQUFNLFNBQVMsSUFBSSxHQUFHO0dBQ3BDLFVBQVUsU0FBUyx1QkFBdUIsR0FBRztHQUM3QyxJQUFJLFFBQVEsVUFBVSxXQUFXO0lBQy9CLGFBQWEsR0FBRztJQUNoQixlQUFlLE9BQU8sR0FBRztJQUN6QixXQUFXLEtBQUssR0FBRztHQUNyQjtFQUNGO0VBRUYsaUJBQWlCLFVBQVU7RUFDM0IsT0FBTyxXQUFXLFNBQVM7Q0FDN0I7Q0FDQSxTQUFTLFdBQVcsS0FBSyxJQUFJO0VBQzNCLElBQUksVUFBVSxNQUFNLFNBQVMsSUFBSSxHQUFHLEtBQUs7RUFDekMsSUFBSSxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sSUFDaEMsaUJBQWlCLElBQUksS0FBSyxFQUFFO0VBRTlCLE9BQU87Q0FDVDtDQUNBLFNBQVMsY0FBYyxLQUFLO0VBQzFCLE1BQU0sU0FBUyxPQUFPLEdBQUc7RUFDekIsaUJBQWlCLE9BQU8sR0FBRztDQUM3QjtDQUVBLFNBQVMsY0FBYyxLQUFLLFlBQVk7RUFDdEMsSUFBSSxVQUFVLE1BQU0sU0FBUyxJQUFJLEdBQUcsS0FBSztFQUd6QyxVQUFVLFFBQVEsVUFBVSxlQUFlLFdBQVcsVUFBVSxhQUFhLFFBQVEsVUFBVSxhQUFhLFdBQVcsVUFBVSxhQUFhLFFBQVEsVUFBVSxhQUFhLFdBQVcsVUFBVSxnQkFBZ0IsUUFBUSxVQUFVLGFBQWEsV0FBVyxVQUFVLGVBQWUsUUFBUSxVQUFVLGdCQUFnQixXQUFXLFVBQVUsYUFBYSx1Q0FBdUMsUUFBUSxRQUFRLFNBQVMsV0FBVyxLQUFLO0VBQ3phLElBQUksV0FBVyxJQUFJLElBQUksTUFBTSxRQUFRO0VBQ3JDLFNBQVMsSUFBSSxLQUFLLFVBQVU7RUFDNUIsWUFBWSxFQUNWLFNBQ0YsQ0FBQztDQUNIO0NBQ0EsU0FBUyxzQkFBc0IsT0FBTztFQUNwQyxJQUFJLEVBQ0YsaUJBQ0EsY0FDQSxrQkFDRTtFQUNKLElBQUksaUJBQWlCLFNBQVMsR0FDNUI7RUFJRixJQUFJLGlCQUFpQixPQUFPLEdBQzFCLFFBQVEsT0FBTyw4Q0FBOEM7RUFFL0QsSUFBSSxVQUFVLE1BQU0sS0FBSyxpQkFBaUIsUUFBUSxDQUFDO0VBQ25ELElBQUksQ0FBQyxZQUFZLG1CQUFtQixRQUFRLFFBQVEsU0FBUztFQUM3RCxJQUFJLFVBQVUsTUFBTSxTQUFTLElBQUksVUFBVTtFQUMzQyxJQUFJLFdBQVcsUUFBUSxVQUFVLGNBRy9CO0VBSUYsSUFBSSxnQkFBZ0I7R0FDbEI7R0FDQTtHQUNBO0VBQ0YsQ0FBQyxHQUNDLE9BQU87Q0FFWDtDQUNBLFNBQVMsc0JBQXNCLFVBQVU7RUFDdkMsSUFBSSxRQUFRLHVCQUF1QixLQUFLLEVBQ3RDLFNBQ0YsQ0FBQztFQUVELElBQUksRUFDRixTQUNBLFVBQ0UsdUJBSmMsc0JBQXNCLFVBSUY7RUFFdEMsc0JBQXNCO0VBQ3RCLE9BQU87R0FDTCxpQkFBaUI7R0FDakI7R0FDQTtFQUNGO0NBQ0Y7Q0FDQSxTQUFTLHNCQUFzQixXQUFXO0VBQ3hDLElBQUksb0JBQW9CLENBQUM7RUFDekIsZ0JBQWdCLFNBQVMsS0FBSyxZQUFZO0dBQ3hDLElBQUksQ0FBQyxhQUFhLFVBQVUsT0FBTyxHQUFHO0lBSXBDLElBQUksT0FBTztJQUNYLGtCQUFrQixLQUFLLE9BQU87SUFDOUIsZ0JBQWdCLE9BQU8sT0FBTztHQUNoQztFQUNGLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FHQSxTQUFTLHdCQUF3QixXQUFXLGFBQWEsUUFBUTtFQUMvRCx1QkFBdUI7RUFDdkIsb0JBQW9CO0VBQ3BCLDBCQUEwQixVQUFVO0VBSXBDLElBQUksQ0FBQyx5QkFBeUIsTUFBTSxlQUFlLGlCQUFpQjtHQUNsRSx3QkFBd0I7R0FDeEIsSUFBSSxJQUFJLHVCQUF1QixNQUFNLFVBQVUsTUFBTSxPQUFPO0dBQzVELElBQUksS0FBSyxNQUNQLFlBQVksRUFDVix1QkFBdUIsRUFDekIsQ0FBQztFQUVMO0VBQ0EsYUFBYTtHQUNYLHVCQUF1QjtHQUN2QixvQkFBb0I7R0FDcEIsMEJBQTBCO0VBQzVCO0NBQ0Y7Q0FDQSxTQUFTLGFBQWEsVUFBVSxTQUFTO0VBQ3ZDLElBQUkseUJBRUYsT0FEVSx3QkFBd0IsVUFBVSxRQUFRLEtBQUksTUFBSywyQkFBMkIsR0FBRyxNQUFNLFVBQVUsQ0FBQyxDQUNuRyxLQUFLLFNBQVM7RUFFekIsT0FBTyxTQUFTO0NBQ2xCO0NBQ0EsU0FBUyxtQkFBbUIsVUFBVSxTQUFTO0VBQzdDLElBQUksd0JBQXdCLG1CQUFtQjtHQUM3QyxJQUFJLE1BQU0sYUFBYSxVQUFVLE9BQU87R0FDeEMscUJBQXFCLE9BQU8sa0JBQWtCO0VBQ2hEO0NBQ0Y7Q0FDQSxTQUFTLHVCQUF1QixVQUFVLFNBQVM7RUFDakQsSUFBSSxzQkFBc0I7R0FDeEIsSUFBSSxNQUFNLGFBQWEsVUFBVSxPQUFPO0dBQ3hDLElBQUksSUFBSSxxQkFBcUI7R0FDN0IsSUFBSSxPQUFPLE1BQU0sVUFDZixPQUFPO0VBRVg7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLGNBQWMsU0FBUyxhQUFhLFVBQVU7RUFDckQsSUFBSSw2QkFBNkI7R0FDL0IsSUFBSSxDQUFDLFNBRUgsT0FBTztJQUNMLFFBQVE7SUFDUixTQUhlLGdCQUFnQixhQUFhLFVBQVUsVUFBVSxJQUc5QyxLQUFLLENBQUM7R0FDMUI7UUFFQSxJQUFJLE9BQU8sS0FBSyxRQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLEdBSzFDLE9BQU87SUFDTCxRQUFRO0lBQ1IsU0FIbUIsZ0JBQWdCLGFBQWEsVUFBVSxVQUFVLElBRzlDO0dBQ3hCO0VBR047RUFDQSxPQUFPO0dBQ0wsUUFBUTtHQUNSLFNBQVM7RUFDWDtDQUNGO0NBQ0EsZUFBZSxlQUFlLFNBQVMsVUFBVSxRQUFRLFlBQVk7RUFDbkUsSUFBSSxDQUFDLDZCQUNILE9BQU87R0FDTCxNQUFNO0dBQ047RUFDRjtFQUVGLElBQUksaUJBQWlCO0VBQ3JCLE9BQU8sTUFBTTtHQUNYLElBQUksV0FBVyxzQkFBc0I7R0FDckMsSUFBSSxjQUFjLHNCQUFzQjtHQUN4QyxJQUFJLGdCQUFnQjtHQUNwQixJQUFJO0lBQ0YsTUFBTSw0QkFBNEI7S0FDaEM7S0FDQSxNQUFNO0tBQ04sU0FBUztLQUNUO0tBQ0EsUUFBUSxTQUFTLGFBQWE7TUFDNUIsSUFBSSxPQUFPLFNBQVM7TUFDcEIsZ0JBQWdCLFNBQVMsVUFBVSxhQUFhLGVBQWUsa0JBQWtCO0tBQ25GO0lBQ0YsQ0FBQztHQUNILFNBQVMsR0FBRztJQUNWLE9BQU87S0FDTCxNQUFNO0tBQ04sT0FBTztLQUNQO0lBQ0Y7R0FDRixVQUFVO0lBT1IsSUFBSSxZQUFZLENBQUMsT0FBTyxTQUN0QixhQUFhLENBQUMsR0FBRyxVQUFVO0dBRS9CO0dBQ0EsSUFBSSxPQUFPLFNBQ1QsT0FBTyxFQUNMLE1BQU0sVUFDUjtHQUVGLElBQUksYUFBYSxZQUFZLGFBQWEsVUFBVSxRQUFRO0dBQzVELElBQUksWUFDRixPQUFPO0lBQ0wsTUFBTTtJQUNOLFNBQVM7R0FDWDtHQUVGLElBQUksb0JBQW9CLGdCQUFnQixhQUFhLFVBQVUsVUFBVSxJQUFJO0dBRTdFLElBQUksQ0FBQyxxQkFBcUIsZUFBZSxXQUFXLGtCQUFrQixVQUFVLGVBQWUsT0FBTyxHQUFHLE1BQU0sRUFBRSxNQUFNLE9BQU8sa0JBQWtCLEVBQUUsQ0FBQyxNQUFNLEVBQUUsR0FDekosT0FBTztJQUNMLE1BQU07SUFDTixTQUFTO0dBQ1g7R0FFRixpQkFBaUI7RUFDbkI7Q0FDRjtDQUNBLFNBQVMsbUJBQW1CLFdBQVc7RUFDckMsV0FBVyxDQUFDO0VBQ1oscUJBQXFCLDBCQUEwQixXQUFXLG9CQUFvQixLQUFBLEdBQVcsUUFBUTtDQUNuRztDQUNBLFNBQVMsWUFBWSxTQUFTLFVBQVU7RUFDdEMsSUFBSSxXQUFXLHNCQUFzQjtFQUVyQyxnQkFBZ0IsU0FBUyxVQURQLHNCQUFzQixZQUNRLFVBQVUsa0JBQWtCO0VBTTVFLElBQUksVUFBVTtHQUNaLGFBQWEsQ0FBQyxHQUFHLFVBQVU7R0FDM0IsWUFBWSxDQUFDLENBQUM7RUFDaEI7Q0FDRjtDQUNBLFNBQVM7RUFDUCxJQUFJLFdBQVc7R0FDYixPQUFPO0VBQ1Q7RUFDQSxJQUFJLFNBQVM7R0FDWCxPQUFPO0VBQ1Q7RUFDQSxJQUFJLFFBQVE7R0FDVixPQUFPO0VBQ1Q7RUFDQSxJQUFJLFNBQVM7R0FDWCxPQUFPO0VBQ1Q7RUFDQSxJQUFJLFNBQVM7R0FDWCxPQUFPO0VBQ1Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFHQSxhQUFZLE9BQU0sS0FBSyxRQUFRLFdBQVcsRUFBRTtFQUM1QyxpQkFBZ0IsT0FBTSxLQUFLLFFBQVEsZUFBZSxFQUFFO0VBQ3BEO0VBQ0EsZUFBZTtFQUNmO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsMkJBQTJCO0VBQzNCLDBCQUEwQjtFQUcxQjtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBcWJBLFNBQVMsdUJBQXVCLE1BQU07Q0FDcEMsT0FBTyxRQUFRLFNBQVMsY0FBYyxRQUFRLEtBQUssWUFBWSxRQUFRLFVBQVUsUUFBUSxLQUFLLFNBQVMsS0FBQTtBQUN6RztBQUNBLFNBQVMsWUFBWSxVQUFVLFNBQVMsVUFBVSxpQkFBaUIsSUFBSSxzQkFBc0IsYUFBYSxVQUFVO0NBQ2xILElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxhQUFhO0VBR2Ysb0JBQW9CLENBQUM7RUFDckIsS0FBSyxJQUFJLFNBQVMsU0FBUztHQUN6QixrQkFBa0IsS0FBSyxLQUFLO0dBQzVCLElBQUksTUFBTSxNQUFNLE9BQU8sYUFBYTtJQUNsQyxtQkFBbUI7SUFDbkI7R0FDRjtFQUNGO0NBQ0YsT0FBTztFQUNMLG9CQUFvQjtFQUNwQixtQkFBbUIsUUFBUSxRQUFRLFNBQVM7Q0FDOUM7Q0FFQSxJQUFJLE9BQU8sVUFBVSxLQUFLLEtBQUssS0FBSyxvQkFBb0IsbUJBQW1CLG9CQUFvQixHQUFHLGNBQWMsU0FBUyxVQUFVLFFBQVEsS0FBSyxTQUFTLFVBQVUsYUFBYSxNQUFNO0NBSXRMLElBQUksTUFBTSxNQUFNO0VBQ2QsS0FBSyxTQUFTLFNBQVM7RUFDdkIsS0FBSyxPQUFPLFNBQVM7Q0FDdkI7Q0FFQSxLQUFLLE1BQU0sUUFBUSxPQUFPLE1BQU0sT0FBTyxRQUFRLGtCQUFrQjtFQUMvRCxJQUFJLGFBQWEsbUJBQW1CLEtBQUssTUFBTTtFQUMvQyxJQUFJLGlCQUFpQixNQUFNLFNBQVMsQ0FBQyxZQUVuQyxLQUFLLFNBQVMsS0FBSyxTQUFTLEtBQUssT0FBTyxRQUFRLE9BQU8sU0FBUyxJQUFJO09BQy9ELElBQUksQ0FBQyxpQkFBaUIsTUFBTSxTQUFTLFlBQVk7R0FFdEQsSUFBSSxTQUFTLElBQUksZ0JBQWdCLEtBQUssTUFBTTtHQUM1QyxJQUFJLGNBQWMsT0FBTyxPQUFPLE9BQU87R0FDdkMsT0FBTyxPQUFPLE9BQU87R0FDckIsWUFBWSxRQUFPLE1BQUssQ0FBQyxDQUFDLENBQUMsU0FBUSxNQUFLLE9BQU8sT0FBTyxTQUFTLENBQUMsQ0FBQztHQUNqRSxJQUFJLEtBQUssT0FBTyxTQUFTO0dBQ3pCLEtBQUssU0FBUyxLQUFLLE1BQU0sS0FBSztFQUNoQztDQUNGO0NBS0EsSUFBSSxtQkFBbUIsYUFBYSxLQUNsQyxLQUFLLFdBQVcsS0FBSyxhQUFhLE1BQU0sV0FBVyxVQUFVLENBQUMsVUFBVSxLQUFLLFFBQVEsQ0FBQztDQUV4RixPQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUdBLFNBQVMseUJBQXlCLHFCQUFxQixXQUFXLE1BQU0sTUFBTTtDQUU1RSxJQUFJLENBQUMsUUFBUSxDQUFDLHVCQUF1QixJQUFJLEdBQ3ZDLE9BQU8sRUFDTCxLQUNGO0NBRUYsSUFBSSxLQUFLLGNBQWMsQ0FBQyxjQUFjLEtBQUssVUFBVSxHQUNuRCxPQUFPO0VBQ0w7RUFDQSxPQUFPLHVCQUF1QixLQUFLLEVBQ2pDLFFBQVEsS0FBSyxXQUNmLENBQUM7Q0FDSDtDQUVGLElBQUksNkJBQTZCO0VBQy9CO0VBQ0EsT0FBTyx1QkFBdUIsS0FBSyxFQUNqQyxNQUFNLGVBQ1IsQ0FBQztDQUNIO0NBRUEsSUFBSSxnQkFBZ0IsS0FBSyxjQUFjO0NBQ3ZDLElBQUksYUFBYSxzQkFBc0IsY0FBYyxZQUFZLElBQUksY0FBYyxZQUFZO0NBQy9GLElBQUksYUFBYSxrQkFBa0IsSUFBSTtDQUN2QyxJQUFJLEtBQUssU0FBUyxLQUFBLEdBQVc7RUFDM0IsSUFBSSxLQUFLLGdCQUFnQixjQUFjO0dBRXJDLElBQUksQ0FBQyxpQkFBaUIsVUFBVSxHQUM5QixPQUFPLG9CQUFvQjtHQUU3QixJQUFJLE9BQU8sT0FBTyxLQUFLLFNBQVMsV0FBVyxLQUFLLE9BQU8sS0FBSyxnQkFBZ0IsWUFBWSxLQUFLLGdCQUFnQixrQkFFN0csTUFBTSxLQUFLLEtBQUssS0FBSyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsS0FBSyxVQUFVO0lBQ3JELElBQUksQ0FBQyxNQUFNLFNBQVM7SUFDcEIsT0FBTyxLQUFLLE1BQU0sT0FBTyxNQUFNLFFBQVE7R0FDekMsR0FBRyxFQUFFLElBQUksT0FBTyxLQUFLLElBQUk7R0FDekIsT0FBTztJQUNMO0lBQ0EsWUFBWTtLQUNWO0tBQ0E7S0FDQSxhQUFhLEtBQUs7S0FDbEIsVUFBVSxLQUFBO0tBQ1YsTUFBTSxLQUFBO0tBQ047SUFDRjtHQUNGO0VBQ0YsT0FBTyxJQUFJLEtBQUssZ0JBQWdCLG9CQUFvQjtHQUVsRCxJQUFJLENBQUMsaUJBQWlCLFVBQVUsR0FDOUIsT0FBTyxvQkFBb0I7R0FFN0IsSUFBSTtJQUNGLElBQUksT0FBTyxPQUFPLEtBQUssU0FBUyxXQUFXLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLO0lBQ3hFLE9BQU87S0FDTDtLQUNBLFlBQVk7TUFDVjtNQUNBO01BQ0EsYUFBYSxLQUFLO01BQ2xCLFVBQVUsS0FBQTtNQUNWO01BQ0EsTUFBTSxLQUFBO0tBQ1I7SUFDRjtHQUNGLFNBQVMsR0FBRztJQUNWLE9BQU8sb0JBQW9CO0dBQzdCO0VBQ0Y7Q0FDRjtDQUNBLFVBQVUsT0FBTyxhQUFhLFlBQVksK0NBQStDO0NBQ3pGLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxLQUFLLFVBQVU7RUFDakIsZUFBZSw4QkFBOEIsS0FBSyxRQUFRO0VBQzFELFdBQVcsS0FBSztDQUNsQixPQUFPLElBQUksS0FBSyxnQkFBZ0IsVUFBVTtFQUN4QyxlQUFlLDhCQUE4QixLQUFLLElBQUk7RUFDdEQsV0FBVyxLQUFLO0NBQ2xCLE9BQU8sSUFBSSxLQUFLLGdCQUFnQixpQkFBaUI7RUFDL0MsZUFBZSxLQUFLO0VBQ3BCLFdBQVcsOEJBQThCLFlBQVk7Q0FDdkQsT0FBTyxJQUFJLEtBQUssUUFBUSxNQUFNO0VBQzVCLGVBQWUsSUFBSSxnQkFBZ0I7RUFDbkMsV0FBVyxJQUFJLFNBQVM7Q0FDMUIsT0FDRSxJQUFJO0VBQ0YsZUFBZSxJQUFJLGdCQUFnQixLQUFLLElBQUk7RUFDNUMsV0FBVyw4QkFBOEIsWUFBWTtDQUN2RCxTQUFTLEdBQUc7RUFDVixPQUFPLG9CQUFvQjtDQUM3QjtDQUVGLElBQUksYUFBYTtFQUNmO0VBQ0E7RUFDQSxhQUFhLFFBQVEsS0FBSyxlQUFlO0VBQ3pDO0VBQ0EsTUFBTSxLQUFBO0VBQ04sTUFBTSxLQUFBO0NBQ1I7Q0FDQSxJQUFJLGlCQUFpQixXQUFXLFVBQVUsR0FDeEMsT0FBTztFQUNMO0VBQ0E7Q0FDRjtDQUdGLElBQUksYUFBYSxVQUFVLElBQUk7Q0FJL0IsSUFBSSxhQUFhLFdBQVcsVUFBVSxtQkFBbUIsV0FBVyxNQUFNLEdBQ3hFLGFBQWEsT0FBTyxTQUFTLEVBQUU7Q0FFakMsV0FBVyxTQUFTLE1BQU07Q0FDMUIsT0FBTztFQUNMLE1BQU0sV0FBVyxVQUFVO0VBQzNCO0NBQ0Y7QUFDRjtBQUdBLFNBQVMsOEJBQThCLFNBQVMsWUFBWSxpQkFBaUI7Q0FDM0UsSUFBSSxvQkFBb0IsS0FBSyxHQUMzQixrQkFBa0I7Q0FFcEIsSUFBSSxRQUFRLFFBQVEsV0FBVSxNQUFLLEVBQUUsTUFBTSxPQUFPLFVBQVU7Q0FDNUQsSUFBSSxTQUFTLEdBQ1gsT0FBTyxRQUFRLE1BQU0sR0FBRyxrQkFBa0IsUUFBUSxJQUFJLEtBQUs7Q0FFN0QsT0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUyxPQUFPLFNBQVMsWUFBWSxVQUFVLGtCQUFrQiw2QkFBNkIsd0JBQXdCLHlCQUF5Qix1QkFBdUIsaUJBQWlCLGtCQUFrQixrQkFBa0IsYUFBYSxVQUFVLHFCQUFxQjtDQUMvUixJQUFJLGVBQWUsc0JBQXNCLGNBQWMsb0JBQW9CLEVBQUUsSUFBSSxvQkFBb0IsRUFBRSxDQUFDLFFBQVEsb0JBQW9CLEVBQUUsQ0FBQyxPQUFPLEtBQUE7Q0FDOUksSUFBSSxhQUFhLFFBQVEsVUFBVSxNQUFNLFFBQVE7Q0FDakQsSUFBSSxVQUFVLFFBQVEsVUFBVSxRQUFRO0NBRXhDLElBQUksa0JBQWtCO0NBQ3RCLElBQUksb0JBQW9CLE1BQU0sUUFNNUIsa0JBQWtCLDhCQUE4QixTQUFTLE9BQU8sS0FBSyxNQUFNLE1BQU0sQ0FBQyxDQUFDLElBQUksSUFBSTtNQUN0RixJQUFJLHVCQUF1QixjQUFjLG9CQUFvQixFQUFFLEdBR3BFLGtCQUFrQiw4QkFBOEIsU0FBUyxvQkFBb0IsRUFBRTtDQUtqRixJQUFJLGVBQWUsc0JBQXNCLG9CQUFvQixFQUFFLENBQUMsYUFBYSxLQUFBO0NBQzdFLElBQUkseUJBQXlCLCtCQUErQixnQkFBZ0IsZ0JBQWdCO0NBQzVGLElBQUksb0JBQW9CLGdCQUFnQixRQUFRLE9BQU8sVUFBVTtFQUMvRCxJQUFJLEVBQ0YsVUFDRTtFQUNKLElBQUksTUFBTSxNQUVSLE9BQU87RUFFVCxJQUFJLE1BQU0sVUFBVSxNQUNsQixPQUFPO0VBRVQsSUFBSSxrQkFDRixPQUFPLDJCQUEyQixPQUFPLE1BQU0sWUFBWSxNQUFNLE1BQU07RUFHekUsSUFBSSxZQUFZLE1BQU0sWUFBWSxNQUFNLFFBQVEsUUFBUSxLQUFLLEtBQUssd0JBQXdCLE1BQUssT0FBTSxPQUFPLE1BQU0sTUFBTSxFQUFFLEdBQ3hILE9BQU87RUFNVCxJQUFJLG9CQUFvQixNQUFNLFFBQVE7RUFDdEMsSUFBSSxpQkFBaUI7RUFDckIsT0FBTyx1QkFBdUIsT0FBT0EsV0FBUztHQUM1QztHQUNBLGVBQWUsa0JBQWtCO0dBQ2pDO0dBQ0EsWUFBWSxlQUFlO0VBQzdCLEdBQUcsWUFBWTtHQUNiO0dBQ0E7R0FDQSx5QkFBeUIseUJBQXlCLFFBRWxELDBCQUEwQixXQUFXLFdBQVcsV0FBVyxXQUFXLFFBQVEsV0FBVyxRQUFRLFVBRWpHLFdBQVcsV0FBVyxRQUFRLFVBQVUsbUJBQW1CLG1CQUFtQixjQUFjO0VBQzlGLENBQUMsQ0FBQztDQUNKLENBQUM7Q0FFRCxJQUFJLHVCQUF1QixDQUFDO0NBQzVCLGlCQUFpQixTQUFTLEdBQUcsUUFBUTtFQU1uQyxJQUFJLG9CQUFvQixDQUFDLFFBQVEsTUFBSyxNQUFLLEVBQUUsTUFBTSxPQUFPLEVBQUUsT0FBTyxLQUFLLGdCQUFnQixJQUFJLEdBQUcsR0FDN0Y7RUFFRixJQUFJLGlCQUFpQixZQUFZLGFBQWEsRUFBRSxNQUFNLFFBQVE7RUFLOUQsSUFBSSxDQUFDLGdCQUFnQjtHQUNuQixxQkFBcUIsS0FBSztJQUN4QjtJQUNBLFNBQVMsRUFBRTtJQUNYLE1BQU0sRUFBRTtJQUNSLFNBQVM7SUFDVCxPQUFPO0lBQ1AsWUFBWTtHQUNkLENBQUM7R0FDRDtFQUNGO0VBSUEsSUFBSSxVQUFVLE1BQU0sU0FBUyxJQUFJLEdBQUc7RUFDcEMsSUFBSSxlQUFlLGVBQWUsZ0JBQWdCLEVBQUUsSUFBSTtFQUN4RCxJQUFJLG1CQUFtQjtFQUN2QixJQUFJLGlCQUFpQixJQUFJLEdBQUcsR0FFMUIsbUJBQW1CO09BQ2QsSUFBSSxzQkFBc0IsSUFBSSxHQUFHLEdBQUc7R0FFekMsc0JBQXNCLE9BQU8sR0FBRztHQUNoQyxtQkFBbUI7RUFDckIsT0FBTyxJQUFJLFdBQVcsUUFBUSxVQUFVLFVBQVUsUUFBUSxTQUFTLEtBQUEsR0FJakUsbUJBQW1CO09BSW5CLG1CQUFtQix1QkFBdUIsY0FBY0EsV0FBUztHQUMvRDtHQUNBLGVBQWUsTUFBTSxRQUFRLE1BQU0sUUFBUSxTQUFTLEVBQUUsQ0FBQztHQUN2RDtHQUNBLFlBQVksUUFBUSxRQUFRLFNBQVMsRUFBRSxDQUFDO0VBQzFDLEdBQUcsWUFBWTtHQUNiO0dBQ0E7R0FDQSx5QkFBeUIseUJBQXlCLFFBQVE7RUFDNUQsQ0FBQyxDQUFDO0VBRUosSUFBSSxrQkFDRixxQkFBcUIsS0FBSztHQUN4QjtHQUNBLFNBQVMsRUFBRTtHQUNYLE1BQU0sRUFBRTtHQUNSLFNBQVM7R0FDVCxPQUFPO0dBQ1AsWUFBWSxJQUFJLGdCQUFnQjtFQUNsQyxDQUFDO0NBRUwsQ0FBQztDQUNELE9BQU8sQ0FBQyxtQkFBbUIsb0JBQW9CO0FBQ2pEO0FBQ0EsU0FBUywyQkFBMkIsT0FBTyxZQUFZLFFBQVE7Q0FFN0QsSUFBSSxNQUFNLE1BQ1IsT0FBTztDQUdULElBQUksQ0FBQyxNQUFNLFFBQ1QsT0FBTztDQUVULElBQUksVUFBVSxjQUFjLFFBQVEsV0FBVyxNQUFNLFFBQVEsS0FBQTtDQUM3RCxJQUFJLFdBQVcsVUFBVSxRQUFRLE9BQU8sTUFBTSxRQUFRLEtBQUE7Q0FFdEQsSUFBSSxDQUFDLFdBQVcsVUFDZCxPQUFPO0NBR1QsSUFBSSxPQUFPLE1BQU0sV0FBVyxjQUFjLE1BQU0sT0FBTyxZQUFZLE1BQ2pFLE9BQU87Q0FHVCxPQUFPLENBQUMsV0FBVyxDQUFDO0FBQ3RCO0FBQ0EsU0FBUyxZQUFZLG1CQUFtQixjQUFjLE9BQU87Q0FDM0QsSUFBSSxRQUVKLENBQUMsZ0JBRUQsTUFBTSxNQUFNLE9BQU8sYUFBYSxNQUFNO0NBR3RDLElBQUksZ0JBQWdCLGtCQUFrQixNQUFNLE1BQU0sUUFBUSxLQUFBO0NBRTFELE9BQU8sU0FBUztBQUNsQjtBQUNBLFNBQVMsbUJBQW1CLGNBQWMsT0FBTztDQUMvQyxJQUFJLGNBQWMsYUFBYSxNQUFNO0NBQ3JDLE9BRUUsYUFBYSxhQUFhLE1BQU0sWUFHaEMsZUFBZSxRQUFRLFlBQVksU0FBUyxHQUFHLEtBQUssYUFBYSxPQUFPLFNBQVMsTUFBTSxPQUFPO0FBRWxHO0FBQ0EsU0FBUyx1QkFBdUIsYUFBYSxLQUFLO0NBQ2hELElBQUksWUFBWSxNQUFNLGtCQUFrQjtFQUN0QyxJQUFJLGNBQWMsWUFBWSxNQUFNLGlCQUFpQixHQUFHO0VBQ3hELElBQUksT0FBTyxnQkFBZ0IsV0FDekIsT0FBTztDQUVYO0NBQ0EsT0FBTyxJQUFJO0FBQ2I7QUFDQSxTQUFTLGdCQUFnQixTQUFTLFVBQVUsYUFBYSxVQUFVLG9CQUFvQjtDQUNyRixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksU0FBUztFQUNYLElBQUksUUFBUSxTQUFTO0VBQ3JCLFVBQVUsT0FBTyxzREFBc0QsT0FBTztFQUM5RSxJQUFJLENBQUMsTUFBTSxVQUNULE1BQU0sV0FBVyxDQUFDO0VBRXBCLGtCQUFrQixNQUFNO0NBQzFCLE9BQ0Usa0JBQWtCO0NBTXBCLElBQUksWUFBWSwwQkFESyxTQUFTLFFBQU8sYUFBWSxDQUFDLGdCQUFnQixNQUFLLGtCQUFpQixZQUFZLFVBQVUsYUFBYSxDQUFDLENBQ3JFLEdBQUcsb0JBQW9CO0VBQUMsV0FBVztFQUFLO0VBQVMsU0FBUyxtQkFBbUIsb0JBQW9CLE9BQU8sS0FBSyxJQUFJLGlCQUFpQixXQUFXLEdBQUc7Q0FBQyxHQUFHLFFBQVE7Q0FDbk4sZ0JBQWdCLEtBQUssR0FBRyxTQUFTO0FBQ25DO0FBQ0EsU0FBUyxZQUFZLFVBQVUsZUFBZTtDQUU1QyxJQUFJLFFBQVEsWUFBWSxRQUFRLGlCQUFpQixTQUFTLE9BQU8sY0FBYyxJQUM3RSxPQUFPO0NBR1QsSUFBSSxFQUFFLFNBQVMsVUFBVSxjQUFjLFNBQVMsU0FBUyxTQUFTLGNBQWMsUUFBUSxTQUFTLGtCQUFrQixjQUFjLGdCQUMvSCxPQUFPO0NBSVQsS0FBSyxDQUFDLFNBQVMsWUFBWSxTQUFTLFNBQVMsV0FBVyxPQUFPLENBQUMsY0FBYyxZQUFZLGNBQWMsU0FBUyxXQUFXLElBQzFILE9BQU87Q0FJVCxPQUFPLFNBQVMsU0FBUyxPQUFPLFFBQVEsTUFBTTtFQUM1QyxJQUFJO0VBQ0osUUFBUSx3QkFBd0IsY0FBYyxhQUFhLE9BQU8sS0FBSyxJQUFJLHNCQUFzQixNQUFLLFdBQVUsWUFBWSxRQUFRLE1BQU0sQ0FBQztDQUM3SSxDQUFDO0FBQ0g7Ozs7OztBQU1BLGVBQWUsb0JBQW9CLE9BQU8sb0JBQW9CLFVBQVU7Q0FDdEUsSUFBSSxDQUFDLE1BQU0sTUFDVDtDQUVGLElBQUksWUFBWSxNQUFNLE1BQU0sS0FBSztDQUlqQyxJQUFJLENBQUMsTUFBTSxNQUNUO0NBRUYsSUFBSSxnQkFBZ0IsU0FBUyxNQUFNO0NBQ25DLFVBQVUsZUFBZSw0QkFBNEI7Q0FTckQsSUFBSSxlQUFlLENBQUM7Q0FDcEIsS0FBSyxJQUFJLHFCQUFxQixXQUFXO0VBRXZDLElBQUksOEJBRG1CLGNBQWMsdUJBQ2tCLEtBQUEsS0FHdkQsc0JBQXNCO0VBQ3RCLFFBQVEsQ0FBQyw2QkFBNkIsYUFBYSxjQUFjLEtBQUssZ0NBQWdDLG9CQUFvQixvRkFBeUYsK0JBQStCLG9CQUFvQixzQkFBc0I7RUFDNVIsSUFBSSxDQUFDLCtCQUErQixDQUFDLG1CQUFtQixJQUFJLGlCQUFpQixHQUMzRSxhQUFhLHFCQUFxQixVQUFVO0NBRWhEO0NBR0EsT0FBTyxPQUFPLGVBQWUsWUFBWTtDQUl6QyxPQUFPLE9BQU8sZUFBZUEsV0FBUyxDQUFDLEdBQUcsbUJBQW1CLGFBQWEsR0FBRyxFQUMzRSxNQUFNLEtBQUEsRUFDUixDQUFDLENBQUM7QUFDSjtBQUVBLGVBQWUsb0JBQW9CLE9BQU87Q0FDeEMsSUFBSSxFQUNGLFlBQ0U7Q0FDSixJQUFJLGdCQUFnQixRQUFRLFFBQU8sTUFBSyxFQUFFLFVBQVU7Q0FFcEQsUUFBTyxNQURhLFFBQVEsSUFBSSxjQUFjLEtBQUksTUFBSyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUEsQ0FDcEQsUUFBUSxLQUFLLFFBQVEsTUFBTSxPQUFPLE9BQU8sS0FBSyxHQUMxRCxjQUFjLEVBQUUsQ0FBQyxNQUFNLEtBQUssT0FDL0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNSO0FBQ0EsZUFBZSxxQkFBcUIsa0JBQWtCLE1BQU0sT0FBTyxTQUFTLGVBQWUsU0FBUyxZQUFZLFVBQVUsb0JBQW9CLGdCQUFnQjtDQUM1SixJQUFJLCtCQUErQixRQUFRLEtBQUksTUFBSyxFQUFFLE1BQU0sT0FBTyxvQkFBb0IsRUFBRSxPQUFPLG9CQUFvQixRQUFRLElBQUksS0FBQSxDQUFTO0NBeUJ6SSxJQUFJLFVBQVUsTUFBTSxpQkFBaUI7RUFDbkMsU0F6QmMsUUFBUSxLQUFLLE9BQU8sTUFBTTtHQUN4QyxJQUFJLG1CQUFtQiw2QkFBNkI7R0FDcEQsSUFBSSxhQUFhLGNBQWMsTUFBSyxNQUFLLEVBQUUsTUFBTSxPQUFPLE1BQU0sTUFBTSxFQUFFO0dBS3RFLElBQUksVUFBVSxPQUFNLG9CQUFtQjtJQUNyQyxJQUFJLG1CQUFtQixRQUFRLFdBQVcsVUFBVSxNQUFNLE1BQU0sUUFBUSxNQUFNLE1BQU0sU0FDbEYsYUFBYTtJQUVmLE9BQU8sYUFBYSxtQkFBbUIsTUFBTSxTQUFTLE9BQU8sa0JBQWtCLGlCQUFpQixjQUFjLElBQUksUUFBUSxRQUFRO0tBQ2hJLE1BQU0sV0FBVztLQUNqQixRQUFRLEtBQUE7SUFDVixDQUFDO0dBQ0g7R0FDQSxPQUFPQSxXQUFTLENBQUMsR0FBRyxPQUFPO0lBQ3pCO0lBQ0E7R0FDRixDQUFDO0VBQ0gsQ0FLbUI7RUFDakI7RUFDQSxRQUFRLFFBQVEsRUFBRSxDQUFDO0VBQ25CO0VBQ0EsU0FBUztDQUNYLENBQUM7Q0FJRCxJQUFJO0VBQ0YsTUFBTSxRQUFRLElBQUksNEJBQTRCO0NBQ2hELFNBQVMsR0FBRyxDQUVaO0NBQ0EsT0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUIsTUFBTSxTQUFTLE9BQU8sa0JBQWtCLGlCQUFpQixlQUFlO0NBQ3hHLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxjQUFhLFlBQVc7RUFFMUIsSUFBSTtFQUdKLElBQUksZUFBZSxJQUFJLFNBQVMsR0FBRyxNQUFNLFNBQVMsQ0FBQztFQUNuRCxpQkFBaUIsT0FBTztFQUN4QixRQUFRLE9BQU8saUJBQWlCLFNBQVMsUUFBUTtFQUNqRCxJQUFJLGlCQUFnQixRQUFPO0dBQ3pCLElBQUksT0FBTyxZQUFZLFlBQ3JCLE9BQU8sUUFBUSx1QkFBTyxJQUFJLE1BQU0sc0VBQXNFLE9BQU8sT0FBTyxrQkFBa0IsTUFBTSxNQUFNLEtBQUssSUFBSSxDQUFDO0dBRTlKLE9BQU8sUUFBUTtJQUNiO0lBQ0EsUUFBUSxNQUFNO0lBQ2QsU0FBUztHQUNYLEdBQUcsR0FBSSxRQUFRLEtBQUEsSUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUU7RUFDeEM7RUFDQSxJQUFJLGtCQUFrQixZQUFZO0dBQ2hDLElBQUk7SUFFRixPQUFPO0tBQ0wsTUFBTTtLQUNOLFFBQVEsT0FITyxrQkFBa0IsaUJBQWdCLFFBQU8sY0FBYyxHQUFHLENBQUMsSUFBSSxjQUFjO0lBSTlGO0dBQ0YsU0FBUyxHQUFHO0lBQ1YsT0FBTztLQUNMLE1BQU07S0FDTixRQUFRO0lBQ1Y7R0FDRjtFQUNGLEVBQUEsQ0FBRztFQUNILE9BQU8sUUFBUSxLQUFLLENBQUMsZ0JBQWdCLFlBQVksQ0FBQztDQUNwRDtDQUNBLElBQUk7RUFDRixJQUFJLFVBQVUsTUFBTSxNQUFNO0VBRTFCLElBQUksa0JBQWtCO0dBQ3BCLElBQUksU0FBUztJQUVYLElBQUk7SUFDSixJQUFJLENBQUMsU0FBUyxNQUFNLFFBQVEsSUFBSSxDQUloQyxXQUFXLE9BQU8sQ0FBQyxDQUFDLE9BQU0sTUFBSztLQUM3QixlQUFlO0lBQ2pCLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQztJQUNyQixJQUFJLGlCQUFpQixLQUFBLEdBQ25CLE1BQU07SUFFUixTQUFTO0dBQ1gsT0FBTztJQUVMLE1BQU07SUFDTixVQUFVLE1BQU0sTUFBTTtJQUN0QixJQUFJLFNBSUYsU0FBUyxNQUFNLFdBQVcsT0FBTztTQUM1QixJQUFJLFNBQVMsVUFBVTtLQUM1QixJQUFJLE1BQU0sSUFBSSxJQUFJLFFBQVEsR0FBRztLQUM3QixJQUFJLFdBQVcsSUFBSSxXQUFXLElBQUk7S0FDbEMsTUFBTSx1QkFBdUIsS0FBSztNQUNoQyxRQUFRLFFBQVE7TUFDaEI7TUFDQSxTQUFTLE1BQU0sTUFBTTtLQUN2QixDQUFDO0lBQ0gsT0FHRSxPQUFPO0tBQ0wsTUFBTSxXQUFXO0tBQ2pCLFFBQVEsS0FBQTtJQUNWO0dBRUo7RUFDRixPQUFPLElBQUksQ0FBQyxTQUFTO0dBQ25CLElBQUksTUFBTSxJQUFJLElBQUksUUFBUSxHQUFHO0dBRTdCLE1BQU0sdUJBQXVCLEtBQUssRUFDaEMsVUFGYSxJQUFJLFdBQVcsSUFBSSxPQUdsQyxDQUFDO0VBQ0gsT0FDRSxTQUFTLE1BQU0sV0FBVyxPQUFPO0VBRW5DLFVBQVUsT0FBTyxXQUFXLEtBQUEsR0FBVyxrQkFBa0IsU0FBUyxXQUFXLGNBQWMsY0FBYyxpQkFBaUIsT0FBTyxNQUFNLE1BQU0sS0FBSyw4Q0FBOEMsT0FBTyxRQUFRLDRDQUE0QztDQUM3UCxTQUFTLEdBQUc7RUFJVixPQUFPO0dBQ0wsTUFBTSxXQUFXO0dBQ2pCLFFBQVE7RUFDVjtDQUNGLFVBQVU7RUFDUixJQUFJLFVBQ0YsUUFBUSxPQUFPLG9CQUFvQixTQUFTLFFBQVE7Q0FFeEQ7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxlQUFlLHNDQUFzQyxvQkFBb0I7Q0FDdkUsSUFBSSxFQUNGLFFBQ0EsU0FDRTtDQUNKLElBQUksV0FBVyxNQUFNLEdBQUc7RUFDdEIsSUFBSTtFQUNKLElBQUk7R0FDRixJQUFJLGNBQWMsT0FBTyxRQUFRLElBQUksY0FBYztHQUduRCxJQUFJLGVBQWUsd0JBQXdCLEtBQUssV0FBVyxHQUFHO0lBQzVELElBQUksT0FBTyxRQUFRLE1BQ2pCLE9BQU87U0FFUCxPQUFPLE1BQU0sT0FBTyxLQUFLO0dBRTdCLE9BQ0UsT0FBTyxNQUFNLE9BQU8sS0FBSztFQUU3QixTQUFTLEdBQUc7R0FDVixPQUFPO0lBQ0wsTUFBTSxXQUFXO0lBQ2pCLE9BQU87R0FDVDtFQUNGO0VBQ0EsSUFBSSxTQUFTLFdBQVcsT0FDdEIsT0FBTztHQUNMLE1BQU0sV0FBVztHQUNqQixPQUFPLElBQUksa0JBQWtCLE9BQU8sUUFBUSxPQUFPLFlBQVksSUFBSTtHQUNuRSxZQUFZLE9BQU87R0FDbkIsU0FBUyxPQUFPO0VBQ2xCO0VBRUYsT0FBTztHQUNMLE1BQU0sV0FBVztHQUNqQjtHQUNBLFlBQVksT0FBTztHQUNuQixTQUFTLE9BQU87RUFDbEI7Q0FDRjtDQUNBLElBQUksU0FBUyxXQUFXLE9BQU87RUFDN0IsSUFBSSx1QkFBdUIsTUFBTSxHQUFHO0dBQ2xDLElBQUksZUFBZTtHQUNuQixJQUFJLE9BQU8sZ0JBQWdCLE9BQU87SUFDaEMsSUFBSSxjQUFjO0lBQ2xCLE9BQU87S0FDTCxNQUFNLFdBQVc7S0FDakIsT0FBTyxPQUFPO0tBQ2QsYUFBYSxlQUFlLE9BQU8sU0FBUyxPQUFPLEtBQUssSUFBSSxhQUFhO0tBQ3pFLFVBQVUsZ0JBQWdCLE9BQU8sU0FBUyxRQUFRLGNBQWMsVUFBVSxJQUFJLFFBQVEsT0FBTyxLQUFLLE9BQU8sSUFBSSxLQUFBO0lBQy9HO0dBQ0Y7R0FFQSxPQUFPO0lBQ0wsTUFBTSxXQUFXO0lBQ2pCLE9BQU8sSUFBSSxvQkFBb0IsZ0JBQWdCLE9BQU8sU0FBUyxPQUFPLEtBQUssSUFBSSxjQUFjLFdBQVcsS0FBSyxLQUFBLEdBQVcsT0FBTyxJQUFJO0lBQ25JLFlBQVkscUJBQXFCLE1BQU0sSUFBSSxPQUFPLFNBQVMsS0FBQTtJQUMzRCxVQUFVLGdCQUFnQixPQUFPLFNBQVMsUUFBUSxjQUFjLFVBQVUsSUFBSSxRQUFRLE9BQU8sS0FBSyxPQUFPLElBQUksS0FBQTtHQUMvRztFQUNGO0VBQ0EsT0FBTztHQUNMLE1BQU0sV0FBVztHQUNqQixPQUFPO0dBQ1AsWUFBWSxxQkFBcUIsTUFBTSxJQUFJLE9BQU8sU0FBUyxLQUFBO0VBQzdEO0NBQ0Y7Q0FDQSxJQUFJLGVBQWUsTUFBTSxHQUFHO0VBQzFCLElBQUksZUFBZTtFQUNuQixPQUFPO0dBQ0wsTUFBTSxXQUFXO0dBQ2pCLGNBQWM7R0FDZCxhQUFhLGdCQUFnQixPQUFPLFNBQVMsT0FBTyxLQUFLLElBQUksY0FBYztHQUMzRSxXQUFXLGdCQUFnQixPQUFPLFNBQVMsT0FBTyxLQUFLLElBQUksY0FBYyxZQUFZLElBQUksUUFBUSxPQUFPLEtBQUssT0FBTztFQUN0SDtDQUNGO0NBQ0EsSUFBSSx1QkFBdUIsTUFBTSxHQUFHO0VBQ2xDLElBQUksZUFBZTtFQUNuQixPQUFPO0dBQ0wsTUFBTSxXQUFXO0dBQ2pCLE1BQU0sT0FBTztHQUNiLGFBQWEsZ0JBQWdCLE9BQU8sU0FBUyxPQUFPLEtBQUssSUFBSSxjQUFjO0dBQzNFLFVBQVUsZ0JBQWdCLE9BQU8sU0FBUyxRQUFRLGNBQWMsVUFBVSxJQUFJLFFBQVEsT0FBTyxLQUFLLE9BQU8sSUFBSSxLQUFBO0VBQy9HO0NBQ0Y7Q0FDQSxPQUFPO0VBQ0wsTUFBTSxXQUFXO0VBQ2pCLE1BQU07Q0FDUjtBQUNGO0FBRUEsU0FBUyx5Q0FBeUMsVUFBVSxTQUFTLFNBQVMsU0FBUyxVQUFVLHNCQUFzQjtDQUNySCxJQUFJLFdBQVcsU0FBUyxRQUFRLElBQUksVUFBVTtDQUM5QyxVQUFVLFVBQVUsNEVBQTRFO0NBQ2hHLElBQUksQ0FBQ0MscUJBQW1CLEtBQUssUUFBUSxHQUFHO0VBQ3RDLElBQUksaUJBQWlCLFFBQVEsTUFBTSxHQUFHLFFBQVEsV0FBVSxNQUFLLEVBQUUsTUFBTSxPQUFPLE9BQU8sSUFBSSxDQUFDO0VBQ3hGLFdBQVcsWUFBWSxJQUFJLElBQUksUUFBUSxHQUFHLEdBQUcsZ0JBQWdCLFVBQVUsTUFBTSxVQUFVLG9CQUFvQjtFQUMzRyxTQUFTLFFBQVEsSUFBSSxZQUFZLFFBQVE7Q0FDM0M7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLDBCQUEwQixVQUFVLFlBQVksVUFBVSxpQkFBaUI7Q0FHbEYsSUFBSSxtQkFBbUI7RUFBQztFQUFVO0VBQVM7RUFBVztFQUFxQjtFQUFZO0VBQVM7RUFBYTtFQUFTO0VBRXRIO0NBQWE7Q0FDYixJQUFJQSxxQkFBbUIsS0FBSyxRQUFRLEdBQUc7RUFFckMsSUFBSSxxQkFBcUI7RUFDekIsSUFBSSxNQUFNLG1CQUFtQixXQUFXLElBQUksSUFBSSxJQUFJLElBQUksV0FBVyxXQUFXLGtCQUFrQixJQUFJLElBQUksSUFBSSxrQkFBa0I7RUFDOUgsSUFBSSxpQkFBaUIsU0FBUyxJQUFJLFFBQVEsR0FDeEMsTUFBTSxJQUFJLE1BQU0sMkJBQTJCO0VBRTdDLElBQUksaUJBQWlCLGNBQWMsSUFBSSxVQUFVLFFBQVEsS0FBSztFQUM5RCxJQUFJLElBQUksV0FBVyxXQUFXLFVBQVUsZ0JBQ3RDLE9BQU8sb0JBQW9CLElBQUksUUFBUSxJQUFJLElBQUksU0FBUyxJQUFJO0NBRWhFO0NBQ0EsSUFBSTtFQUNGLElBQUksTUFBTSxnQkFBZ0IsVUFBVSxRQUFRO0VBQzVDLElBQUksaUJBQWlCLFNBQVMsSUFBSSxRQUFRLEdBQ3hDLE1BQU0sSUFBSSxNQUFNLDJCQUEyQjtDQUUvQyxTQUFTLEdBQUcsQ0FBQztDQUNiLE9BQU87QUFDVDtBQUlBLFNBQVMsd0JBQXdCLFNBQVMsVUFBVSxRQUFRLFlBQVk7Q0FDdEUsSUFBSSxNQUFNLFFBQVEsVUFBVSxrQkFBa0IsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTO0NBQ2xFLElBQUksT0FBTyxFQUNULE9BQ0Y7Q0FDQSxJQUFJLGNBQWMsaUJBQWlCLFdBQVcsVUFBVSxHQUFHO0VBQ3pELElBQUksRUFDRixZQUNBLGdCQUNFO0VBSUosS0FBSyxTQUFTLFdBQVcsWUFBWTtFQUNyQyxJQUFJLGdCQUFnQixvQkFBb0I7R0FDdEMsS0FBSyxVQUFVLElBQUksUUFBUSxFQUN6QixnQkFBZ0IsWUFDbEIsQ0FBQztHQUNELEtBQUssT0FBTyxLQUFLLFVBQVUsV0FBVyxJQUFJO0VBQzVDLE9BQU8sSUFBSSxnQkFBZ0IsY0FFekIsS0FBSyxPQUFPLFdBQVc7T0FDbEIsSUFBSSxnQkFBZ0IsdUNBQXVDLFdBQVcsVUFFM0UsS0FBSyxPQUFPLDhCQUE4QixXQUFXLFFBQVE7T0FHN0QsS0FBSyxPQUFPLFdBQVc7Q0FFM0I7Q0FDQSxPQUFPLElBQUksUUFBUSxLQUFLLElBQUk7QUFDOUI7QUFDQSxTQUFTLDhCQUE4QixVQUFVO0NBQy9DLElBQUksZUFBZSxJQUFJLGdCQUFnQjtDQUN2QyxLQUFLLElBQUksQ0FBQyxLQUFLLFVBQVUsU0FBUyxRQUFRLEdBRXhDLGFBQWEsT0FBTyxLQUFLLE9BQU8sVUFBVSxXQUFXLFFBQVEsTUFBTSxJQUFJO0NBRXpFLE9BQU87QUFDVDtBQUNBLFNBQVMsOEJBQThCLGNBQWM7Q0FDbkQsSUFBSSxXQUFXLElBQUksU0FBUztDQUM1QixLQUFLLElBQUksQ0FBQyxLQUFLLFVBQVUsYUFBYSxRQUFRLEdBQzVDLFNBQVMsT0FBTyxLQUFLLEtBQUs7Q0FFNUIsT0FBTztBQUNUO0FBQ0EsU0FBUyx1QkFBdUIsU0FBUyxTQUFTLHFCQUFxQixpQkFBaUIseUJBQXlCO0NBRS9HLElBQUksYUFBYSxDQUFDO0NBQ2xCLElBQUksU0FBUztDQUNiLElBQUk7Q0FDSixJQUFJLGFBQWE7Q0FDakIsSUFBSSxnQkFBZ0IsQ0FBQztDQUNyQixJQUFJLGVBQWUsdUJBQXVCLGNBQWMsb0JBQW9CLEVBQUUsSUFBSSxvQkFBb0IsRUFBRSxDQUFDLFFBQVEsS0FBQTtDQUVqSCxRQUFRLFNBQVEsVUFBUztFQUN2QixJQUFJLEVBQUUsTUFBTSxNQUFNLE1BQU0sVUFDdEI7RUFFRixJQUFJLEtBQUssTUFBTSxNQUFNO0VBQ3JCLElBQUksU0FBUyxRQUFRO0VBQ3JCLFVBQVUsQ0FBQyxpQkFBaUIsTUFBTSxHQUFHLHFEQUFxRDtFQUMxRixJQUFJLGNBQWMsTUFBTSxHQUFHO0dBQ3pCLElBQUksUUFBUSxPQUFPO0dBSW5CLElBQUksaUJBQWlCLEtBQUEsR0FBVztJQUM5QixRQUFRO0lBQ1IsZUFBZSxLQUFBO0dBQ2pCO0dBQ0EsU0FBUyxVQUFVLENBQUM7R0FDcEIsSUFBSSx5QkFDRixPQUFPLE1BQU07UUFDUjtJQUlMLElBQUksZ0JBQWdCLG9CQUFvQixTQUFTLEVBQUU7SUFDbkQsSUFBSSxPQUFPLGNBQWMsTUFBTSxPQUFPLE1BQ3BDLE9BQU8sY0FBYyxNQUFNLE1BQU07R0FFckM7R0FFQSxXQUFXLE1BQU0sS0FBQTtHQUdqQixJQUFJLENBQUMsWUFBWTtJQUNmLGFBQWE7SUFDYixhQUFhLHFCQUFxQixPQUFPLEtBQUssSUFBSSxPQUFPLE1BQU0sU0FBUztHQUMxRTtHQUNBLElBQUksT0FBTyxTQUNULGNBQWMsTUFBTSxPQUFPO0VBRS9CLE9BQ0UsSUFBSSxpQkFBaUIsTUFBTSxHQUFHO0dBQzVCLGdCQUFnQixJQUFJLElBQUksT0FBTyxZQUFZO0dBQzNDLFdBQVcsTUFBTSxPQUFPLGFBQWE7R0FHckMsSUFBSSxPQUFPLGNBQWMsUUFBUSxPQUFPLGVBQWUsT0FBTyxDQUFDLFlBQzdELGFBQWEsT0FBTztHQUV0QixJQUFJLE9BQU8sU0FDVCxjQUFjLE1BQU0sT0FBTztFQUUvQixPQUFPO0dBQ0wsV0FBVyxNQUFNLE9BQU87R0FHeEIsSUFBSSxPQUFPLGNBQWMsT0FBTyxlQUFlLE9BQU8sQ0FBQyxZQUNyRCxhQUFhLE9BQU87R0FFdEIsSUFBSSxPQUFPLFNBQ1QsY0FBYyxNQUFNLE9BQU87RUFFL0I7Q0FFSixDQUFDO0NBSUQsSUFBSSxpQkFBaUIsS0FBQSxLQUFhLHFCQUFxQjtFQUNyRCxTQUFTLEdBQ04sb0JBQW9CLEtBQUssYUFDNUI7RUFDQSxXQUFXLG9CQUFvQixNQUFNLEtBQUE7Q0FDdkM7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBLFlBQVksY0FBYztFQUMxQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixPQUFPLFNBQVMsU0FBUyxxQkFBcUIsc0JBQXNCLGdCQUFnQixpQkFBaUI7Q0FDOUgsSUFBSSxFQUNGLFlBQ0EsV0FDRSx1QkFBdUIsU0FBUyxTQUFTLHFCQUFxQixpQkFBaUIsS0FDbkY7Q0FFQSxxQkFBcUIsU0FBUSxPQUFNO0VBQ2pDLElBQUksRUFDRixLQUNBLE9BQ0EsZUFDRTtFQUNKLElBQUksU0FBUyxlQUFlO0VBQzVCLFVBQVUsUUFBUSwyQ0FBMkM7RUFFN0QsSUFBSSxjQUFjLFdBQVcsT0FBTyxTQUVsQztPQUNLLElBQUksY0FBYyxNQUFNLEdBQUc7R0FDaEMsSUFBSSxnQkFBZ0Isb0JBQW9CLE1BQU0sU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJLE1BQU0sTUFBTSxFQUFFO0dBQzlGLElBQUksRUFBRSxVQUFVLE9BQU8sY0FBYyxNQUFNLE1BQ3pDLFNBQVNELFdBQVMsQ0FBQyxHQUFHLFFBQVEsR0FDM0IsY0FBYyxNQUFNLEtBQUssT0FBTyxNQUNuQyxDQUFDO0dBRUgsTUFBTSxTQUFTLE9BQU8sR0FBRztFQUMzQixPQUFPLElBQUksaUJBQWlCLE1BQU0sR0FHaEMsVUFBVSxPQUFPLHlDQUF5QztPQUNyRCxJQUFJLGlCQUFpQixNQUFNLEdBR2hDLFVBQVUsT0FBTyxpQ0FBaUM7T0FDN0M7R0FDTCxJQUFJLGNBQWMsZUFBZSxPQUFPLElBQUk7R0FDNUMsTUFBTSxTQUFTLElBQUksS0FBSyxXQUFXO0VBQ3JDO0NBQ0YsQ0FBQztDQUNELE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLFlBQVksZUFBZSxTQUFTLFFBQVE7Q0FDbkUsSUFBSSxtQkFBbUJBLFdBQVMsQ0FBQyxHQUFHLGFBQWE7Q0FDakQsS0FBSyxJQUFJLFNBQVMsU0FBUztFQUN6QixJQUFJLEtBQUssTUFBTSxNQUFNO0VBQ3JCLElBQUksY0FBYyxlQUFlLEVBQUUsR0FDN0I7T0FBQSxjQUFjLFFBQVEsS0FBQSxHQUN4QixpQkFBaUIsTUFBTSxjQUFjO0VBQUEsT0FFbEMsSUFBSSxXQUFXLFFBQVEsS0FBQSxLQUFhLE1BQU0sTUFBTSxRQUdyRCxpQkFBaUIsTUFBTSxXQUFXO0VBRXBDLElBQUksVUFBVSxPQUFPLGVBQWUsRUFBRSxHQUVwQztDQUVKO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyx1QkFBdUIscUJBQXFCO0NBQ25ELElBQUksQ0FBQyxxQkFDSCxPQUFPLENBQUM7Q0FFVixPQUFPLGNBQWMsb0JBQW9CLEVBQUUsSUFBSSxFQUU3QyxZQUFZLENBQUMsRUFDZixJQUFJLEVBQ0YsWUFBWSxHQUNULG9CQUFvQixLQUFLLG9CQUFvQixFQUFFLENBQUMsS0FDbkQsRUFDRjtBQUNGO0FBSUEsU0FBUyxvQkFBb0IsU0FBUyxTQUFTO0NBRTdDLFFBRHNCLFVBQVUsUUFBUSxNQUFNLEdBQUcsUUFBUSxXQUFVLE1BQUssRUFBRSxNQUFNLE9BQU8sT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxFQUFBLENBQzNGLFFBQVEsQ0FBQyxDQUFDLE1BQUssTUFBSyxFQUFFLE1BQU0scUJBQXFCLElBQUksS0FBSyxRQUFRO0FBQzNGO0FBQ0EsU0FBUyx1QkFBdUIsUUFBUTtDQUV0QyxJQUFJLFFBQVEsT0FBTyxXQUFXLElBQUksT0FBTyxLQUFLLE9BQU8sTUFBSyxNQUFLLEVBQUUsU0FBUyxDQUFDLEVBQUUsUUFBUSxFQUFFLFNBQVMsR0FBRyxLQUFLLEVBQ3RHLElBQUksdUJBQ047Q0FDQSxPQUFPO0VBQ0wsU0FBUyxDQUFDO0dBQ1IsUUFBUSxDQUFDO0dBQ1QsVUFBVTtHQUNWLGNBQWM7R0FDZDtFQUNGLENBQUM7RUFDRDtDQUNGO0FBQ0Y7QUFDQSxTQUFTLHVCQUF1QixRQUFRLFFBQVE7Q0FDOUMsSUFBSSxFQUNGLFVBQ0EsU0FDQSxRQUNBLE1BQ0EsWUFDRSxXQUFXLEtBQUssSUFBSSxDQUFDLElBQUk7Q0FDN0IsSUFBSSxhQUFhO0NBQ2pCLElBQUksZUFBZTtDQUNuQixJQUFJLFdBQVcsS0FBSztFQUNsQixhQUFhO0VBQ2IsSUFBSSxVQUFVLFlBQVksU0FDeEIsZUFBZSxnQkFBZ0IsU0FBUyxtQkFBbUIsV0FBVyxhQUFhLDRDQUE0QyxVQUFVLFVBQVU7T0FDOUksSUFBSSxTQUFTLGdCQUNsQixlQUFlO09BQ1YsSUFBSSxTQUFTLGdCQUNsQixlQUFlO0NBRW5CLE9BQU8sSUFBSSxXQUFXLEtBQUs7RUFDekIsYUFBYTtFQUNiLGVBQWUsYUFBYSxVQUFVLDZCQUE2QixXQUFXO0NBQ2hGLE9BQU8sSUFBSSxXQUFXLEtBQUs7RUFDekIsYUFBYTtFQUNiLGVBQWUsNEJBQTRCLFdBQVc7Q0FDeEQsT0FBTyxJQUFJLFdBQVcsS0FBSztFQUN6QixhQUFhO0VBQ2IsSUFBSSxVQUFVLFlBQVksU0FDeEIsZUFBZSxnQkFBZ0IsT0FBTyxZQUFZLElBQUksbUJBQW1CLFdBQVcsYUFBYSw2Q0FBNkMsVUFBVSxVQUFVO09BQzdKLElBQUksUUFDVCxlQUFlLDhCQUE4QixPQUFPLFlBQVksSUFBSTtDQUV4RTtDQUNBLE9BQU8sSUFBSSxrQkFBa0IsVUFBVSxLQUFLLFlBQVksSUFBSSxNQUFNLFlBQVksR0FBRyxJQUFJO0FBQ3ZGO0FBRUEsU0FBUyxhQUFhLFNBQVM7Q0FDN0IsSUFBSSxVQUFVLE9BQU8sUUFBUSxPQUFPO0NBQ3BDLEtBQUssSUFBSSxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0VBQzVDLElBQUksQ0FBQyxLQUFLLFVBQVUsUUFBUTtFQUM1QixJQUFJLGlCQUFpQixNQUFNLEdBQ3pCLE9BQU87R0FDTDtHQUNBO0VBQ0Y7Q0FFSjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUMvQixJQUFJLGFBQWEsT0FBTyxTQUFTLFdBQVcsVUFBVSxJQUFJLElBQUk7Q0FDOUQsT0FBTyxXQUFXQSxXQUFTLENBQUMsR0FBRyxZQUFZLEVBQ3pDLE1BQU0sR0FDUixDQUFDLENBQUM7QUFDSjtBQUNBLFNBQVMsaUJBQWlCLEdBQUcsR0FBRztDQUM5QixJQUFJLEVBQUUsYUFBYSxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsUUFDOUMsT0FBTztDQUVULElBQUksRUFBRSxTQUFTLElBRWIsT0FBTyxFQUFFLFNBQVM7TUFDYixJQUFJLEVBQUUsU0FBUyxFQUFFLE1BRXRCLE9BQU87TUFDRixJQUFJLEVBQUUsU0FBUyxJQUVwQixPQUFPO0NBSVQsT0FBTztBQUNUO0FBSUEsU0FBUyxtQ0FBbUMsUUFBUTtDQUNsRCxPQUFPLFdBQVcsT0FBTyxNQUFNLEtBQUssb0JBQW9CLElBQUksT0FBTyxPQUFPLE1BQU07QUFDbEY7QUFDQSxTQUFTLGlCQUFpQixRQUFRO0NBQ2hDLE9BQU8sT0FBTyxTQUFTLFdBQVc7QUFDcEM7QUFDQSxTQUFTLGNBQWMsUUFBUTtDQUM3QixPQUFPLE9BQU8sU0FBUyxXQUFXO0FBQ3BDO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUTtDQUNoQyxRQUFRLFVBQVUsT0FBTyxVQUFVLFdBQVc7QUFDaEQ7QUFDQSxTQUFTLHVCQUF1QixPQUFPO0NBQ3JDLE9BQU8sT0FBTyxVQUFVLFlBQVksU0FBUyxRQUFRLFVBQVUsU0FBUyxVQUFVLFNBQVMsVUFBVSxTQUFTLE1BQU0sU0FBUztBQUMvSDtBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLElBQUksV0FBVztDQUNmLE9BQU8sWUFBWSxPQUFPLGFBQWEsWUFBWSxPQUFPLFNBQVMsU0FBUyxZQUFZLE9BQU8sU0FBUyxjQUFjLGNBQWMsT0FBTyxTQUFTLFdBQVcsY0FBYyxPQUFPLFNBQVMsZ0JBQWdCO0FBQy9NO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDekIsT0FBTyxTQUFTLFFBQVEsT0FBTyxNQUFNLFdBQVcsWUFBWSxPQUFPLE1BQU0sZUFBZSxZQUFZLE9BQU8sTUFBTSxZQUFZLFlBQVksT0FBTyxNQUFNLFNBQVM7QUFDaks7QUFTQSxTQUFTLGNBQWMsUUFBUTtDQUM3QixPQUFPLG9CQUFvQixJQUFJLE9BQU8sWUFBWSxDQUFDO0FBQ3JEO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUTtDQUNoQyxPQUFPLHFCQUFxQixJQUFJLE9BQU8sWUFBWSxDQUFDO0FBQ3REO0FBQ0EsZUFBZSxpQ0FBaUMsU0FBUyxTQUFTLFFBQVEsZ0JBQWdCLG1CQUFtQjtDQUMzRyxJQUFJLFVBQVUsT0FBTyxRQUFRLE9BQU87Q0FDcEMsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0VBQ25ELElBQUksQ0FBQyxTQUFTLFVBQVUsUUFBUTtFQUNoQyxJQUFJLFFBQVEsUUFBUSxNQUFLLE9BQU0sS0FBSyxPQUFPLEtBQUssSUFBSSxFQUFFLE1BQU0sUUFBUSxPQUFPO0VBSTNFLElBQUksQ0FBQyxPQUNIO0VBRUYsSUFBSSxlQUFlLGVBQWUsTUFBSyxNQUFLLEVBQUUsTUFBTSxPQUFPLE1BQU0sTUFBTSxFQUFFO0VBQ3pFLElBQUksdUJBQXVCLGdCQUFnQixRQUFRLENBQUMsbUJBQW1CLGNBQWMsS0FBSyxNQUFNLHFCQUFxQixrQkFBa0IsTUFBTSxNQUFNLFNBQVMsS0FBQTtFQUM1SixJQUFJLGlCQUFpQixNQUFNLEtBQUssc0JBSTlCLE1BQU0sb0JBQW9CLFFBQVEsUUFBUSxLQUFLLENBQUMsQ0FBQyxNQUFLLFdBQVU7R0FDOUQsSUFBSSxRQUNGLFFBQVEsV0FBVztFQUV2QixDQUFDO0NBRUw7QUFDRjtBQUNBLGVBQWUsOEJBQThCLFNBQVMsU0FBUyxzQkFBc0I7Q0FDbkYsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLHFCQUFxQixRQUFRLFNBQVM7RUFDaEUsSUFBSSxFQUNGLEtBQ0EsU0FDQSxlQUNFLHFCQUFxQjtFQUN6QixJQUFJLFNBQVMsUUFBUTtFQUtyQixJQUFJLENBSlEsUUFBUSxNQUFLLE9BQU0sS0FBSyxPQUFPLEtBQUssSUFBSSxFQUFFLE1BQU0sUUFBUSxPQUkzRCxHQUNQO0VBRUYsSUFBSSxpQkFBaUIsTUFBTSxHQUFHO0dBSTVCLFVBQVUsWUFBWSxzRUFBc0U7R0FDNUYsTUFBTSxvQkFBb0IsUUFBUSxXQUFXLFFBQVEsSUFBSSxDQUFDLENBQUMsTUFBSyxXQUFVO0lBQ3hFLElBQUksUUFDRixRQUFRLE9BQU87R0FFbkIsQ0FBQztFQUNIO0NBQ0Y7QUFDRjtBQUNBLGVBQWUsb0JBQW9CLFFBQVEsUUFBUSxRQUFRO0NBQ3pELElBQUksV0FBVyxLQUFLLEdBQ2xCLFNBQVM7Q0FHWCxJQUFJLE1BRGdCLE9BQU8sYUFBYSxZQUFZLE1BQU0sR0FFeEQ7Q0FFRixJQUFJLFFBQ0YsSUFBSTtFQUNGLE9BQU87R0FDTCxNQUFNLFdBQVc7R0FDakIsTUFBTSxPQUFPLGFBQWE7RUFDNUI7Q0FDRixTQUFTLEdBQUc7RUFFVixPQUFPO0dBQ0wsTUFBTSxXQUFXO0dBQ2pCLE9BQU87RUFDVDtDQUNGO0NBRUYsT0FBTztFQUNMLE1BQU0sV0FBVztFQUNqQixNQUFNLE9BQU8sYUFBYTtDQUM1QjtBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsUUFBUTtDQUNsQyxPQUFPLElBQUksZ0JBQWdCLE1BQU0sQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsTUFBSyxNQUFLLE1BQU0sRUFBRTtBQUN2RTtBQUNBLFNBQVMsZUFBZSxTQUFTLFVBQVU7Q0FDekMsSUFBSSxTQUFTLE9BQU8sYUFBYSxXQUFXLFVBQVUsUUFBUSxDQUFDLENBQUMsU0FBUyxTQUFTO0NBQ2xGLElBQUksUUFBUSxRQUFRLFNBQVMsRUFBRSxDQUFDLE1BQU0sU0FBUyxtQkFBbUIsVUFBVSxFQUFFLEdBRTVFLE9BQU8sUUFBUSxRQUFRLFNBQVM7Q0FJbEMsSUFBSSxjQUFjLDJCQUEyQixPQUFPO0NBQ3BELE9BQU8sWUFBWSxZQUFZLFNBQVM7QUFDMUM7QUFDQSxTQUFTLDRCQUE0QixZQUFZO0NBQy9DLElBQUksRUFDRixZQUNBLFlBQ0EsYUFDQSxNQUNBLFVBQ0EsU0FDRTtDQUNKLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLGFBQ2pDO0NBRUYsSUFBSSxRQUFRLE1BQ1YsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBLFVBQVUsS0FBQTtFQUNWLE1BQU0sS0FBQTtFQUNOO0NBQ0Y7TUFDSyxJQUFJLFlBQVksTUFDckIsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsTUFBTSxLQUFBO0VBQ04sTUFBTSxLQUFBO0NBQ1I7TUFDSyxJQUFJLFNBQVMsS0FBQSxHQUNsQixPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0EsVUFBVSxLQUFBO0VBQ1Y7RUFDQSxNQUFNLEtBQUE7Q0FDUjtBQUVKO0FBQ0EsU0FBUyxxQkFBcUIsVUFBVSxZQUFZO0NBQ2xELElBQUksWUFXRixPQUFPO0VBVEwsT0FBTztFQUNQO0VBQ0EsWUFBWSxXQUFXO0VBQ3ZCLFlBQVksV0FBVztFQUN2QixhQUFhLFdBQVc7RUFDeEIsVUFBVSxXQUFXO0VBQ3JCLE1BQU0sV0FBVztFQUNqQixNQUFNLFdBQVc7Q0FFSDtNQVloQixPQUFPO0VBVEwsT0FBTztFQUNQO0VBQ0EsWUFBWSxLQUFBO0VBQ1osWUFBWSxLQUFBO0VBQ1osYUFBYSxLQUFBO0VBQ2IsVUFBVSxLQUFBO0VBQ1YsTUFBTSxLQUFBO0VBQ04sTUFBTSxLQUFBO0NBRVE7QUFFcEI7QUFDQSxTQUFTLHdCQUF3QixVQUFVLFlBQVk7Q0FXckQsT0FBTztFQVRMLE9BQU87RUFDUDtFQUNBLFlBQVksV0FBVztFQUN2QixZQUFZLFdBQVc7RUFDdkIsYUFBYSxXQUFXO0VBQ3hCLFVBQVUsV0FBVztFQUNyQixNQUFNLFdBQVc7RUFDakIsTUFBTSxXQUFXO0NBRUg7QUFDbEI7QUFDQSxTQUFTLGtCQUFrQixZQUFZLE1BQU07Q0FDM0MsSUFBSSxZQVdGLE9BQU87RUFUTCxPQUFPO0VBQ1AsWUFBWSxXQUFXO0VBQ3ZCLFlBQVksV0FBVztFQUN2QixhQUFhLFdBQVc7RUFDeEIsVUFBVSxXQUFXO0VBQ3JCLE1BQU0sV0FBVztFQUNqQixNQUFNLFdBQVc7RUFDakI7Q0FFVztNQVliLE9BQU87RUFUTCxPQUFPO0VBQ1AsWUFBWSxLQUFBO0VBQ1osWUFBWSxLQUFBO0VBQ1osYUFBYSxLQUFBO0VBQ2IsVUFBVSxLQUFBO0VBQ1YsTUFBTSxLQUFBO0VBQ04sTUFBTSxLQUFBO0VBQ047Q0FFVztBQUVqQjtBQUNBLFNBQVMscUJBQXFCLFlBQVksaUJBQWlCO0NBV3pELE9BQU87RUFUTCxPQUFPO0VBQ1AsWUFBWSxXQUFXO0VBQ3ZCLFlBQVksV0FBVztFQUN2QixhQUFhLFdBQVc7RUFDeEIsVUFBVSxXQUFXO0VBQ3JCLE1BQU0sV0FBVztFQUNqQixNQUFNLFdBQVc7RUFDakIsTUFBTSxrQkFBa0IsZ0JBQWdCLE9BQU8sS0FBQTtDQUVwQztBQUNmO0FBQ0EsU0FBUyxlQUFlLE1BQU07Q0FXNUIsT0FBTztFQVRMLE9BQU87RUFDUCxZQUFZLEtBQUE7RUFDWixZQUFZLEtBQUE7RUFDWixhQUFhLEtBQUE7RUFDYixVQUFVLEtBQUE7RUFDVixNQUFNLEtBQUE7RUFDTixNQUFNLEtBQUE7RUFDTjtDQUVXO0FBQ2Y7QUFDQSxTQUFTLDBCQUEwQixTQUFTLGFBQWE7Q0FDdkQsSUFBSTtFQUNGLElBQUksbUJBQW1CLFFBQVEsZUFBZSxRQUFRLHVCQUF1QjtFQUM3RSxJQUFJLGtCQUFrQjtHQUNwQixJQUFJLE9BQU8sS0FBSyxNQUFNLGdCQUFnQjtHQUN0QyxLQUFLLElBQUksQ0FBQyxHQUFHLE1BQU0sT0FBTyxRQUFRLFFBQVEsQ0FBQyxDQUFDLEdBQzFDLElBQUksS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUN0QixZQUFZLElBQUksR0FBRyxJQUFJLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQztFQUd6QztDQUNGLFNBQVMsR0FBRyxDQUVaO0FBQ0Y7QUFDQSxTQUFTLDBCQUEwQixTQUFTLGFBQWE7Q0FDdkQsSUFBSSxZQUFZLE9BQU8sR0FBRztFQUN4QixJQUFJLE9BQU8sQ0FBQztFQUNaLEtBQUssSUFBSSxDQUFDLEdBQUcsTUFBTSxhQUNqQixLQUFLLEtBQUssQ0FBQyxHQUFHLENBQUM7RUFFakIsSUFBSTtHQUNGLFFBQVEsZUFBZSxRQUFRLHlCQUF5QixLQUFLLFVBQVUsSUFBSSxDQUFDO0VBQzlFLFNBQVMsT0FBTztHQUNkLFFBQVEsT0FBTyxnRUFBZ0UsUUFBUSxJQUFJO0VBQzdGO0NBQ0Y7QUFDRjs7Ozs7Ozs7Ozs7OztBQ3o3SkEsU0FBU0UsYUFBVztDQUNsQixPQUFPLGFBQVcsT0FBTyxTQUFTLE9BQU8sT0FBTyxLQUFLLElBQUksU0FBVSxHQUFHO0VBQ3BFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztHQUN6QyxJQUFJLElBQUksVUFBVTtHQUNsQixLQUFLLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFBLENBQUcsZUFBZSxLQUFLLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFO0VBQy9EO0VBQ0EsT0FBTztDQUNULEdBQUdBLFdBQVMsTUFBTSxNQUFNLFNBQVM7QUFDbkM7QUFLQSxJQUFNLG9CQUFpQywyQkFBTSxjQUFjLElBQUk7QUFFN0Qsa0JBQWtCLGNBQWM7QUFFbEMsSUFBTSx5QkFBc0MsMkJBQU0sY0FBYyxJQUFJO0FBRWxFLHVCQUF1QixjQUFjO0FBRXZDLElBQU0sZUFBNEIsMkJBQU0sY0FBYyxJQUFJO0FBRXhELGFBQWEsY0FBYzs7Ozs7Ozs7OztBQWE3QixJQUFNLG9CQUFpQywyQkFBTSxjQUFjLElBQUk7QUFFN0Qsa0JBQWtCLGNBQWM7QUFFbEMsSUFBTSxrQkFBK0IsMkJBQU0sY0FBYyxJQUFJO0FBRTNELGdCQUFnQixjQUFjO0FBRWhDLElBQU0sZUFBNEIsMkJBQU0sY0FBYztDQUNwRCxRQUFRO0NBQ1IsU0FBUyxDQUFDO0NBQ1YsYUFBYTtBQUNmLENBQUM7QUFFQyxhQUFhLGNBQWM7QUFFN0IsSUFBTSxvQkFBaUMsMkJBQU0sY0FBYyxJQUFJO0FBRTdELGtCQUFrQixjQUFjOzs7Ozs7O0FBU2xDLFNBQVMsUUFBUSxJQUFJLE9BQU87Q0FDMUIsSUFBSSxFQUNGLGFBQ0UsVUFBVSxLQUFLLElBQUksQ0FBQyxJQUFJO0NBQzVCLENBQUMsbUJBQW1CLEtBQTRDQyxVQUFpQixPQUVqRixvRUFBb0U7Q0FDcEUsSUFBSSxFQUNGLFVBQ0EsY0FBQSxhQUNRLFdBQVcsaUJBQWlCO0NBQ3RDLElBQUksRUFDRixNQUNBLFVBQ0EsV0FDRSxnQkFBZ0IsSUFBSSxFQUN0QixTQUNGLENBQUM7Q0FDRCxJQUFJLGlCQUFpQjtDQU1yQixJQUFJLGFBQWEsS0FDZixpQkFBaUIsYUFBYSxNQUFNLFdBQVcsVUFBVSxDQUFDLFVBQVUsUUFBUSxDQUFDO0NBRS9FLE9BQU8sVUFBVSxXQUFXO0VBQzFCLFVBQVU7RUFDVjtFQUNBO0NBQ0YsQ0FBQztBQUNIOzs7Ozs7QUFPQSxTQUFTLHFCQUFxQjtDQUM1QixPQUFBLGFBQWEsV0FBVyxlQUFlLEtBQUs7QUFDOUM7Ozs7Ozs7Ozs7O0FBWUEsU0FBUyxjQUFjO0NBQ3JCLENBQUMsbUJBQW1CLEtBQTRDQSxVQUFpQixPQUVqRix3RUFBd0U7Q0FDeEUsT0FBQSxhQUFhLFdBQVcsZUFBZSxDQUFDLENBQUM7QUFDM0M7Ozs7Ozs7QUFRQSxTQUFTLG9CQUFvQjtDQUMzQixPQUFBLGFBQWEsV0FBVyxlQUFlLENBQUMsQ0FBQztBQUMzQzs7Ozs7Ozs7QUFTQSxTQUFTLFNBQVMsU0FBUztDQUN6QixDQUFDLG1CQUFtQixLQUE0Q0EsVUFBaUIsT0FFakYscUVBQXFFO0NBQ3JFLElBQUksRUFDRixhQUNFLFlBQVk7Q0FDaEIsT0FBQSxhQUFhLGNBQWMsVUFBVSxTQUFTQyxXQUFrQixRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsT0FBTyxDQUFDO0FBQ2pHOzs7O0FBTUEsSUFBTSx3QkFBd0I7QUFHOUIsU0FBUywwQkFBMEIsSUFBSTtDQUVyQyxJQUFJLENBQUEsYUFEaUIsV0FBVyxpQkFBaUIsQ0FBQyxDQUFDLFFBS2pELGFBQU0sZ0JBQWdCLEVBQUU7QUFFNUI7Ozs7Ozs7QUFRQSxTQUFTLGNBQWM7Q0FDckIsSUFBSSxFQUNGLGdCQUFBLGFBQ1EsV0FBVyxZQUFZO0NBR2pDLE9BQU8sY0FBYyxrQkFBa0IsSUFBSSxvQkFBb0I7QUFDakU7QUFDQSxTQUFTLHNCQUFzQjtDQUM3QixDQUFDLG1CQUFtQixLQUE0Q0QsVUFBaUIsT0FFakYsd0VBQXdFO0NBQ3hFLElBQUksb0JBQUEsYUFBMEIsV0FBVyxpQkFBaUI7Q0FDMUQsSUFBSSxFQUNGLFVBQ0EsUUFDQSxjQUFBLGFBQ1EsV0FBVyxpQkFBaUI7Q0FDdEMsSUFBSSxFQUNGLFlBQUEsYUFDUSxXQUFXLFlBQVk7Q0FDakMsSUFBSSxFQUNGLFVBQVUscUJBQ1IsWUFBWTtDQUNoQixJQUFJLHFCQUFxQixLQUFLLFVBQVVFLG9CQUEyQixTQUFTLE9BQU8sb0JBQW9CLENBQUM7Q0FDeEcsSUFBSSxZQUFBLGFBQWtCLE9BQU8sS0FBSztDQUNsQyxnQ0FBZ0M7RUFDOUIsVUFBVSxVQUFVO0NBQ3RCLENBQUM7Q0EyQkQsT0FBQSxhQTFCcUIsWUFBWSxTQUFVLElBQUksU0FBUztFQUN0RCxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7RUFFYixRQUF1RCxVQUFVLFNBQVMscUJBQXFCO0VBSS9GLElBQUksQ0FBQyxVQUFVLFNBQVM7RUFDeEIsSUFBSSxPQUFPLE9BQU8sVUFBVTtHQUMxQixVQUFVLEdBQUcsRUFBRTtHQUNmO0VBQ0Y7RUFDQSxJQUFJLE9BQU8sVUFBVSxJQUFJLEtBQUssTUFBTSxrQkFBa0IsR0FBRyxrQkFBa0IsUUFBUSxhQUFhLE1BQU07RUFRdEcsSUFBSSxxQkFBcUIsUUFBUSxhQUFhLEtBQzVDLEtBQUssV0FBVyxLQUFLLGFBQWEsTUFBTSxXQUFXLFVBQVUsQ0FBQyxVQUFVLEtBQUssUUFBUSxDQUFDO0VBRXhGLENBQUMsQ0FBQyxDQUFDLFFBQVEsVUFBVSxVQUFVLFVBQVUsVUFBVSxLQUFBLENBQU0sTUFBTSxRQUFRLE9BQU8sT0FBTztDQUN2RixHQUFHO0VBQUM7RUFBVTtFQUFXO0VBQW9CO0VBQWtCO0NBQWlCLENBQ2xFO0FBQ2hCO0FBQ0EsSUFBTSxnQkFBNkIsMkJBQU0sY0FBYyxJQUFJOzs7Ozs7QUFPM0QsU0FBUyxtQkFBbUI7Q0FDMUIsT0FBQSxhQUFhLFdBQVcsYUFBYTtBQUN2Qzs7Ozs7OztBQVFBLFNBQVMsVUFBVSxTQUFTO0NBQzFCLElBQUksU0FBQSxhQUFlLFdBQVcsWUFBWSxDQUFDLENBQUM7Q0FDNUMsSUFBSSxRQUNGLE9BQW9CLDJCQUFNLGNBQWMsY0FBYyxVQUFVLEVBQzlELE9BQU8sUUFDVCxHQUFHLE1BQU07Q0FFWCxPQUFPO0FBQ1Q7Ozs7Ozs7QUFRQSxTQUFTLFlBQVk7Q0FDbkIsSUFBSSxFQUNGLFlBQUEsYUFDUSxXQUFXLFlBQVk7Q0FDakMsSUFBSSxhQUFhLFFBQVEsUUFBUSxTQUFTO0NBQzFDLE9BQU8sYUFBYSxXQUFXLFNBQVMsQ0FBQztBQUMzQzs7Ozs7O0FBT0EsU0FBUyxnQkFBZ0IsSUFBSSxRQUFRO0NBQ25DLElBQUksRUFDRixhQUNFLFdBQVcsS0FBSyxJQUFJLENBQUMsSUFBSTtDQUM3QixJQUFJLEVBQ0YsV0FBQSxhQUNRLFdBQVcsaUJBQWlCO0NBQ3RDLElBQUksRUFDRixZQUFBLGFBQ1EsV0FBVyxZQUFZO0NBQ2pDLElBQUksRUFDRixVQUFVLHFCQUNSLFlBQVk7Q0FDaEIsSUFBSSxxQkFBcUIsS0FBSyxVQUFVQSxvQkFBMkIsU0FBUyxPQUFPLG9CQUFvQixDQUFDO0NBQ3hHLE9BQUEsYUFBYSxjQUFjLFVBQVUsSUFBSSxLQUFLLE1BQU0sa0JBQWtCLEdBQUcsa0JBQWtCLGFBQWEsTUFBTSxHQUFHO0VBQUM7RUFBSTtFQUFvQjtFQUFrQjtDQUFRLENBQUM7QUFDdks7Ozs7Ozs7OztBQVVBLFNBQVMsVUFBVSxRQUFRLGFBQWE7Q0FDdEMsT0FBTyxjQUFjLFFBQVEsV0FBVztBQUMxQztBQUdBLFNBQVMsY0FBYyxRQUFRLGFBQWEsaUJBQWlCLFFBQVE7Q0FDbkUsQ0FBQyxtQkFBbUIsS0FBNENGLFVBQWlCLE9BRWpGLHNFQUFzRTtDQUN0RSxJQUFJLEVBQ0YsY0FBQSxhQUNRLFdBQVcsaUJBQWlCO0NBQ3RDLElBQUksRUFDRixTQUFTLGtCQUFBLGFBQ0QsV0FBVyxZQUFZO0NBQ2pDLElBQUksYUFBYSxjQUFjLGNBQWMsU0FBUztDQUN0RCxJQUFJLGVBQWUsYUFBYSxXQUFXLFNBQVMsQ0FBQztDQUNyRCxJQUFJLGlCQUFpQixhQUFhLFdBQVcsV0FBVztDQUN4RCxJQUFJLHFCQUFxQixhQUFhLFdBQVcsZUFBZTtDQUNoRSxJQUFJLGNBQWMsY0FBYyxXQUFXO0NBQ0E7RUFxQnpDLElBQUksYUFBYSxlQUFlLFlBQVksUUFBUTtFQUNwRCxZQUFZLGdCQUFnQixDQUFDLGVBQWUsV0FBVyxTQUFTLEdBQUcsR0FBRyxvRUFBb0UsT0FBTyxpQkFBaUIsNkJBQTZCLGFBQWEsbUJBQW1CLHNLQUFnTCw0Q0FBNEMsYUFBYSxxQkFBcUIsYUFBYSxlQUFlLE1BQU0sTUFBTSxhQUFhLFFBQVEsT0FBTztDQUNuaUI7Q0FDQSxJQUFJLHNCQUFzQixZQUFZO0NBQ3RDLElBQUk7Q0FDSixJQUFJLGFBQWE7RUFDZixJQUFJO0VBQ0osSUFBSSxvQkFBb0IsT0FBTyxnQkFBZ0IsV0FBVyxVQUFVLFdBQVcsSUFBSTtFQUNuRixFQUFFLHVCQUF1QixTQUFTLHdCQUF3QixrQkFBa0IsYUFBYSxPQUFPLEtBQUssSUFBSSxzQkFBc0IsV0FBVyxrQkFBa0IsT0FBOENBLFVBQWlCLE9BQU8sOEtBQW1MLGtFQUFrRSxxQkFBcUIsVUFBVSxvQkFBb0Isa0JBQWtCLFdBQVcsdUNBQXVDO0VBQzlrQixXQUFXO0NBQ2IsT0FDRSxXQUFXO0NBRWIsSUFBSSxXQUFXLFNBQVMsWUFBWTtDQUNwQyxJQUFJLG9CQUFvQjtDQUN4QixJQUFJLHVCQUF1QixLQUFLO0VBZTlCLElBQUksaUJBQWlCLG1CQUFtQixRQUFRLE9BQU8sRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHO0VBRXBFLG9CQUFvQixNQURMLFNBQVMsUUFBUSxPQUFPLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FDaEIsQ0FBQyxDQUFDLE1BQU0sZUFBZSxNQUFNLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDMUU7Q0FDQSxJQUFJLFVBQVUsWUFBWSxRQUFRLEVBQ2hDLFVBQVUsa0JBQ1osQ0FBQztDQUVDLFFBQXVELGVBQWUsV0FBVyxNQUFNLGtDQUFrQyxTQUFTLFdBQVcsU0FBUyxTQUFTLFNBQVMsT0FBTyxLQUFLO0NBQ3BMLFFBQXVELFdBQVcsUUFBUSxRQUFRLFFBQVEsU0FBUyxFQUFFLENBQUMsTUFBTSxZQUFZLEtBQUEsS0FBYSxRQUFRLFFBQVEsU0FBUyxFQUFFLENBQUMsTUFBTSxjQUFjLEtBQUEsS0FBYSxRQUFRLFFBQVEsU0FBUyxFQUFFLENBQUMsTUFBTSxTQUFTLEtBQUEsR0FBVyxzQ0FBc0MsU0FBUyxXQUFXLFNBQVMsU0FBUyxTQUFTLE9BQU8sZ0pBQTBKO0NBRWhmLElBQUksa0JBQWtCLGVBQWUsV0FBVyxRQUFRLEtBQUksVUFBUyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU87RUFDNUYsUUFBUSxPQUFPLE9BQU8sQ0FBQyxHQUFHLGNBQWMsTUFBTSxNQUFNO0VBQ3BELFVBQVUsVUFBVSxDQUFDLG9CQUVyQixVQUFVLGlCQUFpQixVQUFVLGVBQWUsTUFBTSxRQUFRLENBQUMsQ0FBQyxXQUFXLE1BQU0sUUFBUSxDQUFDO0VBQzlGLGNBQWMsTUFBTSxpQkFBaUIsTUFBTSxxQkFBcUIsVUFBVSxDQUFDLG9CQUUzRSxVQUFVLGlCQUFpQixVQUFVLGVBQWUsTUFBTSxZQUFZLENBQUMsQ0FBQyxXQUFXLE1BQU0sWUFBWSxDQUFDO0NBQ3hHLENBQUMsQ0FBQyxHQUFHLGVBQWUsaUJBQWlCLE1BQU07Q0FLM0MsSUFBSSxlQUFlLGlCQUNqQixPQUFvQiwyQkFBTSxjQUFjLGdCQUFnQixVQUFVLEVBQ2hFLE9BQU87RUFDTCxVQUFVRCxXQUFTO0dBQ2pCLFVBQVU7R0FDVixRQUFRO0dBQ1IsTUFBTTtHQUNOLE9BQU87R0FDUCxLQUFLO0VBQ1AsR0FBRyxRQUFRO0VBQ1gsZ0JBQWdCLE9BQU87Q0FDekIsRUFDRixHQUFHLGVBQWU7Q0FFcEIsT0FBTztBQUNUO0FBQ0EsU0FBUyx3QkFBd0I7Q0FDL0IsSUFBSSxRQUFRLGNBQWM7Q0FDMUIsSUFBSSxVQUFVLHFCQUFxQixLQUFLLElBQUksTUFBTSxTQUFTLE1BQU0sTUFBTSxhQUFhLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxLQUFLLFVBQVUsS0FBSztDQUNqSixJQUFJLFFBQVEsaUJBQWlCLFFBQVEsTUFBTSxRQUFRO0NBQ25ELElBQUksWUFBWTtDQUNoQixJQUFJLFlBQVk7RUFDZCxTQUFTO0VBQ1QsaUJBQWlCO0NBQ25CO0NBQ0EsSUFBSSxhQUFhO0VBQ2YsU0FBUztFQUNULGlCQUFpQjtDQUNuQjtDQUNBLElBQUksVUFBVTtDQUVaLFFBQVEsTUFBTSx3REFBd0QsS0FBSztDQUMzRSxVQUF1QiwyQkFBTSxjQUFBLGFBQW9CLFVBQVUsTUFBbUIsMkJBQU0sY0FBYyxLQUFLLE1BQU0scUJBQXlDLEdBQWdCLDJCQUFNLGNBQWMsS0FBSyxNQUFNLGdHQUE2RywyQkFBTSxjQUFjLFFBQVEsRUFDNVUsT0FBTyxXQUNULEdBQUcsZUFBZSxHQUFHLE9BQU8sS0FBa0IsMkJBQU0sY0FBYyxRQUFRLEVBQ3hFLE9BQU8sV0FDVCxHQUFHLGNBQWMsR0FBRyxzQkFBc0IsQ0FBQztDQUU3QyxPQUFvQiwyQkFBTSxjQUFBLGFBQW9CLFVBQVUsTUFBbUIsMkJBQU0sY0FBYyxNQUFNLE1BQU0sK0JBQStCLEdBQWdCLDJCQUFNLGNBQWMsTUFBTSxFQUNsTCxPQUFPLEVBQ0wsV0FBVyxTQUNiLEVBQ0YsR0FBRyxPQUFPLEdBQUcsUUFBcUIsMkJBQU0sY0FBYyxPQUFPLEVBQzNELE9BQU8sVUFDVCxHQUFHLEtBQUssSUFBSSxNQUFNLE9BQU87QUFDM0I7QUFDQSxJQUFNLHNCQUFtQywyQkFBTSxjQUFjLHVCQUF1QixJQUFJO0FBQ3hGLElBQU0sc0JBQU4sY0FBQSxhQUF3QyxVQUFVO0NBQ2hELFlBQVksT0FBTztFQUNqQixNQUFNLEtBQUs7RUFDWCxLQUFLLFFBQVE7R0FDWCxVQUFVLE1BQU07R0FDaEIsY0FBYyxNQUFNO0dBQ3BCLE9BQU8sTUFBTTtFQUNmO0NBQ0Y7Q0FDQSxPQUFPLHlCQUF5QixPQUFPO0VBQ3JDLE9BQU8sRUFDRSxNQUNUO0NBQ0Y7Q0FDQSxPQUFPLHlCQUF5QixPQUFPLE9BQU87RUFTNUMsSUFBSSxNQUFNLGFBQWEsTUFBTSxZQUFZLE1BQU0saUJBQWlCLFVBQVUsTUFBTSxpQkFBaUIsUUFDL0YsT0FBTztHQUNMLE9BQU8sTUFBTTtHQUNiLFVBQVUsTUFBTTtHQUNoQixjQUFjLE1BQU07RUFDdEI7RUFPRixPQUFPO0dBQ0wsT0FBTyxNQUFNLFVBQVUsS0FBQSxJQUFZLE1BQU0sUUFBUSxNQUFNO0dBQ3ZELFVBQVUsTUFBTTtHQUNoQixjQUFjLE1BQU0sZ0JBQWdCLE1BQU07RUFDNUM7Q0FDRjtDQUNBLGtCQUFrQixPQUFPLFdBQVc7RUFDbEMsUUFBUSxNQUFNLHlEQUF5RCxPQUFPLFNBQVM7Q0FDekY7Q0FDQSxTQUFTO0VBQ1AsT0FBTyxLQUFLLE1BQU0sVUFBVSxLQUFBLElBQXlCLDJCQUFNLGNBQWMsYUFBYSxVQUFVLEVBQzlGLE9BQU8sS0FBSyxNQUFNLGFBQ3BCLEdBQWdCLDJCQUFNLGNBQWMsa0JBQWtCLFVBQVU7R0FDOUQsT0FBTyxLQUFLLE1BQU07R0FDbEIsVUFBVSxLQUFLLE1BQU07RUFDdkIsQ0FBQyxDQUFDLElBQUksS0FBSyxNQUFNO0NBQ25CO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsTUFBTTtDQUMzQixJQUFJLEVBQ0YsY0FDQSxPQUNBLGFBQ0U7Q0FDSixJQUFJLG9CQUFBLGFBQTBCLFdBQVcsaUJBQWlCO0NBSTFELElBQUkscUJBQXFCLGtCQUFrQixVQUFVLGtCQUFrQixrQkFBa0IsTUFBTSxNQUFNLGdCQUFnQixNQUFNLE1BQU0sZ0JBQy9ILGtCQUFrQixjQUFjLDZCQUE2QixNQUFNLE1BQU07Q0FFM0UsT0FBb0IsMkJBQU0sY0FBYyxhQUFhLFVBQVUsRUFDN0QsT0FBTyxhQUNULEdBQUcsUUFBUTtBQUNiO0FBQ0EsU0FBUyxlQUFlLFNBQVMsZUFBZSxpQkFBaUIsUUFBUTtDQUN2RSxJQUFJO0NBQ0osSUFBSSxrQkFBa0IsS0FBSyxHQUN6QixnQkFBZ0IsQ0FBQztDQUVuQixJQUFJLG9CQUFvQixLQUFLLEdBQzNCLGtCQUFrQjtDQUVwQixJQUFJLFdBQVcsS0FBSyxHQUNsQixTQUFTO0NBRVgsSUFBSSxXQUFXLE1BQU07RUFDbkIsSUFBSTtFQUNKLElBQUksQ0FBQyxpQkFDSCxPQUFPO0VBRVQsSUFBSSxnQkFBZ0IsUUFHbEIsVUFBVSxnQkFBZ0I7T0FDckIsS0FBSyxVQUFVLFdBQVcsUUFBUSxRQUFRLHVCQUF1QixjQUFjLFdBQVcsS0FBSyxDQUFDLGdCQUFnQixlQUFlLGdCQUFnQixRQUFRLFNBQVMsR0FPckssVUFBVSxnQkFBZ0I7T0FFMUIsT0FBTztDQUVYO0NBQ0EsSUFBSSxrQkFBa0I7Q0FHdEIsSUFBSSxVQUFVLG1CQUFtQixvQkFBb0IsT0FBTyxLQUFLLElBQUksaUJBQWlCO0NBQ3RGLElBQUksVUFBVSxNQUFNO0VBQ2xCLElBQUksYUFBYSxnQkFBZ0IsV0FBVSxNQUFLLEVBQUUsTUFBTSxPQUFPLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTyxFQUFFLE1BQU0sU0FBUyxLQUFBLENBQVM7RUFDMUgsRUFBRSxjQUFjLE1BQTZDQyxVQUFpQixPQUFPLDhEQUE4RCxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUM7RUFDaEwsa0JBQWtCLGdCQUFnQixNQUFNLEdBQUcsS0FBSyxJQUFJLGdCQUFnQixRQUFRLGFBQWEsQ0FBQyxDQUFDO0NBQzdGO0NBSUEsSUFBSSxpQkFBaUI7Q0FDckIsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxtQkFBbUIsVUFBVSxPQUFPLHFCQUN0QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksZ0JBQWdCLFFBQVEsS0FBSztFQUMvQyxJQUFJLFFBQVEsZ0JBQWdCO0VBRTVCLElBQUksTUFBTSxNQUFNLG1CQUFtQixNQUFNLE1BQU0sd0JBQzdDLGdCQUFnQjtFQUVsQixJQUFJLE1BQU0sTUFBTSxJQUFJO0dBQ2xCLElBQUksRUFDRixZQUNBLFdBQ0U7R0FDSixJQUFJLG1CQUFtQixNQUFNLE1BQU0sVUFBVSxXQUFXLE1BQU0sTUFBTSxRQUFRLEtBQUEsTUFBYyxDQUFDLFVBQVUsT0FBTyxNQUFNLE1BQU0sUUFBUSxLQUFBO0dBQ2hJLElBQUksTUFBTSxNQUFNLFFBQVEsa0JBQWtCO0lBSXhDLGlCQUFpQjtJQUNqQixJQUFJLGlCQUFpQixHQUNuQixrQkFBa0IsZ0JBQWdCLE1BQU0sR0FBRyxnQkFBZ0IsQ0FBQztTQUU1RCxrQkFBa0IsQ0FBQyxnQkFBZ0IsRUFBRTtJQUV2QztHQUNGO0VBQ0Y7Q0FDRjtDQUVGLE9BQU8sZ0JBQWdCLGFBQWEsUUFBUSxPQUFPLFVBQVU7RUFFM0QsSUFBSTtFQUNKLElBQUksOEJBQThCO0VBQ2xDLElBQUksZUFBZTtFQUNuQixJQUFJLHlCQUF5QjtFQUM3QixJQUFJLGlCQUFpQjtHQUNuQixRQUFRLFVBQVUsTUFBTSxNQUFNLEtBQUssT0FBTyxNQUFNLE1BQU0sTUFBTSxLQUFBO0dBQzVELGVBQWUsTUFBTSxNQUFNLGdCQUFnQjtHQUMzQyxJQUFJLGdCQUFnQjtJQUNsQixJQUFJLGdCQUFnQixLQUFLLFVBQVUsR0FBRztLQUNwQyxZQUFZLGtCQUFrQixPQUFPLDBFQUEwRTtLQUMvRyw4QkFBOEI7S0FDOUIseUJBQXlCO0lBQzNCLE9BQU8sSUFBSSxrQkFBa0IsT0FBTztLQUNsQyw4QkFBOEI7S0FDOUIseUJBQXlCLE1BQU0sTUFBTSwwQkFBMEI7SUFDakU7R0FDRjtFQUNGO0VBQ0EsSUFBSSxVQUFVLGNBQWMsT0FBTyxnQkFBZ0IsTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDO0VBQ3RFLElBQUksb0JBQW9CO0dBQ3RCLElBQUk7R0FDSixJQUFJLE9BQ0YsV0FBVztRQUNOLElBQUksNkJBQ1QsV0FBVztRQUNOLElBQUksTUFBTSxNQUFNLFdBT3JCLFdBQXdCLDJCQUFNLGNBQWMsTUFBTSxNQUFNLFdBQVcsSUFBSTtRQUNsRSxJQUFJLE1BQU0sTUFBTSxTQUNyQixXQUFXLE1BQU0sTUFBTTtRQUV2QixXQUFXO0dBRWIsT0FBb0IsMkJBQU0sY0FBYyxlQUFlO0lBQzlDO0lBQ1AsY0FBYztLQUNaO0tBQ0E7S0FDQSxhQUFhLG1CQUFtQjtJQUNsQztJQUNVO0dBQ1osQ0FBQztFQUNIO0VBSUEsT0FBTyxvQkFBb0IsTUFBTSxNQUFNLGlCQUFpQixNQUFNLE1BQU0sZ0JBQWdCLFVBQVUsS0FBa0IsMkJBQU0sY0FBYyxxQkFBcUI7R0FDdkosVUFBVSxnQkFBZ0I7R0FDMUIsY0FBYyxnQkFBZ0I7R0FDOUIsV0FBVztHQUNKO0dBQ1AsVUFBVSxZQUFZO0dBQ3RCLGNBQWM7SUFDWixRQUFRO0lBQ1I7SUFDQSxhQUFhO0dBQ2Y7RUFDRixDQUFDLElBQUksWUFBWTtDQUNuQixHQUFHLElBQUk7QUFDVDtBQUNBLElBQUlJLG1CQUE4Qix1QkFBVSxnQkFBZ0I7Q0FDMUQsZUFBZSxnQkFBZ0I7Q0FDL0IsZUFBZSxvQkFBb0I7Q0FDbkMsZUFBZSx1QkFBdUI7Q0FDdEMsT0FBTztBQUNULEVBQUVBLG9CQUFrQixDQUFDLENBQUM7QUFDdEIsSUFBSUMsd0JBQW1DLHVCQUFVLHFCQUFxQjtDQUNwRSxvQkFBb0IsZ0JBQWdCO0NBQ3BDLG9CQUFvQixtQkFBbUI7Q0FDdkMsb0JBQW9CLG1CQUFtQjtDQUN2QyxvQkFBb0IsbUJBQW1CO0NBQ3ZDLG9CQUFvQixtQkFBbUI7Q0FDdkMsb0JBQW9CLHdCQUF3QjtDQUM1QyxvQkFBb0IsZ0JBQWdCO0NBQ3BDLG9CQUFvQixvQkFBb0I7Q0FDeEMsb0JBQW9CLHVCQUF1QjtDQUMzQyxvQkFBb0IsZ0JBQWdCO0NBQ3BDLE9BQU87QUFDVCxFQUFFQSx5QkFBdUIsQ0FBQyxDQUFDO0FBQzNCLFNBQVNDLDRCQUEwQixVQUFVO0NBQzNDLE9BQU8sV0FBVztBQUNwQjtBQUNBLFNBQVNDLHVCQUFxQixVQUFVO0NBQ3RDLElBQUksTUFBQSxhQUFZLFdBQVcsaUJBQWlCO0NBQzVDLENBQUMsT0FBOENQLFVBQWlCLE9BQU9NLDRCQUEwQixRQUFRLENBQUM7Q0FDMUcsT0FBTztBQUNUO0FBQ0EsU0FBU0UscUJBQW1CLFVBQVU7Q0FDcEMsSUFBSSxRQUFBLGFBQWMsV0FBVyxzQkFBc0I7Q0FDbkQsQ0FBQyxTQUFnRFIsVUFBaUIsT0FBT00sNEJBQTBCLFFBQVEsQ0FBQztDQUM1RyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQixVQUFVO0NBQ2pDLElBQUksUUFBQSxhQUFjLFdBQVcsWUFBWTtDQUN6QyxDQUFDLFNBQWdETixVQUFpQixPQUFPTSw0QkFBMEIsUUFBUSxDQUFDO0NBQzVHLE9BQU87QUFDVDtBQUdBLFNBQVMsa0JBQWtCLFVBQVU7Q0FDbkMsSUFBSSxRQUFRLGdCQUFnQixRQUFRO0NBQ3BDLElBQUksWUFBWSxNQUFNLFFBQVEsTUFBTSxRQUFRLFNBQVM7Q0FDckQsQ0FBQyxVQUFVLE1BQU0sTUFBNkNOLFVBQWlCLE9BQU8sV0FBVywwREFBMEQ7Q0FDM0osT0FBTyxVQUFVLE1BQU07QUFDekI7Ozs7QUFLQSxTQUFTLGFBQWE7Q0FDcEIsT0FBTyxrQkFBa0JLLHNCQUFvQixVQUFVO0FBQ3pEOzs7OztBQU1BLFNBQVMsZ0JBQWdCO0NBRXZCLE9BRFlHLHFCQUFtQkgsc0JBQW9CLGFBQ3hDLENBQUMsQ0FBQztBQUNmOzs7OztBQU1BLFNBQVMsaUJBQWlCO0NBQ3hCLElBQUksb0JBQW9CRSx1QkFBcUJILGlCQUFlLGNBQWM7Q0FDMUUsSUFBSSxRQUFRSSxxQkFBbUJILHNCQUFvQixjQUFjO0NBQ2pFLE9BQUEsYUFBYSxlQUFlO0VBQzFCLFlBQVksa0JBQWtCLE9BQU87RUFDckMsT0FBTyxNQUFNO0NBQ2YsSUFBSSxDQUFDLGtCQUFrQixPQUFPLFlBQVksTUFBTSxZQUFZLENBQUM7QUFDL0Q7Ozs7O0FBTUEsU0FBUyxhQUFhO0NBQ3BCLElBQUksRUFDRixTQUNBLGVBQ0VHLHFCQUFtQkgsc0JBQW9CLFVBQVU7Q0FDckQsT0FBQSxhQUFhLGNBQWMsUUFBUSxLQUFJLE1BQUtJLDJCQUFrQyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsU0FBUyxVQUFVLENBQUM7QUFDdEg7Ozs7QUFLQSxTQUFTLGdCQUFnQjtDQUN2QixJQUFJLFFBQVFELHFCQUFtQkgsc0JBQW9CLGFBQWE7Q0FDaEUsSUFBSSxVQUFVLGtCQUFrQkEsc0JBQW9CLGFBQWE7Q0FDakUsSUFBSSxNQUFNLFVBQVUsTUFBTSxPQUFPLFlBQVksTUFBTTtFQUNqRCxRQUFRLE1BQU0sNkRBQTZELFVBQVUsR0FBRztFQUN4RjtDQUNGO0NBQ0EsT0FBTyxNQUFNLFdBQVc7QUFDMUI7Ozs7QUFLQSxTQUFTLG1CQUFtQixTQUFTO0NBRW5DLE9BRFlHLHFCQUFtQkgsc0JBQW9CLGtCQUN4QyxDQUFDLENBQUMsV0FBVztBQUMxQjs7OztBQUtBLFNBQVMsZ0JBQWdCO0NBQ3ZCLElBQUksUUFBUUcscUJBQW1CSCxzQkFBb0IsYUFBYTtDQUNoRSxJQUFJLFVBQVUsa0JBQWtCQSxzQkFBb0IsYUFBYTtDQUNqRSxPQUFPLE1BQU0sYUFBYSxNQUFNLFdBQVcsV0FBVyxLQUFBO0FBQ3hEOzs7Ozs7QUFPQSxTQUFTLGdCQUFnQjtDQUN2QixJQUFJO0NBQ0osSUFBSSxRQUFBLGFBQWMsV0FBVyxpQkFBaUI7Q0FDOUMsSUFBSSxRQUFRRyxxQkFBbUJILHNCQUFvQixhQUFhO0NBQ2hFLElBQUksVUFBVSxrQkFBa0JBLHNCQUFvQixhQUFhO0NBSWpFLElBQUksVUFBVSxLQUFBLEdBQ1osT0FBTztDQUlULFFBQVEsZ0JBQWdCLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxjQUFjO0FBQ3pFOzs7O0FBS0EsU0FBUyxnQkFBZ0I7Q0FDdkIsSUFBSSxRQUFBLGFBQWMsV0FBVyxZQUFZO0NBQ3pDLE9BQU8sU0FBUyxPQUFPLEtBQUssSUFBSSxNQUFNO0FBQ3hDOzs7O0FBS0EsU0FBUyxnQkFBZ0I7Q0FDdkIsSUFBSSxRQUFBLGFBQWMsV0FBVyxZQUFZO0NBQ3pDLE9BQU8sU0FBUyxPQUFPLEtBQUssSUFBSSxNQUFNO0FBQ3hDO0FBQ0EsSUFBSSxZQUFZOzs7Ozs7O0FBUWhCLFNBQVMsV0FBVyxhQUFhO0NBQy9CLElBQUksRUFDRixRQUNBLGFBQ0VFLHVCQUFxQkgsaUJBQWUsVUFBVTtDQUNsRCxJQUFJLFFBQVFJLHFCQUFtQkgsc0JBQW9CLFVBQVU7Q0FDN0QsSUFBSSxDQUFDLFlBQVksaUJBQUEsYUFBdUIsU0FBUyxFQUFFO0NBQ25ELElBQUksa0JBQUEsYUFBd0IsYUFBWSxRQUFPO0VBQzdDLElBQUksT0FBTyxnQkFBZ0IsWUFDekIsT0FBTyxDQUFDLENBQUM7RUFFWCxJQUFJLGFBQWEsS0FDZixPQUFPLFlBQVksR0FBRztFQU14QixJQUFJLEVBQ0YsaUJBQ0EsY0FDQSxrQkFDRTtFQUNKLE9BQU8sWUFBWTtHQUNqQixpQkFBaUJOLFdBQVMsQ0FBQyxHQUFHLGlCQUFpQixFQUM3QyxVQUFVLGNBQWMsZ0JBQWdCLFVBQVUsUUFBUSxLQUFLLGdCQUFnQixTQUNqRixDQUFDO0dBQ0QsY0FBY0EsV0FBUyxDQUFDLEdBQUcsY0FBYyxFQUN2QyxVQUFVLGNBQWMsYUFBYSxVQUFVLFFBQVEsS0FBSyxhQUFhLFNBQzNFLENBQUM7R0FDRDtFQUNGLENBQUM7Q0FDSCxHQUFHLENBQUMsVUFBVSxXQUFXLENBQUM7Q0FJMUIsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxNQUFNLE9BQU8sRUFBRSxTQUFTO0VBQzVCLGNBQWMsR0FBRztFQUNqQixhQUFhLE9BQU8sY0FBYyxHQUFHO0NBQ3ZDLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FNWCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLGVBQWUsSUFDakIsT0FBTyxXQUFXLFlBQVksZUFBZTtDQUVqRCxHQUFHO0VBQUM7RUFBUTtFQUFZO0NBQWUsQ0FBQztDQUl4QyxPQUFPLGNBQWMsTUFBTSxTQUFTLElBQUksVUFBVSxJQUFJLE1BQU0sU0FBUyxJQUFJLFVBQVUsSUFBSTtBQUN6Rjs7Ozs7QUFNQSxTQUFTLG9CQUFvQjtDQUMzQixJQUFJLEVBQ0YsV0FDRVEsdUJBQXFCSCxpQkFBZSxpQkFBaUI7Q0FDekQsSUFBSSxLQUFLLGtCQUFrQkMsc0JBQW9CLGlCQUFpQjtDQUNoRSxJQUFJLFlBQUEsYUFBa0IsT0FBTyxLQUFLO0NBQ2xDLGdDQUFnQztFQUM5QixVQUFVLFVBQVU7Q0FDdEIsQ0FBQztDQWtCRCxPQUFBLGFBakJxQixZQUFZLFNBQVUsSUFBSSxTQUFTO0VBQ3RELElBQUksWUFBWSxLQUFLLEdBQ25CLFVBQVUsQ0FBQztFQUViLFFBQXVELFVBQVUsU0FBUyxxQkFBcUI7RUFJL0YsSUFBSSxDQUFDLFVBQVUsU0FBUztFQUN4QixJQUFJLE9BQU8sT0FBTyxVQUNoQixPQUFPLFNBQVMsRUFBRTtPQUVsQixPQUFPLFNBQVMsSUFBSU4sV0FBUyxFQUMzQixhQUFhLEdBQ2YsR0FBRyxPQUFPLENBQUM7Q0FFZixHQUFHLENBQUMsUUFBUSxFQUFFLENBQ0E7QUFDaEI7QUFDQSxJQUFNLGtCQUFrQixDQUFDO0FBQ3pCLFNBQVMsWUFBWSxLQUFLLE1BQU0sU0FBUztDQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDLGdCQUFnQixNQUFNO0VBQ2xDLGdCQUFnQixPQUFPO0VBQ3ZCLFFBQXVELE9BQU8sT0FBTztDQUN2RTtBQUNGO0FBRUEsSUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixTQUFTLFNBQVMsS0FBSyxTQUFTO0NBQzlCLElBQTZDLENBQUMsY0FBYyxVQUFVO0VBQ3BFLGNBQWMsV0FBVztFQUN6QixRQUFRLEtBQUssT0FBTztDQUN0QjtBQUNGO0FBQ0EsSUFBTSxrQkFBa0IsTUFBTSxLQUFLLFNBQVMsU0FBUyxNQUFNLDBDQUFvRCxNQUFNLFFBQVEsc0JBQXNCLE9BQU8sc0NBQXNDLCtCQUErQixPQUFPLElBQUk7QUFDMU8sU0FBUyx5QkFBeUIsY0FBYyxjQUFjO0NBQzVELEtBQUssZ0JBQWdCLE9BQU8sS0FBSyxJQUFJLGFBQWEsd0JBQXdCLEtBQUEsR0FDeEUsZUFBZSxzQkFBc0IsbUZBQW1GLGdFQUFnRTtDQUUxTCxLQUFLLGdCQUFnQixPQUFPLEtBQUssSUFBSSxhQUFhLDBCQUEwQixLQUFBLE1BQWMsQ0FBQyxnQkFBZ0IsYUFBYSx5QkFBeUIsS0FBQSxJQUMvSSxlQUFlLHdCQUF3QixtRUFBbUUsa0VBQWtFO0NBRTlLLElBQUksY0FBYztFQUNoQixJQUFJLGFBQWEsc0JBQXNCLEtBQUEsR0FDckMsZUFBZSxxQkFBcUIsMERBQTBELCtEQUErRDtFQUUvSixJQUFJLGFBQWEsMkJBQTJCLEtBQUEsR0FDMUMsZUFBZSwwQkFBMEIsd0VBQXdFLG9FQUFvRTtFQUV2TCxJQUFJLGFBQWEsd0JBQXdCLEtBQUEsR0FDdkMsZUFBZSx1QkFBdUIseURBQXlELGlFQUFpRTtFQUVsSyxJQUFJLGFBQWEsbUNBQW1DLEtBQUEsR0FDbEQsZUFBZSxrQ0FBa0MsZ0ZBQWdGLDRFQUE0RTtDQUVqTjtBQUNGO0FBd0JBLElBQU1XLHdCQUFBQSxhQUE0QkM7Ozs7OztBQTZGbEMsU0FBUyxhQUFhLE9BQU87Q0FDM0IsSUFBSSxFQUNGLFVBQ0EsVUFDQSxnQkFDQSxjQUNBLFdBQ0U7Q0FDSixJQUFJLGFBQUEsYUFBbUIsT0FBTztDQUM5QixJQUFJLFdBQVcsV0FBVyxNQUN4QixXQUFXLFVBQVUsb0JBQW9CO0VBQ3ZDO0VBQ0E7RUFDQSxVQUFVO0NBQ1osQ0FBQztDQUVILElBQUksVUFBVSxXQUFXO0NBQ3pCLElBQUksQ0FBQyxPQUFPLGdCQUFBLGFBQXNCLFNBQVM7RUFDekMsUUFBUSxRQUFRO0VBQ2hCLFVBQVUsUUFBUTtDQUNwQixDQUFDO0NBQ0QsSUFBSSxFQUNGLHVCQUNFLFVBQVUsQ0FBQztDQUNmLElBQUksV0FBQSxhQUFpQixhQUFZLGFBQVk7RUFDM0Msc0JBQXNCRCx3QkFBc0JBLDRCQUEwQixhQUFhLFFBQVEsQ0FBQyxJQUFJLGFBQWEsUUFBUTtDQUN2SCxHQUFHLENBQUMsY0FBYyxrQkFBa0IsQ0FBQztDQUNyQyxhQUFNLHNCQUFzQixRQUFRLE9BQU8sUUFBUSxHQUFHLENBQUMsU0FBUyxRQUFRLENBQUM7Q0FDekUsYUFBTSxnQkFBZ0IseUJBQXlCLE1BQU0sR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUNoRSxPQUFvQiwyQkFBTSxjQUFjLFFBQVE7RUFDcEM7RUFDQTtFQUNWLFVBQVUsTUFBTTtFQUNoQixnQkFBZ0IsTUFBTTtFQUN0QixXQUFXO0VBQ0g7Q0FDVixDQUFDO0FBQ0g7Ozs7Ozs7Ozs7QUFVQSxTQUFTLFNBQVMsT0FBTztDQUN2QixJQUFJLEVBQ0YsSUFDQSxTQUNBLE9BQ0EsYUFDRTtDQUNKLENBQUMsbUJBQW1CLEtBQTRDVixVQUFpQixPQUVqRixxRUFBcUU7Q0FDckUsSUFBSSxFQUNGLFFBQ0EsUUFBUSxhQUFBLGFBQ0EsV0FBVyxpQkFBaUI7Q0FDdEMsUUFBdUQsQ0FBQyxVQUFVLHVOQUFpTztDQUNuUyxJQUFJLEVBQ0YsWUFBQSxhQUNRLFdBQVcsWUFBWTtDQUNqQyxJQUFJLEVBQ0YsVUFBVSxxQkFDUixZQUFZO0NBQ2hCLElBQUksV0FBVyxZQUFZO0NBSTNCLElBQUksT0FBTyxVQUFVLElBQUlFLG9CQUEyQixTQUFTLE9BQU8sb0JBQW9CLEdBQUcsa0JBQWtCLGFBQWEsTUFBTTtDQUNoSSxJQUFJLFdBQVcsS0FBSyxVQUFVLElBQUk7Q0FDbEMsYUFBTSxnQkFBZ0IsU0FBUyxLQUFLLE1BQU0sUUFBUSxHQUFHO0VBQ25EO0VBQ0E7RUFDQTtDQUNGLENBQUMsR0FBRztFQUFDO0VBQVU7RUFBVTtFQUFVO0VBQVM7Q0FBSyxDQUFDO0NBQ2xELE9BQU87QUFDVDs7Ozs7O0FBTUEsU0FBUyxPQUFPLE9BQU87Q0FDckIsT0FBTyxVQUFVLE1BQU0sT0FBTztBQUNoQzs7Ozs7O0FBTUEsU0FBUyxNQUFNLFFBQVE7Q0FDckIsVUFBeUQsT0FBTyxzSUFBMkk7QUFDN007Ozs7Ozs7Ozs7QUFVQSxTQUFTLE9BQU8sT0FBTztDQUNyQixJQUFJLEVBQ0YsVUFBVSxlQUFlLEtBQ3pCLFdBQVcsTUFDWCxVQUFVLGNBQ1YsaUJBQWlCLE9BQU8sS0FDeEIsV0FDQSxRQUFRLGFBQWEsT0FDckIsV0FDRTtDQUNKLG1CQUFxQixLQUE0Q0YsVUFBaUIsT0FBTyx3R0FBNkc7Q0FJdE0sSUFBSSxXQUFXLGFBQWEsUUFBUSxRQUFRLEdBQUc7Q0FDL0MsSUFBSSxvQkFBQSxhQUEwQixlQUFlO0VBQzNDO0VBQ0E7RUFDQSxRQUFRO0VBQ1IsUUFBUUQsV0FBUyxFQUNmLHNCQUFzQixNQUN4QixHQUFHLE1BQU07Q0FDWCxJQUFJO0VBQUM7RUFBVTtFQUFRO0VBQVc7Q0FBVSxDQUFDO0NBQzdDLElBQUksT0FBTyxpQkFBaUIsVUFDMUIsZUFBZSxVQUFVLFlBQVk7Q0FFdkMsSUFBSSxFQUNGLFdBQVcsS0FDWCxTQUFTLElBQ1QsT0FBTyxJQUNQLFFBQVEsTUFDUixNQUFNLGNBQ0o7Q0FDSixJQUFJLGtCQUFBLGFBQXdCLGNBQWM7RUFDeEMsSUFBSSxtQkFBbUIsY0FBYyxVQUFVLFFBQVE7RUFDdkQsSUFBSSxvQkFBb0IsTUFDdEIsT0FBTztFQUVULE9BQU87R0FDTCxVQUFVO0lBQ1IsVUFBVTtJQUNWO0lBQ0E7SUFDQTtJQUNBO0dBQ0Y7R0FDQTtFQUNGO0NBQ0YsR0FBRztFQUFDO0VBQVU7RUFBVTtFQUFRO0VBQU07RUFBTztFQUFLO0NBQWMsQ0FBQztDQUNqRSxRQUF1RCxtQkFBbUIsTUFBTSx3QkFBd0IsV0FBVyx1Q0FBdUMsT0FBTyxXQUFXLFNBQVMsT0FBTyw0Q0FBNEMsa0RBQWtEO0NBQzFSLElBQUksbUJBQW1CLE1BQ3JCLE9BQU87Q0FFVCxPQUFvQiwyQkFBTSxjQUFjLGtCQUFrQixVQUFVLEVBQ2xFLE9BQU8sa0JBQ1QsR0FBZ0IsMkJBQU0sY0FBYyxnQkFBZ0IsVUFBVTtFQUNsRDtFQUNWLE9BQU87Q0FDVCxDQUFDLENBQUM7QUFDSjs7Ozs7OztBQU9BLFNBQVMsT0FBTyxPQUFPO0NBQ3JCLElBQUksRUFDRixVQUNBLGFBQ0U7Q0FDSixPQUFPLFVBQVUseUJBQXlCLFFBQVEsR0FBRyxRQUFRO0FBQy9EOzs7OztBQUtBLFNBQVMsTUFBTSxPQUFPO0NBQ3BCLElBQUksRUFDRixVQUNBLGNBQ0EsWUFDRTtDQUNKLE9BQW9CLDJCQUFNLGNBQWMsb0JBQW9CO0VBQ2pEO0VBQ0s7Q0FDaEIsR0FBZ0IsMkJBQU0sY0FBYyxjQUFjLE1BQU0sUUFBUSxDQUFDO0FBQ25FO0FBQ0EsSUFBSSxvQkFBaUMsdUJBQVUsbUJBQW1CO0NBQ2hFLGtCQUFrQixrQkFBa0IsYUFBYSxLQUFLO0NBQ3RELGtCQUFrQixrQkFBa0IsYUFBYSxLQUFLO0NBQ3RELGtCQUFrQixrQkFBa0IsV0FBVyxLQUFLO0NBQ3BELE9BQU87QUFDVCxFQUFFLHFCQUFxQixDQUFDLENBQUM7QUFDekIsSUFBTSxzQkFBc0IsSUFBSSxjQUFjLENBQUMsQ0FBQztBQUNoRCxJQUFNLHFCQUFOLGNBQUEsYUFBdUMsVUFBVTtDQUMvQyxZQUFZLE9BQU87RUFDakIsTUFBTSxLQUFLO0VBQ1gsS0FBSyxRQUFRLEVBQ1gsT0FBTyxLQUNUO0NBQ0Y7Q0FDQSxPQUFPLHlCQUF5QixPQUFPO0VBQ3JDLE9BQU8sRUFDTCxNQUNGO0NBQ0Y7Q0FDQSxrQkFBa0IsT0FBTyxXQUFXO0VBQ2xDLFFBQVEsTUFBTSxvREFBb0QsT0FBTyxTQUFTO0NBQ3BGO0NBQ0EsU0FBUztFQUNQLElBQUksRUFDRixVQUNBLGNBQ0EsWUFDRSxLQUFLO0VBQ1QsSUFBSSxVQUFVO0VBQ2QsSUFBSSxTQUFTLGtCQUFrQjtFQUMvQixJQUFJLEVBQUUsbUJBQW1CLFVBQVU7R0FFakMsU0FBUyxrQkFBa0I7R0FDM0IsVUFBVSxRQUFRLFFBQVE7R0FDMUIsT0FBTyxlQUFlLFNBQVMsWUFBWSxFQUN6QyxXQUFXLEtBQ2IsQ0FBQztHQUNELE9BQU8sZUFBZSxTQUFTLFNBQVMsRUFDdEMsV0FBVyxRQUNiLENBQUM7RUFDSCxPQUFPLElBQUksS0FBSyxNQUFNLE9BQU87R0FFM0IsU0FBUyxrQkFBa0I7R0FDM0IsSUFBSSxjQUFjLEtBQUssTUFBTTtHQUM3QixVQUFVLFFBQVEsT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7R0FDekMsT0FBTyxlQUFlLFNBQVMsWUFBWSxFQUN6QyxXQUFXLEtBQ2IsQ0FBQztHQUNELE9BQU8sZUFBZSxTQUFTLFVBQVUsRUFDdkMsV0FBVyxZQUNiLENBQUM7RUFDSCxPQUFPLElBQUksUUFBUSxVQUFVO0dBRTNCLFVBQVU7R0FDVixTQUFTLFlBQVksVUFBVSxrQkFBa0IsUUFBUSxXQUFXLFVBQVUsa0JBQWtCLFVBQVUsa0JBQWtCO0VBQzlILE9BQU87R0FFTCxTQUFTLGtCQUFrQjtHQUMzQixPQUFPLGVBQWUsU0FBUyxZQUFZLEVBQ3pDLFdBQVcsS0FDYixDQUFDO0dBQ0QsVUFBVSxRQUFRLE1BQUssU0FBUSxPQUFPLGVBQWUsU0FBUyxTQUFTLEVBQ3JFLFdBQVcsS0FDYixDQUFDLElBQUcsVUFBUyxPQUFPLGVBQWUsU0FBUyxVQUFVLEVBQ3BELFdBQVcsTUFDYixDQUFDLENBQUM7RUFDSjtFQUNBLElBQUksV0FBVyxrQkFBa0IsU0FBUyxRQUFRLGtCQUFrQixzQkFFbEUsTUFBTTtFQUVSLElBQUksV0FBVyxrQkFBa0IsU0FBUyxDQUFDLGNBRXpDLE1BQU0sUUFBUTtFQUVoQixJQUFJLFdBQVcsa0JBQWtCLE9BRS9CLE9BQW9CLDJCQUFNLGNBQWMsYUFBYSxVQUFVO0dBQzdELE9BQU87R0FDUCxVQUFVO0VBQ1osQ0FBQztFQUVILElBQUksV0FBVyxrQkFBa0IsU0FFL0IsT0FBb0IsMkJBQU0sY0FBYyxhQUFhLFVBQVU7R0FDN0QsT0FBTztHQUNHO0VBQ1osQ0FBQztFQUlILE1BQU07Q0FDUjtBQUNGOzs7OztBQU1BLFNBQVMsYUFBYSxPQUFPO0NBQzNCLElBQUksRUFDRixhQUNFO0NBQ0osSUFBSSxPQUFPLGNBQWM7Q0FDekIsSUFBSSxXQUFXLE9BQU8sYUFBYSxhQUFhLFNBQVMsSUFBSSxJQUFJO0NBQ2pFLE9BQW9CLDJCQUFNLGNBQUEsYUFBb0IsVUFBVSxNQUFNLFFBQVE7QUFDeEU7Ozs7Ozs7O0FBYUEsU0FBUyx5QkFBeUIsVUFBVSxZQUFZO0NBQ3RELElBQUksZUFBZSxLQUFLLEdBQ3RCLGFBQWEsQ0FBQztDQUVoQixJQUFJLFNBQVMsQ0FBQztDQUNkLGFBQU0sU0FBUyxRQUFRLFdBQVcsU0FBUyxVQUFVO0VBQ25ELElBQUksQ0FBZSwyQkFBTSxlQUFlLE9BQU8sR0FHN0M7RUFFRixJQUFJLFdBQVcsQ0FBQyxHQUFHLFlBQVksS0FBSztFQUNwQyxJQUFJLFFBQVEsU0FBQSxhQUFlLFVBQVU7R0FFbkMsT0FBTyxLQUFLLE1BQU0sUUFBUSx5QkFBeUIsUUFBUSxNQUFNLFVBQVUsUUFBUSxDQUFDO0dBQ3BGO0VBQ0Y7RUFDQSxFQUFFLFFBQVEsU0FBUyxVQUFpREMsVUFBaUIsT0FBTyxPQUFPLE9BQU8sUUFBUSxTQUFTLFdBQVcsUUFBUSxPQUFPLFFBQVEsS0FBSyxRQUFRLHdHQUF3RztFQUNsUixFQUFFLENBQUMsUUFBUSxNQUFNLFNBQVMsQ0FBQyxRQUFRLE1BQU0sYUFBb0RBLFVBQWlCLE9BQU8sMENBQTBDO0VBQy9KLElBQUksUUFBUTtHQUNWLElBQUksUUFBUSxNQUFNLE1BQU0sU0FBUyxLQUFLLEdBQUc7R0FDekMsZUFBZSxRQUFRLE1BQU07R0FDN0IsU0FBUyxRQUFRLE1BQU07R0FDdkIsV0FBVyxRQUFRLE1BQU07R0FDekIsT0FBTyxRQUFRLE1BQU07R0FDckIsTUFBTSxRQUFRLE1BQU07R0FDcEIsUUFBUSxRQUFRLE1BQU07R0FDdEIsUUFBUSxRQUFRLE1BQU07R0FDdEIsY0FBYyxRQUFRLE1BQU07R0FDNUIsZUFBZSxRQUFRLE1BQU07R0FDN0Isa0JBQWtCLFFBQVEsTUFBTSxpQkFBaUIsUUFBUSxRQUFRLE1BQU0sZ0JBQWdCO0dBQ3ZGLGtCQUFrQixRQUFRLE1BQU07R0FDaEMsUUFBUSxRQUFRLE1BQU07R0FDdEIsTUFBTSxRQUFRLE1BQU07RUFDdEI7RUFDQSxJQUFJLFFBQVEsTUFBTSxVQUNoQixNQUFNLFdBQVcseUJBQXlCLFFBQVEsTUFBTSxVQUFVLFFBQVE7RUFFNUUsT0FBTyxLQUFLLEtBQUs7Q0FDbkIsQ0FBQztDQUNELE9BQU87QUFDVDs7OztBQUtBLFNBQVMsY0FBYyxTQUFTO0NBQzlCLE9BQU8sZUFBZSxPQUFPO0FBQy9CO0FBRUEsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxJQUFJLFVBQVUsRUFHWixrQkFBa0IsTUFBTSxpQkFBaUIsUUFBUSxNQUFNLGdCQUFnQixLQUN6RTtDQUNBLElBQUksTUFBTSxXQUFXO0VBRWpCLElBQUksTUFBTSxTQUNSLFFBQXVELE9BQU8saUdBQXNHO0VBR3hLLE9BQU8sT0FBTyxTQUFTO0dBQ3JCLFNBQXNCLDJCQUFNLGNBQWMsTUFBTSxTQUFTO0dBQ3pELFdBQVcsS0FBQTtFQUNiLENBQUM7Q0FDSDtDQUNBLElBQUksTUFBTSxpQkFBaUI7RUFFdkIsSUFBSSxNQUFNLHdCQUNSLFFBQXVELE9BQU8sNEhBQWlJO0VBR25NLE9BQU8sT0FBTyxTQUFTO0dBQ3JCLHdCQUFxQywyQkFBTSxjQUFjLE1BQU0sZUFBZTtHQUM5RSxpQkFBaUIsS0FBQTtFQUNuQixDQUFDO0NBQ0g7Q0FDQSxJQUFJLE1BQU0sZUFBZTtFQUVyQixJQUFJLE1BQU0sY0FDUixRQUF1RCxPQUFPLDhHQUFtSDtFQUdyTCxPQUFPLE9BQU8sU0FBUztHQUNyQixjQUEyQiwyQkFBTSxjQUFjLE1BQU0sYUFBYTtHQUNsRSxlQUFlLEtBQUE7RUFDakIsQ0FBQztDQUNIO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsUUFBUSxNQUFNO0NBQ3hDLE9BQU8sYUFBYTtFQUNsQixVQUFVLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztFQUN2QyxRQUFRRCxXQUFTLENBQUMsR0FBRyxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssUUFBUSxFQUN4RCxvQkFBb0IsS0FDdEIsQ0FBQztFQUNELFNBQVMsb0JBQW9CO0dBQzNCLGdCQUFnQixRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7R0FDN0MsY0FBYyxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7RUFDN0MsQ0FBQztFQUNELGVBQWUsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0VBQzVDO0VBQ0E7RUFDQSxjQUFjLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztFQUMzQyx5QkFBeUIsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0NBQ3hELENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDaEI7Ozs7Ozs7Ozs7Ozs7QUNuOENBLFNBQVMsV0FBVztDQUNsQixPQUFPLFdBQVcsT0FBTyxTQUFTLE9BQU8sT0FBTyxLQUFLLElBQUksU0FBVSxHQUFHO0VBQ3BFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztHQUN6QyxJQUFJLElBQUksVUFBVTtHQUNsQixLQUFLLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFBLENBQUcsZUFBZSxLQUFLLEdBQUcsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFO0VBQy9EO0VBQ0EsT0FBTztDQUNULEdBQUcsU0FBUyxNQUFNLE1BQU0sU0FBUztBQUNuQztBQUNBLFNBQVMsOEJBQThCLEdBQUcsR0FBRztDQUMzQyxJQUFJLFFBQVEsR0FBRyxPQUFPLENBQUM7Q0FDdkIsSUFBSSxJQUFJLENBQUM7Q0FDVCxLQUFLLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxFQUFFLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRztFQUNqRCxJQUFJLE9BQU8sRUFBRSxRQUFRLENBQUMsR0FBRztFQUN6QixFQUFFLEtBQUssRUFBRTtDQUNYO0NBQ0EsT0FBTztBQUNUO0FBRUEsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxjQUFjLFFBQVE7Q0FDN0IsT0FBTyxVQUFVLFFBQVEsT0FBTyxPQUFPLFlBQVk7QUFDckQ7QUFDQSxTQUFTLGdCQUFnQixRQUFRO0NBQy9CLE9BQU8sY0FBYyxNQUFNLEtBQUssT0FBTyxRQUFRLFlBQVksTUFBTTtBQUNuRTtBQUNBLFNBQVMsY0FBYyxRQUFRO0NBQzdCLE9BQU8sY0FBYyxNQUFNLEtBQUssT0FBTyxRQUFRLFlBQVksTUFBTTtBQUNuRTtBQUNBLFNBQVMsZUFBZSxRQUFRO0NBQzlCLE9BQU8sY0FBYyxNQUFNLEtBQUssT0FBTyxRQUFRLFlBQVksTUFBTTtBQUNuRTtBQUNBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDOUIsT0FBTyxDQUFDLEVBQUUsTUFBTSxXQUFXLE1BQU0sVUFBVSxNQUFNLFdBQVcsTUFBTTtBQUNwRTtBQUNBLFNBQVMsdUJBQXVCLE9BQU8sUUFBUTtDQUM3QyxPQUFPLE1BQU0sV0FBVyxNQUV4QixDQUFDLFVBQVUsV0FBVyxZQUV0QixDQUFDLGdCQUFnQixLQUFLO0FBRXhCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBc0JBLFNBQVMsbUJBQW1CLE1BQU07Q0FDaEMsSUFBSSxTQUFTLEtBQUssR0FDaEIsT0FBTztDQUVULE9BQU8sSUFBSSxnQkFBZ0IsT0FBTyxTQUFTLFlBQVksTUFBTSxRQUFRLElBQUksS0FBSyxnQkFBZ0Isa0JBQWtCLE9BQU8sT0FBTyxLQUFLLElBQUksQ0FBQyxDQUFDLFFBQVEsTUFBTSxRQUFRO0VBQzdKLElBQUksUUFBUSxLQUFLO0VBQ2pCLE9BQU8sS0FBSyxPQUFPLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxLQUFJLE1BQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxDQUFDO0NBQ3JGLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDUjtBQUNBLFNBQVMsMkJBQTJCLGdCQUFnQixxQkFBcUI7Q0FDdkUsSUFBSSxlQUFlLG1CQUFtQixjQUFjO0NBQ3BELElBQUkscUJBTUYsb0JBQW9CLFNBQVMsR0FBRyxRQUFRO0VBQ3RDLElBQUksQ0FBQyxhQUFhLElBQUksR0FBRyxHQUN2QixvQkFBb0IsT0FBTyxHQUFHLENBQUMsQ0FBQyxTQUFRLFVBQVM7R0FDL0MsYUFBYSxPQUFPLEtBQUssS0FBSztFQUNoQyxDQUFDO0NBRUwsQ0FBQztDQUVILE9BQU87QUFDVDtBQUVBLElBQUksNkJBQTZCO0FBQ2pDLFNBQVMsK0JBQStCO0NBQ3RDLElBQUksK0JBQStCLE1BQ2pDLElBQUk7RUFDRixJQUFJLFNBQVMsU0FBUyxjQUFjLE1BQU0sR0FFMUMsQ0FBQztFQUNELDZCQUE2QjtDQUMvQixTQUFTLEdBQUc7RUFDViw2QkFBNkI7Q0FDL0I7Q0FFRixPQUFPO0FBQ1Q7QUFDQSxJQUFNLHdDQUF3QixJQUFJLElBQUk7Q0FBQztDQUFxQztDQUF1QjtBQUFZLENBQUM7QUFDaEgsU0FBUyxlQUFlLFNBQVM7Q0FDL0IsSUFBSSxXQUFXLFFBQVEsQ0FBQyxzQkFBc0IsSUFBSSxPQUFPLEdBQUc7RUFDMUQsUUFBdUQsT0FBTyxPQUFPLFVBQVUscUhBQWlIO0VBQ2hNLE9BQU87Q0FDVDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsc0JBQXNCLFFBQVEsVUFBVTtDQUMvQyxJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksY0FBYyxNQUFNLEdBQUc7RUFJekIsSUFBSSxPQUFPLE9BQU8sYUFBYSxRQUFRO0VBQ3ZDLFNBQVMsT0FBTyxjQUFjLE1BQU0sUUFBUSxJQUFJO0VBQ2hELFNBQVMsT0FBTyxhQUFhLFFBQVEsS0FBSztFQUMxQyxVQUFVLGVBQWUsT0FBTyxhQUFhLFNBQVMsQ0FBQyxLQUFLO0VBQzVELFdBQVcsSUFBSSxTQUFTLE1BQU07Q0FDaEMsT0FBTyxJQUFJLGdCQUFnQixNQUFNLEtBQUssZUFBZSxNQUFNLE1BQU0sT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTLFVBQVU7RUFDckgsSUFBSSxPQUFPLE9BQU87RUFDbEIsSUFBSSxRQUFRLE1BQ1YsTUFBTSxJQUFJLE1BQU0sc0VBQXNFO0VBTXhGLElBQUksT0FBTyxPQUFPLGFBQWEsWUFBWSxLQUFLLEtBQUssYUFBYSxRQUFRO0VBQzFFLFNBQVMsT0FBTyxjQUFjLE1BQU0sUUFBUSxJQUFJO0VBQ2hELFNBQVMsT0FBTyxhQUFhLFlBQVksS0FBSyxLQUFLLGFBQWEsUUFBUSxLQUFLO0VBQzdFLFVBQVUsZUFBZSxPQUFPLGFBQWEsYUFBYSxDQUFDLEtBQUssZUFBZSxLQUFLLGFBQWEsU0FBUyxDQUFDLEtBQUs7RUFFaEgsV0FBVyxJQUFJLFNBQVMsTUFBTSxNQUFNO0VBS3BDLElBQUksQ0FBQyw2QkFBNkIsR0FBRztHQUNuQyxJQUFJLEVBQ0YsTUFDQSxNQUNBLFVBQ0U7R0FDSixJQUFJLFNBQVMsU0FBUztJQUNwQixJQUFJLFNBQVMsT0FBTyxPQUFPLE1BQU07SUFDakMsU0FBUyxPQUFPLFNBQVMsS0FBSyxHQUFHO0lBQ2pDLFNBQVMsT0FBTyxTQUFTLEtBQUssR0FBRztHQUNuQyxPQUFPLElBQUksTUFDVCxTQUFTLE9BQU8sTUFBTSxLQUFLO0VBRS9CO0NBQ0YsT0FBTyxJQUFJLGNBQWMsTUFBTSxHQUM3QixNQUFNLElBQUksTUFBTSxzRkFBMkY7TUFDdEc7RUFDTCxTQUFTO0VBQ1QsU0FBUztFQUNULFVBQVU7RUFDVixPQUFPO0NBQ1Q7Q0FFQSxJQUFJLFlBQVksWUFBWSxjQUFjO0VBQ3hDLE9BQU87RUFDUCxXQUFXLEtBQUE7Q0FDYjtDQUNBLE9BQU87RUFDTDtFQUNBLFFBQVEsT0FBTyxZQUFZO0VBQzNCO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxJQUFNLFlBQVk7Q0FBQztDQUFXO0NBQVk7Q0FBa0I7Q0FBVztDQUFTO0NBQVU7Q0FBTTtDQUFzQjtBQUFnQjtBQUNwSSxJQUFBLGFBQWE7Q0FBQztDQUFnQjtDQUFpQjtDQUFhO0NBQU87Q0FBUztDQUFNO0NBQWtCO0FBQVU7QUFDOUcsSUFBQSxhQUFhO0NBQUM7Q0FBYztDQUFZO0NBQWtCO0NBQVc7Q0FBUztDQUFVO0NBQVU7Q0FBWTtDQUFZO0NBQXNCO0FBQWdCO0FBVWxLLElBQU0sdUJBQXVCO0FBQzdCLElBQUk7Q0FDRixPQUFPLHVCQUF1QjtBQUNoQyxTQUFTLEdBQUcsQ0FFWjtBQUNBLFNBQVMsb0JBQW9CLFFBQVEsTUFBTTtDQUN6QyxPQUFPLGFBQWE7RUFDbEIsVUFBVSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7RUFDdkMsUUFBUSxTQUFTLENBQUMsR0FBRyxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssUUFBUSxFQUN4RCxvQkFBb0IsS0FDdEIsQ0FBQztFQUNELFNBQVMscUJBQXFCLEVBQzVCLFFBQVEsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLE9BQ3ZDLENBQUM7RUFDRCxnQkFBZ0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLGtCQUFrQixtQkFBbUI7RUFDbEY7RUFDb0JjO0VBQ3BCLGNBQWMsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0VBQzNDLHlCQUF5QixRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7RUFDdEQsUUFBUSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7Q0FDdkMsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNoQjtBQUNBLFNBQVMsaUJBQWlCLFFBQVEsTUFBTTtDQUN0QyxPQUFPLGFBQWE7RUFDbEIsVUFBVSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7RUFDdkMsUUFBUSxTQUFTLENBQUMsR0FBRyxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssUUFBUSxFQUN4RCxvQkFBb0IsS0FDdEIsQ0FBQztFQUNELFNBQVMsa0JBQWtCLEVBQ3pCLFFBQVEsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLE9BQ3ZDLENBQUM7RUFDRCxnQkFBZ0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLGtCQUFrQixtQkFBbUI7RUFDbEY7RUFDb0JBO0VBQ3BCLGNBQWMsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0VBQzNDLHlCQUF5QixRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7RUFDdEQsUUFBUSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7Q0FDdkMsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNoQjtBQUNBLFNBQVMscUJBQXFCO0NBQzVCLElBQUk7Q0FDSixJQUFJLFNBQVMsVUFBVSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVE7Q0FDMUQsSUFBSSxTQUFTLE1BQU0sUUFDakIsUUFBUSxTQUFTLENBQUMsR0FBRyxPQUFPLEVBQzFCLFFBQVEsa0JBQWtCLE1BQU0sTUFBTSxFQUN4QyxDQUFDO0NBRUgsT0FBTztBQUNUO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUTtDQUNqQyxJQUFJLENBQUMsUUFBUSxPQUFPO0NBQ3BCLElBQUksVUFBVSxPQUFPLFFBQVEsTUFBTTtDQUNuQyxJQUFJLGFBQWEsQ0FBQztDQUNsQixLQUFLLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FHckIsSUFBSSxPQUFPLElBQUksV0FBVyxzQkFDeEIsV0FBVyxPQUFPLElBQUlDLGtCQUF5QixJQUFJLFFBQVEsSUFBSSxZQUFZLElBQUksTUFBTSxJQUFJLGFBQWEsSUFBSTtNQUNyRyxJQUFJLE9BQU8sSUFBSSxXQUFXLFNBQVM7RUFFeEMsSUFBSSxJQUFJLFdBQVc7R0FDakIsSUFBSSxtQkFBbUIsT0FBTyxJQUFJO0dBQ2xDLElBQUksT0FBTyxxQkFBcUIsWUFDOUIsSUFBSTtJQUVGLElBQUksUUFBUSxJQUFJLGlCQUFpQixJQUFJLE9BQU87SUFHNUMsTUFBTSxRQUFRO0lBQ2QsV0FBVyxPQUFPO0dBQ3BCLFNBQVMsR0FBRyxDQUVaO0VBRUo7RUFDQSxJQUFJLFdBQVcsUUFBUSxNQUFNO0dBQzNCLElBQUksUUFBUSxJQUFJLE1BQU0sSUFBSSxPQUFPO0dBR2pDLE1BQU0sUUFBUTtHQUNkLFdBQVcsT0FBTztFQUNwQjtDQUNGLE9BQ0UsV0FBVyxPQUFPO0NBR3RCLE9BQU87QUFDVDtBQUNBLElBQU0sd0JBQXFDLDJCQUFNLGNBQWMsRUFDN0QsaUJBQWlCLE1BQ25CLENBQUM7QUFFQyxzQkFBc0IsY0FBYztBQUV0QyxJQUFNLGtCQUErQiwyQkFBTSw4QkFBYyxJQUFJLElBQUksQ0FBQztBQUVoRSxnQkFBZ0IsY0FBYztBQTRCaEMsSUFBTSxzQkFBQSxhQUE0QkM7QUFFbEMsSUFBTSxnQkFBQSxpQkFBeUJDO0FBRS9CLElBQU0sWUFBQSxhQUFrQkM7QUFDeEIsU0FBUyxvQkFBb0IsSUFBSTtDQUMvQixJQUFJLHFCQUNGLG9CQUFvQixFQUFFO01BRXRCLEdBQUc7QUFFUDtBQUNBLFNBQVMsY0FBYyxJQUFJO0NBQ3pCLElBQUksZUFDRixjQUFjLEVBQUU7TUFFaEIsR0FBRztBQUVQO0FBQ0EsSUFBTSxXQUFOLE1BQWU7Q0FDYixjQUFjO0VBQ1osS0FBSyxTQUFTO0VBQ2QsS0FBSyxVQUFVLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDOUMsS0FBSyxXQUFVLFVBQVM7SUFDdEIsSUFBSSxLQUFLLFdBQVcsV0FBVztLQUM3QixLQUFLLFNBQVM7S0FDZCxRQUFRLEtBQUs7SUFDZjtHQUNGO0dBQ0EsS0FBSyxVQUFTLFdBQVU7SUFDdEIsSUFBSSxLQUFLLFdBQVcsV0FBVztLQUM3QixLQUFLLFNBQVM7S0FDZCxPQUFPLE1BQU07SUFDZjtHQUNGO0VBQ0YsQ0FBQztDQUNIO0FBQ0Y7Ozs7QUFJQSxTQUFTLGVBQWUsTUFBTTtDQUM1QixJQUFJLEVBQ0YsaUJBQ0EsUUFDQSxXQUNFO0NBQ0osSUFBSSxDQUFDLE9BQU8sZ0JBQUEsYUFBc0IsU0FBUyxPQUFPLEtBQUs7Q0FDdkQsSUFBSSxDQUFDLGNBQWMsbUJBQUEsYUFBeUIsU0FBUztDQUNyRCxJQUFJLENBQUMsV0FBVyxnQkFBQSxhQUFzQixTQUFTLEVBQzdDLGlCQUFpQixNQUNuQixDQUFDO0NBQ0QsSUFBSSxDQUFDLFdBQVcsZ0JBQUEsYUFBc0IsU0FBUztDQUMvQyxJQUFJLENBQUMsWUFBWSxpQkFBQSxhQUF1QixTQUFTO0NBQ2pELElBQUksQ0FBQyxjQUFjLG1CQUFBLGFBQXlCLFNBQVM7Q0FDckQsSUFBSSxjQUFBLGFBQW9CLHVCQUFPLElBQUksSUFBSSxDQUFDO0NBQ3hDLElBQUksRUFDRix1QkFDRSxVQUFVLENBQUM7Q0FDZixJQUFJLHVCQUFBLGFBQTZCLGFBQVksT0FBTTtFQUNqRCxJQUFJLG9CQUNGLG9CQUFvQixFQUFFO09BRXRCLEdBQUc7Q0FFUCxHQUFHLENBQUMsa0JBQWtCLENBQUM7Q0FDdkIsSUFBSSxXQUFBLGFBQWlCLGFBQWEsVUFBVSxVQUFVO0VBQ3BELElBQUksRUFDRixpQkFDVyxXQUNTLHVCQUNsQjtFQUNKLFNBQVMsU0FBUyxTQUFTLFNBQVMsUUFBUTtHQUMxQyxJQUFJLFFBQVEsU0FBUyxLQUFBLEdBQ25CLFlBQVksUUFBUSxJQUFJLEtBQUssUUFBUSxJQUFJO0VBRTdDLENBQUM7RUFDRCxnQkFBZ0IsU0FBUSxRQUFPLFlBQVksUUFBUSxPQUFPLEdBQUcsQ0FBQztFQUM5RCxJQUFJLDhCQUE4QixPQUFPLFVBQVUsUUFBUSxPQUFPLE9BQU8sWUFBWSxRQUFRLE9BQU8sT0FBTyxPQUFPLFNBQVMsd0JBQXdCO0VBR25KLElBQUksQ0FBQyxzQkFBc0IsNkJBQTZCO0dBQ3RELElBQUksV0FDRixvQkFBb0IsYUFBYSxRQUFRLENBQUM7UUFFMUMsMkJBQTJCLGFBQWEsUUFBUSxDQUFDO0dBRW5EO0VBQ0Y7RUFFQSxJQUFJLFdBQVc7R0FFYixvQkFBb0I7SUFFbEIsSUFBSSxZQUFZO0tBQ2QsYUFBYSxVQUFVLFFBQVE7S0FDL0IsV0FBVyxlQUFlO0lBQzVCO0lBQ0EsYUFBYTtLQUNYLGlCQUFpQjtLQUNqQixXQUFXO0tBQ1gsaUJBQWlCLG1CQUFtQjtLQUNwQyxjQUFjLG1CQUFtQjtJQUNuQyxDQUFDO0dBQ0gsQ0FBQztHQUVELElBQUksSUFBSSxPQUFPLE9BQU8sU0FBUywwQkFBMEI7SUFDdkQsb0JBQW9CLGFBQWEsUUFBUSxDQUFDO0dBQzVDLENBQUM7R0FFRCxFQUFFLFNBQVMsY0FBYztJQUN2QixvQkFBb0I7S0FDbEIsYUFBYSxLQUFBLENBQVM7S0FDdEIsY0FBYyxLQUFBLENBQVM7S0FDdkIsZ0JBQWdCLEtBQUEsQ0FBUztLQUN6QixhQUFhLEVBQ1gsaUJBQWlCLE1BQ25CLENBQUM7SUFDSCxDQUFDO0dBQ0gsQ0FBQztHQUNELG9CQUFvQixjQUFjLENBQUMsQ0FBQztHQUNwQztFQUNGO0VBRUEsSUFBSSxZQUFZO0dBR2QsYUFBYSxVQUFVLFFBQVE7R0FDL0IsV0FBVyxlQUFlO0dBQzFCLGdCQUFnQjtJQUNkLE9BQU87SUFDUCxpQkFBaUIsbUJBQW1CO0lBQ3BDLGNBQWMsbUJBQW1CO0dBQ25DLENBQUM7RUFDSCxPQUFPO0dBRUwsZ0JBQWdCLFFBQVE7R0FDeEIsYUFBYTtJQUNYLGlCQUFpQjtJQUNqQixXQUFXO0lBQ1gsaUJBQWlCLG1CQUFtQjtJQUNwQyxjQUFjLG1CQUFtQjtHQUNuQyxDQUFDO0VBQ0g7Q0FDRixHQUFHO0VBQUMsT0FBTztFQUFRO0VBQVk7RUFBVztFQUFhO0NBQW9CLENBQUM7Q0FHNUUsYUFBTSxzQkFBc0IsT0FBTyxVQUFVLFFBQVEsR0FBRyxDQUFDLFFBQVEsUUFBUSxDQUFDO0NBRzFFLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksVUFBVSxtQkFBbUIsQ0FBQyxVQUFVLFdBQzFDLGFBQWEsSUFBSSxTQUFTLENBQUM7Q0FFL0IsR0FBRyxDQUFDLFNBQVMsQ0FBQztDQUlkLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksYUFBYSxnQkFBZ0IsT0FBTyxRQUFRO0dBQzlDLElBQUksV0FBVztHQUNmLElBQUksZ0JBQWdCLFVBQVU7R0FDOUIsSUFBSSxhQUFhLE9BQU8sT0FBTyxTQUFTLG9CQUFvQixZQUFZO0lBQ3RFLDJCQUEyQixhQUFhLFFBQVEsQ0FBQztJQUNqRCxNQUFNO0dBQ1IsQ0FBQztHQUNELFdBQVcsU0FBUyxjQUFjO0lBQ2hDLGFBQWEsS0FBQSxDQUFTO0lBQ3RCLGNBQWMsS0FBQSxDQUFTO0lBQ3ZCLGdCQUFnQixLQUFBLENBQVM7SUFDekIsYUFBYSxFQUNYLGlCQUFpQixNQUNuQixDQUFDO0dBQ0gsQ0FBQztHQUNELGNBQWMsVUFBVTtFQUMxQjtDQUNGLEdBQUc7RUFBQztFQUFzQjtFQUFjO0VBQVcsT0FBTztDQUFNLENBQUM7Q0FHakUsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxhQUFhLGdCQUFnQixNQUFNLFNBQVMsUUFBUSxhQUFhLFNBQVMsS0FDNUUsVUFBVSxRQUFRO0NBRXRCLEdBQUc7RUFBQztFQUFXO0VBQVksTUFBTTtFQUFVO0NBQVksQ0FBQztDQUd4RCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLENBQUMsVUFBVSxtQkFBbUIsY0FBYztHQUM5QyxnQkFBZ0IsYUFBYSxLQUFLO0dBQ2xDLGFBQWE7SUFDWCxpQkFBaUI7SUFDakIsV0FBVztJQUNYLGlCQUFpQixhQUFhO0lBQzlCLGNBQWMsYUFBYTtHQUM3QixDQUFDO0dBQ0QsZ0JBQWdCLEtBQUEsQ0FBUztFQUMzQjtDQUNGLEdBQUcsQ0FBQyxVQUFVLGlCQUFpQixZQUFZLENBQUM7Q0FDNUMsYUFBTSxnQkFBZ0I7RUFDcEIsUUFBdUQsbUJBQW1CLFFBQVEsQ0FBQyxPQUFPLE9BQU8scUJBQXFCLDhIQUFtSTtDQUczUCxHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksWUFBQSxhQUFrQixjQUFjO0VBQ2xDLE9BQU87R0FDTCxZQUFZLE9BQU87R0FDbkIsZ0JBQWdCLE9BQU87R0FDdkIsS0FBSSxNQUFLLE9BQU8sU0FBUyxDQUFDO0dBQzFCLE9BQU8sSUFBSSxPQUFPLFNBQVMsT0FBTyxTQUFTLElBQUk7SUFDN0M7SUFDQSxvQkFBb0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLO0dBQ25ELENBQUM7R0FDRCxVQUFVLElBQUksT0FBTyxTQUFTLE9BQU8sU0FBUyxJQUFJO0lBQ2hELFNBQVM7SUFDVDtJQUNBLG9CQUFvQixRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUs7R0FDbkQsQ0FBQztFQUNIO0NBQ0YsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUNYLElBQUksV0FBVyxPQUFPLFlBQVk7Q0FDbEMsSUFBSSxvQkFBQSxhQUEwQixlQUFlO0VBQzNDO0VBQ0E7RUFDQSxRQUFRO0VBQ1I7Q0FDRixJQUFJO0VBQUM7RUFBUTtFQUFXO0NBQVEsQ0FBQztDQUNqQyxJQUFJLGVBQUEsYUFBcUIsZUFBZSxFQUN0QyxzQkFBc0IsT0FBTyxPQUFPLHFCQUN0QyxJQUFJLENBQUMsT0FBTyxPQUFPLG9CQUFvQixDQUFDO0NBQ3hDLGFBQU0sZ0JBQWdCQyx5QkFBZ0MsUUFBUSxPQUFPLE1BQU0sR0FBRyxDQUFDLFFBQVEsT0FBTyxNQUFNLENBQUM7Q0FPckcsT0FBb0IsMkJBQU0sY0FBQSxhQUFvQixVQUFVLE1BQW1CLDJCQUFNLGNBQWNDLGtCQUF5QixVQUFVLEVBQ2hJLE9BQU8sa0JBQ1QsR0FBZ0IsMkJBQU0sY0FBY0MsdUJBQThCLFVBQVUsRUFDMUUsT0FBTyxNQUNULEdBQWdCLDJCQUFNLGNBQWMsZ0JBQWdCLFVBQVUsRUFDNUQsT0FBTyxZQUFZLFFBQ3JCLEdBQWdCLDJCQUFNLGNBQWMsc0JBQXNCLFVBQVUsRUFDbEUsT0FBTyxVQUNULEdBQWdCLDJCQUFNLGNBQWMsUUFBUTtFQUNoQztFQUNWLFVBQVUsTUFBTTtFQUNoQixnQkFBZ0IsTUFBTTtFQUNYO0VBQ1gsUUFBUTtDQUNWLEdBQUcsTUFBTSxlQUFlLE9BQU8sT0FBTyxzQkFBb0MsMkJBQU0sY0FBYyxvQkFBb0I7RUFDaEgsUUFBUSxPQUFPO0VBQ2YsUUFBUSxPQUFPO0VBQ1I7Q0FDVCxDQUFDLElBQUssZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSTtBQUNsQztBQUVBLElBQU0scUJBQWtDLDJCQUFNLEtBQUssVUFBVTtBQUM3RCxTQUFTLFdBQVcsT0FBTztDQUN6QixJQUFJLEVBQ0YsUUFDQSxRQUNBLFVBQ0U7Q0FDSixPQUFPQyxjQUFxQixRQUFRLEtBQUEsR0FBVyxPQUFPLE1BQU07QUFDOUQ7Ozs7QUFJQSxTQUFTLGNBQWMsT0FBTztDQUM1QixJQUFJLEVBQ0YsVUFDQSxVQUNBLFFBQ0EsV0FDRTtDQUNKLElBQUksYUFBQSxhQUFtQixPQUFPO0NBQzlCLElBQUksV0FBVyxXQUFXLE1BQ3hCLFdBQVcsVUFBVSxxQkFBcUI7RUFDeEM7RUFDQSxVQUFVO0NBQ1osQ0FBQztDQUVILElBQUksVUFBVSxXQUFXO0NBQ3pCLElBQUksQ0FBQyxPQUFPLGdCQUFBLGFBQXNCLFNBQVM7RUFDekMsUUFBUSxRQUFRO0VBQ2hCLFVBQVUsUUFBUTtDQUNwQixDQUFDO0NBQ0QsSUFBSSxFQUNGLHVCQUNFLFVBQVUsQ0FBQztDQUNmLElBQUksV0FBQSxhQUFpQixhQUFZLGFBQVk7RUFDM0Msc0JBQXNCLHNCQUFzQiwwQkFBMEIsYUFBYSxRQUFRLENBQUMsSUFBSSxhQUFhLFFBQVE7Q0FDdkgsR0FBRyxDQUFDLGNBQWMsa0JBQWtCLENBQUM7Q0FDckMsYUFBTSxzQkFBc0IsUUFBUSxPQUFPLFFBQVEsR0FBRyxDQUFDLFNBQVMsUUFBUSxDQUFDO0NBQ3pFLGFBQU0sZ0JBQWdCSCx5QkFBZ0MsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ3ZFLE9BQW9CLDJCQUFNLGNBQWMsUUFBUTtFQUNwQztFQUNBO0VBQ1YsVUFBVSxNQUFNO0VBQ2hCLGdCQUFnQixNQUFNO0VBQ3RCLFdBQVc7RUFDSDtDQUNWLENBQUM7QUFDSDs7Ozs7QUFLQSxTQUFTLFdBQVcsT0FBTztDQUN6QixJQUFJLEVBQ0YsVUFDQSxVQUNBLFFBQ0EsV0FDRTtDQUNKLElBQUksYUFBQSxhQUFtQixPQUFPO0NBQzlCLElBQUksV0FBVyxXQUFXLE1BQ3hCLFdBQVcsVUFBVSxrQkFBa0I7RUFDckM7RUFDQSxVQUFVO0NBQ1osQ0FBQztDQUVILElBQUksVUFBVSxXQUFXO0NBQ3pCLElBQUksQ0FBQyxPQUFPLGdCQUFBLGFBQXNCLFNBQVM7RUFDekMsUUFBUSxRQUFRO0VBQ2hCLFVBQVUsUUFBUTtDQUNwQixDQUFDO0NBQ0QsSUFBSSxFQUNGLHVCQUNFLFVBQVUsQ0FBQztDQUNmLElBQUksV0FBQSxhQUFpQixhQUFZLGFBQVk7RUFDM0Msc0JBQXNCLHNCQUFzQiwwQkFBMEIsYUFBYSxRQUFRLENBQUMsSUFBSSxhQUFhLFFBQVE7Q0FDdkgsR0FBRyxDQUFDLGNBQWMsa0JBQWtCLENBQUM7Q0FDckMsYUFBTSxzQkFBc0IsUUFBUSxPQUFPLFFBQVEsR0FBRyxDQUFDLFNBQVMsUUFBUSxDQUFDO0NBQ3pFLGFBQU0sZ0JBQWdCQSx5QkFBZ0MsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ3ZFLE9BQW9CLDJCQUFNLGNBQWMsUUFBUTtFQUNwQztFQUNBO0VBQ1YsVUFBVSxNQUFNO0VBQ2hCLGdCQUFnQixNQUFNO0VBQ3RCLFdBQVc7RUFDSDtDQUNWLENBQUM7QUFDSDs7Ozs7OztBQU9BLFNBQVMsY0FBYyxPQUFPO0NBQzVCLElBQUksRUFDRixVQUNBLFVBQ0EsUUFDQSxZQUNFO0NBQ0osSUFBSSxDQUFDLE9BQU8sZ0JBQUEsYUFBc0IsU0FBUztFQUN6QyxRQUFRLFFBQVE7RUFDaEIsVUFBVSxRQUFRO0NBQ3BCLENBQUM7Q0FDRCxJQUFJLEVBQ0YsdUJBQ0UsVUFBVSxDQUFDO0NBQ2YsSUFBSSxXQUFBLGFBQWlCLGFBQVksYUFBWTtFQUMzQyxzQkFBc0Isc0JBQXNCLDBCQUEwQixhQUFhLFFBQVEsQ0FBQyxJQUFJLGFBQWEsUUFBUTtDQUN2SCxHQUFHLENBQUMsY0FBYyxrQkFBa0IsQ0FBQztDQUNyQyxhQUFNLHNCQUFzQixRQUFRLE9BQU8sUUFBUSxHQUFHLENBQUMsU0FBUyxRQUFRLENBQUM7Q0FDekUsYUFBTSxnQkFBZ0JBLHlCQUFnQyxNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDdkUsT0FBb0IsMkJBQU0sY0FBYyxRQUFRO0VBQ3BDO0VBQ0E7RUFDVixVQUFVLE1BQU07RUFDaEIsZ0JBQWdCLE1BQU07RUFDdEIsV0FBVztFQUNIO0NBQ1YsQ0FBQztBQUNIO0FBRUUsY0FBYyxjQUFjO0FBRTlCLElBQU0sWUFBWSxPQUFPLFdBQVcsZUFBZSxPQUFPLE9BQU8sYUFBYSxlQUFlLE9BQU8sT0FBTyxTQUFTLGtCQUFrQjtBQUN0SSxJQUFNLHFCQUFxQjs7OztBQUkzQixJQUFNLE9BQW9CLDJCQUFNLFdBQVcsU0FBUyxZQUFZLE9BQU8sS0FBSztDQUMxRSxJQUFJLEVBQ0EsU0FDQSxVQUNBLGdCQUNBLFNBQ0EsT0FDQSxRQUNBLElBQ0Esb0JBQ0EsbUJBQ0UsT0FDSixPQUFPLDhCQUE4QixPQUFPLFNBQVM7Q0FDdkQsSUFBSSxFQUNGLGFBQUEsYUFDUSxXQUFXSSxpQkFBd0I7Q0FFN0MsSUFBSTtDQUNKLElBQUksYUFBYTtDQUNqQixJQUFJLE9BQU8sT0FBTyxZQUFZLG1CQUFtQixLQUFLLEVBQUUsR0FBRztFQUV6RCxlQUFlO0VBRWYsSUFBSSxXQUNGLElBQUk7R0FDRixJQUFJLGFBQWEsSUFBSSxJQUFJLE9BQU8sU0FBUyxJQUFJO0dBQzdDLElBQUksWUFBWSxHQUFHLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxXQUFXLFdBQVcsRUFBRSxJQUFJLElBQUksSUFBSSxFQUFFO0dBQ3BGLElBQUksT0FBTyxjQUFjLFVBQVUsVUFBVSxRQUFRO0dBQ3JELElBQUksVUFBVSxXQUFXLFdBQVcsVUFBVSxRQUFRLE1BRXBELEtBQUssT0FBTyxVQUFVLFNBQVMsVUFBVTtRQUV6QyxhQUFhO0VBRWpCLFNBQVMsR0FBRztHQUVWLFFBQXVELE9BQU8sZ0JBQWdCLEtBQUsseUdBQThHO0VBQ25NO0NBRUo7Q0FFQSxJQUFJLE9BQU8sUUFBUSxJQUFJLEVBQ3JCLFNBQ0YsQ0FBQztDQUNELElBQUksa0JBQWtCLG9CQUFvQixJQUFJO0VBQzVDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUM7Q0FDRCxTQUFTLFlBQVksT0FBTztFQUMxQixJQUFJLFNBQVMsUUFBUSxLQUFLO0VBQzFCLElBQUksQ0FBQyxNQUFNLGtCQUNULGdCQUFnQixLQUFLO0NBRXpCO0NBQ0EsT0FHRSwyQkFBTSxjQUFjLEtBQUssU0FBUyxDQUFDLEdBQUcsTUFBTTtFQUMxQyxNQUFNLGdCQUFnQjtFQUN0QixTQUFTLGNBQWMsaUJBQWlCLFVBQVU7RUFDN0M7RUFDRztDQUNWLENBQUMsQ0FBQztBQUVOLENBQUM7QUFFQyxLQUFLLGNBQWM7Ozs7QUFLckIsSUFBTSxVQUF1QiwyQkFBTSxXQUFXLFNBQVMsZUFBZSxPQUFPLEtBQUs7Q0FDaEYsSUFBSSxFQUNBLGdCQUFnQixrQkFBa0IsUUFDbEMsZ0JBQWdCLE9BQ2hCLFdBQVcsZ0JBQWdCLElBQzNCLE1BQU0sT0FDTixPQUFPLFdBQ1AsSUFDQSxnQkFDQSxhQUNFLE9BQ0osT0FBTyw4QkFBOEIsT0FBTyxVQUFVO0NBQ3hELElBQUksT0FBTyxnQkFBZ0IsSUFBSSxFQUM3QixVQUFVLEtBQUssU0FDakIsQ0FBQztDQUNELElBQUksV0FBVyxZQUFZO0NBQzNCLElBQUksY0FBQSxhQUFvQixXQUFXRixzQkFBNkI7Q0FDaEUsSUFBSSxFQUNGLFdBQ0EsYUFBQSxhQUNRLFdBQVdFLGlCQUF3QjtDQUM3QyxJQUFJLGtCQUFrQixlQUFlLFFBR3JDLHVCQUF1QixJQUFJLEtBQUssbUJBQW1CO0NBQ25ELElBQUksYUFBYSxVQUFVLGlCQUFpQixVQUFVLGVBQWUsSUFBSSxDQUFDLENBQUMsV0FBVyxLQUFLO0NBQzNGLElBQUksbUJBQW1CLFNBQVM7Q0FDaEMsSUFBSSx1QkFBdUIsZUFBZSxZQUFZLGNBQWMsWUFBWSxXQUFXLFdBQVcsWUFBWSxXQUFXLFNBQVMsV0FBVztDQUNqSixJQUFJLENBQUMsZUFBZTtFQUNsQixtQkFBbUIsaUJBQWlCLFlBQVk7RUFDaEQsdUJBQXVCLHVCQUF1QixxQkFBcUIsWUFBWSxJQUFJO0VBQ25GLGFBQWEsV0FBVyxZQUFZO0NBQ3RDO0NBQ0EsSUFBSSx3QkFBd0IsVUFDMUIsdUJBQXVCLGNBQWMsc0JBQXNCLFFBQVEsS0FBSztDQU8xRSxNQUFNLG1CQUFtQixlQUFlLE9BQU8sV0FBVyxTQUFTLEdBQUcsSUFBSSxXQUFXLFNBQVMsSUFBSSxXQUFXO0NBQzdHLElBQUksV0FBVyxxQkFBcUIsY0FBYyxDQUFDLE9BQU8saUJBQWlCLFdBQVcsVUFBVSxLQUFLLGlCQUFpQixPQUFPLGdCQUFnQixNQUFNO0NBQ25KLElBQUksWUFBWSx3QkFBd0IsU0FBUyx5QkFBeUIsY0FBYyxDQUFDLE9BQU8scUJBQXFCLFdBQVcsVUFBVSxLQUFLLHFCQUFxQixPQUFPLFdBQVcsTUFBTSxNQUFNO0NBQ2xNLElBQUksY0FBYztFQUNoQjtFQUNBO0VBQ0E7Q0FDRjtDQUNBLElBQUksY0FBYyxXQUFXLGtCQUFrQixLQUFBO0NBQy9DLElBQUk7Q0FDSixJQUFJLE9BQU8sa0JBQWtCLFlBQzNCLFlBQVksY0FBYyxXQUFXO01BT3JDLFlBQVk7RUFBQztFQUFlLFdBQVcsV0FBVztFQUFNLFlBQVksWUFBWTtFQUFNLGtCQUFrQixrQkFBa0I7Q0FBSSxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FFMUosSUFBSSxRQUFRLE9BQU8sY0FBYyxhQUFhLFVBQVUsV0FBVyxJQUFJO0NBQ3ZFLE9BQW9CLDJCQUFNLGNBQWMsTUFBTSxTQUFTLENBQUMsR0FBRyxNQUFNO0VBQy9ELGdCQUFnQjtFQUNMO0VBQ047RUFDRTtFQUNIO0VBQ1k7Q0FDbEIsQ0FBQyxHQUFHLE9BQU8sYUFBYSxhQUFhLFNBQVMsV0FBVyxJQUFJLFFBQVE7QUFDdkUsQ0FBQztBQUVDLFFBQVEsY0FBYzs7Ozs7OztBQVF4QixJQUFNLE9BQW9CLDJCQUFNLFlBQVksT0FBTyxpQkFBaUI7Q0FDbEUsSUFBSSxFQUNBLFlBQ0EsVUFDQSxnQkFDQSxTQUNBLE9BQ0EsU0FBUyxlQUNULFFBQ0EsVUFDQSxVQUNBLG9CQUNBLG1CQUNFLE9BQ0osUUFBUSw4QkFBOEIsT0FBTyxVQUFVO0NBQ3pELElBQUksU0FBUyxVQUFVO0NBQ3ZCLElBQUksYUFBYSxjQUFjLFFBQVEsRUFDckMsU0FDRixDQUFDO0NBQ0QsSUFBSSxhQUFhLE9BQU8sWUFBWSxNQUFNLFFBQVEsUUFBUTtDQUMxRCxJQUFJLGlCQUFnQixVQUFTO0VBQzNCLFlBQVksU0FBUyxLQUFLO0VBQzFCLElBQUksTUFBTSxrQkFBa0I7RUFDNUIsTUFBTSxlQUFlO0VBQ3JCLElBQUksWUFBWSxNQUFNLFlBQVk7RUFDbEMsSUFBSSxnQkFBZ0IsYUFBYSxPQUFPLEtBQUssSUFBSSxVQUFVLGFBQWEsWUFBWSxNQUFNO0VBQzFGLE9BQU8sYUFBYSxNQUFNLGVBQWU7R0FDdkM7R0FDQSxRQUFRO0dBQ1I7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsT0FBb0IsMkJBQU0sY0FBYyxRQUFRLFNBQVM7RUFDdkQsS0FBSztFQUNMLFFBQVE7RUFDUixRQUFRO0VBQ1IsVUFBVSxpQkFBaUIsV0FBVztDQUN4QyxHQUFHLEtBQUssQ0FBQztBQUNYLENBQUM7QUFFQyxLQUFLLGNBQWM7Ozs7O0FBTXJCLFNBQVMsa0JBQWtCLE9BQU87Q0FDaEMsSUFBSSxFQUNGLFFBQ0EsZUFDRTtDQUNKLHFCQUFxQjtFQUNuQjtFQUNBO0NBQ0YsQ0FBQztDQUNELE9BQU87QUFDVDtBQUVFLGtCQUFrQixjQUFjO0FBTWxDLElBQUk7Q0FDSCxTQUFVLGdCQUFnQjtDQUN6QixlQUFlLDBCQUEwQjtDQUN6QyxlQUFlLGVBQWU7Q0FDOUIsZUFBZSxzQkFBc0I7Q0FDckMsZUFBZSxnQkFBZ0I7Q0FDL0IsZUFBZSw0QkFBNEI7QUFDN0MsRUFBQSxDQUFHLG1CQUFtQixpQkFBaUIsQ0FBQyxFQUFFO0FBQzFDLElBQUk7Q0FDSCxTQUFVLHFCQUFxQjtDQUM5QixvQkFBb0IsZ0JBQWdCO0NBQ3BDLG9CQUFvQixpQkFBaUI7Q0FDckMsb0JBQW9CLDBCQUEwQjtBQUNoRCxFQUFBLENBQUcsd0JBQXdCLHNCQUFzQixDQUFDLEVBQUU7QUFFcEQsU0FBUywwQkFBMEIsVUFBVTtDQUMzQyxPQUFPLFdBQVc7QUFDcEI7QUFDQSxTQUFTLHFCQUFxQixVQUFVO0NBQ3RDLElBQUksTUFBQSxhQUFZLFdBQVdILGlCQUF3QjtDQUNuRCxDQUFDLE9BQThDSSxVQUFpQixPQUFPLDBCQUEwQixRQUFRLENBQUM7Q0FDMUcsT0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsVUFBVTtDQUNwQyxJQUFJLFFBQUEsYUFBYyxXQUFXSCxzQkFBNkI7Q0FDMUQsQ0FBQyxTQUFnREcsVUFBaUIsT0FBTywwQkFBMEIsUUFBUSxDQUFDO0NBQzVHLE9BQU87QUFDVDs7Ozs7O0FBT0EsU0FBUyxvQkFBb0IsSUFBSSxPQUFPO0NBQ3RDLElBQUksRUFDRixRQUNBLFNBQVMsYUFDVCxPQUNBLG9CQUNBLFVBQ0EsbUJBQ0UsVUFBVSxLQUFLLElBQUksQ0FBQyxJQUFJO0NBQzVCLElBQUksV0FBVyxZQUFZO0NBQzNCLElBQUksV0FBVyxZQUFZO0NBQzNCLElBQUksT0FBTyxnQkFBZ0IsSUFBSSxFQUM3QixTQUNGLENBQUM7Q0FDRCxPQUFBLGFBQWEsYUFBWSxVQUFTO0VBQ2hDLElBQUksdUJBQXVCLE9BQU8sTUFBTSxHQUFHO0dBQ3pDLE1BQU0sZUFBZTtHQUdyQixJQUFJLFVBQVUsZ0JBQWdCLEtBQUEsSUFBWSxjQUFjLFdBQVcsUUFBUSxNQUFNLFdBQVcsSUFBSTtHQUNoRyxTQUFTLElBQUk7SUFDWDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQztFQUNIO0NBQ0YsR0FBRztFQUFDO0VBQVU7RUFBVTtFQUFNO0VBQWE7RUFBTztFQUFRO0VBQUk7RUFBb0I7RUFBVTtDQUFjLENBQUM7QUFDN0c7Ozs7O0FBS0EsU0FBUyxnQkFBZ0IsYUFBYTtDQUNwQyxRQUF1RCxPQUFPLG9CQUFvQixhQUFhLHlPQUF3UDtDQUN2VixJQUFJLHlCQUFBLGFBQStCLE9BQU8sbUJBQW1CLFdBQVcsQ0FBQztDQUN6RSxJQUFJLHdCQUFBLGFBQThCLE9BQU8sS0FBSztDQUM5QyxJQUFJLFdBQVcsWUFBWTtDQUMzQixJQUFJLGVBQUEsYUFBcUIsY0FJekIsMkJBQTJCLFNBQVMsUUFBUSxzQkFBc0IsVUFBVSxPQUFPLHVCQUF1QixPQUFPLEdBQUcsQ0FBQyxTQUFTLE1BQU0sQ0FBQztDQUNySSxJQUFJLFdBQVcsWUFBWTtDQU0zQixPQUFPLENBQUMsY0FBQSxhQUxvQixhQUFhLFVBQVUsb0JBQW9CO0VBQ3JFLE1BQU0sa0JBQWtCLG1CQUFtQixPQUFPLGFBQWEsYUFBYSxTQUFTLFlBQVksSUFBSSxRQUFRO0VBQzdHLHNCQUFzQixVQUFVO0VBQ2hDLFNBQVMsTUFBTSxpQkFBaUIsZUFBZTtDQUNqRCxHQUFHLENBQUMsVUFBVSxZQUFZLENBQ1UsQ0FBQztBQUN2QztBQUNBLFNBQVMsK0JBQStCO0NBQ3RDLElBQUksT0FBTyxhQUFhLGFBQ3RCLE1BQU0sSUFBSSxNQUFNLCtHQUFvSDtBQUV4STtBQUNBLElBQUksWUFBWTtBQUNoQixJQUFJLDJCQUEyQixPQUFPLE9BQU8sRUFBRSxTQUFTLElBQUk7Ozs7O0FBSzVELFNBQVMsWUFBWTtDQUNuQixJQUFJLEVBQ0YsV0FDRSxxQkFBcUIsZUFBZSxTQUFTO0NBQ2pELElBQUksRUFDRixhQUFBLGFBQ1EsV0FBV0QsaUJBQXdCO0NBQzdDLElBQUksaUJBQWlCRSxXQUFrQjtDQUN2QyxPQUFBLGFBQWEsWUFBWSxTQUFVLFFBQVEsU0FBUztFQUNsRCxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7RUFFYiw2QkFBNkI7RUFDN0IsSUFBSSxFQUNGLFFBQ0EsUUFDQSxTQUNBLFVBQ0EsU0FDRSxzQkFBc0IsUUFBUSxRQUFRO0VBQzFDLElBQUksUUFBUSxhQUFhLE9BQU87R0FDOUIsSUFBSSxNQUFNLFFBQVEsY0FBYyxtQkFBbUI7R0FDbkQsT0FBTyxNQUFNLEtBQUssZ0JBQWdCLFFBQVEsVUFBVSxRQUFRO0lBQzFELG9CQUFvQixRQUFRO0lBQzVCO0lBQ0E7SUFDQSxZQUFZLFFBQVEsVUFBVTtJQUM5QixhQUFhLFFBQVEsV0FBVztJQUNoQyxXQUFXLFFBQVE7R0FDckIsQ0FBQztFQUNILE9BQ0UsT0FBTyxTQUFTLFFBQVEsVUFBVSxRQUFRO0dBQ3hDLG9CQUFvQixRQUFRO0dBQzVCO0dBQ0E7R0FDQSxZQUFZLFFBQVEsVUFBVTtHQUM5QixhQUFhLFFBQVEsV0FBVztHQUNoQyxTQUFTLFFBQVE7R0FDakIsT0FBTyxRQUFRO0dBQ2YsYUFBYTtHQUNiLFdBQVcsUUFBUTtHQUNuQixnQkFBZ0IsUUFBUTtFQUMxQixDQUFDO0NBRUwsR0FBRztFQUFDO0VBQVE7RUFBVTtDQUFjLENBQUM7QUFDdkM7QUFHQSxTQUFTLGNBQWMsUUFBUSxRQUFRO0NBQ3JDLElBQUksRUFDRixhQUNFLFdBQVcsS0FBSyxJQUFJLENBQUMsSUFBSTtDQUM3QixJQUFJLEVBQ0YsYUFBQSxhQUNRLFdBQVdGLGlCQUF3QjtDQUM3QyxJQUFJLGVBQUEsYUFBcUIsV0FBV0csWUFBbUI7Q0FDdkQsQ0FBQyxnQkFBdURGLFVBQWlCLE9BQU8sa0RBQWtEO0NBQ2xJLElBQUksQ0FBQyxTQUFTLGFBQWEsUUFBUSxNQUFNLEVBQUU7Q0FHM0MsSUFBSSxPQUFPLFNBQVMsQ0FBQyxHQUFHLGdCQUFnQixTQUFTLFNBQVMsS0FBSyxFQUM3RCxTQUNGLENBQUMsQ0FBQztDQUlGLElBQUksV0FBVyxZQUFZO0NBQzNCLElBQUksVUFBVSxNQUFNO0VBR2xCLEtBQUssU0FBUyxTQUFTO0VBSXZCLElBQUksU0FBUyxJQUFJLGdCQUFnQixLQUFLLE1BQU07RUFDNUMsSUFBSSxjQUFjLE9BQU8sT0FBTyxPQUFPO0VBRXZDLElBRHlCLFlBQVksTUFBSyxNQUFLLE1BQU0sRUFDaEMsR0FBRztHQUN0QixPQUFPLE9BQU8sT0FBTztHQUNyQixZQUFZLFFBQU8sTUFBSyxDQUFDLENBQUMsQ0FBQyxTQUFRLE1BQUssT0FBTyxPQUFPLFNBQVMsQ0FBQyxDQUFDO0dBQ2pFLElBQUksS0FBSyxPQUFPLFNBQVM7R0FDekIsS0FBSyxTQUFTLEtBQUssTUFBTSxLQUFLO0VBQ2hDO0NBQ0Y7Q0FDQSxLQUFLLENBQUMsVUFBVSxXQUFXLFFBQVEsTUFBTSxNQUFNLE9BQzdDLEtBQUssU0FBUyxLQUFLLFNBQVMsS0FBSyxPQUFPLFFBQVEsT0FBTyxTQUFTLElBQUk7Q0FNdEUsSUFBSSxhQUFhLEtBQ2YsS0FBSyxXQUFXLEtBQUssYUFBYSxNQUFNLFdBQVcsVUFBVSxDQUFDLFVBQVUsS0FBSyxRQUFRLENBQUM7Q0FFeEYsT0FBTyxXQUFXLElBQUk7QUFDeEI7Ozs7O0FBTUEsU0FBUyxXQUFXLFFBQVE7Q0FDMUIsSUFBSTtDQUNKLElBQUksRUFDRixRQUNFLFdBQVcsS0FBSyxJQUFJLENBQUMsSUFBSTtDQUM3QixJQUFJLEVBQ0YsV0FDRSxxQkFBcUIsZUFBZSxVQUFVO0NBQ2xELElBQUksUUFBUSxtQkFBbUIsb0JBQW9CLFVBQVU7Q0FDN0QsSUFBSSxjQUFBLGFBQW9CLFdBQVcsZUFBZTtDQUNsRCxJQUFJLFFBQUEsYUFBYyxXQUFXRSxZQUFtQjtDQUNoRCxJQUFJLFdBQVcsaUJBQWlCLE1BQU0sUUFBUSxNQUFNLFFBQVEsU0FBUyxPQUFPLE9BQU8sS0FBSyxJQUFJLGVBQWUsTUFBTTtDQUNqSCxDQUFDLGVBQXNERixVQUFpQixPQUFPLGtEQUFrRDtDQUNqSSxDQUFDLFNBQWdEQSxVQUFpQixPQUFPLCtDQUErQztDQUN4SCxFQUFFLFdBQVcsU0FBZ0RBLFVBQWlCLE9BQU8sb0VBQW9FO0NBSXpKLElBQUksYUFBYSxZQUFZLFVBQVUsSUFBSTtDQUMzQyxJQUFJLENBQUMsWUFBWSxpQkFBQSxhQUF1QixTQUFTLE9BQU8sVUFBVTtDQUNsRSxJQUFJLE9BQU8sUUFBUSxZQUNqQixjQUFjLEdBQUc7TUFDWixJQUFJLENBQUMsWUFFVixjQUFjLG1CQUFtQixDQUFDO0NBR3BDLGFBQU0sZ0JBQWdCO0VBQ3BCLE9BQU8sV0FBVyxVQUFVO0VBQzVCLGFBQWE7R0FJWCxPQUFPLGNBQWMsVUFBVTtFQUNqQztDQUNGLEdBQUcsQ0FBQyxRQUFRLFVBQVUsQ0FBQztDQUV2QixJQUFJLE9BQUEsYUFBYSxhQUFhLE1BQU0sU0FBUztFQUMzQyxDQUFDLFdBQWtEQSxVQUFpQixPQUFPLHlDQUF5QztFQUNwSCxPQUFPLE1BQU0sWUFBWSxTQUFTLE1BQU0sSUFBSTtDQUM5QyxHQUFHO0VBQUM7RUFBWTtFQUFTO0NBQU0sQ0FBQztDQUNoQyxJQUFJLGFBQWEsVUFBVTtDQUMzQixJQUFJLFNBQUEsYUFBZSxhQUFhLFFBQVEsU0FBUztFQUMvQyxXQUFXLFFBQVEsU0FBUyxDQUFDLEdBQUcsTUFBTTtHQUNwQyxVQUFVO0dBQ1Y7RUFDRixDQUFDLENBQUM7Q0FDSixHQUFHLENBQUMsWUFBWSxVQUFVLENBQUM7Q0FDM0IsSUFBSSxjQUFBLGFBQW9CLGNBQWM7RUFDcEMsSUFBSSxjQUEyQiwyQkFBTSxZQUFZLE9BQU8sUUFBUTtHQUM5RCxPQUFvQiwyQkFBTSxjQUFjLE1BQU0sU0FBUyxDQUFDLEdBQUcsT0FBTztJQUNoRSxVQUFVO0lBQ0U7SUFDUDtHQUNQLENBQUMsQ0FBQztFQUNKLENBQUM7RUFFQyxZQUFZLGNBQWM7RUFFNUIsT0FBTztDQUNULEdBQUcsQ0FBQyxVQUFVLENBQUM7Q0FFZixJQUFJLFVBQVUsTUFBTSxTQUFTLElBQUksVUFBVSxLQUFLO0NBQ2hELElBQUksT0FBTyxZQUFZLElBQUksVUFBVTtDQVFyQyxPQUFBLGFBUGtDLGNBQWMsU0FBUztFQUN2RCxNQUFNO0VBQ047RUFDQTtDQUNGLEdBQUcsU0FBUyxFQUNWLEtBQ0YsQ0FBQyxHQUFHO0VBQUM7RUFBYTtFQUFRO0VBQU07RUFBUztDQUFJLENBQ2xCO0FBQzdCOzs7OztBQUtBLFNBQVMsY0FBYztDQUNyQixJQUFJLFFBQVEsbUJBQW1CLG9CQUFvQixXQUFXO0NBQzlELE9BQU8sTUFBTSxLQUFLLE1BQU0sU0FBUyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUksVUFBUztFQUN2RCxJQUFJLENBQUMsS0FBSyxXQUFXO0VBQ3JCLE9BQU8sU0FBUyxDQUFDLEdBQUcsU0FBUyxFQUMzQixJQUNGLENBQUM7Q0FDSCxDQUFDO0FBQ0g7QUFDQSxJQUFNLGlDQUFpQztBQUN2QyxJQUFJLHVCQUF1QixDQUFDOzs7O0FBSTVCLFNBQVMscUJBQXFCLFFBQVE7Q0FDcEMsSUFBSSxFQUNGLFFBQ0EsZUFDRSxXQUFXLEtBQUssSUFBSSxDQUFDLElBQUk7Q0FDN0IsSUFBSSxFQUNGLFdBQ0UscUJBQXFCLGVBQWUsb0JBQW9CO0NBQzVELElBQUksRUFDRix1QkFDQSx1QkFDRSxtQkFBbUIsb0JBQW9CLG9CQUFvQjtDQUMvRCxJQUFJLEVBQ0YsYUFBQSxhQUNRLFdBQVdELGlCQUF3QjtDQUM3QyxJQUFJLFdBQVcsWUFBWTtDQUMzQixJQUFJLFVBQVUsV0FBVztDQUN6QixJQUFJLGFBQWEsY0FBYztDQUUvQixhQUFNLGdCQUFnQjtFQUNwQixPQUFPLFFBQVEsb0JBQW9CO0VBQ25DLGFBQWE7R0FDWCxPQUFPLFFBQVEsb0JBQW9CO0VBQ3JDO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxZQUFBLGFBQWtCLGtCQUFrQjtFQUNsQyxJQUFJLFdBQVcsVUFBVSxRQUFRO0dBQy9CLElBQUksT0FBTyxTQUFTLE9BQU8sVUFBVSxPQUFPLElBQUksU0FBUyxTQUFTO0dBQ2xFLHFCQUFxQixPQUFPLE9BQU87RUFDckM7RUFDQSxJQUFJO0dBQ0YsZUFBZSxRQUFRLGNBQWMsZ0NBQWdDLEtBQUssVUFBVSxvQkFBb0IsQ0FBQztFQUMzRyxTQUFTLE9BQU87R0FDZCxRQUF1RCxPQUFPLHNHQUFzRyxRQUFRLElBQUk7RUFDbEw7RUFDQSxPQUFPLFFBQVEsb0JBQW9CO0NBQ3JDLEdBQUc7RUFBQztFQUFZO0VBQVEsV0FBVztFQUFPO0VBQVU7Q0FBTyxDQUFDLENBQUM7Q0FFN0QsSUFBSSxPQUFPLGFBQWEsYUFBYTtFQUVuQyxhQUFNLHNCQUFzQjtHQUMxQixJQUFJO0lBQ0YsSUFBSSxtQkFBbUIsZUFBZSxRQUFRLGNBQWMsOEJBQThCO0lBQzFGLElBQUksa0JBQ0YsdUJBQXVCLEtBQUssTUFBTSxnQkFBZ0I7R0FFdEQsU0FBUyxHQUFHLENBRVo7RUFDRixHQUFHLENBQUMsVUFBVSxDQUFDO0VBR2YsYUFBTSxzQkFBc0I7R0FDMUIsSUFBSSx3QkFBd0IsVUFBVSxhQUFhLE9BQU8sVUFBVSxZQUFZLE9BQ2hGLFNBQVMsQ0FBQyxHQUFHLFVBQVUsRUFDckIsVUFBVSxjQUFjLFNBQVMsVUFBVSxRQUFRLEtBQUssU0FBUyxTQUNuRSxDQUFDLEdBQUcsT0FBTyxJQUFJO0dBQ2YsSUFBSSwyQkFBMkIsVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLHdCQUF3Qiw0QkFBNEIsT0FBTyxTQUFTLHFCQUFxQjtHQUN6SixhQUFhLDRCQUE0Qix5QkFBeUI7RUFDcEUsR0FBRztHQUFDO0dBQVE7R0FBVTtFQUFNLENBQUM7RUFHN0IsYUFBTSxzQkFBc0I7R0FFMUIsSUFBSSwwQkFBMEIsT0FDNUI7R0FHRixJQUFJLE9BQU8sMEJBQTBCLFVBQVU7SUFDN0MsT0FBTyxTQUFTLEdBQUcscUJBQXFCO0lBQ3hDO0dBQ0Y7R0FFQSxJQUFJLFNBQVMsTUFBTTtJQUNqQixJQUFJLEtBQUssU0FBUyxlQUFlLG1CQUFtQixTQUFTLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQztJQUMzRSxJQUFJLElBQUk7S0FDTixHQUFHLGVBQWU7S0FDbEI7SUFDRjtHQUNGO0dBRUEsSUFBSSx1QkFBdUIsTUFDekI7R0FHRixPQUFPLFNBQVMsR0FBRyxDQUFDO0VBQ3RCLEdBQUc7R0FBQztHQUFVO0dBQXVCO0VBQWtCLENBQUM7Q0FDMUQ7QUFDRjs7Ozs7Ozs7O0FBU0EsU0FBUyxnQkFBZ0IsVUFBVSxTQUFTO0NBQzFDLElBQUksRUFDRixZQUNFLFdBQVcsQ0FBQztDQUNoQixhQUFNLGdCQUFnQjtFQUNwQixJQUFJLE9BQU8sV0FBVyxPQUFPLEVBQzNCLFFBQ0YsSUFBSSxLQUFBO0VBQ0osT0FBTyxpQkFBaUIsZ0JBQWdCLFVBQVUsSUFBSTtFQUN0RCxhQUFhO0dBQ1gsT0FBTyxvQkFBb0IsZ0JBQWdCLFVBQVUsSUFBSTtFQUMzRDtDQUNGLEdBQUcsQ0FBQyxVQUFVLE9BQU8sQ0FBQztBQUN4Qjs7Ozs7Ozs7O0FBU0EsU0FBUyxZQUFZLFVBQVUsU0FBUztDQUN0QyxJQUFJLEVBQ0YsWUFDRSxXQUFXLENBQUM7Q0FDaEIsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxPQUFPLFdBQVcsT0FBTyxFQUMzQixRQUNGLElBQUksS0FBQTtFQUNKLE9BQU8saUJBQWlCLFlBQVksVUFBVSxJQUFJO0VBQ2xELGFBQWE7R0FDWCxPQUFPLG9CQUFvQixZQUFZLFVBQVUsSUFBSTtFQUN2RDtDQUNGLEdBQUcsQ0FBQyxVQUFVLE9BQU8sQ0FBQztBQUN4Qjs7Ozs7Ozs7O0FBU0EsU0FBUyxVQUFVLFFBQVE7Q0FDekIsSUFBSSxFQUNGLE1BQ0EsWUFDRTtDQUNKLElBQUksVUFBVSxXQUFXLElBQUk7Q0FDN0IsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxRQUFRLFVBQVUsV0FBVztHQUUvQixJQURjLE9BQU8sUUFBUSxPQUNuQixHQUlSLFdBQVcsUUFBUSxTQUFTLENBQUM7UUFFN0IsUUFBUSxNQUFNO0VBRWxCO0NBQ0YsR0FBRyxDQUFDLFNBQVMsT0FBTyxDQUFDO0NBQ3JCLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksUUFBUSxVQUFVLGFBQWEsQ0FBQyxNQUNsQyxRQUFRLE1BQU07Q0FFbEIsR0FBRyxDQUFDLFNBQVMsSUFBSSxDQUFDO0FBQ3BCOzs7Ozs7Ozs7QUFTQSxTQUFTLHVCQUF1QixJQUFJLE1BQU07Q0FDeEMsSUFBSSxTQUFTLEtBQUssR0FDaEIsT0FBTyxDQUFDO0NBRVYsSUFBSSxZQUFBLGFBQWtCLFdBQVcscUJBQXFCO0NBQ3RELEVBQUUsYUFBYSxTQUFnREMsVUFBaUIsT0FBTyx3SkFBNko7Q0FDcFAsSUFBSSxFQUNGLGFBQ0UscUJBQXFCLGVBQWUsc0JBQXNCO0NBQzlELElBQUksT0FBTyxnQkFBZ0IsSUFBSSxFQUM3QixVQUFVLEtBQUssU0FDakIsQ0FBQztDQUNELElBQUksQ0FBQyxVQUFVLGlCQUNiLE9BQU87Q0FFVCxJQUFJLGNBQWMsY0FBYyxVQUFVLGdCQUFnQixVQUFVLFFBQVEsS0FBSyxVQUFVLGdCQUFnQjtDQUMzRyxJQUFJLFdBQVcsY0FBYyxVQUFVLGFBQWEsVUFBVSxRQUFRLEtBQUssVUFBVSxhQUFhO0NBY2xHLE9BQU8sVUFBVSxLQUFLLFVBQVUsUUFBUSxLQUFLLFFBQVEsVUFBVSxLQUFLLFVBQVUsV0FBVyxLQUFLO0FBQ2hHIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyXX0=