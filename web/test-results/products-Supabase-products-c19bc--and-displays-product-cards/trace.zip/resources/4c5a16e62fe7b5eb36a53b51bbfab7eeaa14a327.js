import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/SupabaseProductsPage.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
import { fetchProducts } from "/src/lib/productsClient.ts?t=1786630893033";
import ProductCard from "/src/components/products/ProductCard.tsx?t=1786631703051";
import "/src/styles/products.css?t=1786631620219";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/pages/SupabaseProductsPage.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
var _s = $RefreshSig$();
export default function SupabaseProductsPage() {
	_s();
	const [products, setProducts] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	useEffect(() => {
		let mounted = true;
		setLoading(true);
		fetchProducts(50).then((data) => {
			if (!mounted) return;
			setProducts(data);
		}).catch((err) => {
			if (!mounted) return;
			setError(err.message || "Failed to load products");
		}).finally(() => {
			if (!mounted) return;
			setLoading(false);
		});
		return () => {
			mounted = false;
		};
	}, []);
	function retry() {
		setError(null);
		setLoading(true);
		fetchProducts(50).then(setProducts).catch((err) => setError(err.message || "Failed to load products")).finally(() => setLoading(false));
	}
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "products-container",
		children: /* @__PURE__ */ _jsxDEV("p", { children: "Loading products…" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 7
	}, this);
	if (error) return /* @__PURE__ */ _jsxDEV("div", {
		className: "products-container",
		children: [/* @__PURE__ */ _jsxDEV("p", {
			className: "error",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			onClick: retry,
			children: "Retry"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 7
	}, this);
	if (!products || products.length === 0) return /* @__PURE__ */ _jsxDEV("div", {
		className: "products-container",
		children: /* @__PURE__ */ _jsxDEV("p", { children: ["No products found. ", /* @__PURE__ */ _jsxDEV("a", {
			href: "/",
			children: "Go back"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 30
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 7
	}, this);
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "products-container",
		children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Products" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("section", {
			className: "products-grid",
			"aria-live": "polite",
			children: products.map((p) => /* @__PURE__ */ _jsxDEV(ProductCard, { product: p }, p.id, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 65,
		columnNumber: 5
	}, this);
}
_s(SupabaseProductsPage, "8LTSZUBNC5wklakrHJ01/x4rAc8=");
_c = SupabaseProductsPage;
var _c;
$RefreshReg$(_c, "SupabaseProductsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/SupabaseProductsPage.tsx?t=1786631703051";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/pages/SupabaseProductsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/pages/SupabaseProductsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/pages/SupabaseProductsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHFCQUFxQjtBQUU5QixPQUFPLGlCQUFpQjtBQUN4QixPQUFPOzs7O0FBRVAsZUFBZSxTQUFTLHVCQUF1Qjs7Q0FDN0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUEyQixJQUFJO0NBQy9ELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUV0RCxnQkFBZ0I7RUFDZCxJQUFJLFVBQVU7RUFDZCxXQUFXLElBQUk7RUFDZixjQUFjLEVBQUUsQ0FBQyxDQUNkLE1BQU0sU0FBUztHQUNkLElBQUksQ0FBQyxTQUFTO0dBQ2QsWUFBWSxJQUFJO0VBQ2xCLENBQUMsQ0FBQyxDQUNELE9BQU8sUUFBUTtHQUNkLElBQUksQ0FBQyxTQUFTO0dBQ2QsU0FBUyxJQUFJLFdBQVcseUJBQXlCO0VBQ25ELENBQUMsQ0FBQyxDQUNELGNBQWM7R0FDYixJQUFJLENBQUMsU0FBUztHQUNkLFdBQVcsS0FBSztFQUNsQixDQUFDO0VBQ0gsYUFBYTtHQUNYLFVBQVU7RUFDWjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsU0FBUyxRQUFRO0VBQ2YsU0FBUyxJQUFJO0VBQ2IsV0FBVyxJQUFJO0VBQ2YsY0FBYyxFQUFFLENBQUMsQ0FDZCxLQUFLLFdBQVcsQ0FBQyxDQUNqQixPQUFPLFFBQVEsU0FBUyxJQUFJLFdBQVcseUJBQXlCLENBQUMsQ0FBQyxDQUNsRSxjQUFjLFdBQVcsS0FBSyxDQUFDO0NBQ3BDO0NBRUEsSUFBSSxTQUNGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxLQUFELFlBQUcsb0JBQW9COzs7OztDQUNwQjs7Ozs7Q0FFVCxJQUFJLE9BQ0YsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBUztFQUFTOzs7O1lBQy9CLHdCQUFDLFVBQUQ7R0FBUSxTQUFTO2FBQU87RUFBYTs7OztVQUNsQzs7Ozs7O0NBRVQsSUFBSSxDQUFDLFlBQVksU0FBUyxXQUFXLEdBQ25DLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxLQUFELGFBQUcsdUJBQ2tCLHdCQUFDLEtBQUQ7R0FBRyxNQUFLO2FBQUk7RUFBVTs7OztVQUN4Qzs7Ozs7Q0FDQTs7Ozs7Q0FHVCxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7WUFDaEIsd0JBQUMsV0FBRDtHQUFTLFdBQVU7R0FBZ0IsYUFBVTthQUMxQyxTQUFTLEtBQUssTUFDYix3QkFBQyxhQUFELEVBQXdCLFNBQVMsRUFBSSxHQUFuQixFQUFFOzs7O1VBQWlCLENBQ3RDO0VBQ007Ozs7VUFDTDs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3VwYWJhc2VQcm9kdWN0c1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBmZXRjaFByb2R1Y3RzIH0gZnJvbSAnLi4vbGliL3Byb2R1Y3RzQ2xpZW50JztcbmltcG9ydCB0eXBlIHsgUHJvZHVjdCB9IGZyb20gJy4uL2xpYi9wcm9kdWN0c0NsaWVudCc7XG5pbXBvcnQgUHJvZHVjdENhcmQgZnJvbSAnLi4vY29tcG9uZW50cy9wcm9kdWN0cy9Qcm9kdWN0Q2FyZCc7XG5pbXBvcnQgJy4uL3N0eWxlcy9wcm9kdWN0cy5jc3MnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTdXBhYmFzZVByb2R1Y3RzUGFnZSgpIHtcbiAgY29uc3QgW3Byb2R1Y3RzLCBzZXRQcm9kdWN0c10gPSB1c2VTdGF0ZTxQcm9kdWN0W10gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgbW91bnRlZCA9IHRydWU7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBmZXRjaFByb2R1Y3RzKDUwKVxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgICAgaWYgKCFtb3VudGVkKSByZXR1cm47XG4gICAgICAgIHNldFByb2R1Y3RzKGRhdGEpO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGlmICghbW91bnRlZCkgcmV0dXJuO1xuICAgICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGxvYWQgcHJvZHVjdHMnKTtcbiAgICAgIH0pXG4gICAgICAuZmluYWxseSgoKSA9PiB7XG4gICAgICAgIGlmICghbW91bnRlZCkgcmV0dXJuO1xuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH0pO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBtb3VudGVkID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIGZ1bmN0aW9uIHJldHJ5KCkge1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgZmV0Y2hQcm9kdWN0cyg1MClcbiAgICAgIC50aGVuKHNldFByb2R1Y3RzKVxuICAgICAgLmNhdGNoKChlcnIpID0+IHNldEVycm9yKGVyci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gbG9hZCBwcm9kdWN0cycpKVxuICAgICAgLmZpbmFsbHkoKCkgPT4gc2V0TG9hZGluZyhmYWxzZSkpO1xuICB9XG5cbiAgaWYgKGxvYWRpbmcpXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdHMtY29udGFpbmVyXCI+XG4gICAgICAgIDxwPkxvYWRpbmcgcHJvZHVjdHPigKY8L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICBpZiAoZXJyb3IpXG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdHMtY29udGFpbmVyXCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yXCI+e2Vycm9yfTwvcD5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtyZXRyeX0+UmV0cnk8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIGlmICghcHJvZHVjdHMgfHwgcHJvZHVjdHMubGVuZ3RoID09PSAwKVxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3RzLWNvbnRhaW5lclwiPlxuICAgICAgICA8cD5cbiAgICAgICAgICBObyBwcm9kdWN0cyBmb3VuZC4gPGEgaHJlZj1cIi9cIj5HbyBiYWNrPC9hPlxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuXG4gIHJldHVybiAoXG4gICAgPG1haW4gY2xhc3NOYW1lPVwicHJvZHVjdHMtY29udGFpbmVyXCI+XG4gICAgICA8aDI+UHJvZHVjdHM8L2gyPlxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicHJvZHVjdHMtZ3JpZFwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICB7cHJvZHVjdHMubWFwKChwKSA9PiAoXG4gICAgICAgICAgPFByb2R1Y3RDYXJkIGtleT17cC5pZH0gcHJvZHVjdD17cH0gLz5cbiAgICAgICAgKSl9XG4gICAgICA8L3NlY3Rpb24+XG4gICAgPC9tYWluPlxuICApO1xufVxuIl19