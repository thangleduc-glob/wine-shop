import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Header.tsx");const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=b02da74d";
import { supabase } from "/src/lib/supabaseClient.ts";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/components/Header.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
var _s = $RefreshSig$();
export default function Header() {
	_s();
	const [email, setEmail] = useState(null);
	const navigate = useNavigate();
	useEffect(() => {
		let mounted = true;
		(async () => {
			try {
				const { data } = await supabase.auth.getUser();
				if (mounted) setEmail(data.user?.email ?? null);
			} catch (e) {}
		})();
		const { subscription } = supabase.auth.onAuthStateChange((_event, session) => {
			setEmail(session?.user?.email ?? null);
		});
		return () => {
			mounted = false;
			if (subscription && typeof subscription.unsubscribe === "function") subscription.unsubscribe();
		};
	}, []);
	async function handleSignOut() {
		await supabase.auth.signOut();
		setEmail(null);
		navigate("/");
	}
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "site-header",
		role: "banner",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "site-header-inner",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					className: "brand",
					"aria-label": "Wine Shop home",
					children: "Wine Shop"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					"aria-label": "Main Navigation",
					className: "main-nav",
					children: [/* @__PURE__ */ _jsxDEV("a", {
						href: "#features",
						className: "nav-link",
						children: "Features"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: "#shop",
						className: "nav-link",
						children: "Shop"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "auth-actions",
					children: email ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "user-email",
						children: email
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "btn btn-ghost",
						onClick: handleSignOut,
						children: "Sign out"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Link, {
						className: "btn btn-ghost",
						to: "/login",
						children: "Log in"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						className: "btn btn-primary",
						to: "/signup",
						children: "Sign up"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_s(Header, "zw0184todNkJyls2uUB98Fe/MaI=", false, function() {
	return [useNavigate];
});
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Header.tsx?t=1786627141744";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/components/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/components/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/components/Header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQzNDLFNBQVMsTUFBTSxtQkFBbUI7QUFDbEMsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsZUFBZSxTQUFTLFNBQVM7O0NBQy9CLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUN0RCxNQUFNLFdBQVcsWUFBWTtDQUU3QixnQkFBZ0I7RUFDZCxJQUFJLFVBQVU7RUFDYixDQUFDLFlBQVk7R0FDWixJQUFJO0lBQ0YsTUFBTSxFQUFFLFNBQVMsTUFBTSxTQUFTLEtBQUssUUFBUTtJQUM3QyxJQUFJLFNBQVMsU0FBUyxLQUFLLE1BQU0sU0FBUyxJQUFJO0dBQ2hELFNBQVMsR0FBRyxDQUVaO0VBQ0YsRUFBQyxDQUFFO0VBRUgsTUFBTSxFQUFFLGlCQUFpQixTQUFTLEtBQUssbUJBQW1CLFFBQVEsWUFBWTtHQUM1RSxTQUFTLFNBQVMsTUFBTSxTQUFTLElBQUk7RUFDdkMsQ0FBQztFQUVELGFBQWE7R0FDWCxVQUFVO0dBQ1YsSUFBSSxnQkFBZ0IsT0FBTyxhQUFhLGdCQUFnQixZQUFZLGFBQWEsWUFBWTtFQUMvRjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBRUwsZUFBZSxnQkFBZ0I7RUFDN0IsTUFBTSxTQUFTLEtBQUssUUFBUTtFQUM1QixTQUFTLElBQUk7RUFDYixTQUFTLEdBQUc7Q0FDZDtDQUVBLE9BQ0Usd0JBQUMsVUFBRDtFQUFRLFdBQVU7RUFBYyxNQUFLO1lBQ25DLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxNQUFEO0tBQU0sSUFBRztLQUFJLFdBQVU7S0FBUSxjQUFXO2VBQWlCO0lBQWU7Ozs7O0lBQzFFLHdCQUFDLE9BQUQ7S0FBSyxjQUFXO0tBQWtCLFdBQVU7ZUFBNUMsQ0FDRSx3QkFBQyxLQUFEO01BQUcsTUFBSztNQUFZLFdBQVU7Z0JBQVc7S0FBVzs7OztlQUNwRCx3QkFBQyxLQUFEO01BQUcsTUFBSztNQUFRLFdBQVU7Z0JBQVc7S0FBTzs7OzthQUN6Qzs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixRQUNDLGdEQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFjO0tBQVk7Ozs7ZUFDMUMsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBZ0IsU0FBUztnQkFBZTtLQUFnQjs7OzthQUMxRTs7OztnQkFFRixnREFDRSx3QkFBQyxNQUFEO01BQU0sV0FBVTtNQUFnQixJQUFHO2dCQUFTO0tBQVk7Ozs7ZUFDeEQsd0JBQUMsTUFBRDtNQUFNLFdBQVU7TUFBa0IsSUFBRztnQkFBVTtLQUFhOzs7O2FBQzVEOzs7OztJQUVEOzs7OztHQUNGOzs7Ozs7Q0FDQzs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZWFkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBzdXBhYmFzZSB9IGZyb20gJy4uL2xpYi9zdXBhYmFzZUNsaWVudCdcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGVhZGVyKCkge1xuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbGV0IG1vdW50ZWQgPSB0cnVlXG4gICAgOyhhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpXG4gICAgICAgIGlmIChtb3VudGVkKSBzZXRFbWFpbChkYXRhLnVzZXI/LmVtYWlsID8/IG51bGwpXG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIGlnbm9yZVxuICAgICAgfVxuICAgIH0pKClcblxuICAgIGNvbnN0IHsgc3Vic2NyaXB0aW9uIH0gPSBzdXBhYmFzZS5hdXRoLm9uQXV0aFN0YXRlQ2hhbmdlKChfZXZlbnQsIHNlc3Npb24pID0+IHtcbiAgICAgIHNldEVtYWlsKHNlc3Npb24/LnVzZXI/LmVtYWlsID8/IG51bGwpXG4gICAgfSlcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBtb3VudGVkID0gZmFsc2VcbiAgICAgIGlmIChzdWJzY3JpcHRpb24gJiYgdHlwZW9mIHN1YnNjcmlwdGlvbi51bnN1YnNjcmliZSA9PT0gJ2Z1bmN0aW9uJykgc3Vic2NyaXB0aW9uLnVuc3Vic2NyaWJlKClcbiAgICB9XG4gIH0sIFtdKVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNpZ25PdXQoKSB7XG4gICAgYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduT3V0KClcbiAgICBzZXRFbWFpbChudWxsKVxuICAgIG5hdmlnYXRlKCcvJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJzaXRlLWhlYWRlclwiIHJvbGU9XCJiYW5uZXJcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0ZS1oZWFkZXItaW5uZXJcIj5cbiAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPVwiYnJhbmRcIiBhcmlhLWxhYmVsPVwiV2luZSBTaG9wIGhvbWVcIj5XaW5lIFNob3A8L0xpbms+XG4gICAgICAgIDxuYXYgYXJpYS1sYWJlbD1cIk1haW4gTmF2aWdhdGlvblwiIGNsYXNzTmFtZT1cIm1haW4tbmF2XCI+XG4gICAgICAgICAgPGEgaHJlZj1cIiNmZWF0dXJlc1wiIGNsYXNzTmFtZT1cIm5hdi1saW5rXCI+RmVhdHVyZXM8L2E+XG4gICAgICAgICAgPGEgaHJlZj1cIiNzaG9wXCIgY2xhc3NOYW1lPVwibmF2LWxpbmtcIj5TaG9wPC9hPlxuICAgICAgICA8L25hdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWFjdGlvbnNcIj5cbiAgICAgICAgICB7ZW1haWwgPyAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ1c2VyLWVtYWlsXCI+e2VtYWlsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLWdob3N0XCIgb25DbGljaz17aGFuZGxlU2lnbk91dH0+U2lnbiBvdXQ8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8TGluayBjbGFzc05hbWU9XCJidG4gYnRuLWdob3N0XCIgdG89XCIvbG9naW5cIj5Mb2cgaW48L0xpbms+XG4gICAgICAgICAgICAgIDxMaW5rIGNsYXNzTmFtZT1cImJ0biBidG4tcHJpbWFyeVwiIHRvPVwiL3NpZ251cFwiPlNpZ24gdXA8L0xpbms+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApXG59XG4iXX0=