import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Hero.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
import heroImg from "/src/assets/hero.png?import";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/components/Hero.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
export default function Hero({ title, subtitle, ctaLabel, ctaTarget }) {
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "hero-root",
		"aria-labelledby": "hero-title",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "hero-decor",
			"aria-hidden": "true",
			children: /* @__PURE__ */ _jsxDEV("img", {
				src: heroImg,
				alt: "decorative wine"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "hero-inner",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", {
					"data-testid": "hero-title",
					id: "hero-title",
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this),
				subtitle && /* @__PURE__ */ _jsxDEV("p", {
					className: "hero-sub",
					children: subtitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 22
				}, this),
				ctaLabel && /* @__PURE__ */ _jsxDEV("a", {
					"data-testid": "hero-cta",
					className: "hero-cta",
					href: ctaTarget || "#",
					"aria-label": ctaLabel,
					children: [ctaLabel, /* @__PURE__ */ _jsxDEV("span", {
						className: "arrow",
						"aria-hidden": true,
						children: "→"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_c = Hero;
var _c;
$RefreshReg$(_c, "Hero");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Hero.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/components/Hero.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/components/Hero.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/components/Hero.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sYUFBYTs7O0FBU3BCLGVBQWUsU0FBUyxLQUFLLEVBQUUsT0FBTyxVQUFVLFVBQVUsYUFBb0I7Q0FDNUUsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtFQUFZLG1CQUFnQjtZQUE5QyxDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO0dBQWEsZUFBWTthQUN0Qyx3QkFBQyxPQUFEO0lBQUssS0FBSztJQUFTLEtBQUk7R0FBbUI7Ozs7O0VBQ3ZDOzs7O1lBQ0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE1BQUQ7S0FBSSxlQUFZO0tBQWEsSUFBRztlQUFjO0lBQVU7Ozs7O0lBQ3ZELFlBQVksd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBWTtJQUFZOzs7OztJQUNqRCxZQUNDLHdCQUFDLEtBQUQ7S0FDRSxlQUFZO0tBQ1osV0FBVTtLQUNWLE1BQU0sYUFBYTtLQUNuQixjQUFZO2VBSmQsQ0FNRyxVQUNELHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQVE7Z0JBQVk7S0FBTzs7OzthQUMxQzs7Ozs7O0dBRUY7Ozs7O1VBQ0M7Ozs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhlcm8udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBoZXJvSW1nIGZyb20gJy4uL2Fzc2V0cy9oZXJvLnBuZydcblxudHlwZSBQcm9wcyA9IHtcbiAgdGl0bGU6IHN0cmluZ1xuICBzdWJ0aXRsZT86IHN0cmluZ1xuICBjdGFMYWJlbD86IHN0cmluZ1xuICBjdGFUYXJnZXQ/OiBzdHJpbmdcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSGVybyh7IHRpdGxlLCBzdWJ0aXRsZSwgY3RhTGFiZWwsIGN0YVRhcmdldCB9OiBQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiaGVyby1yb290XCIgYXJpYS1sYWJlbGxlZGJ5PVwiaGVyby10aXRsZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZXJvLWRlY29yXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+XG4gICAgICAgIDxpbWcgc3JjPXtoZXJvSW1nfSBhbHQ9XCJkZWNvcmF0aXZlIHdpbmVcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8taW5uZXJcIj5cbiAgICAgICAgPGgxIGRhdGEtdGVzdGlkPVwiaGVyby10aXRsZVwiIGlkPVwiaGVyby10aXRsZVwiPnt0aXRsZX08L2gxPlxuICAgICAgICB7c3VidGl0bGUgJiYgPHAgY2xhc3NOYW1lPVwiaGVyby1zdWJcIj57c3VidGl0bGV9PC9wPn1cbiAgICAgICAge2N0YUxhYmVsICYmIChcbiAgICAgICAgICA8YVxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJoZXJvLWN0YVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJoZXJvLWN0YVwiXG4gICAgICAgICAgICBocmVmPXtjdGFUYXJnZXQgfHwgJyMnfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD17Y3RhTGFiZWx9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2N0YUxhYmVsfVxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYXJyb3dcIiBhcmlhLWhpZGRlbj7ihpI8L3NwYW4+XG4gICAgICAgICAgPC9hPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gIClcbn1cbiJdfQ==