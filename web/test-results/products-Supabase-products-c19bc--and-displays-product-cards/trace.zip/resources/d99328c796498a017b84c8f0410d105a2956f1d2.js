import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LandingPage.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
import Hero from "/src/components/Hero.tsx";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/pages/LandingPage.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
const FeatureCards = React.lazy(_c = () => import("/src/components/FeatureCards.tsx"));
_c2 = FeatureCards;
const ProductGrid = React.lazy(_c3 = () => import("/src/components/ProductGrid.tsx"));
_c4 = ProductGrid;
import landing from "/src/mocks/landing.json?import";
export default function LandingPage() {
	const data = landing;
	return /* @__PURE__ */ _jsxDEV("main", { children: [
		/* @__PURE__ */ _jsxDEV(Hero, {
			title: data.hero_title,
			subtitle: data.hero_subtitle,
			ctaLabel: data.hero_cta_label,
			ctaTarget: data.cta_target
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			id: "shop-placeholder",
			children: /* @__PURE__ */ _jsxDEV("p", { children: "Featured products and shop preview will be here in later iterations." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 23,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			style: { marginTop: 24 },
			children: /* @__PURE__ */ _jsxDEV(React.Suspense, {
				fallback: /* @__PURE__ */ _jsxDEV("div", {
					"aria-hidden": true,
					children: "Loading features…"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 35
				}, this),
				children: /* @__PURE__ */ _jsxDEV(FeatureCards, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			style: { marginTop: 18 },
			children: /* @__PURE__ */ _jsxDEV(React.Suspense, {
				fallback: /* @__PURE__ */ _jsxDEV("div", {
					"aria-hidden": true,
					children: "Loading products…"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 35
				}, this),
				children: /* @__PURE__ */ _jsxDEV(ProductGrid, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
}
_c5 = LandingPage;
var _c, _c2, _c3, _c4, _c5;
$RefreshReg$(_c, "FeatureCards$React.lazy");
$RefreshReg$(_c2, "FeatureCards");
$RefreshReg$(_c3, "ProductGrid$React.lazy");
$RefreshReg$(_c4, "ProductGrid");
$RefreshReg$(_c5, "LandingPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/LandingPage.tsx?t=1786626172235";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/pages/LandingPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/pages/LandingPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/pages/LandingPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sVUFBVTs7O0FBQ2pCLE1BQU0sZUFBZSxNQUFNLGdCQUFXLE9BQU8sNkJBQTZCOztBQUMxRSxNQUFNLGNBQWMsTUFBTSxpQkFBVyxPQUFPLDRCQUE0Qjs7QUFDeEUsT0FBTyxhQUFhO0FBRXBCLGVBQWUsU0FBUyxjQUFjO0NBQ3BDLE1BQU0sT0FBTztDQUNiLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLHdCQUFDLE1BQUQ7R0FDRSxPQUFPLEtBQUs7R0FDWixVQUFVLEtBQUs7R0FDZixVQUFVLEtBQUs7R0FDZixXQUFXLEtBQUs7RUFDakI7Ozs7O0VBTUQsd0JBQUMsV0FBRDtHQUFTLElBQUc7YUFDVix3QkFBQyxLQUFELFlBQUcsdUVBQXVFOzs7OztFQUNuRTs7Ozs7RUFFVCx3QkFBQyxPQUFEO0dBQUssT0FBTyxFQUFFLFdBQVcsR0FBRzthQUUxQix3QkFBQyxNQUFNLFVBQVA7SUFBZ0IsVUFBVSx3QkFBQyxPQUFEO0tBQUs7ZUFBWTtJQUFzQjs7Ozs7Y0FDL0Qsd0JBQUMsY0FBRCxDQUFlOzs7OztHQUNEOzs7OztFQUNiOzs7OztFQUdMLHdCQUFDLE9BQUQ7R0FBSyxPQUFPLEVBQUUsV0FBVyxHQUFHO2FBQzFCLHdCQUFDLE1BQU0sVUFBUDtJQUFnQixVQUFVLHdCQUFDLE9BQUQ7S0FBSztlQUFZO0lBQXNCOzs7OztjQUMvRCx3QkFBQyxhQUFELENBQWM7Ozs7O0dBQ0E7Ozs7O0VBQ2I7Ozs7O0NBQ0Q7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTGFuZGluZ1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBIZXJvIGZyb20gJy4uL2NvbXBvbmVudHMvSGVybydcbmNvbnN0IEZlYXR1cmVDYXJkcyA9IFJlYWN0LmxhenkoKCkgPT4gaW1wb3J0KCcuLi9jb21wb25lbnRzL0ZlYXR1cmVDYXJkcycpKVxuY29uc3QgUHJvZHVjdEdyaWQgPSBSZWFjdC5sYXp5KCgpID0+IGltcG9ydCgnLi4vY29tcG9uZW50cy9Qcm9kdWN0R3JpZCcpKVxuaW1wb3J0IGxhbmRpbmcgZnJvbSAnLi4vbW9ja3MvbGFuZGluZy5qc29uJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYW5kaW5nUGFnZSgpIHtcbiAgY29uc3QgZGF0YSA9IGxhbmRpbmcgYXMgeyBoZXJvX3RpdGxlOiBzdHJpbmc7IGhlcm9fc3VidGl0bGU/OiBzdHJpbmc7IGhlcm9fY3RhX2xhYmVsPzogc3RyaW5nOyBjdGFfdGFyZ2V0Pzogc3RyaW5nIH1cbiAgcmV0dXJuIChcbiAgICA8bWFpbj5cbiAgICAgIDxIZXJvXG4gICAgICAgIHRpdGxlPXtkYXRhLmhlcm9fdGl0bGV9XG4gICAgICAgIHN1YnRpdGxlPXtkYXRhLmhlcm9fc3VidGl0bGV9XG4gICAgICAgIGN0YUxhYmVsPXtkYXRhLmhlcm9fY3RhX2xhYmVsfVxuICAgICAgICBjdGFUYXJnZXQ9e2RhdGEuY3RhX3RhcmdldH1cbiAgICAgIC8+XG4gICAgICB7LyogPG5hdiBhcmlhLWxhYmVsPVwicHJpbWFyeS1hY3Rpb25zXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAxNiB9fT5cbiAgICAgICAgPGEgaHJlZj1cIi9sb2dpblwiIHN0eWxlPXt7IG1hcmdpblJpZ2h0OiAxMiB9fT5Mb2cgaW48L2E+XG4gICAgICAgIDxhIGhyZWY9XCIvc2lnbnVwXCI+U2lnbiB1cDwvYT5cbiAgICAgICAgPGEgaHJlZj1cIi9wcm9kdWN0c1wiIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDI0IH19PlZpZXcgcHJvZHVjdHM8L2E+XG4gICAgICA8L25hdj4gKi99XG4gICAgICA8c2VjdGlvbiBpZD1cInNob3AtcGxhY2Vob2xkZXJcIj5cbiAgICAgICAgPHA+RmVhdHVyZWQgcHJvZHVjdHMgYW5kIHNob3AgcHJldmlldyB3aWxsIGJlIGhlcmUgaW4gbGF0ZXIgaXRlcmF0aW9ucy48L3A+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgICB7LyogRmVhdHVyZSBjYXJkcyAvIHRlc3RpbW9uaWFscyAqL31cbiAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiAyNCB9fT5cbiAgICAgICAgeyAvKiBMYXp5LWxvYWQgdGhlIGZlYXR1cmUgY2FyZHMgY29tcG9uZW50IHRvIGtlZXAgaW5pdGlhbCBidW5kbGUgc21hbGwgKi8gfVxuICAgICAgICA8UmVhY3QuU3VzcGVuc2UgZmFsbGJhY2s9ezxkaXYgYXJpYS1oaWRkZW4+TG9hZGluZyBmZWF0dXJlc+KApjwvZGl2Pn0+XG4gICAgICAgICAgPEZlYXR1cmVDYXJkcyAvPlxuICAgICAgICA8L1JlYWN0LlN1c3BlbnNlPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNb2NrIHByb2R1Y3RzICovfVxuICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5Ub3A6IDE4IH19PlxuICAgICAgICA8UmVhY3QuU3VzcGVuc2UgZmFsbGJhY2s9ezxkaXYgYXJpYS1oaWRkZW4+TG9hZGluZyBwcm9kdWN0c+KApjwvZGl2Pn0+XG4gICAgICAgICAgPFByb2R1Y3RHcmlkIC8+XG4gICAgICAgIDwvUmVhY3QuU3VzcGVuc2U+XG4gICAgICA8L2Rpdj5cbiAgICA8L21haW4+XG4gIClcbn1cbiJdfQ==