import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuthPage.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
import AuthForm from "/src/components/AuthForm.tsx?t=1786626349323";
import { supabase } from "/src/lib/supabaseClient.ts";
import { useNavigate, Link } from "/node_modules/.vite/deps/react-router-dom.js?v=b02da74d";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/pages/AuthPage.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
var _s = $RefreshSig$();
export default function AuthPage({ initialMode }) {
	_s();
	const navigate = useNavigate();
	async function handleSignup(email, password) {
		const { data, error } = await supabase.auth.signUp({
			email,
			password
		});
		if (error) throw error;
		// Supabase configured to not require email verification per spec
		navigate("/products");
	}
	async function handleLogin(email, password) {
		const { data, error } = await supabase.auth.signInWithPassword({
			email,
			password
		});
		if (error) throw error;
		navigate("/products");
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "auth-page-root",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "auth-hero",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "auth-hero-inner",
				children: [/* @__PURE__ */ _jsxDEV("h1", { children: initialMode === "signup" ? "Create your account" : "Welcome back" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "auth-sub",
					children: "Fast sign in to access product list and personalized features."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "auth-card",
			children: [initialMode === "signup" ? /* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Sign up" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV(AuthForm, {
				mode: "signup",
				onSubmit: handleSignup
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 11
			}, this) : initialMode === "login" ? /* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Log in" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV(AuthForm, {
				mode: "login",
				onSubmit: handleLogin
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Sign up" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV(AuthForm, {
				mode: "signup",
				onSubmit: handleSignup
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 15
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Log in" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV(AuthForm, {
				mode: "login",
				onSubmit: handleLogin
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 15
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "auth-switch",
				children: initialMode === "signup" ? /* @__PURE__ */ _jsxDEV("p", { children: ["Already have an account? ", /* @__PURE__ */ _jsxDEV(Link, {
					to: "/login",
					children: "Log in"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 41
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 13
				}, this) : initialMode === "login" ? /* @__PURE__ */ _jsxDEV("p", { children: ["Don't have an account? ", /* @__PURE__ */ _jsxDEV(Link, {
					to: "/signup",
					children: "Sign up"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 39
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("p", { children: [
					"Don't have an account? ",
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/signup",
						children: "Sign up"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 38
					}, this),
					" · Already have an account? ",
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/login",
						children: "Log in"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 99
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
}
_s(AuthPage, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
	return [useNavigate];
});
_c = AuthPage;
var _c;
$RefreshReg$(_c, "AuthPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/AuthPage.tsx?t=1786626475007";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/pages/AuthPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/pages/AuthPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/pages/AuthPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sY0FBYztBQUNyQixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGFBQWEsWUFBWTs7OztBQU1sQyxlQUFlLFNBQVMsU0FBUyxFQUFFLGVBQXNCOztDQUN2RCxNQUFNLFdBQVcsWUFBWTtDQUU3QixlQUFlLGFBQWEsT0FBZSxVQUFrQjtFQUMzRCxNQUFNLEVBQUUsTUFBTSxVQUFVLE1BQU0sU0FBUyxLQUFLLE9BQU87R0FBRTtHQUFPO0VBQVMsQ0FBQztFQUN0RSxJQUFJLE9BQU8sTUFBTTs7RUFFakIsU0FBUyxXQUFXO0NBQ3RCO0NBRUEsZUFBZSxZQUFZLE9BQWUsVUFBa0I7RUFDMUQsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLFNBQVMsS0FBSyxtQkFBbUI7R0FBRTtHQUFPO0VBQVMsQ0FBQztFQUNsRixJQUFJLE9BQU8sTUFBTTtFQUNqQixTQUFTLFdBQVc7Q0FDdEI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUssZ0JBQWdCLFdBQVcsd0JBQXdCLGVBQW1COzs7O2NBQzNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVc7SUFBaUU7Ozs7WUFDdEY7Ozs7OztFQUNGOzs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNHLGdCQUFnQixXQUNmLHdCQUFDLFdBQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksVUFBVzs7OzthQUNmLHdCQUFDLFVBQUQ7SUFBVSxNQUFLO0lBQVMsVUFBVTtHQUFlOzs7O1dBQzFDOzs7O2NBQ1AsZ0JBQWdCLFVBQ2xCLHdCQUFDLFdBQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksU0FBVTs7OzthQUNkLHdCQUFDLFVBQUQ7SUFBVSxNQUFLO0lBQVEsVUFBVTtHQUFjOzs7O1dBQ3hDOzs7O2NBRVQsZ0RBQ0Usd0JBQUMsV0FBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSSxVQUFXOzs7O2FBQ2Ysd0JBQUMsVUFBRDtJQUFVLE1BQUs7SUFBUyxVQUFVO0dBQWU7Ozs7V0FDMUM7Ozs7YUFDVCx3QkFBQyxXQUFELGFBQ0Usd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7YUFDZCx3QkFBQyxVQUFEO0lBQVUsTUFBSztJQUFRLFVBQVU7R0FBYzs7OztXQUN4Qzs7OztXQUNUOzs7O2FBR0osd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixnQkFBZ0IsV0FDZix3QkFBQyxLQUFELGFBQUcsNkJBQXlCLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO2VBQVM7SUFBWTs7OztZQUFJOzs7O2VBQzVELGdCQUFnQixVQUNsQix3QkFBQyxLQUFELGFBQUcsMkJBQXVCLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO2VBQVU7SUFBYTs7OztZQUFJOzs7O2VBRTlELHdCQUFDLEtBQUQ7S0FBRztLQUNzQix3QkFBQyxNQUFEO01BQU0sSUFBRztnQkFBVTtLQUFhOzs7OztLQUFDO0tBQTRCLHdCQUFDLE1BQUQ7TUFBTSxJQUFHO2dCQUFTO0tBQVk7Ozs7O0lBQ2pIOzs7OztHQUVGOzs7O1dBQ0Y7Ozs7O1VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF1dGhQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgQXV0aEZvcm0gZnJvbSAnLi4vY29tcG9uZW50cy9BdXRoRm9ybSdcbmltcG9ydCB7IHN1cGFiYXNlIH0gZnJvbSAnLi4vbGliL3N1cGFiYXNlQ2xpZW50J1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUsIExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuXG50eXBlIFByb3BzID0ge1xuICBpbml0aWFsTW9kZT86ICdsb2dpbicgfCAnc2lnbnVwJ1xufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBdXRoUGFnZSh7IGluaXRpYWxNb2RlIH06IFByb3BzKSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNpZ251cChlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKSB7XG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5zaWduVXAoeyBlbWFpbCwgcGFzc3dvcmQgfSlcbiAgICBpZiAoZXJyb3IpIHRocm93IGVycm9yXG4gICAgLy8gU3VwYWJhc2UgY29uZmlndXJlZCB0byBub3QgcmVxdWlyZSBlbWFpbCB2ZXJpZmljYXRpb24gcGVyIHNwZWNcbiAgICBuYXZpZ2F0ZSgnL3Byb2R1Y3RzJylcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZUxvZ2luKGVtYWlsOiBzdHJpbmcsIHBhc3N3b3JkOiBzdHJpbmcpIHtcbiAgICBjb25zdCB7IGRhdGEsIGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLnNpZ25JbldpdGhQYXNzd29yZCh7IGVtYWlsLCBwYXNzd29yZCB9KVxuICAgIGlmIChlcnJvcikgdGhyb3cgZXJyb3JcbiAgICBuYXZpZ2F0ZSgnL3Byb2R1Y3RzJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLXBhZ2Utcm9vdFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWhlcm9cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWhlcm8taW5uZXJcIj5cbiAgICAgICAgICA8aDE+e2luaXRpYWxNb2RlID09PSAnc2lnbnVwJyA/ICdDcmVhdGUgeW91ciBhY2NvdW50JyA6ICdXZWxjb21lIGJhY2snfTwvaDE+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXV0aC1zdWJcIj5GYXN0IHNpZ24gaW4gdG8gYWNjZXNzIHByb2R1Y3QgbGlzdCBhbmQgcGVyc29uYWxpemVkIGZlYXR1cmVzLjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWNhcmRcIj5cbiAgICAgICAge2luaXRpYWxNb2RlID09PSAnc2lnbnVwJyA/IChcbiAgICAgICAgICA8c2VjdGlvbj5cbiAgICAgICAgICAgIDxoMj5TaWduIHVwPC9oMj5cbiAgICAgICAgICAgIDxBdXRoRm9ybSBtb2RlPVwic2lnbnVwXCIgb25TdWJtaXQ9e2hhbmRsZVNpZ251cH0gLz5cbiAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICkgOiBpbml0aWFsTW9kZSA9PT0gJ2xvZ2luJyA/IChcbiAgICAgICAgICA8c2VjdGlvbj5cbiAgICAgICAgICAgIDxoMj5Mb2cgaW48L2gyPlxuICAgICAgICAgICAgPEF1dGhGb3JtIG1vZGU9XCJsb2dpblwiIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0gLz5cbiAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxzZWN0aW9uPlxuICAgICAgICAgICAgICA8aDI+U2lnbiB1cDwvaDI+XG4gICAgICAgICAgICAgIDxBdXRoRm9ybSBtb2RlPVwic2lnbnVwXCIgb25TdWJtaXQ9e2hhbmRsZVNpZ251cH0gLz5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgIDxzZWN0aW9uPlxuICAgICAgICAgICAgICA8aDI+TG9nIGluPC9oMj5cbiAgICAgICAgICAgICAgPEF1dGhGb3JtIG1vZGU9XCJsb2dpblwiIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0gLz5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF1dGgtc3dpdGNoXCI+XG4gICAgICAgICAge2luaXRpYWxNb2RlID09PSAnc2lnbnVwJyA/IChcbiAgICAgICAgICAgIDxwPkFscmVhZHkgaGF2ZSBhbiBhY2NvdW50PyA8TGluayB0bz1cIi9sb2dpblwiPkxvZyBpbjwvTGluaz48L3A+XG4gICAgICAgICAgKSA6IGluaXRpYWxNb2RlID09PSAnbG9naW4nID8gKFxuICAgICAgICAgICAgPHA+RG9uJ3QgaGF2ZSBhbiBhY2NvdW50PyA8TGluayB0bz1cIi9zaWdudXBcIj5TaWduIHVwPC9MaW5rPjwvcD5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIERvbid0IGhhdmUgYW4gYWNjb3VudD8gPExpbmsgdG89XCIvc2lnbnVwXCI+U2lnbiB1cDwvTGluaz4gwrcgQWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IDxMaW5rIHRvPVwiL2xvZ2luXCI+TG9nIGluPC9MaW5rPlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==