import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/components/Footer.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
export default function Footer() {
	const year = new Date().getFullYear();
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "site-footer",
		role: "contentinfo",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "site-footer-inner",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-left",
				children: /* @__PURE__ */ _jsxDEV("p", { children: [
					"© ",
					year,
					" Wine Shop. All rights reserved."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 9,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "footer-right",
				children: [
					/* @__PURE__ */ _jsxDEV("a", {
						href: "/terms",
						children: "Terms"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("a", {
						href: "/privacy",
						children: "Privacy"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("a", {
						href: "/contact",
						children: "Contact"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 14,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Footer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/components/Footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/components/Footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/components/Footer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFFbEIsZUFBZSxTQUFTLFNBQVM7Q0FDL0IsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtDQUNwQyxPQUNFLHdCQUFDLFVBQUQ7RUFBUSxXQUFVO0VBQWMsTUFBSztZQUNuQyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxLQUFEO0tBQUc7S0FBUTtLQUFLO0lBQW1DOzs7OztHQUNoRDs7OzthQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxLQUFEO01BQUcsTUFBSztnQkFBUztLQUFROzs7OztLQUN6Qix3QkFBQyxLQUFEO01BQUcsTUFBSztnQkFBVztLQUFVOzs7OztLQUM3Qix3QkFBQyxLQUFEO01BQUcsTUFBSztnQkFBVztLQUFVOzs7OztJQUMxQjs7Ozs7V0FDRjs7Ozs7O0NBQ0M7Ozs7O0FBRVoiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRm9vdGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvb3RlcigpIHtcbiAgY29uc3QgeWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKVxuICByZXR1cm4gKFxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwic2l0ZS1mb290ZXJcIiByb2xlPVwiY29udGVudGluZm9cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2l0ZS1mb290ZXItaW5uZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb290ZXItbGVmdFwiPlxuICAgICAgICAgIDxwPiZjb3B5OyB7eWVhcn0gV2luZSBTaG9wLiBBbGwgcmlnaHRzIHJlc2VydmVkLjwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLXJpZ2h0XCI+XG4gICAgICAgICAgPGEgaHJlZj1cIi90ZXJtc1wiPlRlcm1zPC9hPlxuICAgICAgICAgIDxhIGhyZWY9XCIvcHJpdmFjeVwiPlByaXZhY3k8L2E+XG4gICAgICAgICAgPGEgaHJlZj1cIi9jb250YWN0XCI+Q29udGFjdDwvYT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Zvb3Rlcj5cbiAgKVxufVxuIl19