import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/products/ProductCard.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
import "/src/components/products/productCard.css?t=1786631564877";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/components/products/ProductCard.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
function deterministicSeed(id) {
	let h = 0;
	for (let i = 0; i < id.length; i++) {
		h = h * 31 + id.charCodeAt(i) >>> 0;
	}
	return h;
}
export default function ProductCard({ product }) {
	const price = (product.price_cents ?? 0) / 100;
	const formatted = new Intl.NumberFormat(undefined, {
		style: "currency",
		currency: product.currency ?? "USD"
	}).format(price);
	// deterministic values derived from id so visuals stay stable across renders
	const seed = deterministicSeed(product.id);
	const rating = seed % 5 + 1;
	const thumbSrc = `https://picsum.photos/seed/${encodeURIComponent(product.id)}/600/400`;
	const inStock = (product.stock ?? 0) > 0;
	return /* @__PURE__ */ _jsxDEV("article", {
		className: "product-card",
		role: "article",
		"aria-labelledby": `product-${product.id}`,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "product-thumb",
			children: [/* @__PURE__ */ _jsxDEV("img", {
				src: thumbSrc,
				alt: `Thumbnail of ${product.name}`,
				loading: "lazy"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: `badge ${inStock ? "in" : "out"}`,
				children: inStock ? "IN STOCK" : "OUT OF STOCK"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "product-body",
			children: [
				/* @__PURE__ */ _jsxDEV("h3", {
					id: `product-${product.id}`,
					className: "product-name",
					children: product.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "product-desc",
					children: product.description ? product.description.length > 140 ? product.description.slice(0, 137) + "..." : product.description : "No description"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "product-row",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "product-price",
						children: formatted
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "product-stock",
						children: inStock ? `${product.stock} available` : "0 available"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						"aria-hidden": true,
						className: "product-rating",
						children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ _jsxDEV("span", {
							style: {
								color: i < rating ? "#f59e0b" : "#e6e6e6",
								fontSize: 14
							},
							children: "★"
						}, i, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "product-actions",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "actions-right",
						children: /* @__PURE__ */ _jsxDEV("button", {
							className: "btn-primary",
							disabled: !inStock,
							"aria-disabled": !inStock,
							children: "Buy"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
}
_c = ProductCard;
var _c;
$RefreshReg$(_c, "ProductCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/products/ProductCard.tsx?t=1786631703051";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/components/products/ProductCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/components/products/ProductCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/components/products/ProductCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLE9BQU87OztBQU1QLFNBQVMsa0JBQWtCLElBQVk7Q0FDckMsSUFBSSxJQUFJO0NBQ1IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsUUFBUSxLQUFLO0VBQ2xDLElBQUssSUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDLE1BQU87Q0FDdEM7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxlQUFlLFNBQVMsWUFBWSxFQUFFLFdBQWtCO0NBQ3RELE1BQU0sU0FBUyxRQUFRLGVBQWUsS0FBSztDQUMzQyxNQUFNLFlBQVksSUFBSSxLQUFLLGFBQWEsV0FBVztFQUFFLE9BQU87RUFBWSxVQUFVLFFBQVEsWUFBWTtDQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sS0FBSzs7Q0FHM0gsTUFBTSxPQUFPLGtCQUFrQixRQUFRLEVBQUU7Q0FDekMsTUFBTSxTQUFVLE9BQU8sSUFBSztDQUM1QixNQUFNLFdBQVcsOEJBQThCLG1CQUFtQixRQUFRLEVBQUUsRUFBRTtDQUM5RSxNQUFNLFdBQVcsUUFBUSxTQUFTLEtBQUs7Q0FFdkMsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtFQUFlLE1BQUs7RUFBVSxtQkFBaUIsV0FBVyxRQUFRO1lBQXJGLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxLQUFLO0lBQVUsS0FBSyxnQkFBZ0IsUUFBUTtJQUFRLFNBQVE7R0FBUTs7OzthQUN6RSx3QkFBQyxRQUFEO0lBQU0sV0FBVyxTQUFTLFVBQVUsT0FBTztjQUFVLFVBQVUsYUFBYTtHQUFxQjs7OztXQUM5Rjs7Ozs7WUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsTUFBRDtLQUFJLElBQUksV0FBVyxRQUFRO0tBQU0sV0FBVTtlQUFnQixRQUFRO0lBQVM7Ozs7O0lBQzVFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdCLFFBQVEsY0FBZSxRQUFRLFlBQVksU0FBUyxNQUFNLFFBQVEsWUFBWSxNQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsUUFBUSxjQUFlO0lBQW9COzs7OztJQUU5Syx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFpQjtLQUFlOzs7O2VBQy9DLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFpQixVQUFVLEdBQUcsUUFBUSxNQUFNLGNBQWM7S0FBbUI7Ozs7YUFDekY7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUs7TUFBWSxXQUFVO2dCQUN4QixNQUFNLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ2pDLHdCQUFDLFFBQUQ7T0FBYyxPQUFPO1FBQUUsT0FBTyxJQUFJLFNBQVMsWUFBWTtRQUFXLFVBQVU7T0FBRztpQkFBRztNQUFPLEdBQTlFOzs7O2FBQThFLENBQzFGO0tBQ0U7Ozs7YUFDRjs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFjLFVBQVUsQ0FBQztPQUFTLGlCQUFlLENBQUM7aUJBQVM7TUFBVzs7Ozs7S0FDckY7Ozs7O0lBQ0Y7Ozs7O0dBQ0Y7Ozs7O1VBQ0U7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb2R1Y3RDYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgdHlwZSB7IFByb2R1Y3QgfSBmcm9tICcuLi8uLi9saWIvcHJvZHVjdHNDbGllbnQnXG5pbXBvcnQgJy4vcHJvZHVjdENhcmQuY3NzJ1xuXG50eXBlIFByb3BzID0ge1xuICBwcm9kdWN0OiBQcm9kdWN0XG59XG5cbmZ1bmN0aW9uIGRldGVybWluaXN0aWNTZWVkKGlkOiBzdHJpbmcpIHtcbiAgbGV0IGggPSAwXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgaWQubGVuZ3RoOyBpKyspIHtcbiAgICBoID0gKGggKiAzMSArIGlkLmNoYXJDb2RlQXQoaSkpID4+PiAwXG4gIH1cbiAgcmV0dXJuIGhcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZHVjdENhcmQoeyBwcm9kdWN0IH06IFByb3BzKSB7XG4gIGNvbnN0IHByaWNlID0gKHByb2R1Y3QucHJpY2VfY2VudHMgPz8gMCkgLyAxMDBcbiAgY29uc3QgZm9ybWF0dGVkID0gbmV3IEludGwuTnVtYmVyRm9ybWF0KHVuZGVmaW5lZCwgeyBzdHlsZTogJ2N1cnJlbmN5JywgY3VycmVuY3k6IHByb2R1Y3QuY3VycmVuY3kgPz8gJ1VTRCcgfSkuZm9ybWF0KHByaWNlKVxuXG4gIC8vIGRldGVybWluaXN0aWMgdmFsdWVzIGRlcml2ZWQgZnJvbSBpZCBzbyB2aXN1YWxzIHN0YXkgc3RhYmxlIGFjcm9zcyByZW5kZXJzXG4gIGNvbnN0IHNlZWQgPSBkZXRlcm1pbmlzdGljU2VlZChwcm9kdWN0LmlkKVxuICBjb25zdCByYXRpbmcgPSAoc2VlZCAlIDUpICsgMSAvLyAxLTUgc3RhcnNcbiAgY29uc3QgdGh1bWJTcmMgPSBgaHR0cHM6Ly9waWNzdW0ucGhvdG9zL3NlZWQvJHtlbmNvZGVVUklDb21wb25lbnQocHJvZHVjdC5pZCl9LzYwMC80MDBgXG4gIGNvbnN0IGluU3RvY2sgPSAocHJvZHVjdC5zdG9jayA/PyAwKSA+IDBcblxuICByZXR1cm4gKFxuICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInByb2R1Y3QtY2FyZFwiIHJvbGU9XCJhcnRpY2xlXCIgYXJpYS1sYWJlbGxlZGJ5PXtgcHJvZHVjdC0ke3Byb2R1Y3QuaWR9YH0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtdGh1bWJcIj5cbiAgICAgICAgPGltZyBzcmM9e3RodW1iU3JjfSBhbHQ9e2BUaHVtYm5haWwgb2YgJHtwcm9kdWN0Lm5hbWV9YH0gbG9hZGluZz1cImxhenlcIiAvPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BiYWRnZSAke2luU3RvY2sgPyAnaW4nIDogJ291dCd9YH0+e2luU3RvY2sgPyAnSU4gU1RPQ0snIDogJ09VVCBPRiBTVE9DSyd9PC9zcGFuPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1ib2R5XCI+XG4gICAgICAgIDxoMyBpZD17YHByb2R1Y3QtJHtwcm9kdWN0LmlkfWB9IGNsYXNzTmFtZT1cInByb2R1Y3QtbmFtZVwiPntwcm9kdWN0Lm5hbWV9PC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicHJvZHVjdC1kZXNjXCI+e3Byb2R1Y3QuZGVzY3JpcHRpb24gPyAocHJvZHVjdC5kZXNjcmlwdGlvbi5sZW5ndGggPiAxNDAgPyBwcm9kdWN0LmRlc2NyaXB0aW9uLnNsaWNlKDAsIDEzNykgKyAnLi4uJyA6IHByb2R1Y3QuZGVzY3JpcHRpb24pIDogJ05vIGRlc2NyaXB0aW9uJ308L3A+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LXJvd1wiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2R1Y3QtcHJpY2VcIj57Zm9ybWF0dGVkfTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwcm9kdWN0LXN0b2NrXCI+e2luU3RvY2sgPyBgJHtwcm9kdWN0LnN0b2NrfSBhdmFpbGFibGVgIDogJzAgYXZhaWxhYmxlJ308L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgYXJpYS1oaWRkZW4gY2xhc3NOYW1lPVwicHJvZHVjdC1yYXRpbmdcIj5cbiAgICAgICAgICAgIHtBcnJheS5mcm9tKHsgbGVuZ3RoOiA1IH0pLm1hcCgoXywgaSkgPT4gKFxuICAgICAgICAgICAgICA8c3BhbiBrZXk9e2l9IHN0eWxlPXt7IGNvbG9yOiBpIDwgcmF0aW5nID8gJyNmNTllMGInIDogJyNlNmU2ZTYnLCBmb250U2l6ZTogMTQgfX0+4piFPC9zcGFuPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZHVjdC1hY3Rpb25zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhY3Rpb25zLXJpZ2h0XCI+XG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0bi1wcmltYXJ5XCIgZGlzYWJsZWQ9eyFpblN0b2NrfSBhcmlhLWRpc2FibGVkPXshaW5TdG9ja30+QnV5PC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9hcnRpY2xlPlxuICApXG59XG4iXX0=