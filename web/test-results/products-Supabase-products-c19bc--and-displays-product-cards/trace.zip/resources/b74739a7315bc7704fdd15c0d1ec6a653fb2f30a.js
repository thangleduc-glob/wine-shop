import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AuthForm.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=93d23258";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/components/AuthForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
var _s = $RefreshSig$();
export default function AuthForm({ mode, onSubmit }) {
	_s();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [error, setError] = useState(null);
	function validate() {
		if (!email.includes("@")) {
			setError("Please enter a valid email address.");
			return false;
		}
		if (password.length < 8) {
			setError("Password must be at least 8 characters.");
			return false;
		}
		if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
			setError("Password must include at least one letter and one number.");
			return false;
		}
		return true;
	}
	async function handleSubmit(e) {
		e.preventDefault();
		setError(null);
		if (!validate()) return;
		try {
			await onSubmit(email, password);
		} catch (err) {
			setError(err?.message || "An unexpected error occurred");
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit,
		"aria-label": `${mode}-form`,
		className: "auth-form",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "field",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "email",
					children: "Email"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: "email",
					type: "email",
					value: email,
					onChange: (e) => setEmail(e.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "field",
				children: [/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "password",
					children: "Password"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("input", {
					id: "password",
					type: "password",
					value: password,
					onChange: (e) => setPassword(e.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				role: "alert",
				className: "form-error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: "auth-submit",
				type: "submit",
				children: mode === "signup" ? "Create account" : "Sign in"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
}
_s(AuthForm, "YBsdA/4WTamN5bxFmqgxzZF5USE=");
_c = AuthForm;
var _c;
$RefreshReg$(_c, "AuthForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AuthForm.tsx?t=1786626349323";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/components/AuthForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/components/AuthForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/components/AuthForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjs7OztBQU9oQyxlQUFlLFNBQVMsU0FBUyxFQUFFLE1BQU0sWUFBbUI7O0NBQzFELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUV0RCxTQUFTLFdBQVc7RUFDbEIsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEdBQUc7R0FDeEIsU0FBUyxxQ0FBcUM7R0FDOUMsT0FBTztFQUNUO0VBQ0EsSUFBSSxTQUFTLFNBQVMsR0FBRztHQUN2QixTQUFTLHlDQUF5QztHQUNsRCxPQUFPO0VBQ1Q7RUFDQSxJQUFJLENBQUMsV0FBVyxLQUFLLFFBQVEsS0FBSyxDQUFDLFFBQVEsS0FBSyxRQUFRLEdBQUc7R0FDekQsU0FBUywyREFBMkQ7R0FDcEUsT0FBTztFQUNUO0VBQ0EsT0FBTztDQUNUO0NBRUEsZUFBZSxhQUFhLEdBQW9CO0VBQzlDLEVBQUUsZUFBZTtFQUNqQixTQUFTLElBQUk7RUFDYixJQUFJLENBQUMsU0FBUyxHQUFHO0VBQ2pCLElBQUk7R0FDRixNQUFNLFNBQVMsT0FBTyxRQUFRO0VBQ2hDLFNBQVMsS0FBVTtHQUNqQixTQUFTLEtBQUssV0FBVyw4QkFBOEI7RUFDekQ7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUFNLFVBQVU7RUFBYyxjQUFZLEdBQUcsS0FBSztFQUFRLFdBQVU7WUFBcEU7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsU0FBRDtLQUFPLFNBQVE7ZUFBUTtJQUFZOzs7O2NBQ25DLHdCQUFDLFNBQUQ7S0FBTyxJQUFHO0tBQVEsTUFBSztLQUFRLE9BQU87S0FBTyxXQUFVLE1BQUssU0FBUyxFQUFFLE9BQU8sS0FBSztLQUFHO0lBQVU7Ozs7WUFDN0Y7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxTQUFEO0tBQU8sU0FBUTtlQUFXO0lBQWU7Ozs7Y0FDekMsd0JBQUMsU0FBRDtLQUFPLElBQUc7S0FBVyxNQUFLO0tBQVcsT0FBTztLQUFVLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxLQUFLO0tBQUc7SUFBVTs7OztZQUN6Rzs7Ozs7O0dBQ0osU0FBUyx3QkFBQyxPQUFEO0lBQUssTUFBSztJQUFRLFdBQVU7Y0FBYztHQUFXOzs7OztHQUMvRCx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUFjLE1BQUs7Y0FBVSxTQUFTLFdBQVcsbUJBQW1CO0dBQWtCOzs7OztFQUNwRzs7Ozs7O0FBRVYiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXV0aEZvcm0udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG50eXBlIFByb3BzID0ge1xuICBtb2RlOiAnbG9naW4nIHwgJ3NpZ251cCdcbiAgb25TdWJtaXQ6IChlbWFpbDogc3RyaW5nLCBwYXNzd29yZDogc3RyaW5nKSA9PiBQcm9taXNlPHZvaWQ+XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEF1dGhGb3JtKHsgbW9kZSwgb25TdWJtaXQgfTogUHJvcHMpIHtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKVxuXG4gIGZ1bmN0aW9uIHZhbGlkYXRlKCkge1xuICAgIGlmICghZW1haWwuaW5jbHVkZXMoJ0AnKSkge1xuICAgICAgc2V0RXJyb3IoJ1BsZWFzZSBlbnRlciBhIHZhbGlkIGVtYWlsIGFkZHJlc3MuJylcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICBpZiAocGFzc3dvcmQubGVuZ3RoIDwgOCkge1xuICAgICAgc2V0RXJyb3IoJ1Bhc3N3b3JkIG11c3QgYmUgYXQgbGVhc3QgOCBjaGFyYWN0ZXJzLicpXG4gICAgICByZXR1cm4gZmFsc2VcbiAgICB9XG4gICAgaWYgKCEvW0EtWmEtel0vLnRlc3QocGFzc3dvcmQpIHx8ICEvWzAtOV0vLnRlc3QocGFzc3dvcmQpKSB7XG4gICAgICBzZXRFcnJvcignUGFzc3dvcmQgbXVzdCBpbmNsdWRlIGF0IGxlYXN0IG9uZSBsZXR0ZXIgYW5kIG9uZSBudW1iZXIuJylcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0KGU6IFJlYWN0LkZvcm1FdmVudCkge1xuICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgIHNldEVycm9yKG51bGwpXG4gICAgaWYgKCF2YWxpZGF0ZSgpKSByZXR1cm5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgb25TdWJtaXQoZW1haWwsIHBhc3N3b3JkKVxuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBzZXRFcnJvcihlcnI/Lm1lc3NhZ2UgfHwgJ0FuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQnKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gYXJpYS1sYWJlbD17YCR7bW9kZX0tZm9ybWB9IGNsYXNzTmFtZT1cImF1dGgtZm9ybVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaWVsZFwiPlxuICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICA8aW5wdXQgaWQ9XCJlbWFpbFwiIHR5cGU9XCJlbWFpbFwiIHZhbHVlPXtlbWFpbH0gb25DaGFuZ2U9e2UgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfSByZXF1aXJlZCAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpZWxkXCI+XG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5QYXNzd29yZDwvbGFiZWw+XG4gICAgICAgIDxpbnB1dCBpZD1cInBhc3N3b3JkXCIgdHlwZT1cInBhc3N3b3JkXCIgdmFsdWU9e3Bhc3N3b3JkfSBvbkNoYW5nZT17ZSA9PiBzZXRQYXNzd29yZChlLnRhcmdldC52YWx1ZSl9IHJlcXVpcmVkIC8+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtlcnJvciAmJiA8ZGl2IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImZvcm0tZXJyb3JcIj57ZXJyb3J9PC9kaXY+fVxuICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLXN1Ym1pdFwiIHR5cGU9XCJzdWJtaXRcIj57bW9kZSA9PT0gJ3NpZ251cCcgPyAnQ3JlYXRlIGFjY291bnQnIDogJ1NpZ24gaW4nfTwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbiAgKVxufVxuIl19