import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import "/src/App.css?t=1786627148598";
import LandingPage from "/src/pages/LandingPage.tsx?t=1786626172235";
import Header from "/src/components/Header.tsx?t=1786627141744";
import Footer from "/src/components/Footer.tsx";
import AuthPage from "/src/pages/AuthPage.tsx?t=1786626475007";
import ProductsPage from "/src/pages/ProductsPage.tsx";
import SupabaseProductsPage from "/src/pages/SupabaseProductsPage.tsx?t=1786631703051";
import { Routes, Route, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=b02da74d";
var _jsxFileName = "/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=93d23258";
var _s = $RefreshSig$();
function App() {
	_s();
	const location = useLocation();
	const hideChrome = location.pathname === "/login" || location.pathname === "/signup";
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "app-root",
		children: [
			!hideChrome && /* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 23
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "app-main",
				children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/",
						element: /* @__PURE__ */ _jsxDEV(LandingPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 36
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/login",
						element: /* @__PURE__ */ _jsxDEV(AuthPage, { initialMode: "login" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 41
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/signup",
						element: /* @__PURE__ */ _jsxDEV(AuthPage, { initialMode: "signup" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 42
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(Route, {
						path: "/products",
						element: /* @__PURE__ */ _jsxDEV(SupabaseProductsPage, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 44
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 7
			}, this),
			!hideChrome && /* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 23
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_s(App, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
	return [useLocation];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx?t=1786631703051";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/thang.leduc/Documents/wine-shop/web/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUVQLE9BQU8saUJBQWlCO0FBQ3hCLE9BQU8sWUFBWTtBQUNuQixPQUFPLFlBQVk7QUFDbkIsT0FBTyxjQUFjO0FBQ3JCLE9BQU8sa0JBQWtCO0FBQ3pCLE9BQU8sMEJBQTBCO0FBRWpDLFNBQVMsUUFBUSxPQUFPLG1CQUFtQjs7OztBQUUzQyxTQUFTLE1BQU07O0NBQ2IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxhQUFhLFNBQVMsYUFBYSxZQUFZLFNBQVMsYUFBYTtDQUUzRSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRyxDQUFDLGNBQWMsd0JBQUMsUUFBRCxDQUFTOzs7OztHQUV6Qix3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUNkLHdCQUFDLFFBQUQ7S0FDRSx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFJLFNBQVMsd0JBQUMsYUFBRCxDQUFjOzs7OztLQUFJOzs7OztLQUMzQyx3QkFBQyxPQUFEO01BQU8sTUFBSztNQUFTLFNBQVMsd0JBQUMsVUFBRCxFQUFVLGFBQVksUUFBUzs7Ozs7S0FBSTs7Ozs7S0FDakUsd0JBQUMsT0FBRDtNQUFPLE1BQUs7TUFBVSxTQUFTLHdCQUFDLFVBQUQsRUFBVSxhQUFZLFNBQVU7Ozs7O0tBQUk7Ozs7O0tBQ25FLHdCQUFDLE9BQUQ7TUFBTyxNQUFLO01BQVksU0FBUyx3QkFBQyxzQkFBRCxDQUF1Qjs7Ozs7S0FBSTs7Ozs7SUFFdEQ7Ozs7O0dBQ0o7Ozs7O0dBRUwsQ0FBQyxjQUFjLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7RUFDdEI7Ozs7OztBQUVUOzs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4vQXBwLmNzcydcblxuaW1wb3J0IExhbmRpbmdQYWdlIGZyb20gJy4vcGFnZXMvTGFuZGluZ1BhZ2UnXG5pbXBvcnQgSGVhZGVyIGZyb20gJy4vY29tcG9uZW50cy9IZWFkZXInXG5pbXBvcnQgRm9vdGVyIGZyb20gJy4vY29tcG9uZW50cy9Gb290ZXInXG5pbXBvcnQgQXV0aFBhZ2UgZnJvbSAnLi9wYWdlcy9BdXRoUGFnZSdcbmltcG9ydCBQcm9kdWN0c1BhZ2UgZnJvbSAnLi9wYWdlcy9Qcm9kdWN0c1BhZ2UnXG5pbXBvcnQgU3VwYWJhc2VQcm9kdWN0c1BhZ2UgZnJvbSAnLi9wYWdlcy9TdXBhYmFzZVByb2R1Y3RzUGFnZSdcblxuaW1wb3J0IHsgUm91dGVzLCBSb3V0ZSwgdXNlTG9jYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxuICBjb25zdCBoaWRlQ2hyb21lID0gbG9jYXRpb24ucGF0aG5hbWUgPT09ICcvbG9naW4nIHx8IGxvY2F0aW9uLnBhdGhuYW1lID09PSAnL3NpZ251cCdcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYXBwLXJvb3RcIj5cbiAgICAgIHshaGlkZUNocm9tZSAmJiA8SGVhZGVyIC8+fVxuXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJhcHAtbWFpblwiPlxuICAgICAgICA8Um91dGVzPlxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiL1wiIGVsZW1lbnQ9ezxMYW5kaW5nUGFnZSAvPn0gLz5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIi9sb2dpblwiIGVsZW1lbnQ9ezxBdXRoUGFnZSBpbml0aWFsTW9kZT1cImxvZ2luXCIgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvc2lnbnVwXCIgZWxlbWVudD17PEF1dGhQYWdlIGluaXRpYWxNb2RlPVwic2lnbnVwXCIgLz59IC8+XG4gICAgICAgICAgPFJvdXRlIHBhdGg9XCIvcHJvZHVjdHNcIiBlbGVtZW50PXs8U3VwYWJhc2VQcm9kdWN0c1BhZ2UgLz59IC8+XG4gICAgICAgICAgey8qIDxSb3V0ZSBwYXRoPVwiL3N1cGFiYXNlXCIgZWxlbWVudD17PFN1cGFiYXNlUHJvZHVjdHNQYWdlIC8+fSAvPiAqL31cbiAgICAgICAgPC9Sb3V0ZXM+XG4gICAgICA8L21haW4+XG5cbiAgICAgIHshaGlkZUNocm9tZSAmJiA8Rm9vdGVyIC8+fVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcFxuIl19